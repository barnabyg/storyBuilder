# An Occurrence at Owl Creek Bridge

Plan owl-creek-bridge-tier-l; schema 1; tier L

Character peyton-farquhar: Peyton Farquhar

Character mrs-farquhar: Mrs. Farquhar

Character federal-scout: Gray-clad soldier / Federal scout

Character captain: Captain

Character sergeant: Sergeant

Character lieutenant: Lieutenant

Character two-privates: Two private soldiers

Character sentinels: Two sentinels

## sc-01-bridge-hanging: The Hanging at Owl Creek Bridge

A bound civilian stands on a plank over Owl Creek, surrounded by Federal soldiers and a watching company; the execution apparatus is described and the sergeant steps aside at the captain's nod.

Present: peyton-farquhar, captain, sergeant, two-privates, sentinels, lieutenant

Beat b-01-01: A man stands on a railroad bridge in northern Alabama, hands bound, rope around his neck.

Beat b-01-02: Two privates, a sergeant, and an armed captain oversee the execution; sentinels block the bridge ends.

Beat b-01-03: Across the stream a stockade, cannon, and a company of infantry at parade rest watch in silence.

Beat b-01-04: The condemned man is described as a civilian of about thirty-five, gentlemanly in appearance.

Beat b-01-05: The privates withdraw their planks; the sergeant takes the captain's place holding the plank, ready to step aside.

Beat b-01-06: The condemned man looks at the water and driftwood, then hears an inexplicable metallic ticking that proves to be his watch.

Beat b-01-07: He imagines freeing his hands, dodging bullets, and escaping home; the captain nods and the sergeant steps aside.

Fact kf-farquhar-sabotage: Farquhar attempted to interfere with the Owl Creek bridge, likely by burning the driftwood, and was caught.; initial holders: peyton-farquhar

Fact kf-scout-identity: The gray-clad soldier who visited the plantation was a Federal scout.; initial holders: federal-scout

Fact kf-hanging-order: A Federal order mandates summary hanging for any civilian interfering with the railroad, bridges, tunnels, or trains.; initial holders: federal-scout, peyton-farquhar

Fact kf-farquhar-death: Peyton Farquhar is dead, hanged at Owl Creek bridge with a broken neck.; initial holders: (none)

Causal cl-01: earlier cause sc-01-bridge-hanging → effect sc-03-fall-and-escape

Setup setup-watch-ticking at sc-01-bridge-hanging: The metallic ticking the condemned man hears is revealed to be his watch, marking subjective time dilation.

Setup setup-rope-and-noose at sc-01-bridge-hanging: The rope and noose around his neck are described in detail before the fall.

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":4700}

Beat b-01-01 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":260}

Beat b-01-02 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":260,"end":1000}

Beat b-01-03 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":1000,"end":1900}

Beat b-01-04 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":1900,"end":2400}

Beat b-01-05 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":2400,"end":3200}

Beat b-01-06 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3200,"end":4200}

Beat b-01-07 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4200,"end":4700}

## sc-02-farquhar-backstory: Farquhar's Background and the Scout

Peyton Farquhar is introduced as a devoted Southern planter; a gray-clad soldier visits, describes the Owl Creek bridge and the hanging order, and hints at the dry driftwood; he is revealed as a Federal scout.

Present: peyton-farquhar, mrs-farquhar, federal-scout

Beat b-02-01: Farquhar is a well-to-do Alabama planter, slave owner, secessionist, prevented from soldiering but eager to serve the South.

Beat b-02-02: A gray-clad soldier asks for water; Mrs. Farquhar serves him while her husband questions him about the front.

Beat b-02-03: The soldier reports the Yanks at Owl Creek bridge, the stockade, and the order to hang any civilian interfering with the railroad.

Beat b-02-04: Farquhar asks about distance and forces; the soldier notes the dry driftwood at the bridge pier would burn like tinder.

Beat b-02-05: The soldier departs and later repasses northward; the narrator reveals he was a Federal scout.

Setup setup-driftwood at sc-02-farquhar-backstory: The scout mentions dry driftwood lodged at the bridge pier that would burn like tinder, prompting Farquhar's attempted sabotage.

Setup setup-hanging-order at sc-02-farquhar-backstory: The posted order declares any civilian interfering with the railroad will be summarily hanged.

Reveal rl-01: fact kf-scout-identity at sc-02-farquhar-backstory; holders: peyton-farquhar, mrs-farquhar (acquired at scene start)

Knowledge use ku-01: peyton-farquhar uses fact kf-hanging-order at sc-02-farquhar-backstory

Knowledge use ku-02: federal-scout uses fact kf-scout-identity at sc-02-farquhar-backstory

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4700,"end":7700}

Beat b-02-01 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4700,"end":5600}

Beat b-02-02 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":5600,"end":6100}

Beat b-02-03 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":6100,"end":6700}

Beat b-02-04 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":6700,"end":7400}

Beat b-02-05 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7400,"end":7700}

## sc-03-fall-and-escape: The Fall, the River, and the Escape

Farquhar falls, loses consciousness, revives in the water, frees his hands, surfaces, and evades rifle and cannon fire while swimming downstream.

Present: peyton-farquhar, captain, sergeant, two-privates, sentinels, lieutenant

Beat b-03-01: Falling, he loses consciousness and experiences pain, suffocation, and a pendulum-like luminous sensation.

Beat b-03-02: He realizes the rope broke and he is in the stream; he sinks, then rises, and his hands free themselves and tear away the noose.

Beat b-03-03: He surfaces with preternaturally keen senses, seeing leaves, insects, dewdrops, and hearing the water and gnats.

Beat b-03-04: He sees the bridge and soldiers in silhouette; shots are fired and miss him.

Beat b-03-05: The lieutenant orders a volley; Farquhar dives, sees flattened bullets, and surfaces farther downstream.

Beat b-03-06: The cannon fires; he reasons about dodging and the gun's smoke, then is caught in a vortex and flung onto the southern bank.

Beat b-03-07: He rejoices in the sand and forest as if enchanted, until grapeshot rouses him and he plunges into the woods.

Causal cl-01: earlier cause sc-01-bridge-hanging → effect sc-03-fall-and-escape

Causal cl-02: earlier cause sc-03-fall-and-escape → effect sc-04-night-journey

Payoff pl-01: setup setup-driftwood → payoff at sc-03-fall-and-escape

Payoff pl-02: setup setup-hanging-order → payoff at sc-03-fall-and-escape

Payoff pl-03: setup setup-watch-ticking → payoff at sc-03-fall-and-escape

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":14200}

Beat b-03-01 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":8600}

Beat b-03-02 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8600,"end":9600}

Beat b-03-03 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":9600,"end":10400}

Beat b-03-04 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":10400,"end":11200}

Beat b-03-05 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":11200,"end":12200}

Beat b-03-06 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":12200,"end":13400}

Beat b-03-07 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":13400,"end":14200}

## sc-04-night-journey: The Night Journey Through the Forest

Farquhar travels all day and into the night, footsore and famished, following an uncanny road with strange stars and whispers, his body showing signs of hanging.

Present: peyton-farquhar

Beat b-04-01: He travels all day through an interminable forest, laying his course by the sun.

Beat b-04-02: By nightfall he is fatigued and famished; thoughts of wife and children urge him on.

Beat b-04-03: He finds a wide, straight, untraveled road; strange constellations and whispers in an unknown tongue unsettle him.

Beat b-04-04: His neck is swollen and black, his eyes congested, his tongue swollen with thirst; he can no longer feel the road.

Causal cl-02: earlier cause sc-03-fall-and-escape → effect sc-04-night-journey

Causal cl-03: earlier cause sc-04-night-journey → effect sc-05-homecoming-and-death

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":14200,"end":16400}

Beat b-04-01 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":14200,"end":14700}

Beat b-04-02 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":14700,"end":15100}

Beat b-04-03 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":15100,"end":15900}

Beat b-04-04 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":15900,"end":16400}

## sc-05-homecoming-and-death: The Homecoming and the Reveal

Farquhar reaches his home and sees his wife; as he moves to embrace her, a blow and white light end everything, and the narrator reveals he is dead, hanging beneath the bridge.

Present: peyton-farquhar, mrs-farquhar

Beat b-05-01: He seems to wake from delirium at the gate of his home in morning sunshine.

Beat b-05-02: His wife steps down from the veranda to meet him with joy and grace.

Beat b-05-03: As he springs to embrace her, he feels a stunning blow, a blinding white light, and then darkness and silence.

Beat b-05-04: The narrator states Peyton Farquhar is dead, his body with a broken neck swinging beneath the Owl Creek bridge timbers.

Causal cl-03: earlier cause sc-04-night-journey → effect sc-05-homecoming-and-death

Payoff pl-04: setup setup-rope-and-noose → payoff at sc-05-homecoming-and-death

Reveal rl-02: fact kf-farquhar-death at sc-05-homecoming-and-death; holders: peyton-farquhar (acquired at scene start)

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16400,"end":17700}

Beat b-05-01 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16400,"end":16800}

Beat b-05-02 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16800,"end":17200}

Beat b-05-03 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":17200,"end":17500}

Beat b-05-04 evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":17500,"end":17700}

State st-01 [sc-01-bridge-hanging] peyton-farquhar canon alive: known: alive; confidence 0.95; alternatives: (none recorded) → known: dying; confidence 0.9; alternatives: alive; dead

Relationship rel-01 [sc-02-farquhar-backstory] peyton-farquhar, federal-scout trust: unknown: (no asserted value); confidence unrecorded; alternatives: (none recorded) → known: deceived; confidence 0.9; alternatives: trusting; suspicious

State st-02 [sc-03-fall-and-escape] peyton-farquhar belief escape_status: known: captured; confidence 0.9; alternatives: (none recorded) → ambiguous: escaping; confidence 0.6; alternatives: escaping; hallucinating; dead

State st-03 [sc-05-homecoming-and-death] peyton-farquhar canon alive: ambiguous: escaping; confidence 0.6; alternatives: escaping; hallucinating → known: dead; confidence 0.98; alternatives: (none recorded)

Relationship rel-02 [sc-05-homecoming-and-death] peyton-farquhar, mrs-farquhar reunion: known: separated; confidence 0.9; alternatives: (none recorded) → ambiguous: illusory_reunion; confidence 0.7; alternatives: actual_reunion; dying_vision

Constraint c-01: satisfied; required_ending peyton-farquhar canon alive; expected 'dead'; The story's final sentence fixes Farquhar's death by hanging.

Constraint c-02: human assessment required; literary peyton-farquhar belief escape_status; expected 'ambiguous'; The escape sequence is presented as real-time experience but retrospectively revealed as occurring in the moment of death.

Constraint c-03: unresolved: explicit facts missing; locked story canon setting; expected 'Owl Creek bridge, northern Alabama, American Civil War'; The setting is fixed by the opening and the scout's report.

arcs arc-farquhar [sc-01-bridge-hanging, sc-02-farquhar-backstory, sc-03-fall-and-escape, sc-04-night-journey, sc-05-homecoming-and-death] interpretation: A condemned Southern planter's apparent escape is revealed as a dying fantasy; his devotion to cause and family ends in hanging.; status=known; confidence=0.9

Alternative readings: A straightforward escape narrative interrupted by a twist ending; A meditation on the subjectivity of time at death

Evidence arc-farquhar: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":17700}

Arc character: peyton-farquhar

agency trajectory arc-farquhar: 1 → 2 → 3 → 2 → 0; shape=oscillating; scenes=sc-01-bridge-hanging → sc-02-farquhar-backstory → sc-03-fall-and-escape → sc-04-night-journey → sc-05-homecoming-and-death; ordinal 0-4

reader_affect ra-01 [sc-01-bridge-hanging, sc-03-fall-and-escape, sc-05-homecoming-and-death] interpretation: Suspense and hope during the escape give way to shock and retrospective rereading at the final revelation.; status=known; confidence=0.85

Alternative readings: Detached irony throughout; Tragic inevitability from the start

Evidence ra-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":17700}

mood trajectory ra-01: 2 → 4 → 1; shape=peak; scenes=sc-01-bridge-hanging → sc-03-fall-and-escape → sc-05-homecoming-and-death; ordinal 0-4

tension t-01 [sc-01-bridge-hanging, sc-03-fall-and-escape, sc-05-homecoming-and-death] interpretation: Tension between the apparent reality of the escape and the accumulating signs (watch ticking, strange perceptions, uncanny road) that it is a dying hallucination.; status=ambiguous; confidence=0.8

Alternative readings: Tension between military duty and personal sympathy; Tension between Farquhar's romantic self-image and his actual fate

Evidence t-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3200,"end":17700}

tension trajectory t-01: 2 → 3 → 4 → 4; shape=rising; scenes=sc-01-bridge-hanging → sc-03-fall-and-escape → sc-04-night-journey → sc-05-homecoming-and-death; ordinal 0-4

themes th-01 [sc-01-bridge-hanging, sc-02-farquhar-backstory, sc-05-homecoming-and-death] interpretation: The gap between romantic ideals of honor and the brutal mechanics of war and death.; status=known; confidence=0.85

Alternative readings: The subjectivity of time and consciousness at death; The deception of appearances

Evidence th-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":1900,"end":17700}

themes th-02 [sc-03-fall-and-escape, sc-04-night-journey, sc-05-homecoming-and-death] interpretation: The mind's capacity to construct a coherent escape narrative in the instant of death.; status=ambiguous; confidence=0.75

Alternative readings: A literal supernatural escape; A straightforward adventure story

Evidence th-02: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":17700}

motifs m-01-water [sc-01-bridge-hanging, sc-03-fall-and-escape] observation: Water and the river as both threat and imagined escape route.; status=known; confidence=0.9

Evidence m-01-water: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":13400}

motifs m-02-time [sc-01-bridge-hanging, sc-03-fall-and-escape, sc-04-night-journey] observation: Time dilation and distorted perception, from the watch ticking to the uncanny night journey.; status=known; confidence=0.85

Evidence m-02-time: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3200,"end":16400}

motifs m-03-rope [sc-01-bridge-hanging, sc-05-homecoming-and-death] observation: The rope and noose as instruments of death, echoed in the final broken-neck image.; status=known; confidence=0.9

Evidence m-03-rope: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":100,"end":17700}

motifs m-04-water-escape [sc-03-fall-and-escape] observation: The river as a medium of apparent deliverance after the fall.; status=known; confidence=0.85

Evidence m-04-water-escape: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":14200}

motifs m-05-time-night [sc-04-night-journey] observation: Uncanny night and strange constellations as markers of distorted subjective time.; status=known; confidence=0.8

Evidence m-05-time-night: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":15100,"end":16400}

motifs m-06-rope-final [sc-05-homecoming-and-death] observation: The final image of the broken neck beneath the bridge timbers returns to the hanging apparatus.; status=known; confidence=0.9

Evidence m-06-rope-final: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":17500,"end":17700}

discourse d-01 [sc-01-bridge-hanging, sc-02-farquhar-backstory, sc-03-fall-and-escape, sc-04-night-journey, sc-05-homecoming-and-death] observation: The narrative is non-chronological: it opens at the execution, flashes back to Farquhar's background and the scout's visit, then returns to the fall and follows the escape until the final revelation.; status=known; confidence=0.95

Evidence d-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":17700}

discourse d-02 [sc-03-fall-and-escape, sc-04-night-journey, sc-05-homecoming-and-death] interpretation: The escape sequence is narrated with realistic detail but retrospectively framed as subjective experience occurring in the moment of death.; status=ambiguous; confidence=0.8

Alternative readings: The escape is literally real until the final sentence contradicts it; The escape is a dream or delirium

Evidence d-02: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7700,"end":17700}

subtext sub-01 [sc-02-farquhar-backstory] interpretation: Farquhar's eagerness to serve and his acceptance of 'all is fair in love and war' make him vulnerable to the scout's manipulation.; status=known; confidence=0.85

Alternative readings: Farquhar is a straightforward hero; The scout is a neutral informant

Evidence sub-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4700,"end":7700}

subtext sub-02 [sc-05-homecoming-and-death] interpretation: The homecoming scene's idealized brightness and the wife's 'ineffable joy' signal its status as wish-fulfillment rather than reality.; status=ambiguous; confidence=0.75

Alternative readings: A genuine reunion before death; A hallucination

Evidence sub-02: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16400,"end":17700}

Motif echo me-01: m-01-water → m-04-water-escape (transformation)

Evidence me-01: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":14200}

Motif echo me-02: m-02-time → m-05-time-night (repetition)

Evidence me-02: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3200,"end":16400}

Motif echo me-03: m-03-rope → m-06-rope-final (repetition)

Evidence me-03: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":100,"end":17700}

human constraint_human_assessment [c-02 character peyton-farquhar]: The escape sequence is presented as real-time experience but retrospectively revealed as occurring in the moment of death.

human constraint_fact_missing [c-03 character story]: setting: unresolved: explicit facts missing
