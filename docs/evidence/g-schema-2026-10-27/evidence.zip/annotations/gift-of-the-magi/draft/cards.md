# The Gift of the Magi

Plan gift-of-the-magi-plan; schema 1; tier L

Character della: Della (Mrs. James Dillingham Young)

Character jim: Jim (Mr. James Dillingham Young)

Character madame-sofronie: Mme. Sofronie

Character narrator: Narrator

## sc-01-pennies: One Dollar and Eighty-Seven Cents

Della counts her meager savings on Christmas Eve and despairs that she cannot buy Jim a present.

Present: della, narrator

Beat b-01-count: Della counts $1.87, sixty cents of it in pennies painfully saved.

Beat b-02-howll: She flops on the couch and howls; the narrator moralizes on sobs, sniffles, and smiles.

Fact fact-hair-sold: Della has cut off and sold her hair.; initial holders: della

Fact fact-chain-bought: Della bought a platinum fob chain for Jim's watch.; initial holders: della

Fact fact-watch-sold: Jim sold his gold watch to buy the combs.; initial holders: jim

Fact fact-combs-bought: Jim bought the tortoise-shell combs for Della.; initial holders: jim

Causal c-01: earlier cause sc-01-pennies → effect sc-03-window

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":537}

Beat b-01-count evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":341}

Beat b-02-howll evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":343,"end":537}

## sc-02-flat: The Furnished Flat

The narrator describes the shabby $8 flat, the dead letter-box and bell, and the Youngs' name card and reduced circumstances.

Present: della, jim, narrator

Beat b-03-flat: A furnished flat at $8 per week, barely describable, with a vestibule letter-box and dead bell.

Beat b-04-name: The card reads Mr. James Dillingham Young; the Dillingham was from a $30-a-week past, now shrunk to $20.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":539,"end":1128}

Beat b-03-flat evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":539,"end":790}

Beat b-04-name evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":792,"end":1128}

## sc-03-window: At the Window

Della looks out dully at a gray cat and gray backyard, reckoning she has only $1.87 for Jim's present after months of saving.

Present: della, narrator

Beat b-05-gray: Della powders her cheeks and looks out at a gray cat on a gray fence in a gray backyard.

Beat b-06-only: Tomorrow is Christmas and she has only $1.87; she wanted something fine and rare worthy of Jim.

Causal c-01: earlier cause sc-01-pennies → effect sc-03-window

Causal c-02: earlier cause sc-03-window → effect sc-04-pierglass

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1130,"end":1690}

Beat b-05-gray evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1130,"end":1300}

Beat b-06-only evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1301,"end":1690}

## sc-04-pierglass: Before the Pier Glass

Della stands before the pier glass, lets down her hair, and the narrator names the couple's two proud possessions: Jim's watch and Della's hair.

Present: della, jim, narrator

Beat b-07-glass: Della whirls to the pier glass, eyes shining, face pale, and lets down her hair.

Beat b-08-treasures: The two prized possessions: Jim's heirloom gold watch and Della's hair, compared to Sheba's jewels and Solomon's treasures.

Beat b-09-tear: Her hair falls like a cascade of brown waters; she does it up again and a tear or two splashes on the carpet.

Causal c-02: earlier cause sc-03-window → effect sc-04-pierglass

Causal c-03: earlier cause sc-04-pierglass → effect sc-05-sofronie

Setup setup-hair at sc-04-pierglass: Della's hair is established as one of the couple's two great treasures.

Setup setup-watch at sc-04-pierglass: Jim's heirloom gold watch is established as the other great treasure.

Setup setup-combs at sc-04-pierglass: Della's long-coveted tortoise-shell combs, later given by Jim.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1692,"end":2543}

Beat b-07-glass evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1692,"end":1919}

Beat b-08-treasures evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1921,"end":2320}

Beat b-09-tear evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2322,"end":2543}

## sc-05-sofronie: Mme. Sofronie's

Della goes out in her old brown jacket and hat to a hair-goods shop and sells her hair for twenty dollars.

Present: della, madame-sofronie

Beat b-10-out: Della puts on her old brown jacket and hat and flutters out to the street.

Beat b-11-shop: The sign reads Mme. Sofronie, Hair Goods of All Kinds; Della asks if she will buy her hair.

Beat b-12-sale: Madame offers twenty dollars; Della says give it to me quick.

Causal c-03: earlier cause sc-04-pierglass → effect sc-05-sofronie

Causal c-04: earlier cause sc-05-sofronie → effect sc-06-chain

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2545,"end":3010}

Beat b-10-out evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2545,"end":2698}

Beat b-11-shop evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2700,"end":2902}

Beat b-12-sale evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2904,"end":3010}

## sc-06-chain: The Platinum Fob Chain

Della searches the stores and buys a platinum fob chain for Jim's watch for twenty-one dollars, leaving eighty-seven cents.

Present: della, jim

Beat b-13-search: Two hours of ransacking the stores for Jim's present.

Beat b-14-found: She finds a platinum fob chain, simple and chaste, worthy of The Watch and like Jim himself.

Beat b-15-price: Twenty-one dollars for the chain; she hurries home with 87 cents; the chain replaces Jim's old leather strap.

Causal c-04: earlier cause sc-05-sofronie → effect sc-06-chain

Causal c-05: earlier cause sc-06-chain → effect sc-07-curls

Setup setup-chain at sc-06-chain: The platinum fob chain bought for Jim's watch.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3012,"end":3830}

Beat b-13-search evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3012,"end":3110}

Beat b-14-found evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3112,"end":3560}

Beat b-15-price evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3561,"end":3830}

## sc-07-curls: Repairing the Ravages

Della curls her cropped hair and worries how Jim will react.

Present: della, jim

Beat b-16-curl: She lights the gas, uses curling irons, and within forty minutes has tiny close-lying curls.

Beat b-17-worry: She fears Jim will say she looks like a Coney Island chorus girl, and asks what else she could do with $1.87.

Causal c-05: earlier cause sc-06-chain → effect sc-07-curls

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3832,"end":4270}

Beat b-16-curl evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3832,"end":4060}

Beat b-17-worry evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4062,"end":4270}

## sc-08-jim-arrives: Jim Comes Home

Coffee is made and chops are ready; Della waits with the chain, prays to still look pretty, and Jim enters staring with an unreadable expression.

Present: della, jim

Beat b-18-ready: At seven the coffee is made and the frying-pan is hot for chops; Della doubles the chain and waits by the door.

Beat b-19-prayer: She hears his step, turns white, and whispers, Please God, make him think I am still pretty.

Beat b-20-stare: Jim enters thin and serious, stops immovable, and stares at Della with an expression she cannot read.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4272,"end":5010}

Beat b-18-ready evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4272,"end":4470}

Beat b-19-prayer evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4471,"end":4660}

Beat b-20-stare evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4662,"end":5010}

## sc-09-explanation: Della Explains

Della explains she cut and sold her hair for his present; Jim slowly absorbs the fact and then embraces her.

Present: della, jim, narrator

Beat b-21-plea: Della pleads with Jim not to look that way, says her hair will grow, and asks him to say Merry Christmas.

Beat b-22-labor: Jim laboriously repeats that she cut off her hair and looks about the room curiously.

Beat b-23-love: Della says the hair is sold and gone for him, that nobody could count her love, and asks about the chops.

Beat b-24-embrace: Jim wakes from his trance and enfolds Della; the narrator digresses on wealth and promises later illumination.

Causal c-06: earlier cause sc-09-explanation → effect sc-10-combs

Reveal rev-hair: fact fact-hair-sold at sc-09-explanation; holders: jim (acquired at scene start)

Knowledge use ku-01: della uses fact fact-hair-sold at sc-09-explanation

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5012,"end":6160}

Beat b-21-plea evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5012,"end":5360}

Beat b-22-labor evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5362,"end":5560}

Beat b-23-love evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5562,"end":5880}

Beat b-24-embrace evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5882,"end":6160}

## sc-10-combs: The Combs

Jim gives Della the tortoise-shell combs she had long coveted; she weeps, then hugs them and says her hair grows fast.

Present: della, jim

Beat b-25-package: Jim throws a package on the table and says a haircut could not make him like his girl less.

Beat b-26-tears: Della tears open the package, screams with joy, then turns to hysterical tears and wails.

Beat b-27-combs: The combs are pure tortoise shell with jewelled rims, long worshipped in a Broadway window, now hers but for vanished hair.

Beat b-28-hug: She hugs the combs and says with dim eyes and a smile, My hair grows so fast, Jim!

Causal c-06: earlier cause sc-09-explanation → effect sc-10-combs

Causal c-07: earlier cause sc-10-combs → effect sc-11-reversal

Payoff pay-combs: setup setup-combs → payoff at sc-10-combs

Reveal rev-combs: fact fact-combs-bought at sc-10-combs; holders: della (acquired at scene start)

Knowledge use ku-04: jim uses fact fact-combs-bought at sc-10-combs

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6162,"end":7130}

Beat b-25-package evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6162,"end":6420}

Beat b-26-tears evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6422,"end":6600}

Beat b-27-combs evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6602,"end":6990}

Beat b-28-hug evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6992,"end":7130}

## sc-11-reversal: The Watch Is Sold

Della presents the chain and asks for Jim's watch; Jim smiles on the couch and reveals he sold the watch to buy the combs.

Present: della, jim

Beat b-29-present: Della leaps up and holds out the chain, urging Jim to give her his watch to see how it looks.

Beat b-30-reveal: Jim lies back smiling and says he sold the watch to buy her combs; suggests she put the chops on.

Causal c-07: earlier cause sc-10-combs → effect sc-11-reversal

Payoff pay-hair: setup setup-hair → payoff at sc-11-reversal

Payoff pay-watch: setup setup-watch → payoff at sc-11-reversal

Payoff pay-chain: setup setup-chain → payoff at sc-11-reversal

Reveal rev-chain: fact fact-chain-bought at sc-11-reversal; holders: jim (acquired at scene start)

Reveal rev-watch: fact fact-watch-sold at sc-11-reversal; holders: della (acquired at scene start)

Knowledge use ku-02: della uses fact fact-chain-bought at sc-11-reversal

Knowledge use ku-03: jim uses fact fact-watch-sold at sc-11-reversal

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7132,"end":7660}

Beat b-29-present evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7132,"end":7420}

Beat b-30-reveal evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7422,"end":7660}

## sc-12-magi: They Are the Magi

The narrator compares the couple to the magi and declares them wisest of all who give and receive gifts.

Present: narrator, della, jim

Beat b-31-magi: The magi were wise men who invented Christmas presents; the narrator calls the couple foolish children yet wisest of all givers.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7662,"end":8100}

Beat b-31-magi evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7662,"end":8100}

State st-01 [sc-01-pennies] della goal buy-jim-present: known: determined but under-resourced; confidence 0.9; alternatives: (none recorded) → known: despairing at $1.87; confidence 0.9; alternatives: (none recorded)

State st-02 [sc-04-pierglass] della belief hair-as-currency: known: hair is a treasure to keep; confidence 0.85; alternatives: (none recorded) → known: hair can be sold for Jim's gift; confidence 0.85; alternatives: (none recorded)

State st-03 [sc-05-sofronie] della canon hair-length: known: hair reaches below her knee; confidence 0.95; alternatives: (none recorded) → known: hair cut off and sold; confidence 0.95; alternatives: (none recorded)

Relationship rel-01 [sc-09-explanation] della, jim mutual-love: known: affectionate but anxious; confidence 0.8; alternatives: (none recorded) → known: affection confirmed through sacrifice; confidence 0.85; alternatives: (none recorded)

State st-04 [sc-11-reversal] jim canon watch-possession: known: owns heirloom gold watch; confidence 0.95; alternatives: (none recorded) → known: watch sold; confidence 0.95; alternatives: (none recorded)

Constraint con-01: unresolved: explicit facts missing; locked della canon hair-sold; expected 'true'; Della sells her hair; this cannot be undone within the story.

Constraint con-02: unresolved: explicit facts missing; locked jim canon watch-sold; expected 'true'; Jim has sold the watch before the final reveal.

Constraint con-03: unresolved: explicit facts missing; required_ending story canon magi-declaration; expected 'couple declared wisest of givers'; Story must end with the narrator's magi comparison.

Constraint con-04: human assessment required; literary story canon ironic-reversal; expected 'gifts rendered unusable by mutual sacrifice'; The O. Henry twist depends on both gifts being made useless by the other's sacrifice.

arcs arc-della [sc-01-pennies, sc-03-window, sc-04-pierglass, sc-05-sofronie, sc-06-chain, sc-07-curls, sc-09-explanation, sc-10-combs, sc-11-reversal] interpretation: Della moves from despair over money to sacrificial action and finally to tearful acceptance of a gift made useless by her own sacrifice.; status=known; confidence=0.85

Alternative readings: Della's arc reads as a lesson in the folly of vanity; Della's arc reads as a celebration of selfless love

Evidence arc-della: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":341}

Evidence arc-della: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2904,"end":3010}

Evidence arc-della: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6992,"end":7130}

Arc character: della

agency trajectory arc-della: 1 → 2 → 3 → 1 → 2; shape=oscillating; scenes=sc-01-pennies → sc-04-pierglass → sc-05-sofronie → sc-10-combs → sc-11-reversal; ordinal 0-4

arcs arc-jim [sc-08-jim-arrives, sc-09-explanation, sc-10-combs, sc-11-reversal] interpretation: Jim's arc is revealed late: his stunned silence conceals the sacrifice of his watch for combs.; status=known; confidence=0.8

Alternative readings: Jim's silence reads as disapproval of Della's haircut; Jim's silence reads as shock at her changed appearance

Evidence arc-jim: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4662,"end":5010}

Evidence arc-jim: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7422,"end":7660}

Arc character: jim

agency trajectory arc-jim: 2 → 3 → 4 → 3; shape=peak; scenes=sc-08-jim-arrives → sc-09-explanation → sc-10-combs → sc-11-reversal; ordinal 0-4

reader_affect ra-01 [sc-01-pennies, sc-03-window] interpretation: sympathy for Della's poverty and desperation; status=known; confidence=0.85

Evidence ra-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":341}

mood trajectory ra-01: 2 → 3 → 3; shape=rising; scenes=sc-01-pennies → sc-03-window → sc-04-pierglass; ordinal 0-4

reader_affect ra-02 [sc-10-combs, sc-11-reversal, sc-12-magi] interpretation: ironic tenderness and admiration at the mutual sacrifice; status=known; confidence=0.85

Alternative readings: amusement at the futility of the gifts; melancholy at the couple's poverty

Evidence ra-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7422,"end":7660}

Evidence ra-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7662,"end":8100}

mood trajectory ra-02: 2 → 4 → 4; shape=peak; scenes=sc-10-combs → sc-11-reversal → sc-12-magi; ordinal 0-4

tension t-01 [sc-01-pennies, sc-03-window, sc-04-pierglass, sc-05-sofronie] interpretation: Will Della find a way to buy Jim a worthy present with almost no money?; status=known; confidence=0.85

Evidence t-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1301,"end":1690}

tension trajectory t-01: 2 → 3 → 3 → 4; shape=rising; scenes=sc-01-pennies → sc-03-window → sc-04-pierglass → sc-05-sofronie; ordinal 0-4

tension t-02 [sc-08-jim-arrives, sc-09-explanation, sc-11-reversal] interpretation: What does Jim's unreadable expression mean, and how will the exchanged gifts resolve?; status=ambiguous; confidence=0.7

Alternative readings: Jim is angry about the haircut; Jim is concealing his own sacrifice

Evidence t-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4662,"end":5010}

tension trajectory t-02: 3 → 4 → 4; shape=peak; scenes=sc-08-jim-arrives → sc-09-explanation → sc-11-reversal; ordinal 0-4

themes th-01 [sc-12-magi] interpretation: True wisdom in giving lies in sacrificial love, not in the value of the gift.; status=known; confidence=0.85

Alternative readings: Material poverty makes genuine generosity more admirable; The magi comparison is ironic rather than celebratory

Evidence th-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7662,"end":8100}

themes th-02 [sc-04-pierglass, sc-11-reversal] interpretation: The couple's most prized possessions become the currency of their love.; status=known; confidence=0.8

Evidence th-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1921,"end":2320}

motifs mo-hair-long [sc-04-pierglass] observation: Della's long, beautiful hair as a symbol of beauty and sacrificial value; status=known; confidence=0.85

Evidence mo-hair-long: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2322,"end":2543}

motifs mo-hair-gone [sc-10-combs] observation: The vanished hair that makes the gifted combs useless; status=known; confidence=0.85

Evidence mo-hair-gone: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6602,"end":6990}

motifs mo-watch-kept [sc-04-pierglass] observation: Jim's gold watch as an heirloom and symbol of pride; status=known; confidence=0.85

Evidence mo-watch-kept: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1921,"end":2320}

motifs mo-watch-sold [sc-11-reversal] observation: The watch revealed as sold, making the gifted chain useless; status=known; confidence=0.85

Evidence mo-watch-sold: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7422,"end":7660}

motifs mo-money [sc-01-pennies, sc-03-window, sc-06-chain] observation: Precise sums of money mark the couple's poverty and sacrifice; status=known; confidence=0.9

Evidence mo-money: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":341}

discourse d-01 [sc-01-pennies, sc-02-flat] observation: The narrator addresses the reader directly and digresses with moral commentary.; status=known; confidence=0.9

Evidence d-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":343,"end":537}

discourse d-02 [sc-09-explanation] observation: The narrator withholds the content of Jim's package and promises later illumination.; status=known; confidence=0.85

Evidence d-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5882,"end":6160}

subtext sub-01 [sc-08-jim-arrives, sc-09-explanation] interpretation: Jim's unreadable stare may conceal his own sacrifice rather than anger at Della's haircut.; status=ambiguous; confidence=0.7

Alternative readings: Jim is genuinely shocked and disapproving; Jim is simply slow to process the change

Evidence sub-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4662,"end":5010}

subtext sub-02 [sc-12-magi] interpretation: The magi comparison may be sincere praise or gently ironic consolation for the useless gifts.; status=ambiguous; confidence=0.6

Alternative readings: Sincere celebration of sacrificial love; Ironic undercutting of the couple's foolishness

Evidence sub-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7662,"end":8100}

Motif echo me-01: mo-hair-long → mo-hair-gone (transformation)

Evidence me-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2322,"end":2543}

Evidence me-01: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6602,"end":6990}

Motif echo me-02: mo-watch-kept → mo-watch-sold (transformation)

Evidence me-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1921,"end":2320}

Evidence me-02: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7422,"end":7660}

human constraint_fact_missing [con-01 character della]: hair-sold: unresolved: explicit facts missing

human constraint_fact_missing [con-02 character jim]: watch-sold: unresolved: explicit facts missing

human constraint_fact_missing [con-03 character story]: magi-declaration: unresolved: explicit facts missing

human constraint_human_assessment [con-04 character story]: The O. Henry twist depends on both gifts being made useless by the other's sacrifice.
