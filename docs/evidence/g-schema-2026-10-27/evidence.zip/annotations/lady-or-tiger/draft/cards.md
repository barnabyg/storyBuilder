# The Lady, or the Tiger?

Plan plan-lady-or-tiger; schema 1; tier L

Character char-king: The Semi-Barbaric King

Character char-princess: The Princess

Character char-lover: The Young Courtier (the Princess's Lover)

Character char-lady: The Lady Behind the Door

Character char-narrator: The Narrator

## scene-01-king-and-arena: The King and His Arena of Poetic Justice

The narrator introduces the semi-barbaric king, his self-communing absolutism, and the arena he devised as an instrument of impartial chance in which crime is punished or virtue rewarded.

Present: char-king, char-narrator

Beat beat-01a: The king is described as semi-barbaric, of exuberant fancy and irresistible authority, who turns fancies into facts.

Beat beat-01b: The public arena is described as an agent of poetic justice where crime is punished or virtue rewarded by impartial and incorruptible chance.

Fact fact-secret-doors: Which of the two doors conceals the tiger and which conceals the lady.; initial holders: (none)

Fact fact-love-affair: The princess and the young courtier love each other.; initial holders: char-king, char-princess, char-lover

Fact fact-lady-identity: The identity of the lady selected as the reward.; initial holders: char-king

Causal causal-01: earlier cause scene-01-king-and-arena → effect scene-02-trial-procedure

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":44,"end":1100}

Beat beat-01a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":44,"end":520}

Beat beat-01b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":521,"end":1100}

## scene-02-trial-procedure: The Trial Procedure: Two Doors

The narrator describes the ritual of the arena: the accused walks to two identical doors; one releases a tiger as punishment, the other a lady as reward, followed by immediate marriage or mourning.

Present: char-king, char-narrator

Beat beat-02a: The accused steps into the arena and must open one of two identical doors with no guidance but chance.

Beat beat-02b: The tiger door brings a savage beast, iron bells, and mourning; the lady door brings immediate marriage, a priest, choristers, and celebration.

Causal causal-01: earlier cause scene-01-king-and-arena → effect scene-02-trial-procedure

Setup setup-doors at scene-02-trial-procedure: The two identical doors and their opposed outcomes establish the mechanism on which the climax depends.

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1101,"end":2600}

Beat beat-02a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1101,"end":1700}

Beat beat-02b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1701,"end":2600}

## scene-03-justice-and-popularity: The Fairness and Popularity of the Institution

The narrator asserts the perfect fairness and determinacy of the king's method and notes the institution's popularity, since the accused holds the whole matter in his own hands.

Present: char-king, char-narrator

Beat beat-03a: The narrator claims the tribunal is fair and determinate, with no escape from its judgments.

Beat beat-03b: The people enjoy the uncertainty of slaughter or wedding, and the thinking part cannot charge unfairness.

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":2601,"end":3600}

Beat beat-03a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":2601,"end":3200}

Beat beat-03b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3201,"end":3600}

## scene-04-princess-and-lover: The Princess and the Courtier

The king's daughter, fervent and imperious, loves a handsome but low-stationed courtier; when the king discovers the affair, the youth is imprisoned and a trial day is set.

Present: char-king, char-princess, char-lover, char-narrator

Beat beat-04a: The princess is described as blooming, fervent, and imperious, the apple of the king's eye.

Beat beat-04b: A young courtier of fine blood and low station loves the princess, and she loves him ardently.

Beat beat-04c: The king discovers the love affair, imprisons the youth, and appoints a day for his trial in the arena.

Causal causal-02: earlier cause scene-04-princess-and-lover → effect scene-05-preparations

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3601,"end":4700}

Beat beat-04a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3601,"end":3900}

Beat beat-04b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3901,"end":4300}

Beat beat-04c evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4301,"end":4700}

## scene-05-preparations: Preparations for the Trial

The kingdom searches for the fiercest tiger and the most suitable maiden; everyone knows the youth loved the princess, but the king will not let fact interfere with his tribunal.

Present: char-king, char-princess, char-lover, char-lady, char-narrator

Beat beat-05a: Tiger-cages are searched for the fiercest beast and maidens are surveyed for a fitting bride.

Beat beat-05b: The king refuses to let the known fact of the love affair interfere with the workings of the tribunal.

Causal causal-02: earlier cause scene-04-princess-and-lover → effect scene-05-preparations

Causal causal-03: earlier cause scene-05-preparations → effect scene-06-arena-assembly

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4701,"end":5500}

Beat beat-05a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4701,"end":5100}

Beat beat-05b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5101,"end":5500}

## scene-06-arena-assembly: The Appointed Day: The Arena Assembles

Crowds throng the arena; the king and court take their places opposite the twin doors; the signal is given and the princess's lover walks into the arena.

Present: char-king, char-princess, char-lover, char-narrator

Beat beat-06a: People gather from far and near, and the king and court sit opposite the fateful twin doors.

Beat beat-06b: The signal is given, the lover enters, and the crowd greets his appearance with admiration and anxiety.

Causal causal-03: earlier cause scene-05-preparations → effect scene-06-arena-assembly

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5501,"end":6100}

Beat beat-06a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5501,"end":5800}

Beat beat-06b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5801,"end":6100}

## scene-07-princess-secret: The Princess's Secret Knowledge

The princess, more powerful and forceful than any before interested in such a case, has discovered the secret of the doors: she knows which holds the tiger and which the lady, and she knows and hates the lady.

Present: char-princess, char-lover, char-lady, char-narrator

Beat beat-07a: The princess's fervid soul keeps her present; she has possessed herself of the secret of the doors through gold and will.

Beat beat-07b: She knows the lady's identity and hates her, suspecting glances and brief conversations with her lover.

Causal causal-04: earlier cause scene-07-princess-secret → effect scene-08-the-question-and-signal

Setup setup-secret at scene-07-princess-secret: The princess's possession of the secret of the doors sets up the possibility of a decisive signal.

Setup setup-hatred at scene-07-princess-secret: The princess's hatred of the lady sets up the ambiguity of her choice.

Reveal reveal-01: fact fact-secret-doors at scene-07-princess-secret; holders: char-princess (acquired at scene start)

Reveal reveal-02: fact fact-lady-identity at scene-07-princess-secret; holders: char-princess (acquired at scene start)

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":6101,"end":7300}

Beat beat-07a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":6101,"end":6700}

Beat beat-07b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":6701,"end":7300}

## scene-08-the-question-and-signal: The Silent Question and the Hand to the Right

The lover's glance asks which door; the princess, without hesitation, makes a slight quick movement toward the right, seen only by him.

Present: char-princess, char-lover, char-narrator

Beat beat-08a: The lover sees that the princess knows the secret and his glance asks 'Which?'

Beat beat-08b: The princess raises her hand and makes a slight, quick movement toward the right, seen by no one but her lover.

Causal causal-04: earlier cause scene-07-princess-secret → effect scene-08-the-question-and-signal

Causal causal-05: earlier cause scene-08-the-question-and-signal → effect scene-09-the-door-opened

Payoff payoff-02: setup setup-secret → payoff at scene-08-the-question-and-signal

Knowledge use use-01: char-princess uses fact fact-secret-doors at scene-08-the-question-and-signal

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7301,"end":8000}

Beat beat-08a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7301,"end":7700}

Beat beat-08b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7701,"end":8000}

## scene-09-the-door-opened: The Door on the Right Is Opened

The lover walks firmly across the arena without hesitation, goes to the door on the right, and opens it; the narrator poses the central question of what emerged.

Present: char-princess, char-lover, char-narrator

Beat beat-09a: The lover crosses the empty space and opens the door on the right without hesitation.

Beat beat-09b: The narrator states the point of the story: did the tiger or the lady come out of that door?

Causal causal-05: earlier cause scene-08-the-question-and-signal → effect scene-09-the-door-opened

Payoff payoff-01: setup setup-doors → payoff at scene-09-the-door-opened

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8001,"end":8500}

Beat beat-09a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8001,"end":8300}

Beat beat-09b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8301,"end":8500}

## scene-10-deliberation: The Princess's Anguished Deliberation

The narrator turns the question over to the reader and imagines the princess's tormented reveries: horror at the tiger, agony at the lady, and the thought that death might be better.

Present: char-princess, char-lover, char-lady, char-narrator

Beat beat-10a: The narrator says the question requires study of the human heart and asks the reader to consider the hot-blooded, semi-barbaric princess.

Beat beat-10b: The princess imagines the tiger's fangs with horror but more often imagines the lady, the wedding, and her own despairing shriek lost in the multitude's shouts.

Beat beat-10c: She wonders whether it would be better for him to die and wait for her, yet recoils at the tiger, the shrieks, the blood.

Payoff payoff-03: setup setup-hatred → payoff at scene-10-deliberation

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8501,"end":9900}

Beat beat-10a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8501,"end":8900}

Beat beat-10b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8901,"end":9600}

Beat beat-10c evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":9601,"end":9900}

## scene-11-unanswerable-question: The Question Left to the Reader

The narrator affirms the princess decided after days and nights of deliberation and moved her hand to the right, then refuses to answer and leaves the question to the reader.

Present: char-princess, char-narrator

Beat beat-11a: Her decision was indicated in an instant but made after anguished deliberation; she had decided and moved her hand to the right.

Beat beat-11b: The narrator declines to answer and leaves it to all readers: which came out of the opened door, the lady or the tiger?

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":9901,"end":10500}

Beat beat-11a evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":9901,"end":10200}

Beat beat-11b evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":10201,"end":10500}

State state-01 [scene-04-princess-and-lover] char-lover canon freedom: known: free courtier; confidence unrecorded; alternatives: (none recorded) → known: imprisoned, awaiting trial; confidence unrecorded; alternatives: (none recorded)

Relationship rel-01 [scene-04-princess-and-lover] char-princess, char-lover romantic_love: known: secret mutual love; confidence unrecorded; alternatives: (none recorded) → known: love exposed; lover imprisoned; confidence unrecorded; alternatives: (none recorded)

State state-02 [scene-07-princess-secret] char-princess belief knowledge_of_doors: known: uncertain; confidence unrecorded; alternatives: (none recorded) → known: certain of which door holds tiger and which the lady; confidence unrecorded; alternatives: (none recorded)

Relationship rel-02 [scene-07-princess-secret] char-princess, char-lady rivalry: known: suspicion; confidence unrecorded; alternatives: (none recorded) → known: intense hatred; confidence unrecorded; alternatives: (none recorded)

State state-03 [scene-09-the-door-opened] char-lover canon fate: known: undecided; confidence unrecorded; alternatives: (none recorded) → unknown: (no asserted value); confidence unrecorded; alternatives: devoured by the tiger; married to the lady

Constraint constraint-01: unresolved: explicit facts missing; locked story canon two_doors_mechanism; expected 'one door tiger, one door lady'; The arena's premise is fixed by the narrator.

Constraint constraint-02: unresolved: explicit facts missing; locked story canon princess_signals_right; expected 'princess moves hand to the right'; The signal direction is stated explicitly.

Constraint constraint-03: unresolved: explicit facts missing; required_ending story canon outcome_of_right_door; expected 'unresolved: either the lady or the tiger'; The text deliberately withholds whether the lady or the tiger emerged.

Constraint constraint-04: human assessment required; literary story canon narrator_refuses_resolution; expected 'question left to the reader'; The narrator explicitly declines to answer.

arcs arc-king-justice [scene-01-king-and-arena, scene-02-trial-procedure, scene-03-justice-and-popularity] interpretation: The king's semi-barbaric idealism produces a tribunal of chance that he regards as perfectly fair.; status=known; confidence=unrecorded

Evidence arc-king-justice: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":44,"end":3600}

Arc character: char-king

agency trajectory arc-king-justice: 2 → 2 → 2; shape=flat; scenes=scene-01-king-and-arena → scene-02-trial-procedure → scene-03-justice-and-popularity; ordinal 0-4

arcs arc-princess-love [scene-04-princess-and-lover, scene-07-princess-secret, scene-08-the-question-and-signal, scene-10-deliberation, scene-11-unanswerable-question] interpretation: The princess's fervent love turns into agonized deliberation between jealousy and horror.; status=known; confidence=unrecorded

Evidence arc-princess-love: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3601,"end":10500}

Arc character: char-princess

agency trajectory arc-princess-love: 1 → 2 → 3 → 4 → 4; shape=rising; scenes=scene-04-princess-and-lover → scene-07-princess-secret → scene-08-the-question-and-signal → scene-10-deliberation → scene-11-unanswerable-question; ordinal 0-4

arcs arc-lover-fate [scene-04-princess-and-lover, scene-06-arena-assembly, scene-08-the-question-and-signal, scene-09-the-door-opened] interpretation: The lover moves from happy secrecy to imprisonment, then to a decisive act whose outcome is withheld.; status=ambiguous; confidence=unrecorded

Alternative readings: he is devoured; he is married to the lady

Evidence arc-lover-fate: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":3601,"end":8500}

Arc character: char-lover

agency trajectory arc-lover-fate: 1 → 2 → 3 → 4; shape=peak; scenes=scene-04-princess-and-lover → scene-06-arena-assembly → scene-08-the-question-and-signal → scene-09-the-door-opened; ordinal 0-4

reader_affect affect-01 [scene-09-the-door-opened, scene-10-deliberation, scene-11-unanswerable-question] interpretation: Suspense resolves into deliberate irresolution, inviting the reader to weigh jealousy against horror.; status=known; confidence=unrecorded

Evidence affect-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8001,"end":10500}

mood trajectory affect-01: 4 → 3 → 3; shape=peak; scenes=scene-09-the-door-opened → scene-10-deliberation → scene-11-unanswerable-question; ordinal 0-4

tension tension-01 [scene-06-arena-assembly, scene-08-the-question-and-signal, scene-09-the-door-opened] interpretation: Tension rises as the lover enters the arena and depends on the princess's silent signal.; status=known; confidence=unrecorded

Evidence tension-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5501,"end":8500}

tension trajectory tension-01: 2 → 3 → 4; shape=rising; scenes=scene-06-arena-assembly → scene-08-the-question-and-signal → scene-09-the-door-opened; ordinal 0-4

tension tension-02 [scene-10-deliberation, scene-11-unanswerable-question] interpretation: The unresolved question sustains tension beyond the action, as the narrator transfers the burden of judgment to the reader.; status=known; confidence=unrecorded

Evidence tension-02: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8501,"end":10500}

tension trajectory tension-02: 3 → 3 → 3; shape=flat; scenes=scene-10-deliberation → scene-11-unanswerable-question → scene-11-unanswerable-question; ordinal 0-4

themes theme-justice-chance [scene-01-king-and-arena, scene-02-trial-procedure, scene-03-justice-and-popularity] interpretation: Justice as arbitrary chance masquerading as fairness.; status=known; confidence=unrecorded

Evidence theme-justice-chance: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":44,"end":3600}

themes theme-jealousy-love [scene-07-princess-secret, scene-10-deliberation] interpretation: Love entangled with jealousy and the capacity for cruelty.; status=known; confidence=unrecorded

Evidence theme-jealousy-love: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":6101,"end":9900}

themes theme-indeterminacy [scene-09-the-door-opened, scene-11-unanswerable-question] interpretation: The deliberate withholding of resolution makes interpretation itself the subject.; status=known; confidence=unrecorded

Evidence theme-indeterminacy: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8001,"end":10500}

motifs motif-doors [scene-02-trial-procedure, scene-09-the-door-opened] observation: Twin identical doors as portals of fate.; status=known; confidence=unrecorded

Evidence motif-doors: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1101,"end":1700}

Evidence motif-doors: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8001,"end":8300}

motifs motif-bells [scene-02-trial-procedure] observation: Iron bells of mourning versus brass bells of celebration.; status=known; confidence=unrecorded

Evidence motif-bells: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1701,"end":2600}

motifs motif-hand-signal [scene-08-the-question-and-signal] observation: The slight quick movement of the princess's hand toward the right.; status=known; confidence=unrecorded

Evidence motif-hand-signal: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7701,"end":8000}

discourse discourse-01 [scene-09-the-door-opened, scene-11-unanswerable-question] observation: The narrator directly addresses the reader and poses the central question rather than narrating the outcome.; status=known; confidence=unrecorded

Evidence discourse-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8301,"end":8500}

Evidence discourse-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":10201,"end":10500}

discourse discourse-02 [scene-10-deliberation] interpretation: The narration shifts into the princess's imagined reveries, blurring hypothetical and actual events.; status=ambiguous; confidence=unrecorded

Alternative readings: reported fantasy; narrator's speculation

Evidence discourse-02: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8901,"end":9600}

subtext subtext-01 [scene-10-deliberation, scene-11-unanswerable-question] interpretation: The princess's choice may encode either jealous cruelty or merciful love, and the text refuses to settle it.; status=ambiguous; confidence=unrecorded

Alternative readings: she sent him to the tiger out of jealousy; she sent him to the lady out of love

Evidence subtext-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8501,"end":10500}

Motif echo echo-01: motif-doors → motif-hand-signal (transformation)

Evidence echo-01: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7701,"end":8300}

Motif echo echo-02: motif-bells → motif-doors (contrast)

Evidence echo-02: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1701,"end":2600}

human constraint_fact_missing [constraint-01 character story]: two_doors_mechanism: unresolved: explicit facts missing

human constraint_fact_missing [constraint-02 character story]: princess_signals_right: unresolved: explicit facts missing

human constraint_fact_missing [constraint-03 character story]: outcome_of_right_door: unresolved: explicit facts missing

human constraint_human_assessment [constraint-04 character story]: The narrator explicitly declines to answer.
