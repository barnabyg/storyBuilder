# G-schema evidence

Gate: passed

Automated mechanical evidence: passed

Automated consistency and LLM agreement do not establish literary accuracy.

Report/run ID: 77de4d1b2df3f2936ce0c4ed0970733962a61d3ef58b67a5af4d2b9ca8641483

Code revision: 3f29d9cd83e11b038a6dd963b6f7f168c93ed48e

Schema SHA-256: 890577b4d8f9b6eb75c18df5500f3f702af917b02fcc1626b9be715a45e8f147

Manifest SHA-256: 465d60c829945683ef9943c3057252570f605385de492b6c177bfc8e40432f67

## Validator mutation coverage

44/44 intended categories caught (100.0%); required ≥95% and ≥20 categories.

Suite SHA-256: 35af8e487f5adc38da20b00b5b4488860ae83e039a8c6c3a4eb34bdbc5e1a08c

Control structure: passed

Control state: passed

Control interpretation: passed

Control evidence: passed

duplicate_identity (structure): caught; expected error duplicate_id. A structural record collides with a scene ID. Actual: duplicate_id [s1]: duplicate ID s1

unknown_presence (structure): caught; expected error character_reference. A scene names an unknown character. Actual: character_reference [s1]: unknown character ghost; knowledge_presence [use1]: holder c1 is absent at s1

duplicate_presence (structure): caught; expected error duplicate_presence. A character is listed twice as present. Actual: duplicate_presence [s1]: duplicate character presence

dangling_cause (causality): caught; expected error causal_endpoint. The cause endpoint does not exist. Actual: causal_endpoint [cause1]: cause ghost must be an earlier scene than s3

causal_self_link (causality): caught; expected error causal_self_link. A scene is its own cause. Actual: causal_self_link [cause1]: cause s3 must be an earlier scene than s3; causal_cycle [signal]: causal links contain a cycle: ['s3', 's3']

causal_order (causality): caught; expected error causal_order. An effect is earlier than its cause. Actual: causal_order [cause1]: cause s3 must be an earlier scene than s1

causal_cycle (causality): caught; expected error causal_cycle. A return dependency creates a cycle. Actual: causal_order [cycle]: cause s3 must be an earlier scene than s1; causal_cycle [signal]: causal links contain a cycle: ['s1', 's3', 's1']

missing_setup_scene (setups): caught; expected error setup_scene_reference. The setup scene is unknown. Actual: setup_scene_reference [setup1]: unknown setup scene ghost; unpaid_setup [setup1]: setup setup1 at ghost has no payoff

missing_payoff_setup (setups): caught; expected error payoff_setup_reference. A payoff names an unknown setup. Actual: payoff_setup_reference [payoff1]: setup ghost must precede payoff scene s3; unpaid_setup [setup1]: setup setup1 at s1 has no payoff

missing_payoff_scene (setups): caught; expected error payoff_scene_reference. The payoff scene is unknown. Actual: payoff_scene_reference [payoff1]: setup setup1 must precede payoff scene ghost; unpaid_setup [setup1]: setup setup1 at s1 has no payoff

payoff_order (setups): caught; expected error payoff_order. A payoff does not follow its setup. Actual: payoff_order [payoff1]: setup setup1 must precede payoff scene s1; unpaid_setup [setup1]: setup setup1 at s1 has no payoff

missing_knowledge_fact (knowledge): caught; expected error knowledge_fact. A reveal references an unknown fact. Actual: knowledge_fact [reveal1]: unknown fact ghost at s2; knowledge_before_acquisition [use2]: c2 uses fact fact2 before acquiring it at s3

missing_knowledge_scene (knowledge): caught; expected error knowledge_scene. A knowledge use references an unknown scene. Actual: knowledge_scene [use1]: unknown knowledge scene ghost

unknown_knowledge_holder (knowledge): caught; expected error knowledge_holder. The holder is not a known character. Actual: knowledge_holder [use1]: unknown holder ghost at s1

duplicate_fact_holder (knowledge): caught; expected error duplicate_fact_reference. A reveal repeats a holder/fact reference. Actual: duplicate_fact_reference [reveal1]: fact holders must be unique at s2; knowledge_before_acquisition [use2]: c2 uses fact fact2 before acquiring it at s3

premature_knowledge (knowledge): caught; expected error knowledge_before_acquisition. A character uses a fact before acquiring it. Actual: knowledge_before_acquisition [use1]: c1 uses fact fact2 before acquiring it at s1

absent_knowledge_holder (knowledge): caught; expected error knowledge_presence. A reveal holder is absent from the scene. Actual: knowledge_presence [reveal1]: holder c2 is absent at s2; knowledge_before_acquisition [use2]: c2 uses fact fact2 before acquiring it at s3

unknown_state_character (state): caught; expected error state_character_reference. unknown state character. Actual: state_character_reference [st1 scene s1 character ghost]: unknown character ghost; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

unknown_state_scene (state): caught; expected error state_scene_reference. unknown state scene. Actual: state_scene_reference [st1 scene missing character c1]: unknown scene missing; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

state_before_contradiction (state): caught; expected error state_transition. state before contradiction. Actual: state_transition [st2 scene s2 character c1]: before value contradicts previous explicit after value; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

relationship_unknown_participant (state): caught; expected error relationship_participant. relationship unknown participant. Actual: relationship_participant [r1 scene s1]: unknown participant ghost; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

relationship_duplicate_participant (state): caught; expected error relationship_participant_duplicate. relationship duplicate participant. Actual: relationship_participant_duplicate [r1 scene s1]: relationship participants must be distinct; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

relationship_unknown_scene (state): caught; expected error relationship_scene_reference. relationship unknown scene. Actual: relationship_scene_reference [r1 scene missing]: unknown scene missing; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

relationship_before_contradiction (state): caught; expected error relationship_transition. relationship before contradiction. Actual: relationship_transition [r2 scene s2]: before value contradicts previous explicit after value; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

locked_value_changed (constraints): caught; expected error locked_value. locked value changed. Actual: locked_value [hc1 character c1]: oath: expected 'protect lives'; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

ending_fact_contradicted (constraints): caught; expected error required_ending. ending fact contradicted. Actual: required_ending [hc2 character c1]: priority: expected 'guide the boat home'; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

constraint_unknown_character (constraints): caught; expected error constraint_character_reference. constraint unknown character. Actual: constraint_character_reference [hc1 character ghost]: unknown character ghost; constraint_fact_missing [hc1 character ghost]: oath: unresolved: explicit facts missing; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

constraint_expected_missing (constraints): caught; expected error constraint_expected. constraint expected missing. Actual: constraint_expected [hc1 character c1]: mechanical constraint needs an explicit expected value; constraint_unresolved [hc1 character c1]: oath: unresolved: explicit facts missing; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

state_character_required (state): caught; expected error state_character_required. state character required. Actual: state_character_required [st1 scene s1 character story]: only canon can have story-wide scope; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

duplicate_state_transition (state): caught; expected error state_duplicate. duplicate state transition. Actual: state_duplicate [st2 scene s1 character c1]: multiple transitions for goal priority; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

duplicate_relationship_transition (state): caught; expected error relationship_duplicate. duplicate relationship transition. Actual: relationship_duplicate [r2 scene s1]: multiple transitions for the same relationship; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

absent_state_character (state): caught; expected error state_presence. absent state character. Actual: state_presence [st1 scene s1 character c1]: character is absent from transition scene; state_presence [st3 scene s1 character c1]: character is absent from transition scene; relationship_presence [r1 scene s1]: participant c1 is absent; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

absent_relationship_participant (state): caught; expected error relationship_presence. absent relationship participant. Actual: relationship_presence [r1 scene s1]: participant c2 is absent; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

constraint_character_required (constraints): caught; expected error constraint_character_required. constraint character required. Actual: constraint_character_required [hc1 character story]: only canon can have story-wide scope; constraint_fact_missing [hc1 character story]: oath: unresolved: explicit facts missing; constraint_human_assessment [hc3 character story]: Does the ending earn Mara's change of priority?

interpretive_scene (interpretation): caught; expected error interpretive_scene_reference. An interpretation names an unknown scene. Actual: interpretive_scene_reference [th1]: annotation scene IDs must resolve

arc_character (interpretation): caught; expected error arc_character_reference. An arc names an unknown character. Actual: arc_character_reference [a1]: unknown arc character ghost

trajectory_scene (interpretation): caught; expected error trajectory_scene_reference. An ordinal point names an unknown scene. Actual: trajectory_scene_reference [a1]: trajectory points must name scenes

trajectory_order (interpretation): caught; expected error trajectory_order. Trajectory points reverse story order. Actual: trajectory_order [a1]: trajectory points must follow scene order

motif_endpoint (interpretation): caught; expected error motif_endpoint. An echo names an unknown motif occurrence. Actual: motif_endpoint [echo1]: motif echo endpoints must name motif IDs

motif_self_link (interpretation): caught; expected error motif_self_link. A motif echoes itself instead of another occurrence. Actual: motif_self_link [echo1]: a motif echo must link distinct occurrences

span_source (evidence): caught; expected error span_source. Evidence names an unknown source. Actual: span_source [s1]: invalid evidence span for ghost

span_version (evidence): caught; expected error span_version. Evidence is bound to the wrong source version. Actual: span_version [s1]: invalid evidence span for source1

span_bounds (evidence): caught; expected error span_bounds. The evidence span extends beyond the text. Actual: span_bounds [s1]: invalid evidence span for source1

source_checksum (evidence): caught; expected error source_checksum. The source text no longer matches its checksum. Actual: source_checksum [source1]: source must match SHA-256 and use LF text

## Story inventory and owner review

### owl-creek-bridge: An Occurrence at Owl Creek Bridge

Provenance: https://www.gutenberg.org/cache/epub/375/pg375.txt; Project Gutenberg eBook 375; complete standalone story; Project Gutenberg records public domain in the USA; published 1890

Source: verified; words: 3728; source SHA-256: a64e03d1b1c8e5c24dc8a835083ab660b0690244487ec5c6f4a7884d47f882b4; text SHA-256: e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064

Annotation: drafted; correction revision: 8

Generation attempts: 2; new provider spend USD: 0.0354657

Actual owner correction seconds: 3125.9146163463593; target <7200

Owner review: accepted; literary evidence: The human project owner reviewed the final annotation overview, retained agreed reading, source corrections and linked full scene cards for exact revision 8 and said: Yes, this final version faithfully represents my reading of An Occurrence at Owl Creek Bridge and my response to it. The owner understands the actual hanging and the imagined escape/homecoming in the moments before death. The Union identity of the Federal scout was clarified using the source; the narrator reveals it to the reader, not to Farquhar. The owner suspected the escape because of details including the cannon, untying his hands and an apparently quick journey home. Confederate slaveholding limited sympathy and hope for his escape. The final revelation confirmed suspicion rather than causing shock or much emotion. Suspense was probably strongest at the opening and weakened during the unrealistic-seeming escape. The owner recognized desperation and terror in the character without strongly feeling that terror personally, and identified the mind playing tricks on itself as a theme. The owner previously explicitly confirmed meaningful qualitative differences across all three stories. Numeric ratings, unshown sabotage/capture details and the scout’s intent remain unrecorded. Source/structural details were checked by the assistant; final approval concerns this corrected reading as presented. Exact hashes, detailed feedback and actual timing are preserved. No later scientific gate is implied.

config_sha256: 94b3e63438076350b498f0dae1baa0c0df9bfe669969fd312220940a6278fa6a

git_sha: 3f29d9cd83e11b038a6dd963b6f7f168c93ed48e

model: deepseek/deepseek-flash

prompt: g_schema_paragraphs_owl-creek-bridge@1

prompt_sha256: 622f1a40b3f479619bdd4a4a7bb5632a6619ab8b10e762188595b46e34b2c86a

revision_sha256: 63d166ebb9c6a8e558e07a0e4828ebe3cd9148fab6ffc6da4986db2b8ebda48b

schema_sha256: 890577b4d8f9b6eb75c18df5500f3f702af917b02fcc1626b9be715a45e8f147

session_id: 95af767420a27b66

span_basis: unicode-codepoints-lf

advisory unpaid_setup [setup-driftwood-tinder]: setup setup-driftwood-tinder at scene-plantation-visit has no payoff

tension tension-escape-vs-capture: falling; unknown → unknown → unknown → unknown; scenes scene-hanging-preparation, scene-fall-and-river, scene-flight-through-woods, scene-homecoming-and-death

### gift-of-the-magi: The Gift of the Magi

Provenance: https://www.gutenberg.org/cache/epub/7256/pg7256.txt; Project Gutenberg eBook 7256; complete standalone story; Project Gutenberg records public domain in the USA; published 1905

Source: verified; words: 2057; source SHA-256: cdf8ad2aad68e48c58d6745a8a1ec418871176a6521fb458a8abc88f9a0649a3; text SHA-256: 6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2

Annotation: drafted; correction revision: 9

Generation attempts: 2; new provider spend USD: 0.034437

Actual owner correction seconds: 2925.8613200187683; target <7200

Owner review: accepted; literary evidence: The human project owner reviewed the final annotation overview, retained agreed reading, source corrections and linked full scene cards for exact revision 9 and said: Yes, this final version faithfully represents my reading of The Gift of the Magi. The owner described Della’s choice as desperate and tragic under poverty, not rising control; love outweighs the gifts’ immediate practical use. The ending felt emotional and happy, with sadness giving way at Jim’s smile and suggestion to put the presents away. The narrator’s teasing felt affectionate. Earlier the owner explicitly confirmed meaningful differences between the displayed qualitative patterns for all three stories. Numerical confidence/intensity values and unsupported whole-story agency curves remain unrecorded. Source/structural details were checked by the assistant; the owner’s final approval concerns this corrected literary reading as presented. Detailed human feedback, exact presentation hashes and timing are preserved in the guided-review packet. No later scientific gate is implied.

config_sha256: e89fa60e60c9fae765751bad60aff38a5156d93e911065cd422516c2c26a6fa9

git_sha: 3f29d9cd83e11b038a6dd963b6f7f168c93ed48e

model: deepseek/deepseek-flash

prompt: g_schema_paragraphs_gift-of-the-magi@1

prompt_sha256: a48b43f1cf31209a0093d207f23049c5da431bdf3e955a7880303ba89be8ef58

revision_sha256: 4c0bdccadfb1a657f34cf4938d42b3ea2fc5e935553a8ba9f8dbfea855095380

schema_sha256: 890577b4d8f9b6eb75c18df5500f3f702af917b02fcc1626b9be715a45e8f147

session_id: 4bf497b5cfa2d4fc

span_basis: unicode-codepoints-lf

mood affect-bittersweet-coda: rising; unknown → unknown → unknown; scenes scene-the-combs, scene-the-chain-and-revelation, scene-narrator-coda

tension tension-money-vs-gift: rising; unknown → unknown → unknown; scenes scene-pennies-and-flat, scene-hair-and-watch, scene-selling-hair

tension tension-unreadable-stare: peak; unknown → unknown → unknown; scenes scene-curling-hair, scene-jims-return, scene-explanation-and-embrace

### lady-or-tiger: The Lady, or the Tiger?

Provenance: https://www.gutenberg.org/cache/epub/396/pg396.txt; Project Gutenberg eBook 396; complete standalone story; Project Gutenberg records public domain in the USA; published 1882

Source: verified; words: 2708; source SHA-256: 1a84538761d909b5d996a3e65fc94936fcaae0c4ece17c7ac2942e8e0c8bc570; text SHA-256: b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc

Annotation: drafted; correction revision: 9

Generation attempts: 3; new provider spend USD: 0.052353300000000005

Actual owner correction seconds: 2655.213320493698; target <7200

Owner review: accepted; literary evidence: The human project owner reviewed the final annotation overview, retained agreed reading, source corrections and linked full scene cards for exact revision 9 and said: Yes, this final version faithfully represents my reading of The Lady, or the Tiger? The owner identified love and jealousy as the princess’s conflicting motives, and her knowledge plus the young man’s trust as giving her control at the signal. The outcome remains unknown. Suspense peaked at the signal and move to open the door, then faded into an intellectual puzzle; the owner found the ending interesting but personally unfulfilling. The owner criticized arbitrary punishment/reward, marriage without the woman’s consent, and sexist/misogynistic framing of jealous cruelty. These are recorded as this owner’s literary reading rather than established outcomes or universal responses. The owner previously explicitly confirmed meaningful qualitative differences across all three stories. Numerical confidence/intensity values and unsupported whole-story agency curves remain unrecorded. Source/structural details were checked by the assistant; final approval concerns this corrected reading as presented. Exact presentation hashes, detailed feedback and actual timing are preserved. No later scientific gate is implied.

config_sha256: aab03c91ee9cd3c879d85d90678cf083366cef17baec38b0c348436013059497

git_sha: 3f29d9cd83e11b038a6dd963b6f7f168c93ed48e

model: deepseek/deepseek-flash

prompt: g_schema_paragraphs_lady-or-tiger@1

prompt_sha256: b89a436725fff1ffcb7f73954592b66bd0e78034fcb7a7f962f4bf0fe946f9f4

revision_sha256: ce856b0cbb05563f81b5940e2aaa5c0886a38d912f43c42e201df83c3c73c299

schema_sha256: 890577b4d8f9b6eb75c18df5500f3f702af917b02fcc1626b9be715a45e8f147

session_id: 21461b9cc5cf8b8a

span_basis: unicode-codepoints-lf

tension tension-love-vs-jealousy: peak; unknown → unknown → unknown; scenes scene-love-discovered, scene-trial-arena, scene-unanswered-question

## Trajectory comparisons

owl-creek-bridge / gift-of-the-magi: distinct=True (automated comparison only)

owl-creek-bridge / lady-or-tiger: distinct=True (automated comparison only)

gift-of-the-magi / lady-or-tiger: distinct=True (automated comparison only)

## Remaining owner procedure

Select 3-5 provenance-checked stories in range, correct and validate each tier-L draft with the annotation timer, pause it during idle/generation, and explicitly review the latest correction with literary notes. Compare the coarse trajectories and record whether differences are meaningful.

Fail action: cut or merge slow or non-discriminating channels, then repeat on another story. Routine manual regression testing is not required.

Replay: uv run nde schema-evidence --replay inputs.json --out replayed
