# The Lady, or the Tiger?

Plan lady-or-tiger-annotation; schema 1; tier L

Character char-king: The semi-barbaric king

Character char-princess: The princess

Character char-lover: The young courtier (princess's lover)

Character char-lady: The lady behind the door

## scene-king-justice: The king and his arena of chance

The narrator establishes the semi-barbaric king, his self-willed authority, and the arena tribunal in which an accused person chooses one of two identical doors: one releasing a tiger, the other a lady whom he must marry.

Present: char-king

Beat beat-king-character: The king is described as semi-barbaric, of exuberant fancy and irresistible authority, who turns his fancies into facts.

Beat beat-arena-purpose: The arena is built not for gladiators or martyrs but as an agent of poetic justice decided by impartial chance.

Beat beat-two-doors: The accused walks to two identical doors; one releases a tiger that kills him, the other a lady he is immediately married to.

Beat beat-justice-claim: The narrator calls the method perfectly fair and determinate, since the accused chooses without knowing the outcome.

Beat beat-popularity: The institution is popular because its uncertainty entertains the masses and the accused seems to hold the matter in his own hands.

Fact fact-door-secret: Which of the two doors hides the tiger and which hides the lady.; initial holders: (none)

Fact fact-lady-identity: The identity of the lady selected as the reward behind one door.; initial holders: (none)

Fact fact-princess-knows: That the princess knows the secret of the doors.; initial holders: (none)

Causal causal-king-justice-to-trial: earlier cause scene-king-justice → effect scene-trial-arena

Setup setup-two-doors at scene-king-justice: The arena's two identical doors, one hiding a tiger and one a lady, establish the mechanism of the trial.

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":48,"end":5744}

Beat beat-king-character evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":48,"end":888}

Beat beat-arena-purpose evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":1097,"end":1722}

Beat beat-two-doors evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":2298,"end":4567}

Beat beat-justice-claim evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4569,"end":5232}

Beat beat-popularity evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5234,"end":5744}

## scene-love-discovered: The princess's love and the king's discovery

The king's daughter loves a handsome but low-station courtier; when the king discovers the affair he imprisons the youth and appoints a day for his trial in the arena.

Present: char-king, char-princess, char-lover

Beat beat-princess-intro: The princess is fervent and imperious like her father, and loves the young courtier with warm, barbaric ardor.

Beat beat-imprisonment: The king discovers the love affair, casts the youth into prison, and appoints a day for his arena trial.

Causal causal-discovery-to-trial: earlier cause scene-love-discovered → effect scene-trial-arena

Setup setup-princess-secret at scene-love-discovered: The princess's fierce will and love for the youth set up her later acquisition of the secret of the doors.

Setup setup-princess-jealousy at scene-love-discovered: The princess's imperious, barbaric ardor sets up the jealousy that makes her signal morally ambiguous.

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

Beat beat-princess-intro evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

Beat beat-imprisonment evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

## scene-preparations: Preparations for the trial

The kingdom searches for the fiercest tiger and the most suitable maiden; everyone knows the youth loved the princess, but the king lets the tribunal proceed for his own satisfaction.

Present: char-king, char-lover

Beat beat-tiger-and-bride-selected: Tiger-cages are searched for the fiercest beast and maidens surveyed for a fitting bride.

Beat beat-king-aesthetic: The king refuses to let the known fact of the love affair interfere and anticipates aesthetic pleasure in the outcome.

Causal causal-preparations-to-trial: earlier cause scene-preparations → effect scene-trial-arena

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7037,"end":8016}

Beat beat-tiger-and-bride-selected evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7037,"end":8016}

Beat beat-king-aesthetic evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7037,"end":8016}

## scene-trial-arena: The trial in the arena

The appointed day arrives; the lover enters the arena, fixes his eyes on the princess, and she signals toward the right door. He opens the right door, and the narrator withholds what emerges.

Present: char-king, char-princess, char-lover

Beat beat-crowd-assembles: Crowds throng the arena and the king and court take their places opposite the twin doors.

Beat beat-lover-enters: The signal is given and the princess's lover walks into the arena, greeted with admiration and anxiety.

Beat beat-princess-knows-secret: The princess has obtained the secret of the doors through gold and her will, and knows which room holds the tiger and which the lady.

Beat beat-princess-hates-lady: The princess knows and hates the lady selected as the reward, suspecting glances and brief conversations between her and the lover.

Beat beat-glance-question: The lover reads in the princess's face that she knows the secret, and his glance asks which door.

Beat beat-hand-to-right: The princess makes a slight quick movement toward the right; only the lover sees it.

Beat beat-right-door-opened: The lover walks without hesitation to the right door and opens it; the outcome is not narrated.

Causal causal-discovery-to-trial: earlier cause scene-love-discovered → effect scene-trial-arena

Causal causal-preparations-to-trial: earlier cause scene-preparations → effect scene-trial-arena

Causal causal-king-justice-to-trial: earlier cause scene-king-justice → effect scene-trial-arena

Payoff payoff-two-doors: setup setup-two-doors → payoff at scene-trial-arena

Payoff payoff-princess-secret: setup setup-princess-secret → payoff at scene-trial-arena

Reveal reveal-door-secret: fact fact-door-secret at scene-trial-arena; holders: char-princess (acquired at scene start)

Reveal reveal-lady-identity: fact fact-lady-identity at scene-trial-arena; holders: char-princess (acquired at scene start)

Reveal reveal-princess-knows: fact fact-princess-knows at scene-trial-arena; holders: char-lover (acquired at scene start)

Knowledge use use-door-secret-signal: char-princess uses fact fact-door-secret at scene-trial-arena

Knowledge use use-lady-identity-jealousy: char-princess uses fact fact-lady-identity at scene-trial-arena

Knowledge use use-princess-knows-trust: char-lover uses fact fact-princess-knows at scene-trial-arena

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8018,"end":12595}

Beat beat-crowd-assembles evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8018,"end":8340}

Beat beat-lover-enters evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8342,"end":8710}

Beat beat-princess-knows-secret evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":8712,"end":10032}

Beat beat-princess-hates-lady evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":10034,"end":11099}

Beat beat-glance-question evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":11101,"end":12126}

Beat beat-hand-to-right evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12128,"end":12338}

Beat beat-right-door-opened evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12340,"end":12595}

## scene-unanswered-question: The narrator's unanswered question

The narrator poses the central question of what came out of the door, then presents the princess's imagined agonies over both outcomes and her deliberation, finally refusing to answer and leaving the question to the reader.

Present: char-princess, char-lover

Beat beat-question-posed: The narrator asks whether the tiger or the lady came out of the opened door.

Beat beat-jealousy-frame: The narrator frames the question as a study of the princess's despair and jealousy: she had lost him, but who should have him?

Beat beat-imagined-tiger: The princess imagines in waking hours and dreams her lover opening the tiger's door.

Beat beat-imagined-lady: More often she imagines him opening the lady's door, marrying her, and the crowd's joy drowning the princess's despairing shriek.

Beat beat-death-considered: She wonders whether it would be better for him to die at once and wait for her in the semi-barbaric futurity, then recoils at the tiger, shrieks, and blood.

Beat beat-decision-deliberated: Her decision was indicated in an instant but made after days and nights of anguished deliberation; she had decided and moved her hand to the right.

Beat beat-question-left-open: The narrator declines to answer and leaves the question to the reader.

Payoff payoff-princess-jealousy: setup setup-princess-jealousy → payoff at scene-unanswered-question

Evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12597,"end":14927}

Beat beat-question-posed evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12597,"end":12687}

Beat beat-jealousy-frame evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12689,"end":13150}

Beat beat-imagined-tiger evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":13152,"end":13378}

Beat beat-imagined-lady evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":13380,"end":14236}

Beat beat-death-considered evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14238,"end":14412}

Beat beat-decision-deliberated evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14414,"end":14679}

Beat beat-question-left-open evidence: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14681,"end":14927}

State state-lover-freedom [scene-love-discovered] char-lover canon liberty: known: free; confidence unrecorded; alternatives: (none recorded) → known: imprisoned; confidence unrecorded; alternatives: (none recorded)

Relationship rel-lovers-separated [scene-love-discovered] char-princess, char-lover romantic_bond: known: happy secret love affair; confidence unrecorded; alternatives: (none recorded) → known: lover imprisoned, princess desperate; confidence unrecorded; alternatives: (none recorded)

State state-princess-knowledge [scene-trial-arena] char-princess belief knows_door_secret: known: does not know; confidence unrecorded; alternatives: (none recorded) → known: knows; confidence unrecorded; alternatives: (none recorded)

State state-lover-certainty [scene-trial-arena] char-lover belief hope_of_survival: known: uncertain; confidence unrecorded; alternatives: (none recorded) → known: trusts princess knows; confidence unrecorded; alternatives: (none recorded)

State state-princess-decision [scene-unanswered-question] char-princess goal decision_made: known: deliberating; confidence unrecorded; alternatives: (none recorded) → known: decided to signal right; confidence unrecorded; alternatives: (none recorded)

Constraint constraint-outcome-unresolved: human assessment required; literary story canon door_outcome; expected None; The text deliberately withholds whether the tiger or the lady emerged; the ending is an open question addressed to the reader.

arcs arc-princess-choice [scene-love-discovered, scene-trial-arena, scene-unanswered-question] interpretation: The princess moves from passionate love through jealous deliberation to a decisive but morally opaque signal.; status=known; confidence=0.9

Evidence arc-princess-choice: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

Evidence arc-princess-choice: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12128,"end":12338}

Evidence arc-princess-choice: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14414,"end":14679}

Arc character: char-princess

agency trajectory arc-princess-choice: 1 → 3 → 4; shape=rising; scenes=scene-love-discovered → scene-trial-arena → scene-unanswered-question; ordinal 0-4

arcs arc-lover-fate [scene-love-discovered, scene-preparations, scene-trial-arena] interpretation: The lover passes from happy obscurity to imprisonment and then to an arena trial whose outcome remains unknown.; status=known; confidence=0.9

Evidence arc-lover-fate: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

Evidence arc-lover-fate: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":7037,"end":8016}

Evidence arc-lover-fate: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12340,"end":12595}

Arc character: char-lover

agency trajectory arc-lover-fate: 1 → 2 → 4; shape=rising; scenes=scene-love-discovered → scene-preparations → scene-trial-arena; ordinal 0-4

reader_affect affect-suspense [scene-trial-arena, scene-unanswered-question] interpretation: Suspense and interpretive unease, produced by the withheld outcome and the princess's divided motives.; status=known; confidence=0.85

Evidence affect-suspense: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12597,"end":12687}

Evidence affect-suspense: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14681,"end":14927}

mood trajectory affect-suspense: 1 → 3 → 4; shape=peak; scenes=scene-king-justice → scene-trial-arena → scene-unanswered-question; ordinal 0-4

tension tension-love-vs-jealousy [scene-trial-arena, scene-unanswered-question] interpretation: The princess's love for the youth contends with her jealousy of the lady, leaving her signal's intent unresolved.; status=ambiguous; confidence=0.8

Alternative readings: she sent him to the tiger out of jealousy; she sent him to the lady out of love or self-sacrifice

Evidence tension-love-vs-jealousy: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12689,"end":13150}

Evidence tension-love-vs-jealousy: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14238,"end":14412}

tension trajectory tension-love-vs-jealousy: 1 → 2 → 4; shape=oscillating; scenes=scene-love-discovered → scene-trial-arena → scene-unanswered-question; ordinal 0-4

themes theme-justice-as-chance [scene-king-justice] interpretation: The story ironizes the king's claim that chance-based punishment and reward constitute perfect justice.; status=known; confidence=0.85

Evidence theme-justice-as-chance: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4569,"end":5232}

themes theme-human-heart-opacity [scene-unanswered-question] interpretation: The unresolved ending makes the human heart, especially the princess's, finally unreadable.; status=known; confidence=0.85

Evidence theme-human-heart-opacity: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12689,"end":13150}

Evidence theme-human-heart-opacity: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14681,"end":14927}

themes theme-love-and-jealousy [scene-trial-arena, scene-unanswered-question] interpretation: The princess loves the young man and does not want him to die, but cannot bear his marrying the other woman. Love and jealousy pull her in opposite directions.; status=known; confidence=unrecorded

Evidence theme-love-and-jealousy: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12128,"end":12338}

Evidence theme-love-and-jealousy: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14238,"end":14412}

motifs motif-doors [scene-king-justice, scene-trial-arena] observation: Identical doors as the mechanism of an unknowable choice.; status=known; confidence=0.95

Evidence motif-doors: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":2298,"end":3504}

Evidence motif-doors: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12340,"end":12595}

motifs motif-barbarism [scene-king-justice, scene-love-discovered] observation: Semi-barbarism as the king's and princess's shared inheritance, blending civilization with savage impulse.; status=known; confidence=0.9

Evidence motif-barbarism: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":48,"end":888}

Evidence motif-barbarism: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

motifs motif-imagined-outcomes [scene-unanswered-question] observation: The princess's reveries repeatedly stage both possible outcomes, blurring memory, imagination, and fact.; status=known; confidence=0.9

Evidence motif-imagined-outcomes: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":13152,"end":14236}

discourse discourse-narrator-intrusion [scene-king-justice, scene-unanswered-question] observation: An intrusive narrator comments on the fairness of the arena and finally addresses the reader directly, refusing to resolve the question.; status=known; confidence=0.9

Evidence discourse-narrator-intrusion: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":4569,"end":5232}

Evidence discourse-narrator-intrusion: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14681,"end":14927}

discourse discourse-flashback-princess [scene-trial-arena, scene-unanswered-question] observation: After the door is opened, the narration moves into the princess's prior deliberation and imagined outcomes, presenting them as subjective experience rather than established events.; status=known; confidence=0.85

Evidence discourse-flashback-princess: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":13152,"end":14236}

Evidence discourse-flashback-princess: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14414,"end":14679}

subtext subtext-princess-signal [scene-trial-arena, scene-unanswered-question] interpretation: The princess's rightward signal may encode either jealous vengeance or self-sacrificing love; the text sustains both readings.; status=ambiguous; confidence=0.8

Alternative readings: she chose the tiger; she chose the lady

Evidence subtext-princess-signal: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":12128,"end":12338}

Evidence subtext-princess-signal: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":14238,"end":14412}

Motif echo echo-barbarism-to-imagined: motif-barbarism → motif-imagined-outcomes (transformation)

Evidence echo-barbarism-to-imagined: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":5746,"end":7035}

Evidence echo-barbarism-to-imagined: {"source_id":"source-lady-or-tiger","source_sha256":"b20c5b231dfbb05f8f848e20adabbaf9f13da85f72f6b729048897c3cd0934bc","start":13152,"end":14236}

human constraint_human_assessment [constraint-outcome-unresolved character story]: The text deliberately withholds whether the tiger or the lady emerged; the ending is an open question addressed to the reader.
