# An Occurrence at Owl Creek Bridge

Plan plan-owl-creek-bridge; schema 1; tier L

Character char-peyton-farquhar: Peyton Farquhar

Character char-mrs-farquhar: Mrs. Farquhar

Character char-federal-scout: Gray-clad soldier (Federal scout)

Character char-captain: Federal captain

Character char-sergeant: Federal sergeant

Character char-lieutenant: Confederate lieutenant

## scene-plantation-visit: The gray-clad soldier's visit at the plantation

At dusk a gray-clad soldier rides to Farquhar's gate for water and, while Mrs. Farquhar fetches it, tells Farquhar of the repaired Owl Creek bridge, the order against civilian interference, and the dry driftwood at the pier. After nightfall he rides back north; the narrator discloses he is a Federal scout.

Present: char-peyton-farquhar, char-mrs-farquhar, char-federal-scout

Beat beat-visit-arrival: A gray-clad soldier asks for water; Mrs. Farquhar goes to fetch it while Farquhar questions the rider about news from the front.

Beat beat-visit-intel: The soldier reports the Yanks hold and repair Owl Creek bridge, have posted an order that civilians interfering with the railroad will be summarily hanged, and that only a picket post and one sentinel guard the near side.

Beat beat-visit-driftwood: Farquhar poses a hypothetical about a civilian eluding the post; the soldier recalls dry driftwood lodged against the bridge pier that would burn like tinder.

Beat beat-visit-reveal: The soldier drinks, thanks the lady, and rides off; an hour after nightfall he repasses going north, and the narration identifies him as a Federal scout.

Fact fact-scout-is-federal: The gray-clad visitor is a Federal scout, not a Confederate soldier.; initial holders: char-federal-scout

Fact fact-bridge-defenses: Owl Creek bridge is repaired and held by Federal troops, with a stockade, a cannon, a picket post half a mile out, and a single sentinel at the near end.; initial holders: char-federal-scout

Fact fact-hanging-order: A posted order declares that any civilian caught interfering with the railroad, its bridges, tunnels, or trains will be summarily hanged.; initial holders: char-federal-scout

Fact fact-driftwood-dry: Dry driftwood is lodged against the wooden pier at the near end of the bridge and would burn like tinder.; initial holders: char-federal-scout

Causal causal-scout-intel-to-hanging: earlier cause scene-plantation-visit → effect scene-hanging-preparation

Setup setup-driftwood-tinder at scene-plantation-visit: The scout mentions dry driftwood lodged against the bridge pier that would burn like tinder, planting the means of sabotage.

Setup setup-hanging-order at scene-plantation-visit: The posted order that any civilian interfering with the railroad will be summarily hanged establishes the penalty Farquhar later suffers.

Reveal reveal-scout-identity: fact fact-scout-is-federal at scene-plantation-visit; holders: char-peyton-farquhar (acquired at scene start)

Reveal reveal-bridge-defenses: fact fact-bridge-defenses at scene-plantation-visit; holders: char-peyton-farquhar (acquired at scene start)

Reveal reveal-hanging-order: fact fact-hanging-order at scene-plantation-visit; holders: char-peyton-farquhar (acquired at scene start)

Reveal reveal-driftwood-dry: fact fact-driftwood-dry at scene-plantation-visit; holders: char-peyton-farquhar (acquired at scene start)

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7052,"end":8742}

Beat beat-visit-arrival evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7052,"end":7421}

Beat beat-visit-intel evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":7423,"end":8057}

Beat beat-visit-driftwood evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8059,"end":8473}

Beat beat-visit-reveal evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8475,"end":8742}

## scene-hanging-preparation: Preparations on the bridge

On a railroad bridge in northern Alabama a bound civilian stands with a noose at his neck, guarded by two privates, a sergeant, a captain, and two sentinels, with an infantry company and a cannon on the far bank. The privates withdraw their planks; the sergeant takes the captain's place holding the plank that will tilt at a signal. The condemned man looks at the water and driftwood, closes his eyes, and hears a metallic ticking that is his watch. He imagines freeing his hands and escaping to his family; the captain nods and the sergeant steps aside.

Present: char-peyton-farquhar, char-captain, char-sergeant

Beat beat-bridge-tableau: A bound man with a rope around his neck stands on loose boards over the ties, surrounded by two privates, a sergeant, an armed captain, and two sentinels at the bridge ends.

Beat beat-bridge-spectators: Across the stream an infantry company stands at parade rest before a stockaded fort with a brass cannon; the captain watches silently, and the narration frames the stillness as military deference to death.

Beat beat-bridge-condemned-described: The condemned man is described as a civilian of about thirty-five, planter-like in dress, with a kindly expression unsuited to one whose neck is in the hemp.

Beat beat-bridge-plank-set: The privates draw away their planks; the sergeant salutes and takes position behind the captain, and the condemned man and sergeant now stand on opposite ends of the same plank, which will tilt at a signal.

Beat beat-bridge-watch-ticking: Closing his eyes to think of his wife and children, he is distracted by a regular metallic percussion that grows slower and sharper until he recognizes it as the ticking of his watch.

Beat beat-bridge-escape-fantasy: He imagines freeing his hands, diving to evade bullets, and reaching his home, which he believes lies outside the enemy's lines.

Beat beat-bridge-signal: The captain nods to the sergeant, and the sergeant steps aside.

Causal causal-scout-intel-to-hanging: earlier cause scene-plantation-visit → effect scene-hanging-preparation

Causal causal-signal-to-fall: earlier cause scene-hanging-preparation → effect scene-fall-and-river

Setup setup-plank-tilt at scene-hanging-preparation: The plank held by the sergeant's weight will tilt when he steps aside at the captain's signal.

Knowledge use use-intel-farquhar: char-peyton-farquhar uses fact fact-bridge-defenses at scene-hanging-preparation

Knowledge use use-order-farquhar: char-peyton-farquhar uses fact fact-hanging-order at scene-hanging-preparation

Knowledge use use-driftwood-farquhar: char-peyton-farquhar uses fact fact-driftwood-dry at scene-hanging-preparation

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":6000}

Beat beat-bridge-tableau evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":1139}

Beat beat-bridge-spectators evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":1141,"end":2504}

Beat beat-bridge-condemned-described evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":2506,"end":3209}

Beat beat-bridge-plank-set evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3211,"end":4355}

Beat beat-bridge-watch-ticking evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4357,"end":5412}

Beat beat-bridge-escape-fantasy evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":5414,"end":5806}

Beat beat-bridge-signal evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":5808,"end":6000}

## scene-farquhar-background: Peyton Farquhar's background and devotion to the Southern cause

Narration identifies the condemned man as Peyton Farquhar, a well-to-do Alabama planter and slave owner, an original secessionist kept from military service by unspecified circumstances, who longs for distinction and undertakes what service he can for the South.

Present: char-peyton-farquhar

Beat beat-background-identity: Farquhar is a prosperous planter of an old Alabama family, a slave owner and secessionist ardently devoted to the Southern cause.

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":6002,"end":7050}

Beat beat-background-identity evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":6002,"end":7050}

## scene-fall-and-river: The imagined fall, river escape and flight downstream

In Farquhar’s imagined escape, the rope appears to break and he experiences the following events: Farquhar falls through the bridge and loses consciousness; he awakens to strangling pain, then cold and darkness as the rope breaks and he sinks. Thought returns; he rises, frees his hands, tears off the noose, and surfaces in agony. His senses become preternaturally sharp. He sees the bridge and his executioners, is shot at and missed, dives under a volley, surfaces farther downstream, is near-missed by cannon fire, and is caught in a vortex that flings him onto the southern bank, where he rejoices in the sand and trees.

Present: char-peyton-farquhar, char-captain, char-sergeant, char-lieutenant

Beat beat-fall-unconscious: Falling through the bridge, he loses consciousness and seems to die; pain and suffocation return without thought, then a splash, cold, and darkness restore thought, and he knows the rope broke and he is in the stream.

Beat beat-hands-free-noose-off: His hands free themselves and tear away the noose despite his protest; he surfaces, blinded by sunlight, and draws a great breath in a shriek.

Beat beat-senses-exalted: His physical senses become preternaturally keen, registering ripples, leaves, insects, dewdrops, and the sounds of the water and air as music.

Beat beat-executioners-sighted: Turning in the water, he sees the bridge, fort, and his executioners silhouetted; they shout and point, the captain draws a pistol but does not fire.

Beat beat-rifle-miss: A shot strikes the water near his head; a sentinel fires, and looking through the sights he notes the man's gray eye and that the shot missed.

Beat beat-volley-command: A swirl turns him; he hears the lieutenant's drawn-out chant of command across the water.

Beat beat-dive-volley: He dives deep; the volley thunders and flattened metal bits drift down past him, one lodging warm against his neck before he snatches it out.

Beat beat-reload-and-reason: He surfaces farther downstream, sees the soldiers reloading and the sentinels fire ineffectually, and reasons that the officer will order fire at will.

Beat beat-cannon-fire: A splash and rushing sound precede an explosion; a sheet of water blinds and strangles him as the cannon fires, and the deflected shot smashes branches in the forest. He judges the next charge will be grape and resolves to watch the gun.

Beat beat-vortex-landing: Whirled in a vortex, he is flung onto the gravel of the southern bank behind a concealing point; he weeps with delight, blesses the sand, and finds the trees and light enchanting, content to remain until retaken.

Causal causal-signal-to-fall: earlier cause scene-hanging-preparation → effect scene-fall-and-river

Payoff payoff-plank-tilt: setup setup-plank-tilt → payoff at scene-fall-and-river

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8744,"end":18263}

Beat beat-fall-unconscious evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8744,"end":10720}

Beat beat-hands-free-noose-off evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":10722,"end":12132}

Beat beat-senses-exalted evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":12134,"end":13103}

Beat beat-executioners-sighted evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":13105,"end":13606}

Beat beat-rifle-miss evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":13608,"end":14159}

Beat beat-volley-command evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":14161,"end":14944}

Beat beat-dive-volley evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":14946,"end":15385}

Beat beat-reload-and-reason evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":15387,"end":16205}

Beat beat-cannon-fire evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16207,"end":16992}

Beat beat-vortex-landing evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16994,"end":18263}

## scene-flight-through-woods: The imagined journey through the forest

The imagined escape continues: Grapeshot in the branches rouses him; he climbs the bank and enters the forest. He travels all day by the sun through an interminable, uncanny forest, and by nightfall, fatigued and famished, finds a wide untraveled road under unfamiliar stars, hearing whispers in an unknown tongue. His neck is swollen and black, his eyes congested, his tongue swollen with thirst, and he can no longer feel the road beneath his feet.

Present: char-peyton-farquhar

Beat beat-grapeshot-farewell: A whiz and rattle of grapeshot overhead rouses him from his dream; he springs up the bank and plunges into the forest.

Beat beat-day-travel: He travels all day by the sun through an interminable forest with no break or woodman's road, finding the wildness uncanny.

Beat beat-night-road: By nightfall, driven by thoughts of his wife and children, he finds a wide, straight, untraveled road under unfamiliar golden stars he believes have a malign order, and hears whispers in an unknown tongue.

Beat beat-bodily-symptoms: His neck is horribly swollen with a black circle, his eyes cannot close, his tongue is swollen with thirst, and he can no longer feel the roadway under his feet.

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":18265,"end":20077}

Beat beat-grapeshot-farewell evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":18265,"end":18498}

Beat beat-day-travel evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":18500,"end":18761}

Beat beat-night-road evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":18763,"end":19643}

Beat beat-bodily-symptoms evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":19645,"end":20077}

## scene-homecoming-and-death: The homecoming vision and the revealed death

In the final moments of his imagined escape, he seems to reach his gate and see his wife coming to meet him. As he springs toward her, a blow to the neck, a blaze of light, darkness and silence end the experience. The final paragraph reveals that he has actually been hanged: his body, with a broken neck, swings beneath Owl Creek bridge.

Present: char-peyton-farquhar, char-mrs-farquhar

Beat beat-homecoming-vision: He seems to arrive at his home in morning light, sees his wife waiting with joy at the steps, and springs forward to clasp her.

Beat beat-death-revealed: A stunning blow and blinding light end in darkness; narration declares Peyton Farquhar dead, his broken-necked body swinging beneath the bridge timbers.

Payoff payoff-hanging-order: setup setup-hanging-order → payoff at scene-homecoming-and-death

Evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20079,"end":21086}

Beat beat-homecoming-vision evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20079,"end":20953}

Beat beat-death-revealed evidence: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20955,"end":21086}

State state-farquhar-alive [scene-hanging-preparation] char-peyton-farquhar canon alive: known: alive; confidence 0.95; alternatives: (none recorded) → known: alive; confidence 0.95; alternatives: (none recorded)

State state-farquhar-consciousness [scene-fall-and-river] char-peyton-farquhar belief survival_experience: unknown: (no asserted value); confidence unrecorded; alternatives: (none recorded) → known: He experiences surviving the fall and escaping through the river.; confidence unrecorded; alternatives: (none recorded)

State state-farquhar-death [scene-homecoming-and-death] char-peyton-farquhar canon alive: ambiguous: alive; confidence 0.5; alternatives: alive and escaping; already dead during the river sequence → known: dead; confidence 0.95; alternatives: (none recorded)

Relationship rel-farquhars-marriage [scene-homecoming-and-death] char-peyton-farquhar, char-mrs-farquhar marital_affection: known: separated by war, longing; confidence 0.8; alternatives: (none recorded) → ambiguous: reunion imagined in dying vision; confidence 0.6; alternatives: actual reunion; delirious fantasy

Constraint constraint-death-ending: satisfied; required_ending char-peyton-farquhar canon alive; expected 'dead'; The final paragraph explicitly states Farquhar is dead with a broken neck.

arcs arc-farquhar-fate [scene-plantation-visit, scene-hanging-preparation, scene-fall-and-river, scene-flight-through-woods, scene-homecoming-and-death] interpretation: A condemned man's escape is narrated in vivid detail and then revealed as occurring within the moment of his execution.; status=known; confidence=0.85

Alternative readings: the escape is literally real until the final blow; the escape is a supernatural or hallucinatory experience

Arc character: char-peyton-farquhar

agency trajectory arc-farquhar-fate: 1 → 2 → 3 → 3 → 0; shape=peak; scenes=scene-plantation-visit → scene-hanging-preparation → scene-fall-and-river → scene-flight-through-woods → scene-homecoming-and-death; ordinal 0-4

reader_affect affect-suspense-escape [scene-fall-and-river, scene-flight-through-woods] interpretation: Suspense and hope as the escape seems to succeed, sharpened by repeated near-misses.; status=known; confidence=0.75

Alternative readings: detached irony for a reader who suspects the escape is illusory

Evidence affect-suspense-escape: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8744,"end":20077}

mood trajectory affect-suspense-escape: 2 → 3 → 4; shape=rising; scenes=scene-fall-and-river → scene-flight-through-woods → scene-homecoming-and-death; ordinal 0-4

reader_affect affect-reversal-shock [scene-homecoming-and-death] interpretation: The abrupt final revelation produces shock and a retrospective rereading of the escape as illusion.; status=known; confidence=0.8

Alternative readings: the ending reads as grim confirmation rather than surprise

Evidence affect-reversal-shock: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20079,"end":21086}

mood trajectory affect-reversal-shock: 1 → 2 → 4; shape=peak; scenes=scene-fall-and-river → scene-flight-through-woods → scene-homecoming-and-death; ordinal 0-4

tension tension-escape-vs-capture [scene-fall-and-river, scene-flight-through-woods] interpretation: Tension oscillates between the escape's apparent success and the pursuing fire and uncanny landscape.; status=known; confidence=0.8

Alternative readings: tension is undercut by cues that the escape is unreal

Evidence tension-escape-vs-capture: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":13105,"end":20077}

tension trajectory tension-escape-vs-capture: 3 → 2 → 4; shape=oscillating; scenes=scene-fall-and-river → scene-flight-through-woods → scene-homecoming-and-death; ordinal 0-4

themes theme-death-deference [scene-hanging-preparation] interpretation: Military ritual and stillness frame death as a dignitary to be received with formal deference.; status=known; confidence=0.8

Evidence theme-death-deference: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":1141,"end":2504}

themes theme-illusion-of-escape [scene-fall-and-river, scene-flight-through-woods, scene-homecoming-and-death] interpretation: The elaborate escape may be the mind's final construction against an inescapable death.; status=ambiguous; confidence=0.7

Alternative readings: the escape is a literal sequence interrupted only at the end; the escape is a supernatural deliverance

Evidence theme-illusion-of-escape: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8744,"end":21086}

themes theme-war-and-civilian [scene-plantation-visit, scene-hanging-preparation] interpretation: A civilian's partisan zeal is met by the harsh military code he is warned about.; status=known; confidence=0.75

Evidence theme-war-and-civilian: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":6002,"end":8473}

motifs motif-water-driftwood [scene-hanging-preparation, scene-fall-and-river] observation: Driftwood and the swirling stream recur from the condemned man's view on the bridge to his passage through the water.; status=known; confidence=0.8

Evidence motif-water-driftwood: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3211,"end":4355}

motifs motif-driftwood-tinder [scene-plantation-visit] observation: Dry driftwood at the pier is named as ready fuel for sabotage.; status=known; confidence=0.85

Evidence motif-driftwood-tinder: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8235,"end":8473}

motifs motif-neck-rope [scene-hanging-preparation, scene-fall-and-river, scene-flight-through-woods] observation: The rope and the injured neck recur from the noose on the bridge to the noose torn away underwater and the swollen blackened neck on the road.; status=known; confidence=0.85

Evidence motif-neck-rope: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":0,"end":1139}

motifs motif-neck-bruise [scene-flight-through-woods] observation: His neck is swollen with a black circle where the rope bruised it.; status=known; confidence=0.9

Evidence motif-neck-bruise: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":19645,"end":20077}

motifs motif-wife-children [scene-hanging-preparation, scene-flight-through-woods, scene-homecoming-and-death] observation: Thoughts of wife and children recur as the condemned man's sustaining focus and as the goal of his flight.; status=known; confidence=0.8

Evidence motif-wife-children: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4357,"end":5412}

motifs motif-wife-vision [scene-homecoming-and-death] observation: His wife appears at the steps in the homecoming vision just before the blow.; status=known; confidence=0.85

Evidence motif-wife-vision: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20079,"end":20953}

discourse discourse-flashback-background [scene-farquhar-background, scene-plantation-visit] observation: The narration interrupts the hanging with an extended backstory and an earlier plantation scene, presenting them after the execution signal has been given.; status=known; confidence=0.9

Evidence discourse-flashback-background: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":5808,"end":8742}

discourse discourse-subjective-escape [scene-fall-and-river, scene-flight-through-woods, scene-homecoming-and-death] interpretation: The apparent river escape, forest journey and return to his wife occur in Farquhar’s imagination in the moments before he dies. The final paragraph reveals the actual hanging and changes how the preceding experience is understood.; status=known; confidence=unrecorded

Evidence discourse-subjective-escape: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8744,"end":21086}

discourse discourse-time-dilation [scene-hanging-preparation, scene-fall-and-river] interpretation: The watch's ticking and the sense of ages passing compress or expand time, framing the escape as occurring within a brief interval.; status=known; confidence=0.7

Alternative readings: time dilation is merely a physiological effect of strangulation

Evidence discourse-time-dilation: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":4357,"end":5412}

subtext subtext-scout-trap [scene-plantation-visit] interpretation: The scout's casual mention of the driftwood may be a deliberate lure drawing Farquhar to attempt sabotage and be hanged.; status=ambiguous; confidence=0.6

Alternative readings: the scout merely answers questions without intent to entrap; the driftwood detail is incidental local color

Evidence subtext-scout-trap: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":8059,"end":8742}

subtext subtext-escape-as-consolation [scene-fall-and-river, scene-homecoming-and-death] interpretation: The escape may be read as the mind's merciful consolation, granting the dying man home and family before death.; status=ambiguous; confidence=0.65

Alternative readings: the escape is a literal event cut short; the escape is a supernatural or providential deliverance

Evidence subtext-escape-as-consolation: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":16994,"end":21086}

Motif echo echo-driftwood-water-to-tinder: motif-driftwood-tinder → motif-water-driftwood (transformation)

Evidence echo-driftwood-water-to-tinder: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":3211,"end":4355}

Motif echo echo-rope-to-bruise: motif-neck-rope → motif-neck-bruise (repetition)

Evidence echo-rope-to-bruise: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":19645,"end":20077}

Motif echo echo-family-to-wife-vision: motif-wife-children → motif-wife-vision (transformation)

Evidence echo-family-to-wife-vision: {"source_id":"source-owl-creek-bridge","source_sha256":"e60b1e4cd31eaf09be281789d64aff4c0cbc66a634b66b0cb15aa5dfdc31c064","start":20079,"end":20953}

advisory unpaid_setup [setup-driftwood-tinder]: setup setup-driftwood-tinder at scene-plantation-visit has no payoff
