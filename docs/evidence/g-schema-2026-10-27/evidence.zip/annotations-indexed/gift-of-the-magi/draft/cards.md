# The Gift of the Magi

Plan gift-of-the-magi-annotation; schema 1; tier L

Character char-della: Della (Mrs. James Dillingham Young)

Character char-jim: Jim (Mr. James Dillingham Young)

Character char-madame-sofronie: Mme. Sofronie

## scene-pennies-and-flat: Counting pennies in the shabby flat

On Christmas Eve Della counts $1.87, mostly pennies saved by hard bargaining, and despairs on the couch. The narrator surveys the $8 furnished flat and the vestibule card naming Mr. James Dillingham Young, explaining the family's reduced income and Della's months of saving toward a gift for Jim.

Present: char-della

Beat beat-count-pennies: Della counts her savings three times: one dollar and eighty-seven cents, sixty of it in pennies, the day before Christmas.

Beat beat-della-howls: With nothing else to do, Della flops on the shabby couch and cries.

Beat beat-flat-survey: The narrator describes the $8-per-week furnished flat and the vestibule with its useless letter-box, dead bell, and card for Mr. James Dillingham Young.

Beat beat-income-shrunk: The narrator notes the income fell from $30 to $20 a week, yet Jim is still greeted as Jim and hugged by Della.

Beat beat-only-187: Della looks out at a gray cat and gray backyard, lamenting that she has only $1.87 to buy Jim something fine and rare after months of saving.

Fact fact-jim-sold-watch: Jim sold his gold watch to buy Della the combs.; initial holders: char-jim

Fact fact-della-sold-hair: Della cut off and sold her hair to buy Jim a present.; initial holders: char-della

Causal causal-poverty-to-selling-hair: earlier cause scene-pennies-and-flat → effect scene-selling-hair

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":2232}

Beat beat-count-pennies evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":386}

Beat beat-della-howls evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":388,"end":606}

Beat beat-flat-survey evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":608,"end":1094}

Beat beat-income-shrunk evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1096,"end":1556}

Beat beat-only-187 evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1558,"end":2232}

## scene-hair-and-watch: The two treasures and the decision

Della studies herself in the pier glass, then lets down her hair. The narrator names the couple's two prized possessions—Jim's heirloom gold watch and Della's hair—and describes the hair's beauty before Della, tearful but resolved, puts it up, dons her old jacket and hat, and hurries out.

Present: char-della

Beat beat-pier-glass: Della, slender and practiced, uses the strip-mirror pier glass to view herself.

Beat beat-lets-down-hair: Della whirls from the window, her eyes shining but her face pale, and lets her hair fall to full length.

Beat beat-two-possessions: The narrator identifies the couple's two prides: Jim's inherited gold watch and Della's hair, hyperbolically outshining the queen of Sheba and King Solomon.

Beat beat-tear-on-carpet: Della's cascading hair reaches below her knee; she puts it up nervously, faltering as a tear or two falls on the worn carpet.

Beat beat-out-the-door: Della puts on her old brown jacket and hat and flutters out to the street.

Setup setup-two-treasures at scene-hair-and-watch: The narrator establishes Jim's heirloom watch and Della's hair as the couple's two great possessions, each later sacrificed.

Setup setup-combs-coveted at scene-hair-and-watch: The narrator establishes Della's hair as her prized possession, the very thing the combs are meant to adorn.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2234,"end":3855}

Beat beat-pier-glass evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2234,"end":2544}

Beat beat-lets-down-hair evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2546,"end":2769}

Beat beat-two-possessions evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2771,"end":3343}

Beat beat-tear-on-carpet evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3345,"end":3662}

Beat beat-out-the-door evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3664,"end":3855}

## scene-selling-hair: Selling her hair to Mme. Sofronie

Della climbs to Mme. Sofronie's hair-goods shop, asks her to buy her hair, and accepts twenty dollars, urging haste.

Present: char-della, char-madame-sofronie

Beat beat-shop-sign: Della stops at the sign for Mme. Sofronie, Hair Goods of All Kinds, runs up a flight, and faces the large, chilly Madame.

Beat beat-offer-twenty: Della asks if Madame will buy her hair; Madame has her remove her hat, examines the hair, and offers twenty dollars, which Della accepts at once.

Causal causal-poverty-to-selling-hair: earlier cause scene-pennies-and-flat → effect scene-selling-hair

Causal causal-selling-hair-to-buying-chain: earlier cause scene-selling-hair → effect scene-buying-chain

Causal causal-selling-hair-to-jims-stare: earlier cause scene-selling-hair → effect scene-jims-return

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3857,"end":4321}

Beat beat-shop-sign evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":3857,"end":4052}

Beat beat-offer-twenty evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4054,"end":4321}

## scene-buying-chain: Buying the platinum fob chain

Della spends two hours searching the stores and finds a platinum fob chain worthy of Jim's watch, buying it for twenty-one dollars and returning home with eighty-seven cents.

Present: char-della

Beat beat-ransacking-stores: Della spends two hours ransacking stores for Jim's present.

Beat beat-finds-chain: Della finds a simple platinum fob chain that seems made for Jim and his watch; it costs twenty-one dollars, leaving her eighty-seven cents.

Causal causal-selling-hair-to-buying-chain: earlier cause scene-selling-hair → effect scene-buying-chain

Setup setup-chain-for-watch at scene-buying-chain: Della buys a fob chain specifically to adorn Jim's watch, setting up the expectation that the watch will be shown.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4323,"end":5255}

Beat beat-ransacking-stores evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4323,"end":4452}

Beat beat-finds-chain evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":4454,"end":5255}

## scene-curling-hair: Repairing the ravages at home

Home again, Della curls her shorn hair with irons, studies the result, and jokes nervously to herself about how Jim will react. She sets the coffee and chops ready for his return.

Present: char-della

Beat beat-curls: Della lights the gas, uses her curling irons, and within forty minutes has tiny close-lying curls; she examines herself critically.

Beat beat-self-tease: Della tells herself Jim may say she looks like a chorus girl, and asks what else she could do with $1.87.

Beat beat-supper-ready: At seven the coffee is made and the frying-pan is hot, ready for the chops.

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5257,"end":6060}

Beat beat-curls evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5257,"end":5730}

Beat beat-self-tease evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5732,"end":5945}

Beat beat-supper-ready evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":5947,"end":6060}

## scene-jims-return: Jim's return and his strange stare

Della waits with the doubled chain, prays to still look pretty, and Jim enters looking thin and serious. He stops, staring at her with an expression she cannot read and that terrifies her.

Present: char-della, char-jim

Beat beat-waiting-prayer: Della waits by the door with the chain, hears Jim's step, turns white, and silently prays that he will think she is still pretty.

Beat beat-jim-enters: Jim enters and closes the door, thin and serious at twenty-two, needing an overcoat and gloves.

Beat beat-unreadable-stare: Jim stops as if frozen, fixing on Della an expression that is neither anger nor surprise nor disapproval nor horror, and she is terrified.

Causal causal-selling-hair-to-jims-stare: earlier cause scene-selling-hair → effect scene-jims-return

Causal causal-jims-stare-to-explanation: earlier cause scene-jims-return → effect scene-explanation-and-embrace

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6062,"end":7051}

Beat beat-waiting-prayer evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6062,"end":6458}

Beat beat-jim-enters evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6460,"end":6664}

Beat beat-unreadable-stare evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6666,"end":7051}

## scene-explanation-and-embrace: Della explains; Jim embraces her

Della goes to Jim and explains she cut and sold her hair to buy his present, insisting it will grow back and asking him to be happy. Jim slowly grasps that her hair is gone, looks about the room, and then wakes from his trance and embraces her.

Present: char-della, char-jim

Beat beat-della-explains: Della pleads with Jim not to look that way, explains she sold her hair for his present, and asks him to say Merry Christmas.

Beat beat-jim-slow: Jim laboriously repeats that she has cut off her hair, then looks about the room and asks again whether her hair is gone.

Beat beat-love-counted: Della tells him not to look for the hair, says it went for him, and that no one could count her love for him.

Beat beat-embrace: Jim wakes from his trance and enfolds Della; the narrator digresses on the magi and promises later illumination.

Causal causal-jims-stare-to-explanation: earlier cause scene-jims-return → effect scene-explanation-and-embrace

Setup setup-narrator-promise at scene-explanation-and-embrace: The narrator's aside that the magi's gift was not among their valuables promises later illumination.

Reveal reveal-della-hair-to-jim: fact fact-della-sold-hair at scene-explanation-and-embrace; holders: char-jim (acquired at scene start)

Knowledge use use-della-hair: char-della uses fact fact-della-sold-hair at scene-explanation-and-embrace

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7053,"end":8560}

Beat beat-della-explains evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7053,"end":7482}

Beat beat-jim-slow evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7484,"end":7842}

Beat beat-love-counted evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":7844,"end":8150}

Beat beat-embrace evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8152,"end":8560}

## scene-the-combs: The combs

Jim tosses a package on the table and tells Della to unwrap it. Inside are the tortoise-shell combs she had long coveted, now useless for her shorn hair; she weeps, then hugs them and says her hair grows fast.

Present: char-della, char-jim

Beat beat-package: Jim draws a package from his overcoat and throws it on the table, reassuring Della that no haircut could make him like her less.

Beat beat-combs-revealed: Della tears open the package, screams with joy, then weeps: the beautiful tortoise-shell combs she had worshipped are hers, but her hair is gone.

Beat beat-hugs-combs: Della hugs the combs and, with dim eyes and a smile, says her hair grows so fast.

Causal causal-jim-sold-watch-to-combs: earlier cause scene-the-combs → effect scene-the-chain-and-revelation

Payoff payoff-combs-to-hair: setup setup-combs-coveted → payoff at scene-the-combs

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8562,"end":9740}

Beat beat-package evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8562,"end":8894}

Beat beat-combs-revealed evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8896,"end":9602}

Beat beat-hugs-combs evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":9604,"end":9740}

## scene-the-chain-and-revelation: The chain, and Jim's revelation

Della leaps up and presents the platinum chain, asking for Jim's watch. Instead Jim lies back on the couch, smiles, and reveals he sold the watch to buy the combs, suggesting they put the presents away and eat.

Present: char-della, char-jim

Beat beat-presents-chain: Della eagerly holds out the chain and asks Jim to give her his watch so she can see how it looks.

Beat beat-jim-reveals: Jim lies back smiling and says he sold the watch to buy her combs, proposing they keep the presents awhile and she put the chops on.

Causal causal-jim-sold-watch-to-combs: earlier cause scene-the-combs → effect scene-the-chain-and-revelation

Payoff payoff-chain-to-watch: setup setup-chain-for-watch → payoff at scene-the-chain-and-revelation

Reveal reveal-jim-watch-to-della: fact fact-jim-sold-watch at scene-the-chain-and-revelation; holders: char-della (acquired at scene start)

Knowledge use use-jim-watch: char-jim uses fact fact-jim-sold-watch at scene-the-chain-and-revelation

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":9742,"end":10493}

Beat beat-presents-chain evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":9742,"end":10173}

Beat beat-jim-reveals evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":10493}

## scene-narrator-coda: The narrator's coda on the magi

The narrator compares the couple to the magi who brought gifts to the manger, calls them foolish yet the wisest of gift-givers, and declares them the magi.

Present: (none recorded)

Beat beat-magi-coda: The narrator contrasts the wise magi with the 'two foolish children' and concludes that of all who give and receive gifts, these two are wisest.

Payoff payoff-promise-to-coda: setup setup-narrator-promise → payoff at scene-narrator-coda

Evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

Beat beat-magi-coda evidence: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

State state-della-savings [scene-pennies-and-flat] char-della canon money_saved: unknown: (no asserted value); confidence unrecorded; alternatives: (none recorded) → known: $1.87; confidence 0.98; alternatives: (none recorded)

State state-della-goal-gift [scene-pennies-and-flat] char-della goal buy_jim_gift: known: seeking a gift worthy of Jim; confidence 0.9; alternatives: (none recorded) → known: resolved to sell her hair to fund the gift; confidence 0.85; alternatives: resolve is implied rather than stated

State state-della-hair [scene-selling-hair] char-della canon hair_length: known: below the knee; confidence 0.95; alternatives: (none recorded) → known: cut short; confidence 0.95; alternatives: (none recorded)

State state-della-money-after-sale [scene-selling-hair] char-della canon money_saved: known: $1.87; confidence 0.95; alternatives: (none recorded) → known: $21.87; confidence 0.9; alternatives: exact total not stated; inferred from $1.87 plus $20

State state-della-money-after-chain [scene-buying-chain] char-della canon money_saved: known: $21.87; confidence 0.9; alternatives: (none recorded) → known: $0.87; confidence 0.95; alternatives: (none recorded)

Relationship rel-della-jim-love [scene-explanation-and-embrace] char-della, char-jim mutual_affection: ambiguous: affectionate but strained by Jim's unreadable reaction; confidence 0.6; alternatives: Jim's shock may read as dismay; Jim's shock may read as stunned comprehension → known: reaffirmed affection after Jim embraces Della; confidence 0.85; alternatives: (none recorded)

State state-jim-watch [scene-the-chain-and-revelation] char-jim canon watch_ownership: known: owns the heirloom watch; confidence 0.95; alternatives: (none recorded) → known: sold the watch; confidence 0.95; alternatives: (none recorded)

arcs arc-della-sacrifice [scene-pennies-and-flat, scene-hair-and-watch, scene-selling-hair, scene-buying-chain, scene-curling-hair, scene-jims-return, scene-explanation-and-embrace] interpretation: Della moves from despair over insufficient money to a costly sacrifice for Jim's gift; status=known; confidence=0.85

Evidence arc-della-sacrifice: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1558,"end":5255}

Arc character: char-della

agency trajectory arc-della-sacrifice: 1 → 3 → 4; shape=rising; scenes=scene-pennies-and-flat → scene-selling-hair → scene-buying-chain; ordinal 0-4

arcs arc-ironic-exchange [scene-the-combs, scene-the-chain-and-revelation, scene-narrator-coda] interpretation: Each gift proves useless because the recipient sold the very thing it was meant to adorn, turning sacrifice into ironic symmetry; status=known; confidence=0.9

Alternative readings: Read as tragic waste rather than wise love

Evidence arc-ironic-exchange: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8896,"end":10493}

agency trajectory arc-ironic-exchange: 2 → 4 → 3; shape=peak; scenes=scene-the-combs → scene-the-chain-and-revelation → scene-narrator-coda; ordinal 0-4

reader_affect affect-dread-at-stare [scene-jims-return] interpretation: Suspense and dread as Jim's unreadable stare is filtered through Della's terror; status=known; confidence=0.8

Alternative readings: Curiosity about the cause of Jim's shock

Evidence affect-dread-at-stare: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6666,"end":7051}

mood trajectory affect-dread-at-stare: 1 → 4 → 2; shape=rising; scenes=scene-curling-hair → scene-jims-return → scene-explanation-and-embrace; ordinal 0-4

reader_affect affect-bittersweet-coda [scene-the-combs, scene-the-chain-and-revelation, scene-narrator-coda] interpretation: Bittersweet poignancy at the mutual uselessness of the gifts, resolved by the narrator's praise of the couple's wisdom; status=known; confidence=0.8

Alternative readings: Sentimental uplift; Irony tinged with loss

Evidence affect-bittersweet-coda: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":11166}

mood trajectory affect-bittersweet-coda: 1 → 0 → 3; shape=valley; scenes=scene-the-combs → scene-the-chain-and-revelation → scene-narrator-coda; ordinal 0-4

tension tension-money-vs-gift [scene-pennies-and-flat, scene-hair-and-watch, scene-selling-hair] interpretation: Della's meager savings conflict with her desire for a gift worthy of Jim, driving her to sell her hair; status=known; confidence=0.9

Evidence tension-money-vs-gift: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1558,"end":4321}

tension trajectory tension-money-vs-gift: 2 → 3 → 4; shape=rising; scenes=scene-pennies-and-flat → scene-hair-and-watch → scene-selling-hair; ordinal 0-4

tension tension-unreadable-stare [scene-jims-return, scene-explanation-and-embrace] interpretation: Jim's inexplicable reaction creates suspense until his embrace relieves it; status=known; confidence=0.85

Alternative readings: His reaction may signal displeasure rather than shock

Evidence tension-unreadable-stare: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6666,"end":8560}

tension trajectory tension-unreadable-stare: 1 → 4 → 1; shape=peak; scenes=scene-curling-hair → scene-jims-return → scene-explanation-and-embrace; ordinal 0-4

themes theme-sacrificial-love [scene-selling-hair, scene-buying-chain, scene-the-combs, scene-the-chain-and-revelation, scene-narrator-coda] interpretation: Love expressed through costly sacrifice, valued above the material worth of gifts; status=known; confidence=0.9

Alternative readings: Love as imprudent self-deprivation

Evidence theme-sacrificial-love: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

themes theme-wisdom-of-folly [scene-narrator-coda] interpretation: The narrator revalues apparent foolishness as the truest wisdom in giving; status=known; confidence=0.85

Alternative readings: Ironic praise that undercuts the couple

Evidence theme-wisdom-of-folly: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

motifs motif-hair-long [scene-hair-and-watch] observation: Della's long hair as a prized possession, displayed and mourned before it is cut; status=known; confidence=0.9

Evidence motif-hair-long: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2771,"end":3343}

motifs motif-hair-gone [scene-the-combs] observation: Della's vanished hair, now the reason the combs cannot be worn; status=known; confidence=0.9

Evidence motif-hair-gone: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":9152,"end":9602}

motifs motif-watch-prized [scene-hair-and-watch] observation: Jim's heirloom gold watch as the couple's other great treasure; status=known; confidence=0.9

Evidence motif-watch-prized: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2771,"end":3343}

motifs motif-watch-sold [scene-the-chain-and-revelation] observation: Jim's watch revealed as sold, making the new chain useless; status=known; confidence=0.9

Evidence motif-watch-sold: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":10493}

motifs motif-money-counting [scene-pennies-and-flat, scene-buying-chain] observation: Precise sums of money recur, marking scarcity and sacrifice; status=known; confidence=0.85

Evidence motif-money-counting: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":0,"end":386}

motifs motif-magi-invoked [scene-explanation-and-embrace] observation: The magi frame gift-giving, invoked mid-story as a promise of illumination; status=known; confidence=0.85

Evidence motif-magi-invoked: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":8152,"end":8560}

motifs motif-magi-coda [scene-narrator-coda] observation: The magi return in the coda as the narrator's final comparison for the couple; status=known; confidence=0.85

Evidence motif-magi-coda: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

discourse discourse-narrator-intrusion [scene-pennies-and-flat, scene-explanation-and-embrace, scene-narrator-coda] observation: A chatty, ironic first-person narrator addresses the reader directly, digresses, and frames the tale with moral commentary; status=known; confidence=0.9

Evidence discourse-narrator-intrusion: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":388,"end":606}

discourse discourse-flashback-income [scene-pennies-and-flat] observation: The narrator's account of the earlier $30-per-week prosperity is presented as backstory within the present Christmas Eve scene; status=known; confidence=0.85

Evidence discourse-flashback-income: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":1096,"end":1556}

discourse discourse-hypothetical-queen-solomon [scene-hair-and-watch] observation: The queen of Sheba and King Solomon appear only in counterfactual hyperbole, not as events in the story world; status=known; confidence=0.9

Evidence discourse-hypothetical-queen-solomon: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":2771,"end":3343}

discourse discourse-della-subjective-fear [scene-jims-return] interpretation: Jim's expression is rendered through Della's unreadable, terrified perception rather than objective narration; status=ambiguous; confidence=0.7

Alternative readings: The narrator reports Jim's inner state obliquely; Jim's feeling is genuinely withheld from all

Evidence discourse-della-subjective-fear: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":6666,"end":7051}

subtext subtext-gifts-as-love [scene-the-combs, scene-the-chain-and-revelation] interpretation: The now-useless gifts signify the depth of each partner's love more than their practical use; status=known; confidence=0.85

Alternative readings: The gifts signify the futility of material planning against poverty

Evidence subtext-gifts-as-love: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":10493}

subtext subtext-jims-smile [scene-the-chain-and-revelation] interpretation: Jim's smile and casual tone may mask resignation or may express genuine acceptance of the irony; status=ambiguous; confidence=0.5

Alternative readings: Resigned defeat; Warm acceptance; Suppressed disappointment

Evidence subtext-jims-smile: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":10493}

Motif echo echo-hair-to-combs: motif-hair-long → motif-hair-gone (transformation)

Evidence echo-hair-to-combs: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":9152,"end":9602}

Motif echo echo-watch-to-chain: motif-watch-prized → motif-watch-sold (transformation)

Evidence echo-watch-to-chain: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10175,"end":10493}

Motif echo echo-magi-to-coda: motif-magi-invoked → motif-magi-coda (repetition)

Evidence echo-magi-to-coda: {"source_id":"source-gift-of-the-magi","source_sha256":"6bc777e811313e1625244a600f07d823450ab7b37ae896e52e5774a256462ac2","start":10495,"end":11166}

advisory unpaid_setup [setup-two-treasures]: setup setup-two-treasures at scene-hair-and-watch has no payoff
