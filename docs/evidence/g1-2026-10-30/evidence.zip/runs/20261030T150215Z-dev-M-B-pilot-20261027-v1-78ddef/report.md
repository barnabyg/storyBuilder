# Run report: dev-M-B-pilot-20261027-v1

- **Status:** succeeded
- **Started:** 2026-10-30T15:02:15.875207+00:00
- **Finished:** 2026-10-30T15:23:15.542465+00:00
- **Git SHA:** `f57875350abb7fe8e23e2a530496b581123204fe`
- **Config:** `C:\docs\git\storyBuilder\configs\dev-mb-pilot-20261027.yaml` (hash `f4ef56cc1b6b`)
- **Seed:** 1700
- **Cache:** use, 0 hits, 145 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | deepseek | deepseek-flash | deepseek |

## Prompt templates

- `plan_skeleton@2` (sha256 `0da31dbfa52d`)
- `plan_channels@2` (sha256 `01ada4fa319c`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-03, brief-04, brief-05, brief-06 (from `C:\docs\git\storyBuilder\benchmark\pilots\mb-20261027`)
- **Frozen splits:** dev `0db83f09f9eb`
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 8 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-03 | C | 1 | 1950 | 2000 | 1 | yes | 0 | ok | 13 | 87644 | 23809 | $0.0549 | $0.0549 | [cards.html](stories/C/brief-03/r1/cards.html) [cards.md](stories/C/brief-03/r1/cards.md) [ledger.json](stories/C/brief-03/r1/ledger.json) [plan-selection.json](stories/C/brief-03/r1/plan-selection.json) [plan.json](stories/C/brief-03/r1/plan.json) [planning-provenance.json](stories/C/brief-03/r1/planning-provenance.json) [skeleton.json](stories/C/brief-03/r1/skeleton.json) [source-plan.json](stories/C/brief-03/r1/source-plan.json) [story.md](stories/C/brief-03/r1/story.md) [story.raw.md](stories/C/brief-03/r1/story.raw.md) [validation.json](stories/C/brief-03/r1/validation.json) |
| brief-03 | B | 1 | 2024 | 2000 | 1 | yes | 17 | ok | 26 | 53647 | 46730 | $0.0722 | $0.0722 | [outline.json](stories/B/brief-03/r1/outline.json) [story.md](stories/B/brief-03/r1/story.md) [story.original.md](stories/B/brief-03/r1/story.original.md) [story.raw.md](stories/B/brief-03/r1/story.raw.md) |
| brief-04 | C | 1 | 2111 | 2000 | 1 | yes | 0 | ok | 13 | 92186 | 25810 | $0.0586 | $0.0586 | [cards.html](stories/C/brief-04/r1/cards.html) [cards.md](stories/C/brief-04/r1/cards.md) [ledger.json](stories/C/brief-04/r1/ledger.json) [plan-selection.json](stories/C/brief-04/r1/plan-selection.json) [plan.json](stories/C/brief-04/r1/plan.json) [planning-provenance.json](stories/C/brief-04/r1/planning-provenance.json) [skeleton.json](stories/C/brief-04/r1/skeleton.json) [source-plan.json](stories/C/brief-04/r1/source-plan.json) [story.md](stories/C/brief-04/r1/story.md) [story.raw.md](stories/C/brief-04/r1/story.raw.md) [validation.json](stories/C/brief-04/r1/validation.json) |
| brief-04 | B | 1 | 2190 | 2000 | 2 | yes | 13 | ok | 25 | 56708 | 51544 | $0.0789 | $0.0789 | [outline.json](stories/B/brief-04/r1/outline.json) [story.md](stories/B/brief-04/r1/story.md) [story.original.md](stories/B/brief-04/r1/story.original.md) [story.raw.md](stories/B/brief-04/r1/story.raw.md) |
| brief-05 | C | 1 | 2000 | 2000 | 1 | yes | 0 | ok | 12 | 75029 | 20941 | $0.0476 | $0.0476 | [cards.html](stories/C/brief-05/r1/cards.html) [cards.md](stories/C/brief-05/r1/cards.md) [ledger.json](stories/C/brief-05/r1/ledger.json) [plan-selection.json](stories/C/brief-05/r1/plan-selection.json) [plan.json](stories/C/brief-05/r1/plan.json) [planning-provenance.json](stories/C/brief-05/r1/planning-provenance.json) [skeleton.json](stories/C/brief-05/r1/skeleton.json) [source-plan.json](stories/C/brief-05/r1/source-plan.json) [story.md](stories/C/brief-05/r1/story.md) [story.raw.md](stories/C/brief-05/r1/story.raw.md) [validation.json](stories/C/brief-05/r1/validation.json) |
| brief-05 | B | 1 | 2194 | 2000 | 1 | yes | 14 | ok | 23 | 48769 | 42949 | $0.0662 | $0.0662 | [outline.json](stories/B/brief-05/r1/outline.json) [story.md](stories/B/brief-05/r1/story.md) [story.original.md](stories/B/brief-05/r1/story.original.md) [story.raw.md](stories/B/brief-05/r1/story.raw.md) |
| brief-06 | C | 1 | 1918 | 2000 | 1 | yes | 0 | ok | 11 | 61737 | 15903 | $0.0376 | $0.0376 | [cards.html](stories/C/brief-06/r1/cards.html) [cards.md](stories/C/brief-06/r1/cards.md) [ledger.json](stories/C/brief-06/r1/ledger.json) [plan-selection.json](stories/C/brief-06/r1/plan-selection.json) [plan.json](stories/C/brief-06/r1/plan.json) [planning-provenance.json](stories/C/brief-06/r1/planning-provenance.json) [skeleton.json](stories/C/brief-06/r1/skeleton.json) [source-plan.json](stories/C/brief-06/r1/source-plan.json) [story.md](stories/C/brief-06/r1/story.md) [story.raw.md](stories/C/brief-06/r1/story.raw.md) [validation.json](stories/C/brief-06/r1/validation.json) |
| brief-06 | B | 1 | 2176 | 2000 | 3 | yes | 6 | ok | 22 | 45643 | 40495 | $0.0623 | $0.0623 | [outline.json](stories/B/brief-06/r1/outline.json) [story.md](stories/B/brief-06/r1/story.md) [story.original.md](stories/B/brief-06/r1/story.original.md) [story.raw.md](stories/B/brief-06/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 4 | 0 | 49 | 316596 | 86463 | $0.1987 | $0.1987 | $0.0497 |
| B | 4 | 0 | 96 | 204767 | 181718 | $0.2795 | $0.2795 | $0.0699 |

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 4 | 49 | 403059 | 100765 |
| B | 4 | 96 | 386485 | 96621 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 10% of the larger, with at most 48 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-03 | 1 | 111453 | 10962 | B | 17 | 111453 | 100377 | yes |  |
| brief-04 | 1 | 117996 | 8768 | B | 13 | 117996 | 108252 | yes |  |
| brief-05 | 1 | 95970 | 10964 | B | 14 | 95970 | 91718 | yes |  |
| brief-06 | 1 | 77640 | 10951 | B | 6 | 77640 | 86138 | yes |  |

4 matched, 0 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-03 repetition 1: comparable
- C: final `stories/C/brief-03/r1/story.md`, SHA-256 `afe9fdfe1d3db14d1675ece3fbe7e2b77263fa629adb0e50062d340f2045a1a8`; 1950 words; 111453 tokens; new spend USD 0.054864
- B: final `stories/B/brief-03/r1/story.md`, SHA-256 `9539e7fd19fccbd7bf6e5855a50327a92c7608fcb631cea0977cecdfebb5087f`; 2024 words; 100377 tokens; new spend USD 0.072170

brief-04 repetition 1: comparable
- C: final `stories/C/brief-04/r1/story.md`, SHA-256 `e343b1a747376462ce5d5cb0115ef6ac498366d79c987cfbd0cf8840a493581f`; 2111 words; 117996 tokens; new spend USD 0.058628
- B: final `stories/B/brief-04/r1/story.md`, SHA-256 `185eeda87183922c73708283e5f764d563ef26afb3e1734721218809478966b2`; 2190 words; 108252 tokens; new spend USD 0.078865

brief-05 repetition 1: comparable
- C: final `stories/C/brief-05/r1/story.md`, SHA-256 `06f01894f2229b5a6825cb9a13b99390f69c3b459497c599f03a2f4e4991d3c6`; 2000 words; 95970 tokens; new spend USD 0.047638
- B: final `stories/B/brief-05/r1/story.md`, SHA-256 `5fd007cd68f9a48c10fc2add4206f19642a962d8cfa9f83c3be8ff12e2ec1f36`; 2194 words; 91718 tokens; new spend USD 0.066170

brief-06 repetition 1: comparable
- C: final `stories/C/brief-06/r1/story.md`, SHA-256 `eff6be91bf0676ae56abb1ad8da8dd5578bc3b0b7bd08e6b379fcd82d23de180`; 1918 words; 77640 tokens; new spend USD 0.037605
- B: final `stories/B/brief-06/r1/story.md`, SHA-256 `95238339dba32f729dd6a77e8afdb082736f4abc881ace582095016c069699ff`; 2176 words; 86138 tokens; new spend USD 0.062287

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 28 | 82.1% | 100.0% | 17.9% | 0 |

## Cost

- New spend this run: $0.4782
- Token cost at list price, including cache hits: $0.4782
- Tokens: 521363 input, 268181 output
- Per-run cap: $1.5000; per-day cap: $3.0000
- Spent today (UTC, all runs): $0.4877

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 145 | 0 | 521363 | 268181 | $0.4782 | $0.4782 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-03/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7461 | 679 | $0.0031 | 4.43 | 0 |
| C/brief-03/skeleton #1 | 2 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 8175 | 773 | $0.0034 | 3.54 | 0 |
| C/brief-03/channels-s1 #1 | 1 | deepseek-flash | plan_channels@2 | 1310279880 | no | 8495 | 1682 | $0.0046 | 6.93 | 0 |
| C/brief-03/channels-s2 #1 | 1 | deepseek-flash | plan_channels@2 | 1407915137 | no | 9279 | 2494 | $0.0058 | 8.66 | 0 |
| C/brief-03/channels-s3 #1 | 1 | deepseek-flash | plan_channels@2 | 1438285283 | no | 10079 | 3237 | $0.0069 | 11.83 | 0 |
| C/brief-03/channels-s3 #1 | 2 | deepseek-flash | plan_channels@2 | 1438285283 | no | 13366 | 3234 | $0.0079 | 10.19 | 0 |
| C/brief-03/channels-s4 #1 | 1 | deepseek-flash | plan_channels@2 | 206457204 | no | 10819 | 4127 | $0.0082 | 13.91 | 0 |
| C/brief-03/channels-s5 #1 | 1 | deepseek-flash | plan_channels@2 | 1525124974 | no | 11712 | 5104 | $0.0096 | 16.72 | 0 |
| C/brief-03/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1438 | 522 | $0.0011 | 4.82 | 0 |
| C/brief-03/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1713 | 455 | $0.0011 | 4.94 | 0 |
| C/brief-03/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1477 | 461 | $0.0010 | 4.73 | 0 |
| C/brief-03/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1848 | 498 | $0.0012 | 4.94 | 0 |
| C/brief-03/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1782 | 543 | $0.0012 | 5.60 | 0 |
| B/brief-03/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 561 | 1520 | $0.0020 | 12.40 | 0 |
| B/brief-03/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 693 | 333 | $0.0006 | 3.36 | 0 |
| B/brief-03/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 725 | 264 | $0.0005 | 2.72 | 0 |
| B/brief-03/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 764 | 302 | $0.0006 | 3.27 | 0 |
| B/brief-03/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 803 | 334 | $0.0006 | 3.27 | 0 |
| B/brief-03/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 801 | 282 | $0.0006 | 2.82 | 0 |
| B/brief-03/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 851 | 293 | $0.0006 | 2.87 | 0 |
| B/brief-03/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 893 | 302 | $0.0006 | 3.04 | 0 |
| B/brief-03/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 954 | 287 | $0.0006 | 2.78 | 0 |
| B/brief-03/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2624 | 2500 | $0.0038 | 11.61 | 0 |
| B/brief-03/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 2735 | 2484 | $0.0038 | 10.37 | 0 |
| B/brief-03/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 2719 | 2512 | $0.0038 | 10.94 | 0 |
| B/brief-03/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 2747 | 2512 | $0.0038 | 10.64 | 0 |
| B/brief-03/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 2747 | 2512 | $0.0038 | 10.67 | 0 |
| B/brief-03/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 2747 | 2512 | $0.0038 | 10.42 | 0 |
| B/brief-03/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | no | 2747 | 2512 | $0.0038 | 11.12 | 0 |
| B/brief-03/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | no | 2747 | 2512 | $0.0038 | 10.49 | 0 |
| B/brief-03/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | no | 2747 | 2512 | $0.0038 | 10.65 | 0 |
| B/brief-03/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | no | 2747 | 2512 | $0.0038 | 10.79 | 0 |
| B/brief-03/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | no | 2747 | 2523 | $0.0039 | 10.78 | 0 |
| B/brief-03/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | no | 2758 | 2523 | $0.0039 | 10.64 | 0 |
| B/brief-03/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | no | 2758 | 2523 | $0.0039 | 10.82 | 0 |
| B/brief-03/revision-14 #1 | 1 | deepseek-flash | story_revision@1 | 954275669 | no | 2758 | 2523 | $0.0039 | 10.59 | 0 |
| B/brief-03/revision-15 #1 | 1 | deepseek-flash | story_revision@1 | 784163321 | no | 2758 | 2523 | $0.0039 | 10.47 | 0 |
| B/brief-03/revision-16 #1 | 1 | deepseek-flash | story_revision@1 | 222805417 | no | 2758 | 2523 | $0.0039 | 10.53 | 0 |
| B/brief-03/revision-17 #1 | 1 | deepseek-flash | story_revision@1 | 821015077 | no | 2758 | 2595 | $0.0039 | 11.55 | 0 |
| C/brief-04/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7478 | 798 | $0.0032 | 4.78 | 0 |
| C/brief-04/channels-s1 #1 | 1 | deepseek-flash | plan_channels@2 | 1310279880 | no | 8474 | 1499 | $0.0043 | 6.62 | 0 |
| C/brief-04/channels-s2 #1 | 1 | deepseek-flash | plan_channels@2 | 1407915137 | no | 9104 | 2301 | $0.0055 | 9.12 | 0 |
| C/brief-04/channels-s2 #1 | 2 | deepseek-flash | plan_channels@2 | 1407915137 | no | 11455 | 2300 | $0.0062 | 7.58 | 0 |
| C/brief-04/channels-s3 #1 | 1 | deepseek-flash | plan_channels@2 | 1438285283 | no | 9917 | 3067 | $0.0067 | 10.86 | 0 |
| C/brief-04/channels-s4 #1 | 1 | deepseek-flash | plan_channels@2 | 206457204 | no | 10672 | 3794 | $0.0078 | 13.33 | 0 |
| C/brief-04/channels-s5 #1 | 1 | deepseek-flash | plan_channels@2 | 1525124974 | no | 11399 | 4665 | $0.0090 | 15.05 | 0 |
| C/brief-04/channels-s5 #1 | 2 | deepseek-flash | plan_channels@2 | 1525124974 | no | 16113 | 4672 | $0.0104 | 13.83 | 0 |
| C/brief-04/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1129 | 500 | $0.0009 | 5.23 | 0 |
| C/brief-04/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1607 | 615 | $0.0012 | 6.09 | 0 |
| C/brief-04/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1548 | 630 | $0.0012 | 6.31 | 0 |
| C/brief-04/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1623 | 440 | $0.0010 | 4.72 | 0 |
| C/brief-04/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1667 | 529 | $0.0011 | 5.08 | 0 |
| B/brief-04/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 579 | 1034 | $0.0014 | 7.31 | 0 |
| B/brief-04/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 554 | 546 | $0.0008 | 5.57 | 0 |
| B/brief-04/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 572 | 339 | $0.0006 | 4.20 | 0 |
| B/brief-04/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 639 | 371 | $0.0006 | 4.10 | 0 |
| B/brief-04/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 627 | 374 | $0.0006 | 4.00 | 0 |
| B/brief-04/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 654 | 362 | $0.0006 | 3.99 | 0 |
| B/brief-04/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 669 | 327 | $0.0006 | 3.94 | 0 |
| B/brief-04/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 778 | 343 | $0.0006 | 3.68 | 0 |
| B/brief-04/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2914 | 2795 | $0.0042 | 14.02 | 0 |
| B/brief-04/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 3048 | 2795 | $0.0043 | 12.10 | 0 |
| B/brief-04/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 3048 | 2795 | $0.0043 | 12.39 | 0 |
| B/brief-04/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 3048 | 2795 | $0.0043 | 12.61 | 0 |
| B/brief-04/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 3048 | 2795 | $0.0043 | 12.43 | 0 |
| B/brief-04/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 3048 | 2946 | $0.0044 | 13.53 | 0 |
| B/brief-04/revision-06 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1894988275 | no | 3048 | 2794 | $0.0043 | 12.12 | 0 |
| B/brief-04/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | no | 3047 | 2780 | $0.0043 | 12.36 | 0 |
| B/brief-04/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | no | 3033 | 2841 | $0.0043 | 12.98 | 0 |
| B/brief-04/revision-08 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 469972079 | no | 3033 | 2783 | $0.0042 | 12.32 | 0 |
| B/brief-04/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | no | 3036 | 2863 | $0.0043 | 13.25 | 0 |
| B/brief-04/revision-09 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1551926148 | no | 3036 | 2783 | $0.0043 | 12.00 | 0 |
| B/brief-04/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | no | 3036 | 2783 | $0.0043 | 12.07 | 0 |
| B/brief-04/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | no | 3036 | 2806 | $0.0043 | 12.58 | 0 |
| B/brief-04/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | no | 3059 | 2806 | $0.0043 | 12.14 | 0 |
| B/brief-04/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | no | 3059 | 2882 | $0.0044 | 13.82 | 0 |
| B/brief-04/revision-13 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 594747244 | no | 3059 | 2806 | $0.0043 | 12.34 | 0 |
| C/brief-05/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7464 | 680 | $0.0031 | 4.07 | 0 |
| C/brief-05/channels-s1 #1 | 1 | deepseek-flash | plan_channels@2 | 1310279880 | no | 8424 | 1645 | $0.0045 | 7.31 | 0 |
| C/brief-05/channels-s1 #1 | 2 | deepseek-flash | plan_channels@2 | 1310279880 | no | 10115 | 1612 | $0.0050 | 5.67 | 0 |
| C/brief-05/channels-s2 #1 | 1 | deepseek-flash | plan_channels@2 | 1407915137 | no | 9211 | 2391 | $0.0056 | 9.15 | 0 |
| C/brief-05/channels-s3 #1 | 1 | deepseek-flash | plan_channels@2 | 1438285283 | no | 9978 | 3290 | $0.0069 | 11.45 | 0 |
| C/brief-05/channels-s4 #1 | 1 | deepseek-flash | plan_channels@2 | 206457204 | no | 10877 | 3939 | $0.0080 | 13.93 | 0 |
| C/brief-05/channels-s5 #1 | 1 | deepseek-flash | plan_channels@2 | 1525124974 | no | 11526 | 4859 | $0.0093 | 16.29 | 0 |
| C/brief-05/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1310 | 457 | $0.0009 | 4.47 | 0 |
| C/brief-05/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1411 | 516 | $0.0010 | 5.21 | 0 |
| C/brief-05/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1570 | 573 | $0.0012 | 5.66 | 0 |
| C/brief-05/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1546 | 546 | $0.0011 | 5.31 | 0 |
| C/brief-05/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1597 | 433 | $0.0010 | 4.19 | 0 |
| B/brief-05/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 561 | 1473 | $0.0019 | 13.35 | 0 |
| B/brief-05/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 658 | 379 | $0.0007 | 3.62 | 0 |
| B/brief-05/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 704 | 260 | $0.0005 | 2.76 | 0 |
| B/brief-05/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 753 | 248 | $0.0005 | 2.79 | 0 |
| B/brief-05/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 804 | 328 | $0.0006 | 3.15 | 0 |
| B/brief-05/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 813 | 479 | $0.0008 | 4.60 | 0 |
| B/brief-05/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 818 | 274 | $0.0006 | 3.11 | 0 |
| B/brief-05/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 848 | 315 | $0.0006 | 3.30 | 0 |
| B/brief-05/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 939 | 310 | $0.0007 | 2.85 | 0 |
| B/brief-05/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2820 | 2717 | $0.0041 | 12.03 | 0 |
| B/brief-05/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 2913 | 2750 | $0.0042 | 11.92 | 0 |
| B/brief-05/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 2986 | 2750 | $0.0042 | 11.62 | 0 |
| B/brief-05/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 2986 | 2761 | $0.0042 | 11.77 | 0 |
| B/brief-05/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 2997 | 2761 | $0.0042 | 11.47 | 0 |
| B/brief-05/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 2997 | 2761 | $0.0042 | 11.30 | 0 |
| B/brief-05/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | no | 2997 | 2761 | $0.0042 | 11.30 | 0 |
| B/brief-05/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | no | 2997 | 2761 | $0.0042 | 11.13 | 0 |
| B/brief-05/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | no | 2997 | 2761 | $0.0042 | 11.21 | 0 |
| B/brief-05/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | no | 2997 | 2760 | $0.0042 | 11.47 | 0 |
| B/brief-05/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | no | 2996 | 2760 | $0.0042 | 11.21 | 0 |
| B/brief-05/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | no | 2996 | 2860 | $0.0043 | 12.52 | 0 |
| B/brief-05/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | no | 3096 | 2860 | $0.0044 | 11.56 | 0 |
| B/brief-05/revision-14 #1 | 1 | deepseek-flash | story_revision@1 | 954275669 | no | 3096 | 2860 | $0.0044 | 11.62 | 0 |
| C/brief-06/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7462 | 743 | $0.0031 | 4.82 | 0 |
| C/brief-06/channels-sc-01 #1 | 1 | deepseek-flash | plan_channels@2 | 1082539864 | no | 8482 | 1466 | $0.0043 | 6.65 | 0 |
| C/brief-06/channels-sc-02 #1 | 1 | deepseek-flash | plan_channels@2 | 953394149 | no | 9054 | 2020 | $0.0051 | 7.85 | 0 |
| C/brief-06/channels-sc-03 #1 | 1 | deepseek-flash | plan_channels@2 | 1955734615 | no | 9626 | 2393 | $0.0058 | 8.06 | 0 |
| C/brief-06/channels-sc-04 #1 | 1 | deepseek-flash | plan_channels@2 | 199251043 | no | 9981 | 3062 | $0.0067 | 10.55 | 0 |
| C/brief-06/channels-sc-05 #1 | 1 | deepseek-flash | plan_channels@2 | 1275523251 | no | 10650 | 3748 | $0.0077 | 12.17 | 0 |
| C/brief-06/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1160 | 608 | $0.0011 | 5.98 | 0 |
| C/brief-06/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1195 | 448 | $0.0009 | 4.86 | 0 |
| C/brief-06/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1314 | 455 | $0.0009 | 4.87 | 0 |
| C/brief-06/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1450 | 392 | $0.0009 | 4.19 | 0 |
| C/brief-06/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1363 | 568 | $0.0011 | 5.86 | 0 |
| B/brief-06/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 559 | 1413 | $0.0019 | 12.26 | 0 |
| B/brief-06/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 684 | 334 | $0.0006 | 3.88 | 0 |
| B/brief-06/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 752 | 343 | $0.0006 | 3.85 | 0 |
| B/brief-06/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 758 | 355 | $0.0007 | 3.89 | 0 |
| B/brief-06/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 785 | 253 | $0.0005 | 2.91 | 0 |
| B/brief-06/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 817 | 302 | $0.0006 | 3.50 | 0 |
| B/brief-06/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 878 | 306 | $0.0006 | 3.27 | 0 |
| B/brief-06/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 933 | 288 | $0.0006 | 2.65 | 0 |
| B/brief-06/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 933 | 258 | $0.0006 | 3.08 | 0 |
| B/brief-06/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2654 | 2492 | $0.0038 | 12.48 | 0 |
| B/brief-06/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 2725 | 2782 | $0.0042 | 14.16 | 0 |
| B/brief-06/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 3015 | 2782 | $0.0042 | 12.12 | 0 |
| B/brief-06/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 3015 | 2864 | $0.0043 | 13.15 | 0 |
| B/brief-06/revision-04 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 176769367 | no | 3015 | 2918 | $0.0044 | 13.37 | 0 |
| B/brief-06/revision-04 (attempt 3) #1 | 1 | deepseek-flash | story_revision@1 | 1758213689 | no | 3015 | 2845 | $0.0043 | 12.83 | 0 |
| B/brief-06/revision-04 (attempt 4) #1 | 1 | deepseek-flash | story_revision@1 | 77358525 | no | 3015 | 2782 | $0.0042 | 12.19 | 0 |
| B/brief-06/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 3015 | 2921 | $0.0044 | 13.35 | 0 |
| B/brief-06/revision-05 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1289824051 | no | 3015 | 2911 | $0.0044 | 13.39 | 0 |
| B/brief-06/revision-05 (attempt 3) #1 | 1 | deepseek-flash | story_revision@1 | 2064464777 | no | 3015 | 2782 | $0.0042 | 11.58 | 0 |
| B/brief-06/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 3015 | 2898 | $0.0044 | 13.49 | 0 |
| B/brief-06/revision-06 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1894988275 | no | 3015 | 2867 | $0.0043 | 12.69 | 0 |
| B/brief-06/revision-06 (attempt 3) #1 | 1 | deepseek-flash | story_revision@1 | 1395398776 | no | 3015 | 2799 | $0.0043 | 12.40 | 0 |
