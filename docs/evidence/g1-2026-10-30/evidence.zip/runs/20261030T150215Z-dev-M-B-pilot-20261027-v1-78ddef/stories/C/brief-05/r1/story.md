The farmhouse smelled of dust and old wood, and Martin Leigh carried the last box up the porch steps with a lightness in his chest he hadn't felt in years. The fields rolled out behind the house, green and quiet, and the only sound was June's sneakers slapping the floorboards as she ran from room to room claiming territory.

"Pick a bedroom, any bedroom," Claire called after her. She stood in the kitchen doorway with her arms crossed, taking in the peeling wallpaper and the deep farm sink. "Anything's better than the apartment."

Martin set the box down and grinned at her. "Told you. Fresh air, room to breathe. This is going to be good for us."

Claire didn't answer, but he caught the small lift at the corner of her mouth, and that was enough.

He wandered into the front room. A mantel clock sat above the empty fireplace, a brass thing with a cracked face. He wound it out of habit and frowned at the hands. Then he crossed to the wall clock in the hall. Then the little alarm clock in the kitchen, the one shaped like a frying pan, and the grandfather clock in the corner of the dining room that he had to open the glass to inspect.

Three seventeen. Every one of them. Three seventeen, dead and silent, their pendulums hanging still.

"Claire. Every clock in this house is stopped."

"Probably the power was out," she said, not looking up. "Or the old owners just didn't bother."

He tried the grandfather's pendulum. It wouldn't swing.

In the kitchen, Claire opened the cabinet beneath the sink. Empty. She moved to the pantry, then the sideboard in the dining room, her hand drifting along the shelves, lifting the bottle of cooking sherry and turning it over, reading the label. She set it back and closed the door without a sound.

Martin came back through, and she was wiping the counter with a rag, her face smooth and pleasant. "June wants the room with the window seat," she said.

"Then she gets it." He squeezed her shoulder. "New start, Claire. I mean it."

"I know," she said, and smiled, and he believed her.

At 3:17 the clocks began.

Martin woke the way a man wakes when the smoke alarm has gone off: all at once, upright, heart already running. The bedroom was black. Beside him Claire slept on her side, one hand under the pillow. But the house was ticking. Not one tick. Every clock in every room, stacked together in a low dry chorus that he could feel in his teeth. The mantel clock below. The wall clock in the hall. The old alarm in the spare room. All of them going at once, as though something had thrown a single switch.

He got up slowly so the bedsprings wouldn't speak. In the hall the tick was louder, and the shadows of the banister moved with it, faintly, in time. He went down barefoot. The kitchen clock above the door was sweeping its second hand past the twelve. It had been stopped before. He was sure it had been stopped. He stood under it with his hands loose at his sides and listened to the whole house keep time.

"Martin."

Claire stood in the kitchen doorway with her robe pulled tight. He hadn't heard her come down. She looked at him, then past him, at the table, the counters, the empty sink, reading the room like a page.

"What are you doing?" she said.

"I woke up. The clocks —" He gestured up at the one above the door. "They're running. Every one of them. They all started."

She didn't look at the clock. That was the thing he would remember later. She kept her eyes on him.

"What time did you come down?" she asked.

"You can see it. It's going."

"It's a clock, Martin. Clocks run."

He heard his own voice climbing and made himself stop. He stood very still, which was a mistake, because stillness was what she was looking for. He watched her see it: the stiff shoulders, the careful not-moving, the bare feet on cold tile. He knew exactly what it looked like. It looked like a man holding himself together at three in the morning.

"I haven't had anything," he said.

Claire folded her arms. She didn't say anything for a long moment, and the ticking filled the space between them, and her face was gentle and terrible. "It's all right," she said. "We'll talk in the morning."

"Claire. The clocks were stopped. You saw them stopped."

"Come back to bed," she said.

Martin found the first one in the pantry and carried it to the kitchen table, a heavy mantel clock with a chipped walnut case. He set it beside the wall clock and the little brass alarm from June's room, lined up like specimens. He'd never been much for numbers, but sobriety had taught him to keep track of things. Days. Hours. The exact count of everything he was trying not to lose.

The hands had moved. All of them had moved, and none of them agreed.

He wrote it down in the notebook he'd started keeping in his jacket, the same way he'd once kept a tally of drinks. The pantry clock ran fast by six minutes. The kitchen clock by nine. The one from upstairs, by a quarter of an hour. He circled the numbers and drew an arrow, then another, and saw where they pointed. Not back to where they'd started. Forward. Toward the same hour, each at its own pace, as though the whole house were leaning toward a single minute.

Three seventeen.

He sat with that a long time, the pencil gone slick in his hand. It was ridiculous. It was the kind of thing a man saw when he was looking for something to be wrong. But the clocks had been stopped at that minute when they arrived, and now they were running, and every one of them was racing to get back to it.

He heard Claire in the hallway and shut the notebook, slid it under a stack of unpacked plates. She came in with her sleeves pushed up, the way she did when she was about to say something she'd rehearsed.

"Martin."

"Hey." He stood too fast. "I was just sorting the—"

She held up the notebook. She'd found it anyway. It lay open in her hands, and he could see his own cramped columns, the circled times, the word he'd written at the bottom of the page in letters he hadn't meant anyone to read. 3:17.

"What is this?" Her voice was careful. That was worse than anger. "I found it in your coat. Are you writing down when you drink now? Times, amounts?"

"No. Claire, no, it's the clocks—"

"The clocks." She looked at the table, at the three of them ticking away out of step, and something in her face closed like a door. "You're sneaking around the house at night, you're writing numbers in a notebook you're hiding from me, and you're telling me it's the clocks."

"I'm not drinking. I swear to you."

She turned the notebook over, as if there might be more, and he watched her believe the worst of him, calmly and completely, and he understood that the truth was the one story she would never be able to hear.

He found her in the kitchen, packing June's things into a canvas bag with the deliberate calm of someone who had already decided. Above the sink, the clock said 2:41. It had said 2:39 when he'd come down.

"Claire. Look at it. Look at the minute hand and don't look away for sixty seconds."

"I'm not doing this tonight." She folded a sweater into the bag. "I'm not going to stand here and watch you build a case out of a clock."

"Then don't watch me. Watch it. Whatever you think of me—fine. But watch it and tell me it moves like a clock should."

She did look, briefly, the way you check something to prove it isn't worth checking, and he saw her eyes try to hold the thin black hand and fail. It swept too fast. It swept like a second hand, not a minute hand, and somewhere behind the walls the house ticked like a heart running a fever.

"2:43," he said. "It was 2:39 four minutes ago. It's not keeping time, Claire. It's spending it. There's less than half an hour left."

"Stop." Her voice cracked, and that was worse than anger. "Do you hear yourself? You have a notebook full of this. Times, arrows, numbers—you wrote it all down in the dark like you used to hide bottles. I found it, Martin. I wasn't even looking, and I found it." She closed the bag. "I've done this before. I know how it starts. The intensity. The certainty. I am not going to let June grow up inside that again."

He caught her wrist, gently, and she went still. "Then leave me here. Take her, go to your sister's, I don't care—but not because of me. Because of that. Please. Just tonight. Just until three-eighteen."

"Because of a clock." She pulled free. "Listen to what you're asking me to believe."

"That's all I'm asking. To believe me."

She climbed the stairs and came down with June in her coat, small and blinking and half asleep. Martin crouched to her height and made himself smile, and it felt like lifting a stone.

"Go with Mum," he said. "I'll see you tomorrow."

Claire paused at the door, keys in hand, and for one bare second he thought she might turn back.

"Don't drink," she said. "Please."

Then the door shut, and the ticking filled the house, and the clock over the sink read 2:51.

He stood in the hall with his hand flat against the door and felt the ticking come up through the wood like a pulse. 3:09. He had eight minutes, by the clocks, and the clocks were fast, and he had stopped being able to tell what that meant. He had written it all down and they had taken the notebook for what it was.

Claire's car was pulling out of the drive. He heard the gravel, the low gear, the turn onto the road. He had told her to take June and go, and she had looked at him the way she used to look at the bottles under the sink, and she had taken June, and June had forgotten her coat.

The door opened. June came in with the cold behind her, twelve years old and moving fast and not looking at him.

"Just the coat," she said. "Mom's waiting."

"June." He got between her and the stairs. "Listen to me. Look at the clock. Look at the one in the kitchen and tell me what it says."

"It's a clock, Dad."

"Tell me what it says."

She looked. "It says three-seventeen."

"Does it tick?"

Her jaw set. "I'm getting my coat."

She ducked past him and went up. He followed, and the ticking was everywhere now, all the clocks in the house arriving at the same place, a sound like a hundred small hammers, and he was shouting her name and she was not listening, and the minute hand on the landing clock came down.

3:17.

The ticking stopped. Every clock in the house stopped at once, and in the silence June stood at the top of the stairs with her coat half over her arm and her mouth open, and the stopped hour took her.

She did not fall. That was the thing he would keep. She simply was not there, the coat dropping to the runner, and Martin went up the stairs on his hands and knees and reached the top too late, and knelt in the empty quiet where his daughter had been, and the clocks began, softly, to tick.
