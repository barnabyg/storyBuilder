The night count was the only part of the shift Priya liked. Two a.m., the front lights down, the register quiet, and a drawer of paper prescriptions to reconcile against the system before the morning pharmacist arrived. She worked the stack with a pen in her teeth, ticking each one.

Eugene Doyle, R-4471. She ticked it and moved on, then stopped.

She shuffled back. The slip was a monthly refill, ninety tablets, metoprolol. She checked the file tab and there it was in the system, the same refill, three months running. And above it, in the red block the software used for flagged accounts, a date of death. Eugene Doyle had died in March. This was June.

Priya sat back and looked at the ceiling, at the water stain shaped like a boot. It would be a clerical error, she thought. Family hadn't cancelled. It happened. But the refills kept being picked up, which meant somebody kept coming in, and the register would show who.

The bell over the door went at a quarter past two. Priya looked up from the drawer.

The woman was old, older than the pharmacy's usual night traffic, in a coat too heavy for June. She came to the counter with her purse held against her chest and said, "Doyle. Pickup."

Priya found the bag. She set it on the counter and did not slide it across.

"Mrs. Doyle," she said. "I have to ask. The account's still active and it shouldn't be. The refills have been going out for three months."

The woman's hands were folded on the purse. "I know."

"I'm sorry for your loss. But I can't keep dispensing to a deceased patient. I'll need to call the family, get the account closed."

"No." It came out fast. "No, don't do that. Please." She opened the purse and took out a fold of bills, flattened and soft, the way money gets when it's been carried a long time. She counted out the exact amount on the counter, one bill at a time, and pushed it toward Priya. "I pay cash. I always pay cash. Just don't call the family."

Priya looked at the money. She looked at the woman's face, which was not embarrassed, exactly, but tired in a way she recognized. "Who are you to him?"

Margaret Doyle straightened her coat. "I'm his wife," she said. "And I'm asking you."