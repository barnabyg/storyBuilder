The lot still smelled of cut grass and diesel when Lucía swung her truck through the gate at half past five. She had been the first to sign for a permit in March, the first to pay, and she had spent the spring rebuilding her menu the way a person rebuilds a wall—one careful brick at a time. The blue rectangle on the fence post, slot fourteen, would be hers.

A green-and-cream truck sat in slot fourteen.

She knew it before she read the painted name, before she saw the man in the apron leaning into his prep window. Mateo Cruz. Of course. He had a way of turning up at the edge of her luck.

Lucía killed the engine and walked to the festival office, a trailer that hummed with a window unit. The clerk, a young woman with a lanyard and a look of having already had this conversation, did not make her wait.

"Ferrer? I know. I'm sorry." She turned her screen around. Two rows, identical permit numbers. "The system double-issued slot fourteen. Yours and Cruz's. I can't void either one before opening night—the district office has to review it, and they're closed until Monday."

"Monday is the second day of the festival," Lucía said.

"I know."

"Then give me a different slot."

"There isn't one. That's the whole problem." The clerk's voice dropped. "You two are going to have to work it out."

Mateo was waiting by her truck when she came back, arms folded, sleeves pushed to the elbow. He had the same dark hair she remembered from the restaurant-supply auctions, and the same infuriating calm.

"I heard," he said. "Look—there's room if we angle them. You take the morning window, I take the afternoon. We share the frontage, split the permit fee."

"No."

"Lucía."

"I paid for that spot in March. I have a lease riding on this summer." She stepped past him and laid her hand flat on the fence post, on the blue sticker, as if the paper could be reasoned with. "This is mine. I'm not splitting my kitchen with the man who undercut me at every turn."

"I never undercut you."

"You parked in my spot."

"I parked in my spot." He said it without heat, which was worse. "The clerk made a mistake, not me."

"Then you can move."

He studied her a moment, and something in his face—patience, or worse, sympathy—made her want to shout. "I'm here at five every morning," he said quietly. "You know where to find me if you change your mind."

"I won't."

She said it to his back as he walked away, and she meant it, and she stood there in the empty lot with her hand on the fence and her heart going like a service bell, telling herself the space was still hers.