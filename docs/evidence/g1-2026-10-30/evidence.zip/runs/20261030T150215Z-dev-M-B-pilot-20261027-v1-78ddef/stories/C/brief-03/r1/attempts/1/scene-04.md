The next afternoon, before her shift, Priya sat at her kitchen table with her laptop open to two documents. The resignation letter came first and was easy: two weeks' notice, gratitude for the opportunity, no reasons given. She read it twice and did not send it. Then she opened the audit portal and began the incident report. She typed the patient name, the date of death, the refill dates. Her cursor hovered over the field marked *dispensing pharmacist*. She typed her own name, deleted it, typed it again. Reporting meant Margaret's name in a file that would travel to the board, to the insurer, maybe to a prosecutor. The money for the aide and the dialysis rides would stop in a single afternoon. She saved the draft without submitting it and closed the laptop, and the two documents sat in her machine like a pair of unopened letters, each one addressed to a different version of her life.

Margaret came in at nine, ten minutes before closing, carrying a canvas tote that clinked when she set it on the counter. She lifted out six amber bottles, unopened, labels facing away.

"I can't do it anymore," Margaret said. "My hands shake too much to count them out, and I keep thinking about that detective's car in the lot."

Priya looked at the bottles. Returning them to stock was against policy; they should be destroyed and documented, and documentation was the one thing she could not afford.

"Margaret, if I take these back, there's a record. There's always a record."

"I know." Margaret's voice was steady in a way that unsettled Priya more than trembling would have. "I've been deciding things my whole life, and I've made a mess of the last of them. So I'm not going to decide this one." She pushed the tote an inch closer. "You do it. Whatever you think is right, I'll live with it. You're the only one who knows the whole of it, and I'm too tired to carry it another day."

Priya stared at the bottles, at the small typed name on each label that belonged to a man three months in the ground. The resignation letter and the report sat side by side in her closed laptop, and Margaret stood waiting, having handed her the weight of them both, and Priya understood that there was no version of the next hour in which she chose only for herself.