# The Stopped Hour

Plan brief-05; schema 1; tier M

Character martin: Martin Leigh

Character claire: Claire Leigh

Character june: June Leigh

## s1: The Stopped Hour

The Leighs arrive at a farmhouse where every clock is frozen at 3:17.

Present: martin, claire, june

Beat s1b1: Martin finds every clock in the house stopped at the same minute.

Beat s1b2: Claire quietly inventories the liquor cabinets on arrival.

Fact fact-clocks: Every clock in the farmhouse is stopped at exactly 3:17.; initial holders: martin

Fact fact-watch: Claire is covertly checking the house for alcohol and expects Martin to fail.; initial holders: claire

Fact fact-countdown: The clocks are running fast toward a single hour, 3:17, as if counting down.; initial holders: martin

Fact fact-claim: The stopped hour takes whoever is in the house when the clocks reach 3:17.; initial holders: martin

Causal c-s1-s2: earlier cause s1 → effect s2

Setup setup-liquor at s1: Claire's silent inventory of the liquor cabinets establishes her watchfulness and the relapse assumption that will later override Martin's warnings.

Knowledge use use-watch: claire uses fact fact-watch at s1

## s2: First Night

On their first night the clocks start again, but only Martin hears them.

Present: martin, claire, june

Beat s2b1: At 3:17 a.m. the clocks resume in unison and Martin wakes to ticking.

Beat s2b2: Claire finds him in the kitchen and reads his stillness as a relapse.

Causal c-s1-s2: earlier cause s1 → effect s2

Causal c-s2-s3: earlier cause s2 → effect s3

## s3: Counting Down

Martin tracks the clocks losing time and traces the previous owners.

Present: martin, claire

Beat s3b1: Martin maps the clocks running fast toward a single hour.

Beat s3b2: Claire finds his hidden notes and confronts him about drinking.

Causal c-s2-s3: earlier cause s2 → effect s3

Setup setup-notes at s3: Martin's hidden notes mapping the clocks become the object Claire finds and reads as proof of relapse.

Reveal rev-countdown: fact fact-countdown at s3; holders: claire (acquired at scene start)

Knowledge use use-clocks-s3: martin uses fact fact-clocks at s3

## s4: Not Believed

Martin's warnings collapse under his family's certainty that he has relapsed.

Present: martin, claire, june

Beat s4b1: Martin pleads with Claire while the countdown closes in.

Beat s4b2: Claire takes June and leaves for the night to keep her safe.

Causal c-s4-s5: earlier cause s4 → effect s5

Payoff pay-liquor: setup setup-liquor → payoff at s4

## s5: The Last Minute

Martin is proven right at 3:17, and the cost falls on June.

Present: martin, june

Beat s5b1: June returns for her coat as every clock strikes the final minute.

Beat s5b2: Martin reaches June too late as the stopped hour claims her.

Causal c-s4-s5: earlier cause s4 → effect s5

Reveal rev-claim: fact fact-claim at s5; holders: june (acquired at scene start)

Knowledge use use-claim-s5: martin uses fact fact-claim at s5

State st-martin-goal [s1] martin goal fresh-start: known: hoping the move will reset the family; confidence unrecorded; alternatives: (none recorded) → known: determined to prove the move can work; confidence unrecorded; alternatives: (none recorded)

State st-martin-belief [s1] martin belief house-is-ordinary: unknown: (no asserted value); confidence unrecorded; alternatives: (none recorded) → known: the stopped clocks are a strange but harmless quirk; confidence unrecorded; alternatives: (none recorded)

State st-martin-belief-s2 [s2] martin belief clocks-are-harmless: known: the stopped clocks are a strange but harmless quirk; confidence unrecorded; alternatives: (none recorded) → ambiguous: the clocks restarting is something only he can hear; confidence unrecorded; alternatives: a dream; a symptom of withdrawal

State st-claire-belief-s2 [s2] claire belief martin-relapsed: ambiguous: watchful but hoping the move holds; confidence unrecorded; alternatives: genuine fresh start; relapse already beginning → known: certain Martin has started drinking again; confidence unrecorded; alternatives: (none recorded)

State st-martin-goal-s3 [s3] martin goal fresh-start: known: determined to prove the move can work; confidence unrecorded; alternatives: (none recorded) → known: desperate to make someone believe the countdown before it ends; confidence unrecorded; alternatives: (none recorded)

State st-claire-belief-s3 [s3] claire belief martin-relapsed: known: certain Martin has started drinking again; confidence unrecorded; alternatives: (none recorded) → known: his hidden notes confirm her certainty; she stops considering other explanations; confidence unrecorded; alternatives: (none recorded)

State st-martin-belief-s4 [s4] martin belief can-be-believed: known: if he can show the evidence someone will believe him; confidence unrecorded; alternatives: (none recorded) → known: no amount of truth will outweigh their certainty, and he is alone with the countdown; confidence unrecorded; alternatives: (none recorded)

State st-claire-goal-s4 [s4] claire goal protect-june: known: manage Martin's relapse while keeping the household calm; confidence unrecorded; alternatives: (none recorded) → known: remove June from the house regardless of what Martin says; confidence unrecorded; alternatives: (none recorded)

State st-martin-goal-s5 [s5] martin goal protect-june: known: desperate to make someone believe the countdown before it ends; confidence unrecorded; alternatives: (none recorded) → known: get June out of the house before 3:17, even if she never believes why; confidence unrecorded; alternatives: (none recorded)

State st-june-belief-s5 [s5] june belief father-is-sick: known: her father's warnings are the relapse her mother warned her about; confidence unrecorded; alternatives: (none recorded) → known: the clocks are real and her father was right; confidence unrecorded; alternatives: (none recorded)

advisory unpaid_setup [setup-notes]: setup setup-notes at s3 has no payoff
