The tide had turned and was beginning its slow creep back up the mud, and Nell Harker was ankle-deep in the black ooze where the Thames gave up its secrets. The water lay flat and greasy under the summer sun, and the whole river stank like a drain, which was nothing new to her. She kept her eyes down, where the good things were — a twist of copper wire, the neck of a bottle, anything that might fetch a penny from the rag-and-bone man.

What she saw instead was a corner of leather, black with wet and wedged tight between two stones, with a brass clasp winking at her like a coin half-buried. She worked it loose with her fingers, heedless of the mud that climbed her wrists. It was a book — a thick one, the covers swollen and warped, the pages inside sodden but bound fast. Paper. Worthless, her mind said at once, for wet paper was good for nothing but the fire and this was too wet even for that. But the clasp was brass, and brass was brass.

She was reaching for her shawl to wrap it when a shadow fell across the mud.

"Well, mudlark. What's that you've got?"

It was one of the bailiff's boys, a lanky lad with a stick and a mean little grin, come down the stairs from the bridge to see what the scavengers had turned up. Nell's heart gave a thump. Found on the foreshore, it was the lord's, or the City's, or whoever's hands were quickest to claim it.

"Nothing," she said, and slid the book under her shawl in one motion, tucking it against her ribs where the wool would hide it. "A bit of rag."

The boy squinted at her, leaning on his stick. "Rag with a brass on it?"

"You saw no brass," Nell said, and held his eye the way her mother had taught her, though her heart was hammering. "You saw a girl with her hands full of nothing, and you'd best go look up the other bank, for I heard there's a whole crate come loose by the stairs."

He looked at her a long moment. Then he spat, and turned, and went, and Nell let out the breath she had been holding and felt the book's hard corner press against her, cold and heavy as a secret.

She waited until the tide turned and the last of the scavengers had gone up the stairs, then she climbed into the mouth of a broken drain where the wind couldn't reach. The notebook was sodden but not ruined; the pages had swollen like a pressed flower, and the ink had blurred at the edges, but the lines held.

She opened it flat on her knees.

There were numbers, which she couldn't read, but numbers she had no use for. It was the drawings that stopped her. Someone had drawn the river in a long black rope, and beside it the streets laid out like a game of cat's cradle, and through them all ran a heavy double line, ruled with a careful hand, slanting down and down toward the east.

She knew these shapes. She knew them the way she knew her own palm. She turned the book sideways and the crooked lane by the tanner's came upright under her finger, and there was the culvert where the water always stood green, and there—her breath went shallow—there was the notch of the court where she slept. The double line ran straight through it. Not beside it. Through it, like a needle through cloth.

She sat very still. She thought of the ground behind the court, how it fell away toward the river, how in a hard rain the water already came in under the doors and the neighbours put bricks down to stand on. A drain cut through there would not carry the water off. It would bring it.

She was up before she had decided to move, wading the shallows to the stairs, the book inside her shirt.

Arthur Pym was on the counting-house steps at the corner of the wharf, hunched over a slate, his cuffs grey with dust. He saw her and his face changed all at once—first blank, then sick.

"You," he said.

"You lost this." She held the corner of it out of her shirt, not enough to give it, enough to be seen.

His hand went to his mouth. "Quiet," he said. "For God's sake—" He glanced up and down the wharf and drew her into the shadow of the stair. His breath was short. "Where did you—never mind. Give it here and I'll say no more about it."

"It goes through Cooper's Court," she said. "Your line. I looked."

He stared at her as though she had spoken in a foreign tongue. "You can't read."

"I don't need to read to see a line go through a court." She pressed the book against her chest. "You'll tell them. The men who draw these."

Pym's face worked. "If anyone learns it left my hands," he said, low, "I'm finished. Turned off without a character. Do you understand what that means?" He swallowed. "Please. Just give it back and go, and I'll—I'll see you right. A shilling."

Nell did not move.

Nell did not move.

The young man in the good coat stood at the edge of the foreshore, his boots sinking, his face going from red to white and back again. He was not much older than some of the boys who worked the coal barges, and he had the soft hands of someone who had never pulled a rope in his life.

"That's mine," he said. "That's my book."

"Then you lost it," said Nell.

"I know I lost it." He stepped closer, then stopped, as though she were a dog that might bite. "Give it here, and I'll—I'll give you a shilling. Two shillings."

Nell held the notebook against her chest. "What's in it?"

"Nothing that would trouble you. Survey lines. Figures. It's dull as ditchwater, I promise you."

"I can't read," said Nell.

The clerk's mouth opened and shut. He looked at her hands, at the wet coat she wore, at the mud to her knees, and something in his face shifted—relief, maybe, or shame. "Then you don't know what you've got."

"I know what it draws." She turned a page and held it up. "That's the river. That's the new cut. And that—" she jabbed her finger at the line that ran down through the crooked squares— "that's the lane behind our court. The line goes straight through it."

He took the book from her, gently, and looked. His jaw worked. "It's only a plan. It's not built."

"It'll drown us. The ground falls that way. I've watched it in the rains since I was small."

The clerk glanced up and down the shore, as if expecting a policeman to rise out of the mud. "If my chief learns I had this out of the office—" He swallowed. "I'd be turned off. No character. I'd not get another clerkship in London."

"So you won't take it to them."

"I can't. You don't understand how these things work. A clerk doesn't walk into a room of engineers and tell them their scheme is wrong. Not a clerk like me."

"Then we'll be a pair," said Nell. "You can't read it out and I can't read it at all. But you can read, and I can show you where the lines go. You'll know it's true when you see it."

He was silent a long moment. The tide was turning; she could hear it working at the mud.

"Swear it," she said. "Swear you'll speak it to them. Not whisper it. Speak it out, so they hear."

"I—" He stopped, and she saw the stammer waiting in him, the way a rat waits at a hole. He took a breath and forced it down. "I swear."

"On what?"

"On my post," he said, and his voice was bitter. "It's the only thing I've got to swear on."

The works office stood at the end of a lane of stinking mud, its door propped open to let the summer air through, though the air did no good. Nell had washed her hands in the river and tucked the notebook under her jacket, and Arthur walked half a pace behind her, his collar turned up as though the whole of London might know his face.

Inspector Rook filled the doorway before they reached it. He had a constable's shoulders and a rate-collector's eyes, and he looked at Nell the way a man looks at a rat on a clean floor.

"Not this one," he said. "I know you, Nell Harker. Thieving off the foreshore and now bringing your filth up to the works. Be off, or I'll have you off."

"I've got something," Nell said. "A surveyor's book. It shows the new line—"

"A nuisance, that's what you've got." He put a hand out to turn her. "There's engineers inside with no time for mudlarks' tales."

Arthur started to speak and his tongue caught on the first word, and Rook's lip curled at the sound of it.

Nell ducked under his arm and got to the table where the plans lay pinned and weighted, and Rook came after her roaring, and she put her finger down on the paper and held it there.

"Here," she said. "Your line runs by the Falcon Stairs and turns up Cutler's Row, and then it comes to the low ground by the tanners' yard. I know that ground. It falls a foot and a half from the corner of Cutler's to the pump. It floods every winter, and if you put your sewer through it, the whole court goes under."

The room had gone quiet. One of the engineers looked up from his rule, and then down at the map, and then at the small dirty finger pressed against the paper.

"And how would a girl know the fall of the ground?" Rook said, but his voice had lost its certainty, and he said it to the engineer rather than to her.

Bazalgette looked at her for a long moment, then closed the notebook and handed it back to Arthur. "Show me," he said.

Nell led them out of the office and along the river, back toward her court. Bazalgette walked with his coat buttoned and his hat low, saying nothing, and Arthur came behind with the notebook clutched to his chest like a prayer book. At the mouth of the court Nell stopped and pointed.

"Here it's high," she said. "You can see the cobbles dry. Walk down to the end where the pump is, and the stones go wet even when it hasn't rained, and the water sits in the hollow by the step. That's the fall of it. The whole street tips toward the river, and the river's banked up higher than the street, so when it rises it don't go back down. It comes in."

Bazalgette walked the court himself, slowly, his boots deliberate on the cobbles. At the far end he crouched and put his palm flat against the wet stones, then looked back along the lane toward the river. He took a small level from his pocket and set it on the ground, and Nell watched the bubble drift.

"Show me the marks," he said, and she did, the waterline on the brick by the pump, the green stain halfway up the step, the place where the mud never dried.

He straightened. "The route as drawn runs along the low side," he said, half to himself. "It would cut the drain and back the water into every cellar here. The fall is the wrong way."

He turned to Arthur. "Whose survey is this?"

Arthur's mouth worked. "Mine, sir. I—I copied it wrong. The levels. I transposed them."

Bazalgette looked at him a moment, and at Nell, who had not moved and was not going to. "Then it's well it was found," he said. "I'll have the route shifted to the high side, along the new embankment. It costs more, but it spares this ground." He took out his own pencil and wrote in the margin of a folded plan. "And I'll want the name of the person who read the ground for me. Not the clerk. The girl."

Nell stood very still. In the court behind her, someone's washing hung motionless in the thick air, and for the first time in her life she understood that being heard was not the same as being loud.