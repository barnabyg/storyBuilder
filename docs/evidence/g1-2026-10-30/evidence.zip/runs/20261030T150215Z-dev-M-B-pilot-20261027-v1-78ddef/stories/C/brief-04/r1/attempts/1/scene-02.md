She waited until the tide turned and the last of the scavengers had gone up the stairs, then she climbed into the mouth of a broken drain where the wind couldn't reach. The notebook was sodden but not ruined; the pages had swollen like a pressed flower, and the ink had blurred at the edges, but the lines held.

She opened it flat on her knees.

There were numbers, which she couldn't read, but numbers she had no use for. It was the drawings that stopped her. Someone had drawn the river in a long black rope, and beside it the streets laid out like a game of cat's cradle, and through them all ran a heavy double line, ruled with a careful hand, slanting down and down toward the east.

She knew these shapes. She knew them the way she knew her own palm. She turned the book sideways and the crooked lane by the tanner's came upright under her finger, and there was the culvert where the water always stood green, and there—her breath went shallow—there was the notch of the court where she slept. The double line ran straight through it. Not beside it. Through it, like a needle through cloth.

She sat very still. She thought of the ground behind the court, how it fell away toward the river, how in a hard rain the water already came in under the doors and the neighbours put bricks down to stand on. A drain cut through there would not carry the water off. It would bring it.

She was up before she had decided to move, wading the shallows to the stairs, the book inside her shirt.

Arthur Pym was on the counting-house steps at the corner of the wharf, hunched over a slate, his cuffs grey with dust. He saw her and his face changed all at once—first blank, then sick.

"You," he said.

"You lost this." She held the corner of it out of her shirt, not enough to give it, enough to be seen.

His hand went to his mouth. "Quiet," he said. "For God's sake—" He glanced up and down the wharf and drew her into the shadow of the stair. His breath was short. "Where did you—never mind. Give it here and I'll say no more about it."

"It goes through Cooper's Court," she said. "Your line. I looked."

He stared at her as though she had spoken in a foreign tongue. "You can't read."

"I don't need to read to see a line go through a court." She pressed the book against her chest. "You'll tell them. The men who draw these."

Pym's face worked. "If anyone learns it left my hands," he said, low, "I'm finished. Turned off without a character. Do you understand what that means?" He swallowed. "Please. Just give it back and go, and I'll—I'll see you right. A shilling."

Nell did not move.