Mateo came around the side of the truck with the folded receipt in his hand. He must have fished it from her apron when she turned, or maybe she'd dropped it and he'd picked it up the way he picked up everything—quietly, before she knew she'd lost it.

"Thirty-one," he said. "You counted."

"I count every day."

"You counted and you told Tomás." His jaw was tight. "You told him about the numbers, and you didn't tell him about the burner. About any of it."

"Neither did you."

"Because I thought we were—" He stopped himself. "I thought we had an arrangement. I thought the arrangement was the point."

"The lease is the point." Her voice came out harder than she meant. "You knew that going in."

"So it's true, then. You're taking it for yourself after all."

She wanted to say no. The word was there, ready, and what came out instead was, "Somebody has to." Because it was true, and because he'd said it first, and because pride was cheaper than honesty and she had a pocket full of receipts to prove it.

He looked at her the way he'd looked at the burnt batch on the second morning—not angry, worse, disappointed, already revising the recipe.

"Then we're done sharing," he said, and went to his window.

She took the menu board down from between the trucks—the one they'd chalked together, his handwriting slanted under hers, the day's specials in two colors—and she tore it down the middle, then the middle again, and dropped the pieces in the bin where he could see them. The lunch rush came and she worked it alone, one burner, her own salt, her own hands moving exactly as fast as hers could move. The line was shorter than yesterday. She told herself it was the heat.