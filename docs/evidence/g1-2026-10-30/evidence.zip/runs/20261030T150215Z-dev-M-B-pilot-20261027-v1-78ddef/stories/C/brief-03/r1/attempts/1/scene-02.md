Priya waited until the bell over the door stopped swinging, then lifted the counter flap and followed.

Out in the lot the night air was thin and cold. Margaret walked slowly, one hand on the fender of each parked car as she passed, until she reached the far corner under the broken light. A silver sedan idled there, and a man Priya didn't recognize leaned against it, collar up, watching the street.

Priya stopped behind a delivery van and watched Margaret draw a white bag from her coat. The man took it, felt its weight, and counted bills into her palm without a word. Margaret folded the money and put it away. The sedan pulled out, and she stood alone a moment under the dead light, her breath clouding.

Priya stepped out from behind the van. "Mrs. Doyle."

Margaret didn't startle. She turned as though she'd known the whole time. "You followed me."

"I did."

"Then you saw."

"I saw you sell prescription medication to a man in a parking lot. That's a felony, and so is what I'd be if I kept filling it."

Margaret nodded slowly, as if Priya had said something reasonable about the weather. "His name is Dale. He pays cash. He doesn't ask questions." She looked down at her shoes. "I have a woman who comes Tuesdays and Fridays. Helps me wash. Cooks a little. Forty dollars a visit. The dialysis is three times a week—the rides alone are twenty each way, and Medicare doesn't care how tired I am or how far the clinic is."

Priya said nothing.

"I'm not asking you to feel sorry for me," Margaret said. "I'm telling you where it goes. It goes to keeping me upright. That's all it does."

The wind moved through the lot. Somewhere a car door slammed. Priya looked at the old woman's hands, still closed around the folded bills, and understood that she had just watched the exact arithmetic of a life being stretched to cover itself.

"Go home, Mrs. Doyle," she said. "I'll think about it."

"Don't think too long," Margaret said. "Dale comes Tuesdays."