The tide had turned and was beginning its slow creep back up the mud, and Nell Harker was ankle-deep in the black ooze where the Thames gave up its secrets. The water lay flat and greasy under the summer sun, and the whole river stank like a drain, which was nothing new to her. She kept her eyes down, where the good things were — a twist of copper wire, the neck of a bottle, anything that might fetch a penny from the rag-and-bone man.

What she saw instead was a corner of leather, black with wet and wedged tight between two stones, with a brass clasp winking at her like a coin half-buried. She worked it loose with her fingers, heedless of the mud that climbed her wrists. It was a book — a thick one, the covers swollen and warped, the pages inside sodden but bound fast. Paper. Worthless, her mind said at once, for wet paper was good for nothing but the fire and this was too wet even for that. But the clasp was brass, and brass was brass.

She was reaching for her shawl to wrap it when a shadow fell across the mud.

"Well, mudlark. What's that you've got?"

It was one of the bailiff's boys, a lanky lad with a stick and a mean little grin, come down the stairs from the bridge to see what the scavengers had turned up. Nell's heart gave a thump. Found on the foreshore, it was the lord's, or the City's, or whoever's hands were quickest to claim it.

"Nothing," she said, and slid the book under her shawl in one motion, tucking it against her ribs where the wool would hide it. "A bit of rag."

The boy squinted at her, leaning on his stick. "Rag with a brass on it?"

"You saw no brass," Nell said, and held his eye the way her mother had taught her, though her heart was hammering. "You saw a girl with her hands full of nothing, and you'd best go look up the other bank, for I heard there's a whole crate come loose by the stairs."

He looked at her a long moment. Then he spat, and turned, and went, and Nell let out the breath she had been holding and felt the book's hard corner press against her, cold and heavy as a secret.