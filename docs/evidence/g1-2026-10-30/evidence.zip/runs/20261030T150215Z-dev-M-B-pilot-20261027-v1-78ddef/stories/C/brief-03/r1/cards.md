# The Dead Man's Refills

Plan brief-03; schema 1; tier M

Character priya: Priya Raman

Character margaret: Margaret Doyle

Character halvorsen: Detective Halvorsen

Character eugene: Eugene Doyle

## s1: Night Count

Priya spots a refill for a dead man and meets the woman paying for it.

Present: priya, margaret

Beat s1-b1: Priya counts the same monthly refill for Eugene Doyle and notes the death date in the file.

Beat s1-b2: Margaret pays in crumpled cash and asks Priya not to call the family.

Fact fact-eugene-dead: Eugene Doyle has been dead three months, yet refills continue in his name.; initial holders: priya, margaret

Fact fact-cash-secrecy: Margaret pays in crumpled cash and begs Priya not to call the family.; initial holders: priya, margaret

Fact fact-money-for-care: Margaret sells the pills to fund her home aide and dialysis rides.; initial holders: margaret

Fact fact-audit-flag: The pharmacy audit has flagged a diversion of controlled refills, and Halvorsen is asking Priya who handled them.; initial holders: halvorsen

Fact fact-margaret-defers: Margaret has stopped deciding for herself and wants Priya to choose what happens to them both.; initial holders: margaret

Fact fact-eugene-scheme: Before dying, Eugene wrote and notarized a letter authorizing the refills and naming Margaret as the seller, so the scheme was his design to fund her care.; initial holders: eugene, margaret

Causal cl-s1-s2: earlier cause s1 → effect s2

Setup setup-letter at s1: Eugene's file contains a sealed, notarized envelope Priya never opens in the opening count.

Knowledge use ku-s1-dead: priya uses fact fact-eugene-dead at s1

## s2: The Buyer

Priya follows Margaret and learns where the pills and the money go.

Present: priya, margaret

Beat s2-b1: Priya follows Margaret to a parking lot and watches her sell the pills to a stranger.

Beat s2-b2: Margaret admits the money pays for her home aide and dialysis rides.

Causal cl-s1-s2: earlier cause s1 → effect s2

Causal cl-s2-s3: earlier cause s2 → effect s3

Reveal rev-s2-care: fact fact-money-for-care at s2; holders: priya (acquired at scene start)

Knowledge use ku-s2-dead: priya uses fact fact-eugene-dead at s2

Knowledge use ku-s2-cash: priya uses fact fact-cash-secrecy at s2

## s3: Paper Trail

A detective's questions force Priya to choose silence over disclosure.

Present: priya, halvorsen

Beat s3-b1: Halvorsen questions Priya about a diversion flagged in the pharmacy audit.

Beat s3-b2: Priya lies by omission and immediately regrets the ease of it.

Causal cl-s2-s3: earlier cause s2 → effect s3

Causal cl-s3-s4: earlier cause s3 → effect s4

Reveal rev-s3-flag: fact fact-audit-flag at s3; holders: priya (acquired at scene start)

Knowledge use ku-s3-care: priya uses fact fact-money-for-care at s3

Knowledge use ku-s3-flag: priya uses fact fact-audit-flag at s3

## s4: Two Weeks

Priya stalls between quitting and reporting as Margaret pushes the choice onto her.

Present: priya, margaret

Beat s4-b1: Priya drafts a resignation letter and a report in the same hour, unable to file either.

Beat s4-b2: Margaret returns the unused bottles and asks Priya to decide for both of them.

Causal cl-s3-s4: earlier cause s3 → effect s4

Reveal rev-s4-defers: fact fact-margaret-defers at s4; holders: priya (acquired at scene start)

Knowledge use ku-s4-care: priya uses fact fact-money-for-care at s4

Knowledge use ku-s4-flag: priya uses fact fact-audit-flag at s4

## s5: The Letter

Eugene's own letter reveals he built the scheme, recasting everything Priya saw.

Present: priya, margaret, eugene

Beat s5-b1: Priya finds a notarized letter from Eugene in the file authorizing the refills and naming Margaret as seller.

Beat s5-b2: The letter reveals Eugene arranged the scheme before his death to fund Margaret's care, recasting every earlier scene.

Payoff pay-letter: setup setup-letter → payoff at s5

Reveal rev-s5-scheme: fact fact-eugene-scheme at s5; holders: priya (acquired at scene start)

Knowledge use ku-s5-defers: priya uses fact fact-margaret-defers at s5

Knowledge use ku-s5-scheme: priya uses fact fact-eugene-scheme at s5

State st-s1-goal [s1] priya goal resolve-discrepancy: known: finish the night count without incident; confidence unrecorded; alternatives: (none recorded) → known: determine why a dead man's refill keeps coming; confidence unrecorded; alternatives: (none recorded)

State st-s1-belief [s1] priya belief margaret-motive: known: a grieving widow clinging to her husband's routine; confidence unrecorded; alternatives: (none recorded) → ambiguous: something is off; she is hiding something larger; confidence unrecorded; alternatives: grief; fraud; something else

State st-s2-goal [s2] priya goal resolve-discrepancy: known: determine why a dead man's refill keeps coming; confidence unrecorded; alternatives: (none recorded) → known: learn what Margaret does with the pills before deciding anything; confidence unrecorded; alternatives: (none recorded)

State st-s2-belief [s2] priya belief margaret-motive: ambiguous: something is off; she is hiding something larger; confidence unrecorded; alternatives: grief; fraud; something else → known: Margaret sells the pills because she cannot afford to live without the money; confidence unrecorded; alternatives: (none recorded)

State st-s3-goal [s3] priya goal resolve-discrepancy: known: learn what Margaret does with the pills before deciding anything; confidence unrecorded; alternatives: (none recorded) → known: keep Margaret's name out of the audit without lying outright to a detective; confidence unrecorded; alternatives: (none recorded)

State st-s4-goal [s4] priya goal resolve-discrepancy: known: keep Margaret's name out of the audit without lying outright to a detective; confidence unrecorded; alternatives: (none recorded) → known: decide whether to file the report or the resignation before Margaret's next refill; confidence unrecorded; alternatives: (none recorded)

State st-s4-belief [s4] priya belief who-owns-the-choice: known: this is my decision alone to carry; confidence unrecorded; alternatives: (none recorded) → known: Margaret has handed me the choice on purpose; whatever I do now I do for both of us; confidence unrecorded; alternatives: (none recorded)

State st-s5-belief [s5] priya belief who-authored-the-scheme: known: Margaret invented the scheme and I am shielding her from its consequences; confidence unrecorded; alternatives: (none recorded) → known: Eugene built the scheme himself and Margaret only carried out his last instruction; my silence was never just hers to own; confidence unrecorded; alternatives: (none recorded)
