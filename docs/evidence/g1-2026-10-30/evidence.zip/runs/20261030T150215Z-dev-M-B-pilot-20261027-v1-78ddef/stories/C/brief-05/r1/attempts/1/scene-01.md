The farmhouse smelled of dust and old wood, and Martin Leigh carried the last box up the porch steps with a lightness in his chest he hadn't felt in years. The fields rolled out behind the house, green and quiet, and the only sound was June's sneakers slapping the floorboards as she ran from room to room claiming territory.

"Pick a bedroom, any bedroom," Claire called after her. She stood in the kitchen doorway with her arms crossed, taking in the peeling wallpaper and the deep farm sink. "Anything's better than the apartment."

Martin set the box down and grinned at her. "Told you. Fresh air, room to breathe. This is going to be good for us."

Claire didn't answer, but he caught the small lift at the corner of her mouth, and that was enough.

He wandered into the front room. A mantel clock sat above the empty fireplace, a brass thing with a cracked face. He wound it out of habit and frowned at the hands. Then he crossed to the wall clock in the hall. Then the little alarm clock in the kitchen, the one shaped like a frying pan, and the grandfather clock in the corner of the dining room that he had to open the glass to inspect.

Three seventeen. Every one of them. Three seventeen, dead and silent, their pendulums hanging still.

"Claire. Every clock in this house is stopped."

"Probably the power was out," she said, not looking up. "Or the old owners just didn't bother."

He tried the grandfather's pendulum. It wouldn't swing.

In the kitchen, Claire opened the cabinet beneath the sink. Empty. She moved to the pantry, then the sideboard in the dining room, her hand drifting along the shelves, lifting the bottle of cooking sherry and turning it over, reading the label. She set it back and closed the door without a sound.

Martin came back through, and she was wiping the counter with a rag, her face smooth and pleasant. "June wants the room with the window seat," she said.

"Then she gets it." He squeezed her shoulder. "New start, Claire. I mean it."

"I know," she said, and smiled, and he believed her.