Martin found the first one in the pantry and carried it to the kitchen table, a heavy mantel clock with a chipped walnut case. He set it beside the wall clock and the little brass alarm from June's room, lined up like specimens. He'd never been much for numbers, but sobriety had taught him to keep track of things. Days. Hours. The exact count of everything he was trying not to lose.

The hands had moved. All of them had moved, and none of them agreed.

He wrote it down in the notebook he'd started keeping in his jacket, the same way he'd once kept a tally of drinks. The pantry clock ran fast by six minutes. The kitchen clock by nine. The one from upstairs, by a quarter of an hour. He circled the numbers and drew an arrow, then another, and saw where they pointed. Not back to where they'd started. Forward. Toward the same hour, each at its own pace, as though the whole house were leaning toward a single minute.

Three seventeen.

He sat with that a long time, the pencil gone slick in his hand. It was ridiculous. It was the kind of thing a man saw when he was looking for something to be wrong. But the clocks had been stopped at that minute when they arrived, and now they were running, and every one of them was racing to get back to it.

He heard Claire in the hallway and shut the notebook, slid it under a stack of unpacked plates. She came in with her sleeves pushed up, the way she did when she was about to say something she'd rehearsed.

"Martin."

"Hey." He stood too fast. "I was just sorting the—"

She held up the notebook. She'd found it anyway. It lay open in her hands, and he could see his own cramped columns, the circled times, the word he'd written at the bottom of the page in letters he hadn't meant anyone to read. *3:17.*

"What is this?" Her voice was careful. That was worse than anger. "I found it in your coat. Are you writing down when you drink now? Times, amounts?"

"No. Claire, no, it's the clocks—"

"The clocks." She looked at the table, at the three of them ticking away out of step, and something in her face closed like a door. "You're sneaking around the house at night, you're writing numbers in a notebook you're hiding from me, and you're telling me it's the clocks."

"I'm not drinking. I swear to you."

She turned the notebook over, as if there might be more, and he watched her believe the worst of him, calmly and completely, and he understood that the truth was the one story she would never be able to hear.