He found her in the kitchen, packing June's things into a canvas bag with the deliberate calm of someone who had already decided. Above the sink, the clock said 2:41. It had said 2:39 when he'd come down.

"Claire. Look at it. Look at the minute hand and don't look away for sixty seconds."

"I'm not doing this tonight." She folded a sweater into the bag. "I'm not going to stand here and watch you build a case out of a clock."

"Then don't watch me. Watch it. Whatever you think of me—fine. But watch it and tell me it moves like a clock should."

She did look, briefly, the way you check something to prove it isn't worth checking, and he saw her eyes try to hold the thin black hand and fail. It swept too fast. It swept like a second hand, not a minute hand, and somewhere behind the walls the house ticked like a heart running a fever.

"2:43," he said. "It was 2:39 four minutes ago. It's not keeping time, Claire. It's spending it. There's less than half an hour left."

"Stop." Her voice cracked, and that was worse than anger. "Do you hear yourself? You have a notebook full of this. Times, arrows, numbers—you wrote it all down in the dark like you used to hide bottles. I found it, Martin. I wasn't even looking, and I found it." She closed the bag. "I've done this before. I know how it starts. The intensity. The certainty. I am not going to let June grow up inside that again."

He caught her wrist, gently, and she went still. "Then leave me here. Take her, go to your sister's, I don't care—but not because of me. Because of that. Please. Just tonight. Just until three-eighteen."

"Because of a clock." She pulled free. "Listen to what you're asking me to believe."

"That's all I'm asking. To believe me."

She climbed the stairs and came down with June in her coat, small and blinking and half asleep. Martin crouched to her height and made himself smile, and it felt like lifting a stone.

"Go with Mum," he said. "I'll see you tomorrow."

Claire paused at the door, keys in hand, and for one bare second he thought she might turn back.

"Don't drink," she said. "Please."

Then the door shut, and the ticking filled the house, and the clock over the sink read 2:51.