Bazalgette looked at her for a long moment, then closed the notebook and handed it back to Arthur. "Show me," he said.

Nell led them out of the office and along the river, back toward her court. Bazalgette walked with his coat buttoned and his hat low, saying nothing, and Arthur came behind with the notebook clutched to his chest like a prayer book. At the mouth of the court Nell stopped and pointed.

"Here it's high," she said. "You can see the cobbles dry. Walk down to the end where the pump is, and the stones go wet even when it hasn't rained, and the water sits in the hollow by the step. That's the fall of it. The whole street tips toward the river, and the river's banked up higher than the street, so when it rises it don't go back down. It comes in."

Bazalgette walked the court himself, slowly, his boots deliberate on the cobbles. At the far end he crouched and put his palm flat against the wet stones, then looked back along the lane toward the river. He took a small level from his pocket and set it on the ground, and Nell watched the bubble drift.

"Show me the marks," he said, and she did, the waterline on the brick by the pump, the green stain halfway up the step, the place where the mud never dried.

He straightened. "The route as drawn runs along the low side," he said, half to himself. "It would cut the drain and back the water into every cellar here. The fall is the wrong way."

He turned to Arthur. "Whose survey is this?"

Arthur's mouth worked. "Mine, sir. I—I copied it wrong. The levels. I transposed them."

Bazalgette looked at him a moment, and at Nell, who had not moved and was not going to. "Then it's well it was found," he said. "I'll have the route shifted to the high side, along the new embankment. It costs more, but it spares this ground." He took out his own pencil and wrote in the margin of a folded plan. "And I'll want the name of the person who read the ground for me. Not the clerk. The girl."

Nell stood very still. In the court behind her, someone's washing hung motionless in the thick air, and for the first time in her life she understood that being heard was not the same as being loud.