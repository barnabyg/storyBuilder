# The Mudlark's Map

Plan brief-04; schema 1; tier M

Character nell: Nell Harker

Character clerk: Arthur Pym

Character engineer: Mr. Bazalgette

Character inspector: Inspector Rook

## s1: Low Water, Black Water

Nell finds a waterlogged surveyor's notebook in the Thames mud.

Present: nell

Beat b1a: At low tide Nell spots a brass-clasped notebook wedged in the mud.

Beat b1b: She hides it in her shawl as a bailiff's boy eyes her.

Fact fact-notebook: The notebook holds a surveyor's planned sewer route.; initial holders: clerk

Fact fact-route-cuts-court: The drawn sewer route passes straight through Nell's own court.; initial holders: clerk

Fact fact-clerk-post-risk: Arthur lost the notebook and would lose his post if his superiors learned of it.; initial holders: clerk

Fact fact-ground-fall: The ground falls toward Nell's court, so the planned route would flood it.; initial holders: nell

Setup setup-notebook at s1: The notebook is found and kept, making its drawings available to be read and tested later.

## s2: Marks She Cannot Read

Nell studies the notebook's lines and routes by shape, not letters.

Present: nell, clerk

Beat b2a: Nell traces the drawn sewer line and sees it cut through her own court.

Beat b2b: She confronts Arthur Pym, the clerk, who begs her to return it quietly.

Causal c-s2-s3: earlier cause s2 → effect s3

Reveal rev-s2-nell: fact fact-route-cuts-court at s2; holders: nell (acquired at scene start)

## s3: The Clerk's Bargain

Arthur agrees to read the notebook aloud if Nell keeps his secret.

Present: nell, clerk

Beat b3a: Arthur admits the notebook is his and that losing it would cost him his post.

Beat b3b: Nell makes him swear to speak her warning to the engineers.

Causal c-s2-s3: earlier cause s2 → effect s3

Causal c-s3-s4: earlier cause s3 → effect s4

Reveal rev-s3-nell: fact fact-clerk-post-risk at s3; holders: nell (acquired at scene start)

## s4: Turned Away at the Door

The engineers dismiss a mudlark and a stammering clerk.

Present: nell, clerk, inspector

Beat b4a: Inspector Rook blocks Nell at the works office and calls her a nuisance.

Beat b4b: Nell points out the flood line on the map with her exact memory of the streets.

Causal c-s3-s4: earlier cause s3 → effect s4

Causal c-s4-s5: earlier cause s4 → effect s5

Knowledge use ku-s4-nell: nell uses fact fact-route-cuts-court at s4

## s5: The Surveyor Listens

Bazalgette tests Nell's claim against the notebook and his own plans.

Present: nell, clerk, engineer

Beat b5a: Bazalgette walks the court with Nell and sees the fall of the ground for himself.

Beat b5b: He orders the sewer route shifted to spare the district.

Causal c-s4-s5: earlier cause s4 → effect s5

Payoff pay-notebook: setup setup-notebook → payoff at s5

Reveal rev-s5-engineer: fact fact-route-cuts-court at s5; holders: engineer (acquired at scene start)

Reveal rev-s5-engineer-ground: fact fact-ground-fall at s5; holders: engineer (acquired at scene start)

Knowledge use ku-s5-nell: nell uses fact fact-ground-fall at s5

State st-nell-goal-1 [s1] nell goal aim: known: scavenge for salable finds before the tide returns; confidence 0.8; alternatives: (none recorded) → known: keep the strange brass-clasped find hidden and safe; confidence 0.8; alternatives: (none recorded)

State st-nell-belief-1 [s1] nell belief notebook-worth: known: paper is worthless in the mud; confidence 0.7; alternatives: (none recorded) → ambiguous: this paper matters to someone, and might matter to her; confidence 0.5; alternatives: just a rich man's litter

State st-nell-belief-2 [s2] nell belief notebook-worth: ambiguous: this paper matters to someone, and might matter to her; confidence 0.5; alternatives: just a rich man's litter → known: the notebook is a threat to her own court, and she must act on it; confidence 0.8; alternatives: (none recorded)

State st-nell-goal-2 [s2] nell goal aim: known: keep the strange brass-clasped find hidden and safe; confidence 0.8; alternatives: (none recorded) → known: get the notebook's warning understood and acted upon; confidence 0.7; alternatives: (none recorded)

State st-clerk-belief-1 [s2] clerk belief nell-threat: known: a mudlark with his notebook is a danger to his post; confidence 0.6; alternatives: (none recorded) → known: the girl knows the route and will not be bought off quietly; confidence 0.7; alternatives: (none recorded)

State st-nell-belief-3 [s3] nell belief clerk-leverage: ambiguous: the clerk holds the letters and she holds the paper; confidence 0.5; alternatives: he can simply take it from her → known: his fear of losing his post gives her a hold to bargain with; confidence 0.7; alternatives: (none recorded)

State st-clerk-goal-1 [s3] clerk goal aim: known: recover the notebook quietly and keep his post; confidence 0.8; alternatives: (none recorded) → known: keep the girl silent by helping her warning reach the engineers; confidence 0.6; alternatives: still try to buy back the notebook outright

State st-nell-goal-3 [s4] nell goal aim: known: get the notebook's warning understood and acted upon; confidence 0.7; alternatives: (none recorded) → known: force the office to hear her proof before Rook drives her off; confidence 0.7; alternatives: (none recorded)

State st-nell-belief-4 [s4] nell belief being-heard: ambiguous: if the warning is true enough, the powerful must listen; confidence 0.5; alternatives: only someone with station can make them listen → known: truth alone is turned away; proof must be shoved under their noses; confidence 0.7; alternatives: (none recorded)

State st-nell-belief-5 [s5] nell belief being-heard: known: truth alone is turned away; proof must be shoved under their noses; confidence 0.7; alternatives: (none recorded) → known: a witness who can show the ground can make even a powerful man look and change his plan; confidence 0.8; alternatives: (none recorded)
