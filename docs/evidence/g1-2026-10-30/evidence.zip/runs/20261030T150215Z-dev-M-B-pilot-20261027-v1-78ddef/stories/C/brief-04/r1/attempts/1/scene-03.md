Nell did not move.

The young man in the good coat stood at the edge of the foreshore, his boots sinking, his face going from red to white and back again. He was not much older than some of the boys who worked the coal barges, and he had the soft hands of someone who had never pulled a rope in his life.

"That's mine," he said. "That's my book."

"Then you lost it," said Nell.

"I know I lost it." He stepped closer, then stopped, as though she were a dog that might bite. "Give it here, and I'll—I'll give you a shilling. Two shillings."

Nell held the notebook against her chest. "What's in it?"

"Nothing that would trouble you. Survey lines. Figures. It's dull as ditchwater, I promise you."

"I can't read," said Nell.

The clerk's mouth opened and shut. He looked at her hands, at the wet coat she wore, at the mud to her knees, and something in his face shifted—relief, maybe, or shame. "Then you don't know what you've got."

"I know what it draws." She turned a page and held it up. "That's the river. That's the new cut. And that—" she jabbed her finger at the line that ran down through the crooked squares— "that's the lane behind our court. The line goes straight through it."

He took the book from her, gently, and looked. His jaw worked. "It's only a plan. It's not built."

"It'll drown us. The ground falls that way. I've watched it in the rains since I was small."

The clerk glanced up and down the shore, as if expecting a policeman to rise out of the mud. "If my chief learns I had this out of the office—" He swallowed. "I'd be turned off. No character. I'd not get another clerkship in London."

"So you won't take it to them."

"I can't. You don't understand how these things work. A clerk doesn't walk into a room of engineers and tell them their scheme is wrong. Not a clerk like me."

"Then we'll be a pair," said Nell. "You can't read it out and I can't read it at all. But you can read, and I can show you where the lines go. You'll know it's true when you see it."

He was silent a long moment. The tide was turning; she could hear it working at the mud.

"Swear it," she said. "Swear you'll speak it to them. Not whisper it. Speak it out, so they hear."

"I—" He stopped, and she saw the stammer waiting in him, the way a rat waits at a hole. He took a breath and forced it down. "I swear."

"On what?"

"On my post," he said, and his voice was bitter. "It's the only thing I've got to swear on."