# The Shared Permit

Plan brief-06; schema 1; tier M

Character lucia: Lucía Ferrer

Character mateo: Mateo Ríos

Character tomas: Tomás Vidal

## sc-01: One Space, Two Trucks

Lucía arrives at the festival lot to find Mateo already parked on the single permit she thought was hers.

Present: lucia, mateo

Beat b-01a: The permit clerk says the error cannot be undone before opening night.

Beat b-01b: Lucía refuses Mateo's offer to split the spot and stakes her claim.

Fact kf-permit-error: The single parking permit was double-issued by a clerical error that cannot be corrected before opening night.; initial holders: lucia, mateo

Fact kf-lease-rule: The landlord's lease goes to the truck with the best solo festival numbers, not to a partnership.; initial holders: tomas

Causal cl-01-02: earlier cause sc-01 → effect sc-02

## sc-02: Truce at the Frying Line

A morning rush forces the rivals to share burners and customers, and their food improves.

Present: lucia, mateo

Beat b-02a: Mateo salts Lucía's sauce without asking and it wins the crowd.

Beat b-02b: Lucía quietly returns the favor by fixing his burnt batch.

Causal cl-01-02: earlier cause sc-01 → effect sc-02

Causal cl-02-03: earlier cause sc-02 → effect sc-03

Setup setup-sauce at sc-02: Mateo's unasked-for salt on Lucía's sauce proves their cooking is better together.

## sc-03: The Lease Judge

Tomás, the landlord's scout, tells Lucía the lease goes to the truck with the best festival numbers.

Present: lucia, tomas

Beat b-03a: Tomás praises the shared line and hints the winner must stand alone.

Beat b-03b: Lucía hides the partnership from her own pride and starts counting sales.

Causal cl-02-03: earlier cause sc-02 → effect sc-03

Causal cl-03-04: earlier cause sc-03 → effect sc-04

Reveal rv-lease-rule: fact kf-lease-rule at sc-03; holders: lucia (acquired at scene start)

## sc-04: Split Down the Middle

Lucía and Mateo fight over credit for their best day and each claims the permit alone.

Present: lucia, mateo

Beat b-04a: Mateo accuses Lucía of taking the lease for herself after all.

Beat b-04b: Lucía tears up their shared menu board and works the next shift solo.

Causal cl-03-04: earlier cause sc-03 → effect sc-04

Causal cl-04-05: earlier cause sc-04 → effect sc-05

Knowledge use ku-lease-rule-lucia: lucia uses fact kf-lease-rule at sc-04

## sc-05: The Last Service

On closing night Lucía wins the lease and realizes the kitchen she wants is the one they built together.

Present: lucia, mateo, tomas

Beat b-05a: Tomás hands Lucía the winning lease and she sees Mateo packing his truck.

Beat b-05b: Lucía gives the lease back and asks Mateo to open a restaurant with her instead.

Causal cl-04-05: earlier cause sc-04 → effect sc-05

Payoff po-sauce: setup setup-sauce → payoff at sc-05

State st-lucia-goal-spot [sc-01] lucia goal permit: known: arrives certain the permit is hers alone; confidence 0.9; alternatives: (none recorded) → known: refuses any shared arrangement; must hold the spot alone; confidence 0.9; alternatives: (none recorded)

State st-lucia-belief-mateo [sc-01] lucia belief mateo: known: a rival who took what was hers; confidence 0.7; alternatives: (none recorded) → ambiguous: a rival who is oddly willing to compromise; confidence 0.5; alternatives: a genuine rival; someone testing her pride

State st-lucia-belief-mateo-sc02 [sc-02] lucia belief mateo: ambiguous: a rival who is oddly willing to compromise; confidence 0.5; alternatives: a genuine rival; someone testing her pride → known: a cook whose instincts sharpen her own; confidence 0.6; alternatives: (none recorded)

State st-lucia-goal-lease-sc03 [sc-03] lucia goal permit: known: refuses any shared arrangement; must hold the spot alone; confidence 0.9; alternatives: (none recorded) → known: win the lease by outselling Mateo, even if the partnership must be hidden; confidence 0.8; alternatives: (none recorded)

State st-lucia-belief-mateo-sc04 [sc-04] lucia belief mateo: known: a cook whose instincts sharpen her own; confidence 0.6; alternatives: (none recorded) → ambiguous: a rival who sees her as the one who betrays first; confidence 0.5; alternatives: a rival justified in distrusting her; a mirror of her own pride

State st-lucia-goal-lease-sc05 [sc-05] lucia goal permit: known: win the lease by outselling Mateo, even if the partnership must be hidden; confidence 0.8; alternatives: (none recorded) → known: give the lease back and build a restaurant with Mateo; confidence 0.9; alternatives: (none recorded)
