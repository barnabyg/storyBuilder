By seven the line at her window was six deep, and the fryer was the only thing on her truck that didn't need an apology. She had the chorizo criollo going, the peppers blistering, the sauce she'd built that morning at four a.m. when she couldn't sleep for wanting this. Then she turned her back for one minute to bag an order, and when she turned around Mateo was leaning across her prep rail with a pinch of flake salt in his fingers, dropping it over her pot like he owned the place.

"Hey—"

"Taste it," he said, and stepped back before she could hit him with the ladle.

She tasted it, furious. It was better. The sauce had been tight and sour at the edges, working too hard, and the salt had opened it up like a window. A woman at the front of the line said, "Oh, that's *good*," and then four more people said it, and Lucía stood there with the ladle and the salt taste on her tongue and hated how right he was.

"Your flame's too high on the far burner," she told him, not looking at him, and pointed through the gap between their trucks. "You're burning the onions."

"I know."

"Then fix it."

He went. She heard him scraping, swearing softly, and then the smell of scorch going bitter and spreading, and the line at his window backing up and shuffling over to hers with the patience of hungry people who did not care whose truck was whose. She finished her orders. Then she wiped her hands, walked around the back of his truck, took the spatula out of his grip, and tipped the burnt batch into the bin.

"You don't throw it out," he said, wounded.

"You don't serve it." She dropped the pan back on the flame, added oil, and slid in a fresh handful of onions. "Lower. Watch the edges go glassy before you touch them. And your salt was good. Don't make me say it twice."

He stood beside her at his own stove, close enough that their elbows almost touched, and neither of them moved away.