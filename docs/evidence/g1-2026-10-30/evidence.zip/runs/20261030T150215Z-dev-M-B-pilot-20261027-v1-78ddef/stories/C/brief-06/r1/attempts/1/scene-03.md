Tomás came by at noon, in a linen jacket that had no business at a food festival, and stood in front of the two trucks with his hands folded behind his back like a man appraising a painting.

"Now this," he said, "this I like. Two lines, one rhythm. Your girl hands off a ticket and yours has the plate up before she's turned around." He nodded at the shared burner, where Mateo's pan and Lucía's saucepan sat side by side. "Somebody in this lot is cooking with a second pair of hands. I can taste it."

Lucía wiped her knife and said nothing.

"One thing, though." Tomás leaned in, lowering his voice as if it were a kindness. "The lease. My client is old-fashioned. He looks at one truck's numbers, one name on the paper. A partnership reads to him like a man who can't decide what he's selling." He tapped the counter once. "Best solo week wins the lease. Keep that in mind."

He moved on down the row. Lucía stood very still until he was three stalls gone.

"Best solo week," she said, to no one, to herself. She pulled the cash box out from under the counter and set it down hard. "Fine. Then we count."

Mateo looked up from the flat top. "Count what?"

"Everything." She was already separating the bills. "My till, your till. From this morning on."

"Lucía—"

"Tomás likes the shared line." She squared the stack of fives. "Tomás isn't the one signing."

It wasn't true, what she'd said to Tomás, or rather it was true the way a lie is true—she hadn't told him about the shared burner, the salt in her sauce, the way Mateo's hand moved to the pan before she asked. Pride had kept her mouth shut, and pride was cheaper than honesty. She counted. Thirty-one tickets before noon, and she knew exactly which of them had come for his name and which for hers, and she wrote the number on the back of a receipt and folded it into her apron like a secret she was already ashamed of keeping.