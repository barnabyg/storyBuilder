The night count was the only part of the shift Priya liked. Two a.m., the front lights down, the register quiet, and a drawer of paper prescriptions to reconcile against the system before the morning pharmacist arrived. She worked the stack with a pen in her teeth, ticking each one.

Eugene Doyle, R-4471. She ticked it and moved on, then stopped.

She shuffled back. The slip was a monthly refill, ninety tablets, metoprolol. She checked the file tab and there it was in the system, the same refill, three months running. And above it, in the red block the software used for flagged accounts, a date of death. Eugene Doyle had died in March. This was June.

Priya sat back and looked at the ceiling, at the water stain shaped like a boot. It would be a clerical error, she thought. Family hadn't cancelled. It happened. But the refills kept being picked up, which meant somebody kept coming in, and the register would show who.

The bell over the door went at a quarter past two. Priya looked up from the drawer.

The woman was old, older than the pharmacy's usual night traffic, in a coat too heavy for June. She came to the counter with her purse held against her chest and said, "Doyle. Pickup."

Priya found the bag. She set it on the counter and did not slide it across.

"Mrs. Doyle," she said. "I have to ask. The account's still active and it shouldn't be. The refills have been going out for three months."

The woman's hands were folded on the purse. "I know."

"I'm sorry for your loss. But I can't keep dispensing to a deceased patient. I'll need to call the family, get the account closed."

"No." It came out fast. "No, don't do that. Please." She opened the purse and took out a fold of bills, flattened and soft, the way money gets when it's been carried a long time. She counted out the exact amount on the counter, one bill at a time, and pushed it toward Priya. "I pay cash. I always pay cash. Just don't call the family."

Priya looked at the money. She looked at the woman's face, which was not embarrassed, exactly, but tired in a way she recognized. "Who are you to him?"

Margaret Doyle straightened her coat. "I'm his wife," she said. "And I'm asking you."

Priya waited until the bell over the door stopped swinging, then lifted the counter flap and followed.

Out in the lot the night air was thin and cold. Margaret walked slowly, one hand on the fender of each parked car as she passed, until she reached the far corner under the broken light. A silver sedan idled there, and a man Priya didn't recognize leaned against it, collar up, watching the street.

Priya stopped behind a delivery van and watched Margaret draw a white bag from her coat. The man took it, felt its weight, and counted bills into her palm without a word. Margaret folded the money and put it away. The sedan pulled out, and she stood alone a moment under the dead light, her breath clouding.

Priya stepped out from behind the van. "Mrs. Doyle."

Margaret didn't startle. She turned as though she'd known the whole time. "You followed me."

"I did."

"Then you saw."

"I saw you sell prescription medication to a man in a parking lot. That's a felony, and so is what I'd be if I kept filling it."

Margaret nodded slowly, as if Priya had said something reasonable about the weather. "His name is Dale. He pays cash. He doesn't ask questions." She looked down at her shoes. "I have a woman who comes Tuesdays and Fridays. Helps me wash. Cooks a little. Forty dollars a visit. The dialysis is three times a week—the rides alone are twenty each way, and Medicare doesn't care how tired I am or how far the clinic is."

Priya said nothing.

"I'm not asking you to feel sorry for me," Margaret said. "I'm telling you where it goes. It goes to keeping me upright. That's all it does."

The wind moved through the lot. Somewhere a car door slammed. Priya looked at the old woman's hands, still closed around the folded bills, and understood that she had just watched the exact arithmetic of a life being stretched to cover itself.

"Go home, Mrs. Doyle," she said. "I'll think about it."

"Don't think too long," Margaret said. "Dale comes Tuesdays."

The detective came on a Thursday, near the end of Priya's shift, when the store was empty and the fluorescent lights buzzed like a trapped fly. He introduced himself as Halvorsen, showed a badge, and asked if there was somewhere they could talk. She took him to the little office behind the counter, where the safe and the filing cabinets were.

"Routine audit," he said, though his tone suggested nothing was routine. "Your chain flags controlled substance refills that don't line up with the prescriber's records. There's a pattern here. Same patient, same drug, filled on a regular schedule." He laid a printout on the desk. She didn't need to look at the name. She looked anyway. Doyle, Eugene.

"Mr. Doyle passed away," Priya said.

"Three months ago. We know." Halvorsen's pen tapped the paper. "So who's been picking these up?"

Priya's mouth was dry. She could see Margaret's hands, the cracked knuckles, the crumpled bills. She could see the aide's car idling at the curb, the dialysis clinic's sliding doors. She thought of the word she was about to use, and how small it was, and how much it would cost.

"I'd have to check the logs," she said. "We get a lot of regulars. I don't always match a face to a file."

"You're the night pharmacist," Halvorsen said. "You'd have handled most of these."

"I handle a lot of prescriptions."

He studied her for a moment. Then he nodded slowly, as if he'd expected exactly this, and slid the printout into his folder. "I'll be back with a formal request for the records," he said. "In the meantime, if you think of anything."

She walked him to the door and watched his car pull out of the lot. Then she stood behind the counter with her hands flat on the cold laminate and felt the lie settle into her like a swallowed stone. She had not said a single false word. She had simply let the truth stay where it was. It had been so easy that her hands were not even shaking. That was the part that frightened her.

The next afternoon, before her shift, Priya sat at her kitchen table with her laptop open to two documents. The resignation letter came first and was easy: two weeks' notice, gratitude for the opportunity, no reasons given. She read it twice and did not send it. Then she opened the audit portal and began the incident report. She typed the patient name, the date of death, the refill dates. Her cursor hovered over the field marked dispensing pharmacist. She typed her own name, deleted it, typed it again. Reporting meant Margaret's name in a file that would travel to the board, to the insurer, maybe to a prosecutor. The money for the aide and the dialysis rides would stop in a single afternoon. She saved the draft without submitting it and closed the laptop, and the two documents sat in her machine like a pair of unopened letters, each one addressed to a different version of her life.

Margaret came in at nine, ten minutes before closing, carrying a canvas tote that clinked when she set it on the counter. She lifted out six amber bottles, unopened, labels facing away.

"I can't do it anymore," Margaret said. "My hands shake too much to count them out, and I keep thinking about that detective's car in the lot."

Priya looked at the bottles. Returning them to stock was against policy; they should be destroyed and documented, and documentation was the one thing she could not afford.

"Margaret, if I take these back, there's a record. There's always a record."

"I know." Margaret's voice was steady in a way that unsettled Priya more than trembling would have. "I've been deciding things my whole life, and I've made a mess of the last of them. So I'm not going to decide this one." She pushed the tote an inch closer. "You do it. Whatever you think is right, I'll live with it. You're the only one who knows the whole of it, and I'm too tired to carry it another day."

Priya stared at the bottles, at the small typed name on each label that belonged to a man three months in the ground. The resignation letter and the report sat side by side in her closed laptop, and Margaret stood waiting, having handed her the weight of them both, and Priya understood that there was no version of the next hour in which she chose only for herself.

Priya opened the file cabinet under the counter because she needed something to do with her hands. The Doyle folder was thin, the way files got thin after a death—a few transfer sheets, a photocopied insurance card, the original refill authorizations from the prescribing clinic. At the back, behind the transfer sheets, was an envelope she had never noticed, heavy bond paper, sealed, with a notary's embossed stamp creasing one corner.

Margaret had gone very still.

"What is that," Priya said. Not a question, the way she said it.

"Eugene's," Margaret said. "He told me to give it to whoever asked. I thought—I thought it would be me who asked." She folded her hands on the counter and did not reach for it.

Priya slit the envelope with her thumb. The letter was one page, typed, signed in a hand that had gone shaky and large toward the end, and notarized in the same month Eugene Doyle had died. It authorized, in plain language, the continued dispensing of his maintenance medications to his named agent, Margaret Doyle, for the express purpose of their lawful resale to defray the cost of her home aide and her dialysis transportation. It acknowledged the arrangement as his own design, executed while he retained capacity, and asked any pharmacist of conscience who read it to understand that his wife had acted on his instruction and not her own invention. The notary's seal was crisp. There was a second signature line, blank, for the pharmacist.

Priya read it twice. The first time she read it as evidence. The second time she read it as a will.

Every night she had stood behind this counter recast itself. Margaret's crumpled cash had not been the sweating of a woman caught in something; it had been the careful carrying-out of an old man's last piece of business, done badly because grief does everything badly. The begging not to call the family had not been fear of exposure. It had been loyalty to a promise. And the choice Margaret had pressed into Priya's hands tonight—file the report or file the resignation—had never been Margaret's to give at all. Eugene had given it to her three months ago, in an envelope, with a stamp on it.

Margaret watched her. "He said you'd be the one," she said quietly. "He said the night girl was too honest to let it slide and too kind to burn me. He said he was sorry to put it on you."

Priya set the letter down on the counter between them, squared it with the edge, and looked at the blank line waiting for her name.