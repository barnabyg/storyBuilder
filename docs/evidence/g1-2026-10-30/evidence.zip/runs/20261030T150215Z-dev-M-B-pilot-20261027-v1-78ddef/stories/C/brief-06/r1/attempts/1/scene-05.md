Closing night, Tomás found her at the pass with a manila envelope in his hand.

"You won," he said, sliding it across the steel. "Best solo numbers. The lease on Ninth is yours, Ferrer. Landlord wants the deposit by Monday."

Lucía looked down at the paper. Her name, typed clean, the date of possession. A year ago she'd have wept over it. She glanced past Tomás, out into the lot, where Mateo's truck sat with its side panel folded down and its shelves already emptying into plastic crates. He was rolling his knives into the canvas roll, one at a time, in order, the way she'd watched him do every morning for six weeks.

"Where's he going?"

"Lot closes tonight either way. He came in second." Tomás shrugged. "Close. A few dollars a head."

She held the envelope a moment, feeling its weight. The restaurant she'd promised herself—her name on a door that couldn't be taken out from under her, a stove that stayed hot all night. She had the sauce recipe because she'd made it alone and the line had been shorter and she'd told herself the heat was the reason.

But she knew what her sauce tasted like without his salt. She'd eaten it for four days.

"Tomás." She pushed the envelope back across the pass. "Give it to the second-place truck."

He stared at her. "That's not how it works."

"Make it how it works. Or tell the landlord his numbers were wrong, because they were—the best days in this lot belonged to two trucks, not one." She was already untying her apron. "I'll take my chances."

She crossed the lot before she could think better of it. Mateo didn't look up until her shadow fell over the crates.

"Kill the packing," she said.

"What?"

"The lease. I gave it back." Her voice came out steadier than she felt. "I want to cook. With you. A restaurant, both names, one kitchen. Your salt, my sauce. I'm not proud enough to pretend the food isn't better when I'm arguing with you."

Mateo set the knife roll down slowly, very slowly, and looked at her for a long moment, as if checking the proof of a sauce by smell alone.

"You gave back the lease."

"I did."

He shook his head, and then he laughed—one short, disbelieving breath—and reached past her to the fold-down shelf, where a jar of his salt still sat. He unscrewed the lid and set it in her hand.

"Then you're doing the prep," he said. "And I'm keeping the permit. I already have it framed."