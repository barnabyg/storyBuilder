The detective came on a Thursday, near the end of Priya's shift, when the store was empty and the fluorescent lights buzzed like a trapped fly. He introduced himself as Halvorsen, showed a badge, and asked if there was somewhere they could talk. She took him to the little office behind the counter, where the safe and the filing cabinets were.

"Routine audit," he said, though his tone suggested nothing was routine. "Your chain flags controlled substance refills that don't line up with the prescriber's records. There's a pattern here. Same patient, same drug, filled on a regular schedule." He laid a printout on the desk. She didn't need to look at the name. She looked anyway. Doyle, Eugene.

"Mr. Doyle passed away," Priya said.

"Three months ago. We know." Halvorsen's pen tapped the paper. "So who's been picking these up?"

Priya's mouth was dry. She could see Margaret's hands, the cracked knuckles, the crumpled bills. She could see the aide's car idling at the curb, the dialysis clinic's sliding doors. She thought of the word she was about to use, and how small it was, and how much it would cost.

"I'd have to check the logs," she said. "We get a lot of regulars. I don't always match a face to a file."

"You're the night pharmacist," Halvorsen said. "You'd have handled most of these."

"I handle a lot of prescriptions."

He studied her for a moment. Then he nodded slowly, as if he'd expected exactly this, and slid the printout into his folder. "I'll be back with a formal request for the records," he said. "In the meantime, if you think of anything."

She walked him to the door and watched his car pull out of the lot. Then she stood behind the counter with her hands flat on the cold laminate and felt the lie settle into her like a swallowed stone. She had not said a single false word. She had simply let the truth stay where it was. It had been so easy that her hands were not even shaking. That was the part that frightened her.