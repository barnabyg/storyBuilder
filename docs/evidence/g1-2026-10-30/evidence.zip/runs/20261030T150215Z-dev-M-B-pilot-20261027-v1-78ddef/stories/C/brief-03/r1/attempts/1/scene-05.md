Priya opened the file cabinet under the counter because she needed something to do with her hands. The Doyle folder was thin, the way files got thin after a death—a few transfer sheets, a photocopied insurance card, the original refill authorizations from the prescribing clinic. At the back, behind the transfer sheets, was an envelope she had never noticed, heavy bond paper, sealed, with a notary's embossed stamp creasing one corner.

Margaret had gone very still.

"What is that," Priya said. Not a question, the way she said it.

"Eugene's," Margaret said. "He told me to give it to whoever asked. I thought—I thought it would be me who asked." She folded her hands on the counter and did not reach for it.

Priya slit the envelope with her thumb. The letter was one page, typed, signed in a hand that had gone shaky and large toward the end, and notarized in the same month Eugene Doyle had died. It authorized, in plain language, the continued dispensing of his maintenance medications to his named agent, Margaret Doyle, for the express purpose of their lawful resale to defray the cost of her home aide and her dialysis transportation. It acknowledged the arrangement as his own design, executed while he retained capacity, and asked any pharmacist of conscience who read it to understand that his wife had acted on his instruction and not her own invention. The notary's seal was crisp. There was a second signature line, blank, for the pharmacist.

Priya read it twice. The first time she read it as evidence. The second time she read it as a will.

Every night she had stood behind this counter recast itself. Margaret's crumpled cash had not been the sweating of a woman caught in something; it had been the careful carrying-out of an old man's last piece of business, done badly because grief does everything badly. The begging not to call the family had not been fear of exposure. It had been loyalty to a promise. And the choice Margaret had pressed into Priya's hands tonight—file the report or file the resignation—had never been Margaret's to give at all. Eugene had given it to her three months ago, in an envelope, with a stamp on it.

Margaret watched her. "He said you'd be the one," she said quietly. "He said the night girl was too honest to let it slide and too kind to burn me. He said he was sorry to put it on you."

Priya set the letter down on the counter between them, squared it with the edge, and looked at the blank line waiting for her name.