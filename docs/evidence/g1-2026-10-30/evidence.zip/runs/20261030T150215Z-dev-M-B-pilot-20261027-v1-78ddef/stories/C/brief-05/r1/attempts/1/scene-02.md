At 3:17 the clocks began.

Martin woke the way a man wakes when the smoke alarm has gone off: all at once, upright, heart already running. The bedroom was black. Beside him Claire slept on her side, one hand under the pillow. But the house was ticking. Not one tick. Every clock in every room, stacked together in a low dry chorus that he could feel in his teeth. The mantel clock below. The wall clock in the hall. The old alarm in the spare room. All of them going at once, as though something had thrown a single switch.

He got up slowly so the bedsprings wouldn't speak. In the hall the tick was louder, and the shadows of the banister moved with it, faintly, in time. He went down barefoot. The kitchen clock above the door was sweeping its second hand past the twelve. It had been stopped before. He was sure it had been stopped. He stood under it with his hands loose at his sides and listened to the whole house keep time.

"Martin."

Claire stood in the kitchen doorway with her robe pulled tight. He hadn't heard her come down. She looked at him, then past him, at the table, the counters, the empty sink, reading the room like a page.

"What are you doing?" she said.

"I woke up. The clocks —" He gestured up at the one above the door. "They're running. Every one of them. They all started."

She didn't look at the clock. That was the thing he would remember later. She kept her eyes on him.

"What time did you come down?" she asked.

"You can see it. It's going."

"It's a clock, Martin. Clocks run."

He heard his own voice climbing and made himself stop. He stood very still, which was a mistake, because stillness was what she was looking for. He watched her see it: the stiff shoulders, the careful not-moving, the bare feet on cold tile. He knew exactly what it looked like. It looked like a man holding himself together at three in the morning.

"I haven't had anything," he said.

Claire folded her arms. She didn't say anything for a long moment, and the ticking filled the space between them, and her face was gentle and terrible. "It's all right," she said. "We'll talk in the morning."

"Claire. The clocks were stopped. You saw them stopped."

"Come back to bed," she said.