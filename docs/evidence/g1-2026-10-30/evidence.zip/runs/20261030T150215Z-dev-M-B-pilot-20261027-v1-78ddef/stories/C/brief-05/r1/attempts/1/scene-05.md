He stood in the hall with his hand flat against the door and felt the ticking come up through the wood like a pulse. 3:09. He had eight minutes, by the clocks, and the clocks were fast, and he had stopped being able to tell what that meant. He had written it all down and they had taken the notebook for what it was.

Claire's car was pulling out of the drive. He heard the gravel, the low gear, the turn onto the road. He had told her to take June and go, and she had looked at him the way she used to look at the bottles under the sink, and she had taken June, and June had forgotten her coat.

The door opened. June came in with the cold behind her, twelve years old and moving fast and not looking at him.

"Just the coat," she said. "Mom's waiting."

"June." He got between her and the stairs. "Listen to me. Look at the clock. Look at the one in the kitchen and tell me what it says."

"It's a clock, Dad."

"Tell me what it says."

She looked. "It says three-seventeen."

"Does it tick?"

Her jaw set. "I'm getting my coat."

She ducked past him and went up. He followed, and the ticking was everywhere now, all the clocks in the house arriving at the same place, a sound like a hundred small hammers, and he was shouting her name and she was not listening, and the minute hand on the landing clock came down.

3:17.

The ticking stopped. Every clock in the house stopped at once, and in the silence June stood at the top of the stairs with her coat half over her arm and her mouth open, and the stopped hour took her.

She did not fall. That was the thing he would keep. She simply was not there, the coat dropping to the runner, and Martin went up the stairs on his hands and knees and reached the top too late, and knelt in the empty quiet where his daughter had been, and the clocks began, softly, to tick.