The works office stood at the end of a lane of stinking mud, its door propped open to let the summer air through, though the air did no good. Nell had washed her hands in the river and tucked the notebook under her jacket, and Arthur walked half a pace behind her, his collar turned up as though the whole of London might know his face.

Inspector Rook filled the doorway before they reached it. He had a constable's shoulders and a rate-collector's eyes, and he looked at Nell the way a man looks at a rat on a clean floor.

"Not this one," he said. "I know you, Nell Harker. Thieving off the foreshore and now bringing your filth up to the works. Be off, or I'll have you off."

"I've got something," Nell said. "A surveyor's book. It shows the new line—"

"A nuisance, that's what you've got." He put a hand out to turn her. "There's engineers inside with no time for mudlarks' tales."

Arthur started to speak and his tongue caught on the first word, and Rook's lip curled at the sound of it.

Nell ducked under his arm and got to the table where the plans lay pinned and weighted, and Rook came after her roaring, and she put her finger down on the paper and held it there.

"Here," she said. "Your line runs by the Falcon Stairs and turns up Cutler's Row, and then it comes to the low ground by the tanners' yard. I know that ground. It falls a foot and a half from the corner of Cutler's to the pump. It floods every winter, and if you put your sewer through it, the whole court goes under."

The room had gone quiet. One of the engineers looked up from his rule, and then down at the map, and then at the small dirty finger pressed against the paper.

"And how would a girl know the fall of the ground?" Rook said, but his voice had lost its certainty, and he said it to the engineer rather than to her.