The lot still smelled of cut grass and diesel when Lucía swung her truck through the gate at half past five. She had been the first to sign for a permit in March, the first to pay, and she had spent the spring rebuilding her menu the way a person rebuilds a wall—one careful brick at a time. The blue rectangle on the fence post, slot fourteen, would be hers.

A green-and-cream truck sat in slot fourteen.

She knew it before she read the painted name, before she saw the man in the apron leaning into his prep window. Mateo Cruz. Of course. He had a way of turning up at the edge of her luck.

Lucía killed the engine and walked to the festival office, a trailer that hummed with a window unit. The clerk, a young woman with a lanyard and a look of having already had this conversation, did not make her wait.

"Ferrer? I know. I'm sorry." She turned her screen around. Two rows, identical permit numbers. "The system double-issued slot fourteen. Yours and Cruz's. I can't void either one before opening night—the district office has to review it, and they're closed until Monday."

"Monday is the second day of the festival," Lucía said.

"I know."

"Then give me a different slot."

"There isn't one. That's the whole problem." The clerk's voice dropped. "You two are going to have to work it out."

Mateo was waiting by her truck when she came back, arms folded, sleeves pushed to the elbow. He had the same dark hair she remembered from the restaurant-supply auctions, and the same infuriating calm.

"I heard," he said. "Look—there's room if we angle them. You take the morning window, I take the afternoon. We share the frontage, split the permit fee."

"No."

"Lucía."

"I paid for that spot in March. I have a lease riding on this summer." She stepped past him and laid her hand flat on the fence post, on the blue sticker, as if the paper could be reasoned with. "This is mine. I'm not splitting my kitchen with the man who undercut me at every turn."

"I never undercut you."

"You parked in my spot."

"I parked in my spot." He said it without heat, which was worse. "The clerk made a mistake, not me."

"Then you can move."

He studied her a moment, and something in his face—patience, or worse, sympathy—made her want to shout. "I'm here at five every morning," he said quietly. "You know where to find me if you change your mind."

"I won't."

She said it to his back as he walked away, and she meant it, and she stood there in the empty lot with her hand on the fence and her heart going like a service bell, telling herself the space was still hers.

By seven the line at her window was six deep, and the fryer was the only thing on her truck that didn't need an apology. She had the chorizo criollo going, the peppers blistering, the sauce she'd built that morning at four a.m. when she couldn't sleep for wanting this. Then she turned her back for one minute to bag an order, and when she turned around Mateo was leaning across her prep rail with a pinch of flake salt in his fingers, dropping it over her pot like he owned the place.

"Hey—"

"Taste it," he said, and stepped back before she could hit him with the ladle.

She tasted it, furious. It was better. The sauce had been tight and sour at the edges, working too hard, and the salt had opened it up like a window. A woman at the front of the line said, "Oh, that's good," and then four more people said it, and Lucía stood there with the ladle and the salt taste on her tongue and hated how right he was.

"Your flame's too high on the far burner," she told him, not looking at him, and pointed through the gap between their trucks. "You're burning the onions."

"I know."

"Then fix it."

He went. She heard him scraping, swearing softly, and then the smell of scorch going bitter and spreading, and the line at his window backing up and shuffling over to hers with the patience of hungry people who did not care whose truck was whose. She finished her orders. Then she wiped her hands, walked around the back of his truck, took the spatula out of his grip, and tipped the burnt batch into the bin.

"You don't throw it out," he said, wounded.

"You don't serve it." She dropped the pan back on the flame, added oil, and slid in a fresh handful of onions. "Lower. Watch the edges go glassy before you touch them. And your salt was good. Don't make me say it twice."

He stood beside her at his own stove, close enough that their elbows almost touched, and neither of them moved away.

Tomás came by at noon, in a linen jacket that had no business at a food festival, and stood in front of the two trucks with his hands folded behind his back like a man appraising a painting.

"Now this," he said, "this I like. Two lines, one rhythm. Your girl hands off a ticket and yours has the plate up before she's turned around." He nodded at the shared burner, where Mateo's pan and Lucía's saucepan sat side by side. "Somebody in this lot is cooking with a second pair of hands. I can taste it."

Lucía wiped her knife and said nothing.

"One thing, though." Tomás leaned in, lowering his voice as if it were a kindness. "The lease. My client is old-fashioned. He looks at one truck's numbers, one name on the paper. A partnership reads to him like a man who can't decide what he's selling." He tapped the counter once. "Best solo week wins the lease. Keep that in mind."

He moved on down the row. Lucía stood very still until he was three stalls gone.

"Best solo week," she said, to no one, to herself. She pulled the cash box out from under the counter and set it down hard. "Fine. Then we count."

Mateo looked up from the flat top. "Count what?"

"Everything." She was already separating the bills. "My till, your till. From this morning on."

"Lucía—"

"Tomás likes the shared line." She squared the stack of fives. "Tomás isn't the one signing."

It wasn't true, what she'd said to Tomás, or rather it was true the way a lie is true—she hadn't told him about the shared burner, the salt in her sauce, the way Mateo's hand moved to the pan before she asked. Pride had kept her mouth shut, and pride was cheaper than honesty. She counted. Thirty-one tickets before noon, and she knew exactly which of them had come for his name and which for hers, and she wrote the number on the back of a receipt and folded it into her apron like a secret she was already ashamed of keeping.

Mateo came around the side of the truck with the folded receipt in his hand. He must have fished it from her apron when she turned, or maybe she'd dropped it and he'd picked it up the way he picked up everything—quietly, before she knew she'd lost it.

"Thirty-one," he said. "You counted."

"I count every day."

"You counted and you told Tomás." His jaw was tight. "You told him about the numbers, and you didn't tell him about the burner. About any of it."

"Neither did you."

"Because I thought we were—" He stopped himself. "I thought we had an arrangement. I thought the arrangement was the point."

"The lease is the point." Her voice came out harder than she meant. "You knew that going in."

"So it's true, then. You're taking it for yourself after all."

She wanted to say no. The word was there, ready, and what came out instead was, "Somebody has to." Because it was true, and because he'd said it first, and because pride was cheaper than honesty and she had a pocket full of receipts to prove it.

He looked at her the way he'd looked at the burnt batch on the second morning—not angry, worse, disappointed, already revising the recipe.

"Then we're done sharing," he said, and went to his window.

She took the menu board down from between the trucks—the one they'd chalked together, his handwriting slanted under hers, the day's specials in two colors—and she tore it down the middle, then the middle again, and dropped the pieces in the bin where he could see them. The lunch rush came and she worked it alone, one burner, her own salt, her own hands moving exactly as fast as hers could move. The line was shorter than yesterday. She told herself it was the heat.

Closing night, Tomás found her at the pass with a manila envelope in his hand.

"You won," he said, sliding it across the steel. "Best solo numbers. The lease on Ninth is yours, Ferrer. Landlord wants the deposit by Monday."

Lucía looked down at the paper. Her name, typed clean, the date of possession. A year ago she'd have wept over it. She glanced past Tomás, out into the lot, where Mateo's truck sat with its side panel folded down and its shelves already emptying into plastic crates. He was rolling his knives into the canvas roll, one at a time, in order, the way she'd watched him do every morning for six weeks.

"Where's he going?"

"Lot closes tonight either way. He came in second." Tomás shrugged. "Close. A few dollars a head."

She held the envelope a moment, feeling its weight. The restaurant she'd promised herself—her name on a door that couldn't be taken out from under her, a stove that stayed hot all night. She had the sauce recipe because she'd made it alone and the line had been shorter and she'd told herself the heat was the reason.

But she knew what her sauce tasted like without his salt. She'd eaten it for four days.

"Tomás." She pushed the envelope back across the pass. "Give it to the second-place truck."

He stared at her. "That's not how it works."

"Make it how it works. Or tell the landlord his numbers were wrong, because they were—the best days in this lot belonged to two trucks, not one." She was already untying her apron. "I'll take my chances."

She crossed the lot before she could think better of it. Mateo didn't look up until her shadow fell over the crates.

"Kill the packing," she said.

"What?"

"The lease. I gave it back." Her voice came out steadier than she felt. "I want to cook. With you. A restaurant, both names, one kitchen. Your salt, my sauce. I'm not proud enough to pretend the food isn't better when I'm arguing with you."

Mateo set the knife roll down slowly, very slowly, and looked at her for a long moment, as if checking the proof of a sauce by smell alone.

"You gave back the lease."

"I did."

He shook his head, and then he laughed—one short, disbelieving breath—and reached past her to the fold-down shelf, where a jar of his salt still sat. He unscrewed the lid and set it in her hand.

"Then you're doing the prep," he said. "And I'm keeping the permit. I already have it framed."