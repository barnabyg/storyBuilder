The clocks read 2:41. Martin stood in the kitchen with his coat half on, counting the hands again, and then he was moving.

"Bags," he said. "Everybody, get bags. We leave in five minutes."

Diane came out of the laundry with a basket on her hip. "What are you talking about?"

"Before 3:17. We have to be gone before 3:17." He took the stairs two at a time, pulled a duffel from the closet, and began throwing clothes into it. June appeared in her doorway, her hair wet from the bath. "Go get your shoes," he told her. "We're going for a drive."

By the time he got them to the porch, Diane was planted between him and the truck. "You're scaring her," she said. "Look at your hands. Look at you." June had started to cry, quietly, the way she did when she was trying not to be noticed.

"I need you to trust me for one hour," Martin said.

Ray's truck came up the drive then, headlights sweeping the yard. He stepped out slow, hands loose at his sides. "Diane called," he said. "Let's talk inside."

Martin grabbed June's arm. "Come on, sweetheart—"

She cried out, and Ray was there, stepping between them. "Let go of her, Martin. Let go." Diane swept June up and carried her inside, and the screen door banged.

Martin held out the ledger with both hands, open to the page. "Look. Look at the clocks. 2:44, all of them. Tell me what you see."

Ray looked at the clocks. His face was patient and tired. "I see five-forty," he said. "Martin. I think you need a meeting tonight, or a hospital. Either one. I'll drive you myself."

Martin stood in the yard with the cold coming up through his socks. Their faces had the same softness they wore when they were braced against him.

"I'll sleep in the barn," he said. "That proves I'm calm. You lock up. I'll be out there."

He gathered his duffel and walked across the yard. Behind him, one by one, he heard the bolts go home.