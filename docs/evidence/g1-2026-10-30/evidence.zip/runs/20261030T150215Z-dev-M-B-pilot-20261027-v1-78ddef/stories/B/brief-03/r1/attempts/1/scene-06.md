After Dennis left, Priya pulled the Vance file again. If she was going down, she wanted to know exactly what she was going down for. The paper folder was thin, but near the back, taped along the seam, her thumb caught an edge that wasn't paper.

An envelope. Sealed, yellowed, stapled inside the folder and never scanned into the system.

She slit it open with a letter opener. The handwriting inside was shaky, an old man's hand.

*To the pharmacy,*

*My name is Harold Vance. By the time you read this I may be gone. I have arranged for Mrs. Alcott to collect my prescriptions. This is my decision, made in sound mind.*

*I know what my medications are worth to people who can't afford them. I know she needs the money more than I need the pills. She has been a good neighbor to me, and I would not see her go without.*

*I take full responsibility for this arrangement. No employee of this pharmacy is to blame. If anyone must answer for it, it is me, and I am not here to answer.*

*Signed, Harold Vance*

The date was two days before he died.

Priya sat down on a crate of saline, the letter trembling in her hands. He had planned it. All of it. And Mrs. Alcott, all this time, had only been doing what a dying man asked of her.