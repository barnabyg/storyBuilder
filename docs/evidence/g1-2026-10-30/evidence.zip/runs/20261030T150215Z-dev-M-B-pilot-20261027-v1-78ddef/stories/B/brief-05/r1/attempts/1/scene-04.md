The attic smelled of wet cardboard and old dust. Martin found the ledger wedged behind a rafter, its cover swollen with water stains, the pages rippled like a tide line. Inside, in a careful hand, someone had listed every clock in the house—parlor, hallway, kitchen, the little brass one from the upstairs landing—and beside each name, over and over down the columns, the same three digits: 3:17. 3:17. 3:17. The last entry was not a time at all. *It comes when the clocks reach zero.*

He sat on the attic steps and called the realtor with shaking hands. She was hesitant at first, then blunt. The previous owner, a widower named Hollis, had died in the house. His wife had died there years before that—a fall, on the stairs. "I'm sorry," she said. "I assumed you'd been told."

Diane was in the kitchen. He laid the ledger open on the counter. She looked at it the way she looked at a puddle on the floor. "Martin," she said quietly. "It's a moldy notebook. Have you been drinking up there?"

"Mom?" June stood in the doorway, hair wet from the bath. "What happens at zero?"

"Nothing," Martin said, too fast. "Nothing happens." He closed the ledger and carried it upstairs and slid it under his side of the mattress.

That night Diane stepped into the pantry and called Ray. "I think he's started again," she whispered. "Could you come by tomorrow?"