On her days, Lucía arrived early and erased him—his chalk marks scrubbed from the asphalt, his grease stains bleached to ghosts, her own banner hung square over the shared boundary. On his days, Tomás chalked a fat arrow pointing to his window and wrote *THIS WAY* in letters a city block wide. The crowd loved it. Lucía did not.

"You should try his smoked-paprika aioli," a woman said at her window, licking her thumb. "It's the best thing here."

Lucía smiled until her face ached. After the rush she slipped to his truck, unscrewed the jar, and tasted. The aioli bloomed on her tongue—smoke and acid and something bright—and she knew at once it was the missing note in her grilled octopus, the flatness she'd been chasing for weeks. She capped the jar, wiped her mouth, and refused to ask.

Instead she salted her next batch harder, and harder still. The lunch crowd chewed and winced. A man returned his plate. Lucía stared at the ruined octopus and felt her pride curdle.

The next morning a jar of aioli sat on her prep counter, a scrap of paper beneath it: *You're welcome. —T.*

She threw it in the bin. That night, alone under the string lights, she fished it out and ate a spoonful in the dark.

"You two are gold," the festival director told her the next afternoon, beaming. "Best buzz we've had in years. The lease committee's watching, you know. They love a story."

Lucía smiled again. It tasted like salt.