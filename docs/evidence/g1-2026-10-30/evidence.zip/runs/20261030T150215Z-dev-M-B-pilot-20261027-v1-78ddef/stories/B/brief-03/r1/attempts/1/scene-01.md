The clock behind the register read 11:47, and Priya had already begun subtracting. Two weeks, three days, six hours. She rolled her shoulders and turned back to the queue of refills, the printer spitting labels with a sound like something tearing.

The woman arrived at the counter with a paper bag that had gone soft with use. Priya recognized her the way she recognized most of the overnight regulars—by the coat, the careful walk, the way she set the bag down as though it might break.

"Evening," the woman said. "I need to pick up for Harold Vance. The blood pressure, the heart one, and the pain medication."

Priya typed the name. The file opened, and a red flag sat at the top of the screen like a thumb pressed into dough. Deceased. Three months ago. Below it, a note in the system: *Verify. Prescriptions should have been canceled.*

She looked up. "Mrs. Alcott. You've been in before for this patient."

"That's right."

"Can you tell me your relationship to Mr. Vance?"

The woman's eyes slid to the counter between them. "I was his neighbor. Just helping out."

The system would let her do it. The authorization was there, the refills were active, and nobody had closed the file. Priya could feel the two weeks ticking somewhere in the walls, and she had learned long ago which battles the register would fight for her.

She filled them. She watched the old woman count out exact change from a coin purse, one dime at a time, and not look at her once.