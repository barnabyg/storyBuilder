On Friday morning Priya filed the audit report. She wrote that the refills had been authorized by the patient himself before his death, that the file contained written instructions, and that she had followed them in good faith. She scanned Harold Vance's letter and attached it as Exhibit A. She did not mention the parking lot. She did not mention the man with the cash, or the oxygen concentrator humming in Mrs. Alcott's front room, or the way the old woman's hands shook when she counted out her change.

Dennis read it twice, his jaw working. "Convenient," he said. "A dead man to blame."

"The signature's verified," Priya said. "The date's before he died. Call his lawyer if you want."

He wanted to. He called, and the lawyer confirmed the handwriting, and Dennis came back red-faced and closed the audit with a written warning to the pharmacy for inadequate controls on deceased-patient files. It was the best outcome he could get, and he knew it.

That afternoon Priya called Mrs. Alcott. "The refills stop now," she said. "I can't help you anymore. I'm sorry."

There was a long silence. Then, quietly, "Thank you, dear."

Priya handed in her two weeks' notice that night. She walked out under the parking-lot lights feeling neither clean nor sorry, only tired, and certain that she had done the one thing she could not prove was right.