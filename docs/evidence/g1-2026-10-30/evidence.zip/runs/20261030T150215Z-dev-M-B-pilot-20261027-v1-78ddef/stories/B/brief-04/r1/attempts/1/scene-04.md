Finch led her to a coffee house off the Strand, where the air was thick with steam and the smell of roasted beans, and bought her a cup she did not drink. He spread the notebook on the table between them and traced the lines with a stained forefinger.

"These hatched marks are the new sewers," he said. "The circles are the old drains they mean to join. And here—" he tapped a cluster of figures "—these are the levels. The height of the ground above the river."

Nell leaned close. She could not read the figures, but she did not need to. She set her finger on the map where the line bent toward the river.

"That's wrong," she said. "That ain't where the turn is. The turn's by the tan-yard, past the second arch. I know it. I've walked it a hundred times."

Finch frowned, then drew out a pencil and made a mark. "And here?"

"Lower. The ground falls away by the rope-walk. It floods every spring."

He was quiet a long while, his pencil still. "If the levels are wrong," he said at last, "the sewer would run above the ground at the low end. It would back up. It would flood your district."

"I told you."

"I know." He pressed his hands to his face. "If I bring this forward, I lose my post. Mr. Tredgold would see me ruined."

"You won't bring it forward," Nell said. "We'll give it to someone who'll listen. There's an engineer, Mr. Bazalgette's man, who's said to be fair. We leave the book with him, no name on it. No one need know it was yours."

Finch stared at her, then slowly nodded.