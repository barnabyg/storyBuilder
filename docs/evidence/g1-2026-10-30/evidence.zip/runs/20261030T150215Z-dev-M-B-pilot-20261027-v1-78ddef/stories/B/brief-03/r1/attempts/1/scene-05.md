Dennis caught her at the end of the shift, before the day staff arrived. He had a printout in his hand and the pinched look of a man who'd been on the phone with corporate before his first coffee.

"District flagged the Vance file," he said, keeping his voice low behind the pharmacy counter. "Repeated refills after the death date. Their system caught it before ours did."

Priya's stomach dropped. "I was going to bring it to you."

"The last several fills have your initials on them. Pharmacist of record." He tapped the page. "Audit's coming in a week. They'll go through everything."

She said nothing.

"Look," Dennis said, glancing toward the front of the store, "there's a clean way through this. You write up a report — customer fraud, Mrs. Alcott using a dead man's prescriptions for her own gain. Then the liability lands on her, not us. Not you."

"She's eighty-something," Priya said. "She's got emphysema and no money. A fraud report means charges."

"That's not our problem. Our problem is the audit."

Priya looked at the printout, at her own initials in a neat row. "Give me a day."

"Friday," Dennis said. "Report on my desk by Friday, or you're the one under review."