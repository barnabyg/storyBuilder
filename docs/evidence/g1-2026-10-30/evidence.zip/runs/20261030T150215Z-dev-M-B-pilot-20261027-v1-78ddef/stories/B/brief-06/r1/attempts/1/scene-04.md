The night air was still heavy when Tomás walked her the three blocks to her apartment. He was quiet for most of it, then, at the corner, he said it plainly: he'd put everything into a taquería two years back, and his partner had walked out mid-lease, leaving him the debt and the locked door. That was why the lease mattered. Not the money—the getting back up.

Lucía stopped under the streetlight. She told him about her own place, the lease that had looked like a lifeline and turned out to be a trap, and how the festival was the only road she had left. He nodded slowly, and then the thing they'd both been circling finally surfaced: they were the two finalists for the same vacant space. The committee would decide by summer's sales.

They stood there a moment, close enough that she could smell smoke and lime on him. He kissed her—quick, almost apologetic—and she kissed him back before they both pulled away, each reading the same arithmetic in the other's face. Partner and obstacle, in the same man.

"We keep this quiet," she said. "And we compete honest."

"Honest," he agreed.

Neither of them sounded sure.