The transformer blew at seven-forty on the hottest night of the festival, a sound like a gunshot, and then the whole row went dark and silent. Lucía stood in the sudden blackness with a tray of empanadas half-fried and listened to her refrigerators die.

Tomás appeared at her window with a flashlight. "Cold storage," he said. "Mine's got space. Bring everything."

"I'm not putting my stock in your truck."

"Then watch it spoil." He was already walking. "I've got a gas burner. We cook what we can, we sell it hot. Or we eat the loss."

She held out four minutes, until the first faint sourness reached her nose. Then she carried her pans across.

They worked shoulder to shoulder in the cramped heat, his burner hissing under her stockpot. He reached over and turned down her braise. "You're burning the bottom."

"And you're drowning that in cumin."

He tasted. Grudgingly, he added less. She tasted his sauce, added salt and a squeeze of lime, and he didn't argue.

The improvised menu sold out in an hour.

"You know," said Mrs. Ochoa, licking her fingers, "that's the best thing you've fed me all summer."

Lucía looked up and found Tomás already looking at her. Neither of them said anything.

At closing he counted the take and pushed half toward her without being asked. They sat on his tailgate in the dark, and he told her about his taquería, the flood, the insurance that didn't come. She told him about the lease that swallowed her restaurant whole.

The generator hummed. Neither of them moved to go.