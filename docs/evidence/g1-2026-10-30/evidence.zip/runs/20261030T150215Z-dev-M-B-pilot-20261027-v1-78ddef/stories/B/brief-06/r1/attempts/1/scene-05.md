The festival director found Lucía during the afternoon lull, wiping down her prep counter. He kept his voice low, almost kind, which made it worse. The committee had reviewed the summer’s numbers. Tomás’s margins were stronger, his crowds steadier. Nothing was decided—but she should know which way the wind blew.

She stood there with a rag in her hand and felt the lease slipping through her fingers like water.

The propane. Tomás ran two tanks in series, a setup that was legal enough but wouldn’t survive a fussy inspection. One phone call, anonymous, and he’d be dark for the final weekend. She told herself it was business. She dialed before she could think.

She watched from her window as the inspectors arrived, clipboards out, and shut his grill down mid-service—a line of customers stranded, Tomás’s hands hanging useless at his sides. He came to her truck an hour later, and she had never seen him look so tired.

“I thought we’d moved past this,” he said quietly.

“I don’t know what you’re talking about.”

He looked at her a long moment, then turned and walked away without a word.

By evening she had her best sales day yet. The register hummed. She felt nothing.

A woman leaned into her window, smiling. “Two of the chicken, please—and where’d the aioli go? The other truck always had it.”