The clock above the register read 11:47, and Priya had already begun subtracting. Two weeks, three days, six hours until she stopped being a pharmacist. She rolled her shoulders and turned back to the printer spitting labels with a sound like something tearing.

The woman arrived at the counter with a paper bag gone soft with use. Priya recognized her the way she recognized most of the overnight regulars—by the coat, the careful walk, the way she set the bag down as though it might break.

"Evening," the woman said. "Picking up for Harold Vance. The blood pressure, the heart one, and the pain medication."

Priya typed the name, and the file opened with a red flag at the top like a thumb pressed into dough. Deceased. Three months ago. Below it, a note in the system: Verify. Prescriptions should have been canceled.

She looked up. The woman had a pharmacy ID tag clipped to the inside of her coat, faded but legible. Alcott.

"Mrs. Alcott. You've been in before for this patient."

"That's right."

"Can you tell me your relationship to Mr. Vance?"

The woman's eyes slid to the counter between them. "I was his neighbor. Just helping out."

The system would let her do it. The authorization was there, the refills were active, and nobody had closed the file. Priya had learned long ago which battles the register would fight for her and which ones it would quietly let her lose. She filled them. She watched the old woman count out exact change from a coin purse, one dime at a time, and not look at her once.

The next night Priya stayed late, after Dennis had gone home and the front lights had dimmed to their overnight setting. She pulled Harold Vance's file expecting to find some clerical ghost—a death recorded against the wrong account, a name transposed in the system. It would be a relief to close the folder and forget it.

Instead she found a form. A signed authorization, dated six weeks before Harold died, naming Margaret Alcott as an approved pickup person for all his medications. His signature was steady, deliberate, pressed hard enough to score the paper.

Beneath it, a note from his physician: Prescriptions to continue per patient's arrangements.

Priya stared at the phrase a long moment, then called the number on the letterhead. A receptionist answered on the fifth ring, sounding like the end of a very long day.

"The doctor did sign off on it," the woman said. "Beyond that I couldn't tell you. He's been dead two years himself, honey. I just answer the phone."

Priya hung up. Behind her, Dennis had come back for his keys and stood in the doorway, reading over her shoulder.

"Vance? Old guy, right?" He shrugged. "Store gets paid either way. Not your problem, Priya."

She caught up with Mrs. Alcott at the crosswalk two blocks down. The old woman walked with a hitch in her step, a pharmacy bag swinging from one hand, and Priya didn't decide to follow so much as find herself already following, her coat half-buttoned against the cold. The strip mall's parking lot was nearly empty. A gray sedan idled under a dead streetlight, and Mrs. Alcott went straight to it, leaned into the passenger window, and passed a plastic bag of pill bottles through. The man inside handed back a folded stack of bills. It took four seconds.

"Mrs. Alcott."

The old woman turned. She didn't look surprised. She looked tired, in a way Priya recognized from her own mirror.

"You've been watching me," Mrs. Alcott said.

"That's Harold Vance's medication. He's been dead three months."

"I know what it is." She tucked the cash into her coat. "The man in the car sells to people who can't afford insurance. I get a hundred a month."

"Ma'am—"

"It pays my aide three days a week. It pays for my insulin. Medicare takes care of the rest of me, not that." Her mouth tightened. "You going to tell me I'm a criminal?"

"I'm telling you I can't let this keep happening."

Mrs. Alcott nodded slowly, as if she'd expected exactly that. "Then I guess you'll have to turn me in." She turned and walked on, and Priya stood in the cold with her half-buttoned coat and watched her go.

She didn't sleep. She lay on her couch watching the ceiling change color with the dawn, and by two in the afternoon she had talked herself into a reasonable-sounding pretext: a medication interaction check, a professional courtesy, nothing a pharmacist wouldn't do. Mrs. Alcott's address took her to a low brick building on the east side, three floors up a stairwell that smelled of cabbage and bleach.

The apartment was small and cluttered, newspapers stacked against the radiators, a plastic oxygen tank standing sentry by a recliner. Mrs. Alcott answered the door in a cardigan, her breath audible before she spoke. On the table beside her chair sat a shoebox of envelopes, several with red stamps.

"I brought your refill records," Priya said. "I wanted to check something."

A home health aide emerged from the kitchen, a young woman in scrubs who looked at Priya with open suspicion until the pretext satisfied her. Then, quietly, she said, "She's been skipping her insulin. Stretching it. I tell her, but she won't listen."

Mrs. Alcott waved her off. On the sideboard stood a framed photograph of an old man in a fishing hat, squinting into the sun. "Harold," she said. "He was a kind man. He wanted to help me. I'm only doing what he asked."

Priya said nothing. She gathered her bag and left without promising anything, and behind her, through the half-open door, Mrs. Alcott's voice followed her down the stairs, thin but steady.

"You do what you have to do."

Dennis caught her at the end of the shift, before the day staff arrived. He had a printout in his hand and the pinched look of a man who'd been on the phone with corporate before his first coffee.

"District flagged the Vance file," he said, keeping his voice low behind the pharmacy counter. "Repeated refills after the death date. Their system caught it before ours did."

Priya's stomach dropped. "I was going to bring it to you."

"The last several fills have your initials on them. Pharmacist of record." He tapped the page. "Audit's coming in a week. They'll go through everything."

She said nothing.

"Look," Dennis said, glancing toward the front of the store, "there's a clean way through this. You write up a report—customer fraud, Mrs. Alcott using a dead man's prescriptions for her own gain. Then the liability lands on her, not us. Not you."

"She's eighty-something," Priya said. "She's got emphysema and no money. A fraud report means charges."

"That's not our problem. Our problem is the audit."

Priya looked at the printout, at her own initials in a neat row. "Give me a day."

"Friday," Dennis said. "Report on my desk by Friday, or you're the one under review."

After he left, Priya pulled the Vance file again. If she was going down, she wanted to know exactly what she was going down for. The paper folder was thin, but near the back, taped along the seam, her thumb caught an edge that wasn't paper.

An envelope. Sealed, yellowed, stapled inside the folder and never scanned into the system.

She slit it open with a letter opener. The handwriting inside was shaky, an old man's hand.

To the pharmacy,

My name is Harold Vance. By the time you read this I may be gone. I have arranged for Mrs. Alcott to collect my prescriptions. This is my decision, made in sound mind.

I know what my medications are worth to people who can't afford them. I know she needs the money more than I need the pills. She has been a good neighbor to me, and I would not see her go without. I have watched the people who work in this store, and I know there is at least one who will understand what I am asking, and will not punish an old woman for honoring a dying man's wish.

I take full responsibility for this arrangement. No employee of this pharmacy is to blame. If anyone must answer for it, it is me, and I am not here to answer.

Signed, Harold Vance

The date was two days before he died.

Priya sat down on a crate of saline, the letter trembling in her hands. He had planned it. All of it. The authorization, the physician's note, the envelope taped where only someone who cared to look would find it. And Mrs. Alcott, all this time, had only been doing what a dying man asked of her.

On Friday morning Priya filed the audit report. She wrote that the refills had been authorized by the patient himself before his death, that the file contained written instructions, and that she had followed them in good faith. She scanned Harold Vance's letter and attached it as Exhibit A. She did not mention the parking lot. She did not mention the man with the cash, or the oxygen concentrator humming in Mrs. Alcott's front room, or the way the old woman's hands shook when she counted out her change.

Dennis read it twice, his jaw working. "Convenient," he said. "A dead man to blame."

"The signature's verified," Priya said. "The date's before he died. Call his lawyer if you want."

He wanted to. He called, and the lawyer confirmed the handwriting, and Dennis came back red-faced and closed the audit with a written warning to the pharmacy for inadequate controls on deceased-patient files. It was the best outcome he could get, and he knew it.

That afternoon Priya called Mrs. Alcott. "The refills stop now," she said. "I can't help you anymore. I'm sorry."

There was a long silence. Then, quietly, "Thank you, dear."

Priya handed in her notice that night, two weeks early, and walked out under the parking-lot lights feeling neither clean nor sorry, only tired, and certain that she had done the one thing she could not prove was right.

A week later, a man in a gray suit came through the automatic doors at ten past nine, briefcase in hand, and asked the counter girl for Priya Raman by name.

He introduced himself as Harold Vance's attorney and set a sealed envelope on the counter between them. Inside was a copy of the will, and he waited while she read it, his hands folded.

The paragraph was short. Harold Vance had arranged the prescription scheme with Mrs. Alcott deliberately, in the last weeks of his life, and had left a small sum—four thousand dollars—to the pharmacist who "did the human thing."

"Why me?" Priya asked.

The lawyer smiled thinly. "Mr. Vance spent a lot of time in this store. He watched you, months back, refuse to report a homeless man who walked out with insulin. He told me he'd found the one pharmacist in this city he could trust to be merciful." He tapped the will. "The scheme was the test. He wanted to know if you'd follow the rules or the person. You did the human thing."

Priya stood very still. The letter, the signatures, the deliberate paperwork—all of it, designed to see what she would do. She looked at the bequest, then at the empty stretch of counter where Mrs. Alcott used to stand, and understood that she had been part of his plan from the beginning.