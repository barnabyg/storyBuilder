The committee called on Monday. They had watched the final weekend—the two trucks parked nose to tail, the shared prep table, the line that wrapped past the fountain—and they had read Lucía's withdrawal and Tomás's letter in the same sitting. The lease, they said, was never meant to crown one chef. It was meant to keep a kitchen alive in that corner of the market. They offered it to the pair as a joint venture, and Lucía laughed so suddenly she had to put the phone down.

They signed on a Tuesday, at a folding table in the empty restaurant, her name and his on the same line. Then they painted the sign together, badly, Tomás holding the stencil while Lucía cursed the letter S. Sal & Brasa. Salt and ember. A name that finally fit both of them.

Opening night the window fogged before eight. Lucía plated the octopus—charred, blistered, unapologetic—and set it in the pass with his saffron aioli pooled beneath it, and they toasted with cheap cava in mismatched glasses, to second chances.

A customer, fork suspended, asked across the counter who the chef was.

"We are," they said, at the same time.