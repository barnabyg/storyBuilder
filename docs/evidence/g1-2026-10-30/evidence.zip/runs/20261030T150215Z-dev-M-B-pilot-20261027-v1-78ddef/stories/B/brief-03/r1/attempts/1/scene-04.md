Priya didn't sleep. She lay on her couch watching the ceiling change color with the dawn, and by two in the afternoon she had talked herself into a reasonable-sounding pretext: a medication interaction check, a professional courtesy, nothing a pharmacist wouldn't do. Mrs. Alcott's address took her to a low brick building on the east side, three floors up a stairwell that smelled of cabbage and bleach.

The apartment was small and cluttered, newspapers stacked against the radiators, a plastic oxygen tank standing sentry by a recliner. Mrs. Alcott answered the door in a cardigan, her breath audible before she spoke. On the table beside her chair sat a shoebox of envelopes, several with red stamps.

"I brought your refill records," Priya said. "I wanted to check something."

A home health aide emerged from the kitchen, a young woman in scrubs who looked at Priya with open suspicion until the pretext satisfied her. Then, quietly, she said, "She's been skipping her insulin. Stretching it. I tell her, but she won't listen."

Mrs. Alcott waved her off. On the sideboard stood a framed photograph of an old man in a fishing hat, squinting into the sun. "Harold," she said. "He was a kind man. He wanted to help me. I'm only doing what he asked."

Priya said nothing. She gathered her bag and left without promising anything, and behind her, through the half-open door, Mrs. Alcott's voice followed her down the stairs, thin but steady.

"You do what you have to do."