The vestry office smelled of coal smoke and wet wool, and Nell stopped just inside the door, suddenly aware of her own reek. The clerk behind the counter had a high collar and a pen he did not put down.

"I need to show you something." She laid the notebook on the counter and opened it to the folded map. "This here's the new sewer. It comes down our way, and it'll flood the whole of Cuttle Lane."

The clerk leaned back as though she carried plague. "Take your filthy hands off that counter. And take your rubbish with you."

"It in't rubbish. It's a surveyor's book. Look at the ink on it—"

"I can see what it is." He tapped his pen against the wood. "I can see a ragamuffin off the river with some drowned ledger she's fished out of the mud, hoping for a reward. We get one of you a week."

"I can't read it," Nell said, and hated saying it. "But I know the streets. I know every turning. That line there goes straight through the bakehouse and the pump. You put a sewer through there and the water comes up in every cellar."

The clerk's face went flat and ugly. "You calling the Board liars now? Get out, or I'll have the constable to you for vagrancy and thieving both."

Nell gathered the notebook against her chest and went out into the stink of the street. Her ears burned. But her feet already knew the way, and she began to walk, thinking hard about who in all London might listen to a girl like her.