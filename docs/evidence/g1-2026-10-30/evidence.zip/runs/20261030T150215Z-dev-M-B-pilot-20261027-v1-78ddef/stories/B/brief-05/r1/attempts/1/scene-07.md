The bed was empty. The sheets were thrown back, and the window stood wide open to the night, the curtain lifting and falling in a slow breath. Beside the pillow, the little alarm clock read 3:17, its second hand frozen.

Diane came in behind him and stopped. The sound she made was not a word. Then she turned on him, her voice climbing, cracking. “Where is she? What did you do?” She seized his arm. “You took her. You’re drunk—you’ve been drinking, you did something to her—”

“Diane—” He pulled free. On the floorboards, a line of small wet footprints led out the door and down the hall, toward the attic stairs. “Look. Look at that.”

She was already backing away, phone to her ear, saying the address, saying *my husband*. Martin followed the prints alone, up the narrow stairs, into the dust and dark.

June’s doll sat beneath the pinned clock list, its face turned up to him. He lifted the page. The last entry had changed. In place of the old time, one word, in the same cramped hand: *paid*.

He was still holding the doll when the police came up, his knuckles split and bleeding where he’d torn through the attic latch. Every clock in the house had stopped at 3:17. From the doorway below, Diane’s voice carried clear and steady: “He’s been drinking for weeks. I should have said something sooner.”