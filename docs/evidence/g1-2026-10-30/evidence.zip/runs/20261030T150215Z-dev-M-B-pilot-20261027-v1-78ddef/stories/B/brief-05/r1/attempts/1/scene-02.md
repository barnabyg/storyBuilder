The ticking followed him down to breakfast, a dry, patient sound from every room. Martin poured coffee and watched the mantel clock. Its hands had moved since the night before—backward. It read 3:16 now, and as he stared, the minute hand trembled and stepped back another notch.

"Diane. Look at this."

She came over with her toast, and he pointed. "It's going backward. It was 3:17 last night, now it's—"

She squinted at it. "It says ten past seven, Martin."

He looked again. The hands sat where they should, and the tick was ordinary. On the counter the kitchen timer glowed ten minutes, though no one had touched it, and he watched it count down while he explained, and when Diane turned it read 0:00.

"Have you been sleeping?" she asked gently. "Have you been to a meeting this week?"

"I'm fine. I'm not—" He set down his cup too hard. "I'm going to be late."

In the truck, the dashboard clock ticked backward in time with the house. He watched it take a minute, and the wheel came loose in his hands, and gravel sprayed before he got the truck straight again.