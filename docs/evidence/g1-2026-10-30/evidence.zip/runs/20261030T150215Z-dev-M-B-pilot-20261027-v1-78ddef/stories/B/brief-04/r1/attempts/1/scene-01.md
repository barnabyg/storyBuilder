The tide was out, and the river lay exposed and stinking. Nell Harker picked her way along the foreshore, her skirts kilted to her knees and her boots sinking into the grey ooze with every step. The Great Stink had been brooding over London for weeks, and down here at the water's edge it was worst of all—a thick, rotting sweetness that caught in the throat and made her eyes water. She breathed through her mouth and kept her gaze on the mud.

A broken crate jutted from the silt, and wedged against its splintered ribs was something that did not belong to the river. Nell crouched and worked it loose: a small book, bound in oiled leather, swollen with damp but still whole. She wiped the worst of the slime on her apron and tucked it inside her bodice, where it lay cold against her ribs until the light failed and she made her way home.

Their lodgings were two rooms off a court in Bermondsey, shared with the widow Oakes and her brood. Nell lit a stub of candle and opened the book on the table. The pages were crowded with lines, ruled straight and true, and numbers in a neat clerk's hand she could not read a word of. But her eye went at once to the folded sheet tucked in the back—a map, drawn fine as a spider's web, with a long dark line running through it like a seam.

Jem came in from the yard, wiping his hands. He was fourteen and had been two years at the board school before his father died, and he could puzzle out letters if they were large enough.

"Here," Nell said, turning the map to him. "What's it say?"

He squinted, moving his finger along the words. "Main Drainage. Sewers." He looked up, frowning. "It's a plan of the new works, Nell. Look—that's the river, and these lines go under the streets."

"Which streets?"

He traced the dark line eastward, and Nell followed it with her finger, and her stomach turned to water. She knew these places. She knew every turning of them—the court where the pump stood, the wall behind the tanning yard, the dip in the ground by the old burial plot where the water always gathered after rain. The line ran straight through them all, through the alley where they slept, and she knew, as surely as she knew her own name, what a sewer laid through there would do when the rains came.

"It's going to flood us," she said. "Jem, it's going to drown us in our beds."