Lucía set the whisk down and tasted from the spoon. Garlic, egg, oil—the same components he used, and it was nothing. Flat as a puddle. She tried again, a splash more lemon, a pinch of salt, and it stayed mute, a sauce with no argument in it. She stood in the heat of her own truck and understood, slowly and with a kind of grief, that every dish she had been proud of this summer had his fingerprints somewhere in it—his char on the peppers, his trick with the smoked salt, his hand steadying hers over the flame.

She found him at the back of the lot, loading crates into the truck. "I filed the complaint," she said. "The one about your cooler. The temperature report. It was me."

Tomás stopped with a crate half-lifted. When he turned, his face was terrible, then very still. "Why," he said quietly, "would you throw away the lease you fought for?"

She didn't answer him. She walked to the committee tent with her papers and withdrew her application, and she recommended Tomás Ibarra in her place, her voice steady. Then she found the festival director and told him the whole thing, the falsified report, her name on it.

From the lot, Tomás watched her come out. He didn't move. The director found him a minute later, clapped him on the shoulder, and told him his permit was reinstated for the final weekend.