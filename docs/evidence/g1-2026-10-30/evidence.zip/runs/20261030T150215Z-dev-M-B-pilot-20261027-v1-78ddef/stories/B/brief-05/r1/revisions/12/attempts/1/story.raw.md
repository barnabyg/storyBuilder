The truck's tires crunched gravel and Martin cut the engine. For a moment the three of them sat in the heat, looking at the farmhouse—white paint curling off in strips, a porch that sagged like an old mattress, a windbreak of dead cottonwoods behind it.

"Ninety-four days," Martin said. "Ninety-four days, ninety-four nights. One day at a time."

"Dad," June said, "you always say the nights part."

"Because the nights are the hard part, bug."

Diane squeezed his knee, and he covered her hand with his, and for a moment the house was just a house. They carried boxes up the porch steps, and the door swung open on a smell of dust and cedar and something older underneath.

They found the first clock in the front room: a mantel clock, brass gone green, its hands frozen at 3:17. A dust ring marked where it had sat for years. The wall clock in the kitchen read 3:17. So did the little timer on the counter, its display faded to a brownish ghost of numbers. Upstairs, a bedside alarm, 3:17, its face filmed gray.

"Old folks," Diane said, and laughed. "Probably went to bed at three in the afternoon."

June lifted the mantel clock and wiped its face on her shirt. "I'm calling you Mr. Tick." She turned the key, and the hands held, stubborn.

Martin picked up the kitchen timer. Its battery door slid open under his thumb, and he palmed the battery and slid it into his pocket without deciding to. His hand shook doing it. Diane's eyes followed the motion, and she said nothing, and that silence went into him like a splinter.

That night the house was so quiet it seemed to have stopped breathing. Martin lay staring at the ceiling, ninety-four days, ninety-four nights, when every clock in the house began, at once, to tick.

The ticking followed him down to breakfast, a dry, patient sound from every room. Martin poured coffee and watched the mantel clock. Its hands had moved since the night before—backward. It read 3:16 now, and as he stared, the minute hand trembled and stepped back another notch.

"Diane. Look at this."

She came over with her toast, and he pointed. "It's going backward. It was 3:17 last night, now it's—"

She squinted at it. "It says ten past seven, Martin."

He looked again. The hands sat where they should, and the tick was ordinary. On the counter the kitchen timer glowed ten minutes, though no one had touched it, and he watched it count down while he explained, and when Diane turned it read 0:00.

"Have you been sleeping?" she asked gently. "Have you been to a meeting this week?"

"I'm fine. I'm not—" He set down his cup too hard. "I'm going to be late."

In the truck, the dashboard clock ticked backward in time with the house. He watched it take a minute, and the wheel came loose in his hands, and gravel sprayed before he got the truck straight again. He pulled to the shoulder and sat with the engine running, his heart going, and made himself say the thing he had been circling all morning: if he told her, she would not believe him, and the not-believing would be worse than the clocks. He had spent two years learning to be a man whose word was worth something. He could feel it going, minute by minute, the way the clock was going.

He called Ray from the truck. Ray had been his sponsor for two years, and he had a voice like a hand on your back. "Stress is a trigger," Ray said, flat and certain. "Secrets too. You're doing the thing where you carry it alone. Tell Diane everything."

At dinner, Diane set her fork down before the plates were cleared. "You've been strange since we got here. The clocks, Martin. You were talking about clocks." June looked up from her macaroni. "Is Daddy sick again?"

He tried to smile for her and felt it come out wrong. The next morning he found June standing in the hallway with her ear pressed to the wall clock. "It keeps whispering," she said. "It says six and five and four." Diane came out of the kitchen and June went quiet and went to wash her hands, and Martin did not know whether to be grateful or afraid.

The bottle surfaced during the search for a missing wrench. Diane found it in a crate Martin had already gone through twice, and he had no answer for that. Her face closed like a door. His hands shook when he told her he hadn't touched it, and he saw her eyes go to the tremor, then away.

"I'll keep it safe," she said, and put it on the top shelf of the pantry.

That night the wall clock in the hallway read 2:44. It had been counting down all along. Martin stood in the dark with his pulse loud in his ears and understood, finally, what the numbers were for.

The attic smelled of wet cardboard and old dust. Martin found the ledger wedged behind a rafter, its cover swollen with water stains, the pages rippled like a tide line. Inside, in a careful hand, someone had listed every clock in the house—parlor, hallway, kitchen, the little brass one from the upstairs landing—and beside each name, over and over down the columns, the same three digits: 3:17. 3:17. 3:17. The last entry was not a time at all. It comes when the clocks reach zero.

He sat on the attic steps and called the realtor with shaking hands. She was hesitant at first, then blunt. The previous owner, a widower named Hollis, had died in the house. His wife had died there years before that—a fall, on the stairs. "I'm sorry," she said. "I assumed you'd been told."

Diane was in the kitchen. He laid the ledger open on the counter. She looked at it the way she looked at a puddle on the floor. "Martin," she said quietly. "It's a moldy notebook. Have you been drinking up there?"

"Mom?" June stood in the doorway, hair wet from the bath. "What happens at zero?"

"Nothing," Martin said, too fast. "Nothing happens." He closed the ledger and carried it upstairs and slid it under his side of the mattress.

That night he lay awake and listened to the clocks and heard, in their ticking, a sound like a woman's voice counting under her breath. He got up and stood over June's bed and watched her sleep, her hair fanned out on the pillow, and told himself he would take her out of the house in the morning if he had to carry her.

In the morning the clocks read 2:52, and he could not make himself say it.

Diane stepped into the pantry and called Ray. "I think he's started again," she whispered. "Could you come by tomorrow?"

The clocks read 2:41. Martin stood in the kitchen with his coat half on, counting the hands again, and then he was moving.

"Bags," he said. "Everybody, get bags. We leave in five minutes."

Diane came out of the laundry with a basket on her hip. "What are you talking about?"

"Before 3:17. We have to be gone before 3:17." He took the stairs two at a time, pulled a duffel from the closet, and began throwing clothes into it. June appeared in her doorway, her hair wet from the bath. "Go get your shoes," he told her. "We're going for a drive."

By the time he got them to the porch, Diane was planted between him and the truck. "You're scaring her," she said. "Look at your hands. Look at you." June had started to cry, quietly, the way she did when she was trying not to be noticed.

"I need you to trust me for one hour," Martin said.

Ray's truck came up the drive then, headlights sweeping the yard. He stepped out slow, hands loose at his sides. "Diane called," he said. "Let's talk inside."

Martin grabbed June's arm. "Come on, sweetheart—"

She cried out, and Ray was there, stepping between them. "Let go of her, Martin. Let go." Diane swept June up and carried her inside, and the screen door banged.

Martin held out the ledger with both hands, open to the page. "Look. Look at the clocks. 2:44, all of them. Tell me what you see."

Ray looked at the clocks. His face was patient and tired. "I see five-forty," he said. "Martin. I think you need a meeting tonight, or a hospital. Either one. I'll drive you myself."

Martin stood in the yard with the cold coming up through his socks. Their faces had the same softness they wore when they were braced against him.

"I'll sleep in the barn," he said. "That proves I'm calm. You lock up. I'll be out there."

He gathered his duffel and walked across the yard. Behind him, one by one, he heard the bolts go home.

The barn was cold, and the loft window gave him a clear line to the kitchen. He watched the clock on the wall through the glass. 3:10. Then every dial in the farmhouse jumped at once, hands shivering, ticking loud enough that he imagined he could hear them across the yard—counting single digits now, he was certain of it, though he couldn't say how he knew.

At zero, everything stopped. The silence that followed was worse than the ticking. Then June's bedroom light flicked on, off, on, off, three times, and did not come on again.

Martin was out of the loft before he knew he'd moved. He hit the kitchen door at a run, rattled the handle, pounded with the flat of his hand. "Diane! Diane, open the door!" A low sound moved through the walls, not wind, not pipes—something sliding, patient, wrong.

He put his elbow through the window. Glass opened his palm and he barely felt it, hauling himself over the sill, blood smearing the frame. In the hallway the tall clock had started again, hands spinning forward, fast and smooth, as though the countdown had reset to some fresh and generous number.

From upstairs, June's voice: "Daddy?"

He took the stairs two at a time.

The bed was empty. The sheets were thrown back, and the window stood wide open to the night, the curtain lifting and falling in a slow breath. Beside the pillow, the little alarm clock read 3:17, its second hand frozen.

Diane came in behind him and stopped. The sound she made was not a word. Then she turned on him, her voice climbing, cracking. "Where is she? What did you do?" She seized his arm. "You took her. You're drunk—you've been drinking, you did something to her—"

"Diane—" He pulled free. On the floorboards, a line of small wet footprints led out the door and down the hall, toward the attic stairs. "Look. Look at that."

She was already backing away, phone to her ear, saying the address, saying my husband. Martin followed the prints alone, up the narrow stairs, into the dust and dark.

June's doll sat beneath the pinned clock list, its face turned up to him. He lifted the page. The last entry had changed. In place of the old time, one word, in the same cramped hand: paid.

He was still holding the doll when the police came up, his knuckles split and bleeding where he'd torn through the attic latch. Every clock in the house had stopped at 3:17. From the doorway below, Diane's voice carried clear and steady: "He's been drinking for weeks. I should have said something sooner."

They put him in the back of the cruiser with his hands cuffed in front of him, and he twisted against the seat to keep the farmhouse in view. "The clocks," he said to the deputy. "Write it down. Every clock in that house, stopped at three seventeen, and now they're running again. That's not nothing."

In the yard, Diane stood with a blanket pulled tight around her shoulders, Ray's hand at her elbow, and she would not look at the car. Not once.

Ray talked to the officers in a low voice, the way a man talks about weather. The drinking, the years of it, the meetings, the relapse nobody wanted to name. When the deputy held up the ledger, Ray shook his head. "You should have seen him before," he said. "A man like that can believe anything."

The cruiser rolled down the drive, and through the windows Martin watched the clocks. All of them. The kitchen clock, the hall clock, the little brass thing on the landing—ticking, all of them, and every hand moving the wrong way around the dial. Not toward morning. Toward something else.

Diane went back inside alone. She stood a long time in front of the mantel clock, and when she saw it running backward she reached up and wound it, gently, the way her grandmother had taught her. It stopped at 3:17.

Then, from inside the walls, faint as breath through plaster: "Daddy, the clocks are counting."