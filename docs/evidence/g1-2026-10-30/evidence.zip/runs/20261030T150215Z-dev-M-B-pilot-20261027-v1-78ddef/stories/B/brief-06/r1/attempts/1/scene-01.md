Lucía Ferrer rehearsed her pitch under her breath the whole drive down to the waterfront: *a neighborhood kitchen, seasonal, rooted—* she had it pared to ninety seconds, because ninety seconds was what the lease committee gave you and she had learned, in the year since the bank took her restaurant, exactly how much could be lost in a minute and a half.

She swung La Brasa into the festival lot at six forty and found her number, fourteen, occupied. Tomás Ríos's truck sat square on the painted lines, awning already cranked out, *Sal & Brasa* lettered in fat blue script she had always privately considered smug.

"You've got to be kidding me."

The permit clerk, summoned from a golf cart, was apologetic and immovable. The database had merged their applications. Both fees were paid. One slot existed. The festival did not, under any circumstances, refund.

"Then tell him to move," Lucía said.

Tomás leaned out his window, unbothered as a cat. "Same paperwork says I'm here. We can split it. Alternating days."

"Alternating—whose name is on the permit?"

"Mine's on it. So's yours. That's the whole problem."

They were still arguing, voices rising over the hiss of a neighboring fryer, when the festival director came down the row with a clipboard and a voice like a closing door. Any truck without valid paperwork on the lot, she said, gets towed by nine.

Lucía looked at Tomás. Tomás looked at Lucía.

"Fine," she said, through her teeth.