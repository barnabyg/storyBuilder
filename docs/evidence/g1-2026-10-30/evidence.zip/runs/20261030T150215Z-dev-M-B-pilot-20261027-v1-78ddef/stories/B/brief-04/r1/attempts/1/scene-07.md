The notice went up on the board outside the Vestry three weeks later, and though Nell couldn't read a word of it, she heard the news shouted across the market before noon: the new sewer would run south of the tan-yards after all, and the paper gave the credit to a sharp-eyed mudlark who had found the error in a surveyor's book.

A week after that, a messenger in a good coat came down to the foreshore asking for Nell Harker, and the other mudlarks fell back and stared as she was led away up the steps. At the Board of Works she stood in her patched boots before a long table of gentlemen, and Mr. Bazalgette himself put five gold sovereigns into her hand and a folded letter with a red seal.

"Read it when you can," he said. "It says what you did."

Mr. Finch was there too, at a clerk's desk by the window, ink on his cuffs. He caught her eye and nodded, and she saw the relief in his face—kept on, and better placed than before. "I owe you my post," he murmured as she passed.

That evening Nell took her sovereigns to a bookseller's near the bridge and bought a primer, a slate, and a spelling book, and she found an old schoolmaster two streets over who would teach her letters for a shilling a week. She still goes down to the river at low tide, because the mud is where she learned to see. But the mudlarks nod at her now, and the watermen call her the clever one, and in her primer's margins she practices the word engineer.