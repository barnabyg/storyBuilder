On the last night, she came back.

Lucía carried her cooler through the crowd like an apology, and when she reached his window she set it down and said, "I brought octopus. If you'll have me."

Tomás looked at the cooler, then at her. "No slot," he said. "No permit."

"I know what I'm asking."

He stepped back and let her in.

The line began before the first plate went out. Her octopus, charred and tender, laid over his aioli, lemon and smoked paprika on top. People carried plates down the boardwalk and came back for more. Lucía worked the grill beside him and found the rhythm they'd found that night of the blackout, hands crossing, no words needed.

Near midnight the committee chair ate standing up, wiped his mouth, and said to no one in particular, "Together they're better than either one of them alone."

After closing, Tomás killed the lights. The string lights hummed overhead.

"I don't want the lease," he said. "Not if it means going up against you."

"Tomás—"

"Go in with me. Partners. One menu, both our names."

She hesitated. She thought about pride, and what it had cost her, and what it hadn't been worth.

"Yes," she said.

They shook on it. Then, under the lights, they stopped shaking.