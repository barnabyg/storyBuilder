They put him in the back of the cruiser with his hands cuffed in front of him, and he twisted against the seat to keep the farmhouse in view. "The clocks," he said to the deputy. "Write it down. Every clock in that house, stopped at three seventeen, and now they're running again. That's not nothing."

In the yard, Diane stood with a blanket pulled tight around her shoulders, Ray's hand at her elbow, and she would not look at the car. Not once.

Ray talked to the officers in a low voice, the way a man talks about weather. The drinking, the years of it, the meetings, the relapse nobody wanted to name. When the deputy held up the ledger, Ray shook his head. "You should have seen him before," he said. "A man like that can believe anything."

The cruiser rolled down the drive, and through the windows Martin watched the clocks. All of them. The kitchen clock, the hall clock, the little brass thing on the landing—ticking, all of them, and every hand moving the wrong way around the dial. Not toward morning. Toward something else.

Diane went back inside alone. She stood a long time in front of the mantel clock, and when she saw it running backward she reached up and wound it, gently, the way her grandmother had taught her. It stopped at 3:17.

Then, from inside the walls, faint as breath through plaster: "Daddy, the clocks are counting."