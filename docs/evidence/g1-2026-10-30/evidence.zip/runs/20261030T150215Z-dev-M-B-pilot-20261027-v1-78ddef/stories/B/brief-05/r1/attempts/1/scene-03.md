He called Ray from the truck, parked at the far end of the lane with the engine off. "Stress is a trigger," Ray said, his voice flat and certain. "Secrets too. You're doing the thing where you carry it alone. Tell Diane everything."

At dinner, Diane set her fork down before the plates were cleared. "You've been strange since we got here. The clocks, Martin. You were talking about clocks." June looked up from her macaroni. "Is Daddy sick again?"

He tried to smile for her and felt it come out wrong.

The bottle surfaced during the search for a missing wrench. Diane found it in a crate Martin had already gone through twice, and he had no answer for that. Her face closed like a door. His hands shook when he told her he hadn't touched it, and he saw her eyes go to the tremor, then away.

"I'll keep it safe," she said, and put it on the top shelf of the pantry.

That night the wall clock in the hallway read 2:44. It had been counting down all along. Martin stood in the dark with his pulse loud in his ears and understood, finally, what the numbers were for.