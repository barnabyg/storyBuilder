The truck's tires crunched gravel, and Martin cut the engine. For a moment the three of them sat in the heat, looking at the farmhouse—white paint curling off in strips, a porch that sagged like an old mattress, a windbreak of dead cottonwoods behind it.

"Ninety-four days," Martin said. "Ninety-four days, ninety-four nights. One day at a time."

"Dad," June said, "you always say the nights part."

"Because the nights are the hard part, bug."

Diane squeezed his knee. They carried boxes up the porch steps, and the door swung open on a house that smelled of dust and cedar and something older underneath.

They found the first clock in the front room: a mantel clock, brass gone green, its hands frozen at 3:17. A dust ring marked where it had sat for years. The wall clock in the kitchen read 3:17. So did the little timer on the counter. Upstairs, a bedside alarm, 3:17, its face filmed gray.

"Old folks," Diane said, and laughed. "Probably went to bed at three in the afternoon."

June lifted the mantel clock, wiped its face on her shirt. "I'm calling you Mr. Tick." She turned the key, and the hands held, stubborn.

Martin picked up the kitchen timer. Its battery door slid open under his thumb, and he palmed the battery and slid it into his pocket without deciding to. His hand shook doing it. Diane's eyes followed the motion, and she said nothing, and that silence went into him like a splinter.

That night the house was so quiet it seemed to have stopped breathing. Martin lay staring at the ceiling, ninety-four days, ninety-four nights, when every clock in the house began, at once, to tick.