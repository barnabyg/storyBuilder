The name inside the cover had been inked in a careful copperplate she could not read but could copy in her mind like a drawing: *Property of T. Finch, Clerk*. She stopped a printer's boy in Farringdon and asked him to spell it out, then asked a porter at the Guildhall, and by afternoon she had it: T. Finch, clerk to the surveyor's office at the Metropolitan Board of Works, Spring Gardens.

She waited on the steps in the reeking heat among the clerks and messenger boys until the doors opened and the men came out in their black coats. She studied them the way she studied the riverbank, reading each one for the mark of a man who had lost something. The thin young man with ink on his cuffs and a frantic way of patting his pockets was the one.

"Mr. Finch," she said, stepping into his path.

He looked at her as though she were a rat out of the gutter. Then she held up the notebook, and the colour went out of his face entirely.

"Where did you—" He seized her arm and drew her aside. "That's mine. I lost it. Do you know what happens to a clerk who loses a surveyor's book? I'm turned off without a character. My mother—" He stopped and swallowed.

"I can't read it," Nell said. "But I know what's drawn in it, and it's wrong, and it'll drown my street. You help me read it proper and get me heard, and you'll have your book back. Else I take it to the Board myself and say where I found it."

Finch stared at her a long moment. Then he took off his hat and wiped his forehead.

"God help me," he said. "Come round the back."