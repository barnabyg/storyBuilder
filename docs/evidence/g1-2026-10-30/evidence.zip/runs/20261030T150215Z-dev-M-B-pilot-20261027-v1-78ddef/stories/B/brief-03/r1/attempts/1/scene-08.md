A week into her notice, a man in a gray suit came through the automatic doors at ten past nine, briefcase in hand, and asked the counter girl for Priya Raman by name.

He introduced himself as Harold Vance's attorney and set a sealed envelope on the counter between them. Inside was a copy of the will, and he waited while she read it, his hands folded.

The paragraph was short. Harold Vance, knowing the date of his own death, had arranged the prescription scheme with Mrs. Alcott deliberately, and had left a small sum—four thousand dollars—to the pharmacist who "did the human thing."

"Why me?" Priya asked.

The lawyer smiled thinly. "Mr. Vance spent a lot of time in this store. He watched you, months back, refuse to report a homeless man who walked out with insulin. He told me he'd found the one pharmacist in this city he could trust to be merciful." He tapped the will. "The scheme was the test. He wanted to know if you'd follow the rules or the person. You did the human thing."

Priya stood very still. The letter, the signatures, the deliberate paperwork—all of it, designed to see what she would do. She looked at the bequest, then at the empty stretch of counter where Mrs. Alcott used to stand, and understood that she had been part of his plan from the beginning.