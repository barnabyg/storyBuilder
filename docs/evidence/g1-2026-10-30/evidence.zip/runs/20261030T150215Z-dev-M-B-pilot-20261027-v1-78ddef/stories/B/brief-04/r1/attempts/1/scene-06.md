Mr. Bazalgette looked down at Nell from beneath heavy brows. "Well? Speak up."

"The tan-yard," Nell said. "It sits low, sir, lower than Rotherhithe Street by a good six foot. When the new sewer runs through, the levels in that book put the invert above the yard's bottom. Every high tide and every hard rain, the yard floods, and so do the courts behind it. Forty families, near enough."

"You've seen these plans?"

"I've seen the streets. I know every one of them from the river to the church, and I know where the ground lies. The book says the sewer falls east by one in four hundred, but the ground at King's Stairs falls faster than that. The numbers don't meet."

Bazalgette's eyes moved to Finch. "And you?"

"I lost the notebook, sir. On the ferry. This girl found it and brought it back—and she saw what I ought to have seen." Finch swallowed. "The route as drawn will flood the district. I'll take whatever penalty's due, but she's right."

Bazalgette spread the notebook on the table and traced the line with one finger, then another, checking the figures against the streets. His jaw tightened.

"Fetch me the levels for the tan-yard," he said to an assistant. "And a fresh survey of the eastern reach. This will be reviewed." He turned to Nell and, for the first time, smiled. "You've a sharp pair of eyes, girl. Sharper than some in this room."