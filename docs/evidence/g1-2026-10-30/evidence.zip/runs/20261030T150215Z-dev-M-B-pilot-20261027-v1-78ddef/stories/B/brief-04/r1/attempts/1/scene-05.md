They went at first light, before the clerks arrived to unlock the doors. Finch carried the notebook wrapped in brown paper, and Nell walked a half-step behind him, her bare feet silent on the stone. He had written the note in his careful copperplate and read it aloud to her twice so she could hold it in her mind.

The Board of Works office smelled of coal smoke and wet wool. Finch set the parcel on the counter and was turning to go when a voice stopped him cold.

"Finch. What's this?"

Mr. Grimes was a broad man with a chain across his waistcoat. He plucked the paper open before Finch could speak, and his face darkened at the sight of the leather cover.

"You lost this? A survey notebook, left God knows where for anyone to pick up?" His voice rose. "You'll answer for this to the Board, I promise you."

"It was found, sir," Finch said, his throat tight. "By this girl. And she says—"

"She says." Grimes turned his glare on Nell. "A mudlark off the riverbank, come to sell us our own property back."

Nell lifted her chin. "I found it in the mud. And the marks on it are wrong—the line runs downhill where it shouldn't, and it floods the streets by the tan-yard. I know that ground. I've walked it all my life."

Grimes dismissed her with a wave. "Out. Both of you."

But the door behind him had opened, and a tall, grey-whiskered man stood there with a roll of drawings under his arm, his eyes moving from the notebook to the child's muddy feet.

"What's this about the tan-yard?" asked Mr. Bazalgette.