The tide was out, and the river lay exposed and stinking. Nell Harker picked her way along the foreshore with her skirts kilted to her knees, her boots sinking into the grey ooze at every step. The Great Stink had brooded over London for weeks, and down here at the water's edge it was worst of all—a thick, rotting sweetness that caught in the throat and stayed there. She breathed through her mouth and kept her gaze on the mud, where a broken crate jutted from the silt.

Wedged against its splintered ribs was something that did not belong to the river. Nell crouched and worked it loose: a small book bound in oiled leather, swollen with damp but still whole. She wiped the worst of the slime on her apron and tucked it inside her bodice, where it lay cold against her ribs until the light failed.

Their lodgings were two rooms off a court in Bermondsey, shared with the widow Oakes and her brood. Nell lit a stub of candle and opened the book on the table. The pages were crowded with lines ruled straight and true, and numbers in a neat clerk's hand she could not read a word of. But her eye went at once to the folded sheet tucked in the back—a map, drawn fine as a spider's web, with a long dark line running through it like a seam.

Jem came in from the yard, wiping his hands. He was fourteen and had been two years at the board school before his father died, and he could puzzle out letters if they were large enough.

"Here," Nell said, turning the map to him. "What's it say?"

He squinted, moving his finger along the words. "Main Drainage. Sewers." He looked up, frowning. "It's a plan of the new works, Nell. Look—that's the river, and these lines go under the streets."

"Which streets?"

He traced the dark line eastward, and Nell followed it with her finger, and her stomach turned to water. She knew these places. She knew every turning of them—the court where the pump stood, the wall behind the tanning yard, the dip in the ground by the old burial plot where the water always gathered after rain. The line ran straight through them all, through the alley where they slept, and she knew, as surely as she knew her own name, what a sewer laid through there would do when the rains came.

"It's going to flood us," she said. "Jem, it's going to drown us in our beds."

He was quiet a moment, studying the map. "Maybe they know that. Maybe they've allowed for it."

"Then why's the line drawn through the low ground?" She jabbed her finger at the paper. "Look here. The ground falls away past the rope-walk. I know it does. And the line goes down with it, right into the dip."

Jem chewed his lip. "You'd have to show someone. Someone who'd listen."

"Who'd listen to me?"

He had no answer for that.

The vestry office smelled of coal smoke and wet wool, and Nell stopped just inside the door, suddenly aware of her own reek. The clerk behind the counter had a high collar and a pen he did not put down.

"I need to show you something." She laid the notebook on the counter and opened it to the folded map. "This here's the new sewer. It comes down our way, and it'll flood the whole of Cuttle Lane."

The clerk leaned back as though she carried plague. "Take your filthy hands off that counter. And take your rubbish with you."

"It in't rubbish. It's a surveyor's book. Look at the ink on it—"

"I can see what it is." He tapped his pen against the wood. "I can see a ragamuffin off the river with some drowned ledger she's fished out of the mud, hoping for a reward. We get one of you a week."

"I can't read it," Nell said, and hated saying it. "But I know the streets. I know every turning. That line there goes straight through the bakehouse and the pump. You put a sewer through there and the water comes up in every cellar."

The clerk's face went flat and ugly. "You calling the Board liars now? Get out, or I'll have the constable to you for vagrancy and thieving both."

Nell gathered the notebook against her chest and went out into the stink of the street. Her ears burned. She stood a moment in the doorway, watching the clerks pass with their umbrellas and their clean boots, and thought: they will not hear me because I am nobody. So I must find someone who is somebody, and give him a reason to listen.

The name inside the cover had been inked in a careful copperplate she could not read but could copy in her mind like a drawing: Property of T. Finch, Clerk. She stopped a printer's boy in Farringdon and asked him to spell it out, then asked a porter at the Guildhall, and by afternoon she had it: T. Finch, clerk to the surveyor's office at the Metropolitan Board of Works, Spring Gardens.

She waited on the steps in the reeking heat among the clerks and messenger boys until the doors opened and the men came out in their black coats. She studied them the way she studied the riverbank, reading each one for the mark of a man who had lost something. The thin young man with ink on his cuffs and a frantic way of patting his pockets was the one.

"Mr. Finch," she said, stepping into his path.

He looked at her as though she were a rat out of the gutter. Then she held up the notebook, and the colour went out of his face entirely.

"Where did you—" He seized her arm and drew her aside. "That's mine. I lost it. Do you know what happens to a clerk who loses a surveyor's book? I'm turned off without a character. My mother's a widow, and she has nothing but what I send her. If I lose this post we're both in the workhouse."

"I can't read it," Nell said. "But I know what's drawn in it, and it's wrong, and it'll drown my street. You help me read it proper and get me heard, and you'll have your book back. Else I take it to the Board myself and say where I found it. But I'd rather not do that, Mr. Finch. I'd rather we both came out of this whole."

Finch stared at her a long moment. Then he took off his hat and wiped his forehead.

"God help me," he said. "Come round the back."

Finch led her to a coffee house off the Strand, where the air was thick with steam and the smell of roasted beans, and bought her a cup she did not drink. He spread the notebook on the table between them and traced the lines with a stained forefinger.

"These hatched marks are the new sewers," he said. "The circles are the old drains they mean to join. And here—" he tapped a cluster of figures "—these are the levels. The height of the ground above the river."

Nell leaned close. She could not read the figures, but she did not need to. She set her finger on the map where the line bent toward the river.

"That's wrong," she said. "That ain't where the turn is. The turn's by the tan-yard, past the second arch. I know it. I've walked it a hundred times."

Finch frowned, then drew out a pencil and made a mark. "And here?"

"Lower. The ground falls away by the rope-walk. It floods every spring, and the cellars in Cuttle Lane stand in water up to the second step. If your sewer goes through there at the level you've drawn, the water'll have nowhere to go but up."

He was quiet a long while, his pencil still. "If the levels are wrong," he said at last, "the sewer would run above the ground at the low end. It would back up. It would flood your district."

"I told you."

"I know." He pressed his hands to his face. "But if I bring this forward, I lose my post. Mr. Grimes would see me ruined. He's been waiting two years for a reason to be rid of me."

"You won't bring it forward," Nell said. "We'll give it to someone who'll listen. There's an engineer, Mr. Bazalgette's man, who's said to be fair. We leave the book with him, no name on it. No one need know it was yours."

Finch stared at her, then slowly nodded.

They went at first light, before the clerks arrived to unlock the doors. Finch carried the notebook wrapped in brown paper, and Nell walked a half-step behind him, her bare feet silent on the stone. He had written the note in his careful copperplate and read it aloud to her twice so she could hold it in her mind.

The Board of Works office smelled of coal smoke and wet wool. Finch set the parcel on the counter and was turning to go when a voice stopped him cold.

"Finch. What's this?"

Mr. Grimes was a broad man with a chain across his waistcoat. He plucked the paper open before Finch could speak, and his face darkened at the sight of the leather cover.

"You lost this? A survey notebook, left God knows where for anyone to pick up?" His voice rose. "You'll answer for this to the Board, I promise you."

"It was found, sir," Finch said, his throat tight. "By this girl. And she says—"

"She says." Grimes turned his glare on Nell. "A mudlark off the riverbank, come to sell us our own property back."

Nell lifted her chin. "I found it in the mud. And the marks on it are wrong—the line runs downhill where it shouldn't, and it floods the streets by the tan-yard. I know that ground. I've walked it all my life."

Grimes dismissed her with a wave. "Out. Both of you."

But the door behind him had opened, and a tall, grey-whiskered man stood there with a roll of drawings under his arm, his eyes moving from the notebook to the child's muddy feet.

"What's this about the tan-yard?" asked Mr. Bazalgette.

Mr. Bazalgette looked down at Nell from beneath heavy brows. "Well? Speak up."

"The tan-yard," Nell said. "It sits low, sir, lower than Rotherhithe Street by a good six foot. When the new sewer runs through, the levels in that book put the invert above the yard's bottom. Every high tide and every hard rain, the yard floods, and so do the courts behind it. Forty families, near enough."

"You've seen these plans?"

"I've seen the streets. I know every one of them from the river to the church, and I know where the ground lies. The book says the sewer falls east by one in four hundred, but the ground at King's Stairs falls faster than that. The numbers don't meet."

Bazalgette's eyes moved to Finch. "And you?"

"I lost the notebook, sir. On the ferry. This girl found it and brought it back—and she saw what I ought to have seen." Finch swallowed. "The route as drawn will flood the district. I'll take whatever penalty's due, but she's right."

Bazalgette spread the notebook on the table and traced the line with one finger, then another, checking the figures against the streets. His jaw tightened.

"Fetch me the levels for the tan-yard," he said to an assistant. "And a fresh survey of the eastern reach. This will be reviewed." He turned to Nell and, for the first time, smiled. "You've a sharp pair of eyes, girl. Sharper than some in this room."

The notice went up on the board outside the Vestry three weeks later, and though Nell couldn't read a word of it, she heard the news shouted across the market before noon: the new sewer would run south of the tan-yards after all, and the paper gave the credit to a sharp-eyed mudlark who had found the error in a surveyor's book.

A week after that, a messenger in a good coat came down to the foreshore asking for Nell Harker, and the other mudlarks fell back and stared as she was led away up the steps. At the Board of Works she stood in her patched boots before a long table of gentlemen, and Mr. Bazalgette himself put five gold sovereigns into her hand and a folded letter with a red seal.

"Read it when you can," he said. "It says what you did."

Mr. Finch was there too, at a clerk's desk by the window, ink on his cuffs. He caught her eye and nodded, and she saw the relief in his face—kept on, and better placed than before. "I owe you my post," he murmured as she passed.

That evening Nell took her sovereigns to a bookseller's near the bridge and bought a primer, a slate, and a spelling book, and she found an old schoolmaster two streets over who would teach her letters for a shilling a week. She still goes down to the river at low tide, because the mud is where she learned to see. But the mudlarks nod at her now, and the watermen call her the clever one, and in her primer's margins she practices the word engineer.