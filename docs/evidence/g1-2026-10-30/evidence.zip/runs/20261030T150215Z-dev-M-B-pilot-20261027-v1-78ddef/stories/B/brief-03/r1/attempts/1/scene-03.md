Priya caught up with her at the crosswalk, two blocks down. The old woman walked with a hitch in her step, a pharmacy bag swinging from one hand, and Priya didn't decide to follow so much as find herself already following, her coat half-buttoned against the cold. The strip mall's parking lot was nearly empty. A gray sedan idled under a dead streetlight, and Mrs. Alcott went straight to it, leaned into the passenger window, and passed a plastic bag of pill bottles through. The man inside handed back a folded stack of bills. It took four seconds.

"Mrs. Alcott."

The old woman turned. She didn't look surprised. She looked tired, in a way Priya recognized from her own mirror.

"You've been watching me," Mrs. Alcott said.

"That's Harold Vance's medication. He's been dead three months."

"I know what it is." She tucked the cash into her coat. "The man in the car sells to people who can't afford insurance. I get a hundred a month."

"Ma'am—"

"It pays my aide three days a week. It pays for my insulin. Medicare takes care of the rest of me, not that." Her mouth tightened. "You going to tell me I'm a criminal?"

"I'm telling you I can't let this keep happening."

Mrs. Alcott nodded slowly, as if she'd expected exactly that. "Then I guess you'll have to turn me in."