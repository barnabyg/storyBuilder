Lucía Ferrer rehearsed her pitch under her breath the whole drive down to the waterfront: a neighborhood kitchen, seasonal, rooted in the markets her grandmother had dragged her through as a girl. She had it pared to ninety seconds, because ninety seconds was what the lease committee gave you, and she had learned, in the year since the bank took her restaurant, exactly how much could be lost in a minute and a half. The restaurant had been called La Brasa, and it had been hers for six years, until the landlord doubled the rent to a number that had clearly been waiting in a drawer for the day her review came out. She had signed the lease at twenty-nine, believing the paper was a promise. It had been a trap with good lighting.

She swung her truck into the festival lot at six forty and found slot fourteen occupied. Tomás Ríos's truck sat square on the painted lines, awning already cranked out, Sal & Brasa lettered in fat blue script she had always privately considered smug. He was a decent cook and he knew it, which was the worst thing you could say about a man. He was also, she had noticed, always the first to arrive and the last to leave, and he charred his peppers over open flame when everyone else used the oven, and she had noticed that too, and resented noticing.

"You've got to be kidding me."

The permit clerk, summoned from a golf cart, was apologetic and immovable. The database had merged their applications. Both fees were paid. One slot existed. The festival did not, under any circumstances, refund.

"Then tell him to move," Lucía said.

Tomás leaned out his window, unbothered as a cat. "Same paperwork says I'm here. We can split it. Alternating days."

"Alternating—whose name is on the permit?"

"Mine's on it. So's yours. That's the whole problem."

They were still arguing, voices rising over the hiss of a neighboring fryer, when the festival director came down the row with a clipboard and a voice like a closing door. Any truck without valid paperwork on the lot, she said, gets towed by nine. Lucía looked at Tomás. Tomás looked at Lucía. Behind her eyes she did the arithmetic she did every morning now, the one where the restaurant fund had a hole in it shaped like a summer.

"Fine," she said, through her teeth.

On her days, Lucía arrived early and erased him—his chalk marks scrubbed from the asphalt, his grease stains bleached to ghosts, her own banner hung square over the shared boundary. On his days, Tomás chalked a fat arrow pointing to his window and wrote THIS WAY in letters a city block wide. The crowd loved it. Lucía did not. She sold her grilled octopus and her empanadas and her burnt-orange flan, and she smiled at every customer, and every night she went home to her studio apartment, where the rent was current and the kitchen was a two-burner hotplate, and lay awake doing arithmetic on the lease.

"You should try his smoked-paprika aioli," a woman said at her window one afternoon, licking her thumb. "It's the best thing here."

Lucía smiled until her face ached. After the rush she slipped to his truck, unscrewed the jar, and tasted. The aioli bloomed on her tongue—smoke and acid and something bright she couldn't name—and she knew at once it was the missing note in her octopus, the flatness she'd been chasing for weeks. She capped the jar, wiped her mouth, and refused to ask. Asking was how you ended up in debt to a man, and she had spent a year learning the interest.

Instead she salted her next batch harder, and harder still. The lunch crowd chewed and winced. A man returned his plate. Lucía stared at the ruined octopus and felt her pride curdle. She had run a restaurant with a menu that won a review in the paper, and now she was losing a parking lot to a man who wrote his own advertisements on the ground.

The next morning a jar of aioli sat on her prep counter, a scrap of paper beneath it: You're welcome. —T.

She threw it in the bin. That night, alone under the string lights, she fished it out and ate a spoonful in the dark, standing over the sink like a thief.

"You two are gold," the festival director told her the next afternoon, beaming. "Best buzz we've had in years. The lease committee's watching, you know. They love a story."

Lucía smiled again. It tasted like salt. She told herself the story would be hers alone by September.

The transformer blew at seven-forty on the hottest night of the festival, a sound like a gunshot, and then the whole row went dark and silent. Lucía stood in the sudden blackness with a tray of empanadas half-fried and listened to her refrigerators die, and to the sound of her summer spoiling in the dark. Tomás appeared at her window with a flashlight. "Cold storage," he said. "Mine's got space. Bring everything."

"I'm not putting my stock in your truck."

"Then watch it spoil." He was already walking. "I've got a gas burner. We cook what we can, we sell it hot. Or we eat the loss."

She held out four minutes, until the first faint sourness reached her nose. Then she carried her pans across.

They worked shoulder to shoulder in the cramped heat, his burner hissing under her stockpot, her knife flashing through his onions. He reached over and turned down her braise. "You're burning the bottom."

"And you're drowning that in cumin."

He tasted. Grudgingly, he added less. She tasted his sauce, added salt and a squeeze of lime, and he didn't argue. The improvised menu sold out in an hour. "You know," said Mrs. Ochoa, licking her fingers, "that's the best thing you've fed me all summer." Lucía looked up and found Tomás already looking at her. Neither of them said anything.

At closing he counted the take and pushed half toward her without being asked. They sat on his tailgate in the dark, and he told her about his taquería, the flood, the insurance that didn't come, the two years he'd spent cooking on other people's stoves and telling himself it was temporary. She told him about her restaurant, the lease that had looked like a lifeline and turned out to be a trap, the way she still woke at four sometimes and reached for a walk-in that wasn't there. The generator hummed. Neither of them moved to go.

He walked her the three blocks to her apartment, and at the corner, under the streetlight, he said it plainly: he was one of the two finalists for the vacant space at the corner of Market and Vine. She said she knew. He said he'd guessed she was the other. The committee would decide by summer's sales. They stood there a moment, close enough that she could smell smoke and lime on him. He kissed her—quick, almost apologetic—and she kissed him back before they both pulled away, each reading the same arithmetic in the other's face. Partner and obstacle, in the same man.

"We keep this quiet," she said. "And we compete honest."

"Honest," he agreed. Neither of them sounded sure.

The festival director found Lucía during the afternoon lull, wiping down her prep counter. He kept his voice low, almost kind, which made it worse. The committee had reviewed the summer's numbers. Tomás's margins were stronger, his crowds steadier. Nothing was decided—but she should know which way the wind blew. She stood there with a rag in her hand and felt the lease slipping through her fingers like water. She thought about the hotplate. She thought about her mother asking, on every phone call, whether she was eating.

The propane. Tomás ran two tanks in series, a setup that was legal enough but wouldn't survive a fussy inspection. One phone call, anonymous, and he'd be dark for the final weekend. She told herself it was business. She dialed before she could think, and afterward she sat with the phone in her lap for a long time, feeling the small hot coin of it burn through her pocket.

She watched from her window as the inspectors arrived, clipboards out, and shut his grill down mid-service—a line of customers stranded, Tomás's hands hanging useless at his sides. He came to her truck an hour later, and she had never seen him look so tired.

"I thought we'd moved past this," he said quietly.

"I don't know what you're talking about."

He looked at her a long moment, then turned and walked away without a word.

By evening she had her best sales day yet. The register hummed. She felt nothing.

A woman leaned into her window, smiling. "Two of the chicken, please—and where'd the aioli go? The other truck always had it."

Lucía set the whisk down and tasted from the spoon. Garlic, egg, oil—the same components he used, and it was nothing. Flat as a puddle. She tried again, a splash more lemon, a pinch of salt, and it stayed mute, a sauce with no argument in it. She stood in the heat of her own truck and understood, slowly and with a kind of grief, that every dish she had been proud of this summer had his fingerprints somewhere in it—his char on the peppers, his trick with the smoked salt, his hand steadying hers over the flame. She had been cooking alone for a year and calling it pride. It had only been alone.

She found him at the back of the lot, loading crates into the truck. "I filed the complaint," she said. "The one about your tanks. It was me."

Tomás stopped with a crate half-lifted. When he turned, his face was terrible, then very still. "Why," he said quietly, "would you throw away the lease you fought for?"

She didn't answer him. She walked to the committee tent with her papers and withdrew her application, and she recommended Tomás Ríos in her place, her voice steady. Then she found the festival director and told him the whole thing, the falsified report, her name on it. From the lot, Tomás watched her come out. He didn't move. The director found him a minute later, clapped him on the shoulder, and told him his permit was reinstated for the final weekend.

On the last night, she came back.

Lucía carried her cooler through the crowd like an apology, and when she reached his window she set it down and said, "I brought octopus. If you'll have me."

Tomás looked at the cooler, then at her. "No slot," he said. "No permit."

"I know what I'm asking."

He stepped back and let her in.

The line began before the first plate went out. Her octopus, charred and tender, laid over his aioli, lemon and smoked paprika on top. People carried plates down the boardwalk and came back for more. Lucía worked the grill beside him and found the rhythm they'd found that night of the blackout, hands crossing, no words needed. Near midnight the committee chair ate standing up, wiped his mouth, and said to no one in particular, "Together they're better than either one of them alone."

After closing, Tomás killed the lights. The string lights hummed overhead.

"I don't want the lease," he said. "Not if it means going up against you."

"Tomás—"

"Go in with me. Partners. One menu, both our names."

She hesitated. She thought about pride, and what it had cost her, and what it hadn't been worth. "Yes," she said.

They shook on it. Then, under the lights, they stopped shaking.

The committee called on Monday. They had watched the final weekend—the two trucks parked nose to tail, the shared prep table, the line that wrapped past the fountain—and they had read Lucía's withdrawal and Tomás's letter in the same sitting. The lease, they said, was never meant to crown one chef. It was meant to keep a kitchen alive in that corner of the market. They offered it to the pair as a joint venture, and Lucía laughed so suddenly she had to put the phone down.

They signed on a Tuesday, at a folding table in the empty restaurant, her name and his on the same line. Then they painted the sign together, badly, Tomás holding the stencil while Lucía cursed the letter S. Sal & Brasa. Salt and ember. A name that finally fit both of them.

Opening night the window fogged before eight. Lucía plated the octopus—charred, blistered, unapologetic—and set it in the pass with his saffron aioli pooled beneath it, and they toasted with cheap cava in mismatched glasses, to second chances.

A customer, fork suspended, asked across the counter who the chef was.

"We are," they said, at the same time.