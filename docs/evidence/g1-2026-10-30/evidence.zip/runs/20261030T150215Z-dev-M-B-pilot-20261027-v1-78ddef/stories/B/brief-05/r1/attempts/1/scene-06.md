The barn was cold, and the loft window gave him a clear line to the kitchen. He watched the clock on the wall through the glass. 3:10. Then every dial in the farmhouse jumped at once, hands shivering, ticking loud enough that he imagined he could hear them across the yard—counting single digits now, he was certain of it, though he couldn't say how he knew.

At zero, everything stopped. The silence that followed was worse than the ticking. Then June's bedroom light flicked on, off, on, off, three times, and did not come on again.

Martin was out of the loft before he knew he'd moved. He hit the kitchen door at a run, rattled the handle, pounded with the flat of his hand. "Diane! Diane, open the door!" A low sound moved through the walls, not wind, not pipes—something sliding, patient, wrong.

He put his elbow through the window. Glass opened his palm and he barely felt it, hauling himself over the sill, blood smearing the frame. In the hallway the tall clock had started again, hands spinning forward, fast and smooth, as though the countdown had reset to some fresh and generous number.

From upstairs, June's voice: "Daddy?"

He took the stairs two at a time.