The next night Priya stayed late, after Dennis had gone home and the front lights had dimmed to their overnight setting. She pulled Harold Vance's file expecting to find some clerical ghost—a death recorded against the wrong account, a name transposed in the system. It would be a relief to close the folder and forget it.

Instead she found a form. A signed authorization, dated six weeks before Harold died, naming Margaret Alcott as an approved pickup person for all his medications. His signature was steady, deliberate, pressed hard enough to score the paper.

Beneath it, a note from his physician in the file: *Prescriptions to continue per patient's arrangements.*

Priya stared at the phrase a long moment, then called the number on the letterhead. A receptionist answered on the fifth ring, sounding like the end of a very long day.

"The doctor did sign off on it," the woman said. "Beyond that I couldn't tell you. He's been dead two years himself, honey. I just answer the phone."

Priya hung up. Behind her, Dennis had come back for his keys and stood in the doorway, reading over her shoulder.

"Vance? Old guy, right?" He shrugged. "Store gets paid either way. Not your problem, Priya."