# Realisation evidence

packet_sha256: b757b0c93dab16f2e4a914d235e1f9c3302b17e47ecd129b513ec7c8d1a87f2a

story_sha256: 906c7025207cdfb7e2c6cabed3eb8dd5189e8b54c74995962dc4392832a15083

plan_sha256: 12d73359ea68188fac9a4a467c9ae1315de24d550ca652c606c8da1048d41dbf

sample: ['brief-02']

denominator: 11

assessed: 0

missing: 11

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
