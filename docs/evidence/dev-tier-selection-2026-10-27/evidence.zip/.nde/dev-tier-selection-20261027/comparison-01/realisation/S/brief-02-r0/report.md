# Realisation evidence

packet_sha256: 4cb4f3e237fe0a7c29cc37ca88d5c5c4ded7583b5baeb73098fd6f0e7a591bd4

story_sha256: c59ada2e31972a5c41a6c86a016031475b9e2dfb7fe4a8daf0a110aad5724ce8

plan_sha256: 8c0629fab33b7431e5433a0eda196c70c6c5268e33fd85068e59c0f9598001f0

sample: ['brief-02']

denominator: 0

assessed: 0

missing: 0

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: No belief/relationship/reveal/tension channels are represented.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
