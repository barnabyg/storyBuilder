# Realisation evidence

packet_sha256: 99a835db7f80adf499179a614b98714909fb8936b6b7a4a0fba65502c42f37d5

story_sha256: 767fc2fb95bbcd7378bf8a8ab75b9f6554bd15e7f8b78fed4cc46ce82531d59d

plan_sha256: 494a399e268560018256a2e650195382f433f6d240c61ae9687c9e820b957fa2

sample: ['brief-02']

denominator: 21

assessed: 0

missing: 21

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
