The door to his quarters slid open just wide enough for Mira to slip through, her maintenance uniform rumpled, a data slate clutched against her chest. The guard outside didn't turn around. Tomas sat up on the bunk, and she pressed a finger to her lips before he could speak.

"I copied it," she whispered. "Everything you pulled. The logs, the edits, the course heading from forty years ago. It's on this slate and two backups." She set it on the desk between them. "I read all of it twice. Voss is wrong. Whatever happens out there, it isn't hers to decide for eight thousand people."

Tomas stared at her. "You could be confined too."

"I know." She pulled a thin coil of wire from her pocket and held it up. "But the night maintenance rotation is mine to run, and the guard on this corridor owes me a favor. Come on."

They moved through the service crawlways single file, Mira leading with a penlight clamped in her teeth. At a junction node she spliced his slate into the ship's internal comm array, and Tomas's hands shook as he keyed the sequence. His voice, when he began, came out steadier than he felt. He read the evidence aloud: the original destination, the false hope, the forty years of quiet edits. He gave the coordinates. He told them who had done it and why.

Then he released the files and let the channel stay open.

Mira pulled the splice. In the maintenance node's cramped dark, the two of them sat with their backs against the bulkheads, and the ship's hum went on around them, unchanged and enormous, and they waited.