At 22:00 ship time, when the day shift's noise had drained out of the corridors, Tomas Okafor began his audit. He started with the environmental logs, as always: oxygen partial pressures across all forty-one decks, scrubber cycle times, the slow drift of humidity in the hydroponics bays. Every value was checked against its twin, every twin against the checksum in the header. The ship recorded everything, and the records agreed with themselves, and that agreement was the closest thing to honesty Tomas had ever found in people or machinery. People forgot. People rounded. The log did not.

He worked down his list in order, because order was the point. Water reclamation. Power draw. The maintenance ledger, where every repair on the ship was stamped, signed, and hashed. It was there, at 23:40, that the number failed to reconcile.

Tomas frowned at the discrepancy—a checksum mismatch in the maintenance stamps attached to the navigation log. Small. Almost beneath notice. He ran the check again, then a third time on the backup terminal, and the mismatch held steady, the same gap in the same place. It had the look of a fault in his own instruments, a corrupted cache or a stale index, and he told himself so. He cleared the cache and re-ran the audit from the beginning. The number failed again.

"You're still here," Ildiko said from the hatch, her shift bag over one shoulder. She had the easy manner of someone who finished her work when her work was finished. "That's the third night this week."

"Checksum won't reconcile," Tomas said, not looking up. "Navigation maintenance stamps."

"Then log it and go to bed. That's what the ticket system is for."

"I can't close a ticket I can't explain." He turned the screen toward her, though she was already halfway out the door. "It's not random. It repeats. Same offset, every cycle."

Ildiko paused, glanced at the numbers, and shrugged. "So the archive is glitchy. Report it to Records in the morning. They'll re-stamp it and it'll reconcile and you'll have slept."

"Records doesn't re-stamp navigation. Nobody touches navigation but the council."

"Then it's above your pay grade and mine." She tapped the hatch frame twice, a friendly farewell. "Good night, Tomas."

The hatch sealed behind her. Tomas sat in the hum of the empty bay and ran the check a fourth time, then a fifth, watching the same stubborn number refuse to agree with itself.