The console asked for an authorization code, and Tomas typed his. It asked for a second, and he typed that too. Somewhere in the council offices an alarm would be lighting up, a technician's credentials reaching for a channel they were never meant to touch.

Mercer's voice came through the desk speaker, tight and hurried. "Tomas. The channel opens in forty seconds. You can still stop this. Whatever you think you're doing, there are eleven thousand people asleep in the rings who will wake up to a changed sky and no way to—"

"I know what they'll wake up to," Tomas said. "That's the point."

"Listen to me. We have four generations of—"

He pressed the key that dropped her from the line. Ildiko's hand was still flat on the desk, and he saw her knuckles go pale, but she didn't pull it back.

The channel opened.

"All decks," he said. His voice filled the maintenance bay and, he knew, the mess halls and the corridors and the quiet cabins where people were eating or mending clothes or arguing about nothing at all. "This is Technician Tomas Okafor, navigation maintenance. I'm reading you the ship's log. The unedited one."

He read it. Not the whole thing—nobody could read fifty years aloud—but the shape of it: the course the founders had charted, the hazard the council had found waiting there, the turn the ship had made in the dark, and the decades of quiet revisions that had kept the turn out of every public record. He read the dates. He read the names of the technicians who had made the edits, his own predecessor among them, and then the names of the councilors who had ordered it.

"The ship is not going where you were told," he said. "It has not been going there for sixty-one years. I don't know what should be done about that. But it isn't my decision, and it was never theirs to make alone."

He paused. The channel waited, open and empty, and he could hear the soft hiss of a hundred speakers holding the silence with him.

"That's the log," he said. "That's all of it."