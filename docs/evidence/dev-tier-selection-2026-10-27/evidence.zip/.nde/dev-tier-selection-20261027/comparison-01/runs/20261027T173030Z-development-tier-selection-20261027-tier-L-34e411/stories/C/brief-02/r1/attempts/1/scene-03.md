Han stood in the doorway with his kit bag still over his shoulder, and Tomas realized he had been talking to himself, or to the screens, for some minutes.

"Don't," Tomas said. "Whatever you're going to say."

Han set the bag down slowly. "I wasn't going to say anything."

"Good." Tomas pulled the backups off the display, one by one, and stacked them in his head like plates. Forty years of tiny corrections. A heading nudged by a quarter degree, then a quarter more, each edit logged as a routine recalibration, each one signed off by a name he had been taught to trust. "I need to see Mercer."

Han didn't stop him. That was the strange part. Han just watched him go, and Tomas understood, walking the long corridor to the council deck, that Han had known, or guessed, and had decided not to be the one who said it aloud.

Mercer's office was small and warm, crowded with paper she still insisted on keeping. She looked up from her desk as he came in, and her face did something complicated and then settled.

"You found it," she said. Not a question.

"Forty years of edits. The charter says we're bound for Kepler-186. The log says otherwise."

"Sit down, Tomas."

"I'd rather stand."

"That's fine." She folded her hands. "Yes. The council authorized every one of those edits. It began long before me. I've signed my share." She said it plainly, the way she might confirm a shipment of filters. No denial, no threat, no reaching for a comm. It unsettled him more than either would have. "Ask me why."

"Why?"

"The original course," she said, "ran us toward something the founders knew about and chose not to put in the charter. A debris field, a radiation front—the records are partial. What's clear is that they judged the passengers couldn't be told, and they turned us. Quietly. And every council since has kept the turn quiet, because the moment it surfaces, the question isn't the hazard anymore. It's who decided."

Tomas gripped the edge of her desk. "That's not a reason. That's a confession with a preface."

"It's both." Mercer's voice stayed level. "I'm not going to threaten you, Tomas. I'm going to ask you to hold two things at once. Forty thousand people are asleep, or born into a ship they call a promise. Stability is not nothing. It's the only thing keeping the corridors walkable." She paused. "And then there's the truth they never consented to receive. Weigh them. I'd like to know which way you tip."

He looked at her hands, still folded, and understood she genuinely wanted an answer, and that this was somehow the worst thing she had done all morning.