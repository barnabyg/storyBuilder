The tower stairs were cold under Ada's hand, the iron rail slick with the damp that came off the water after sundown. She climbed them anyway, as she had every night since the light had been struck from the register, and set her lamp on the old pedestal and lit it by hand. The flame guttered, then held. Below her the harbour lay in its usual scatter of lights, and there at the wharf, small and patient, rode the *Marigold*, her hull dark against the black water.

She signed the bill of sale at the kitchen table, her pen pressing harder than it needed to. Eli Pruitt sat across from her with his cap in his hands, his face flushed as though he'd run the length of the wharf. His traps had come up empty two seasons running; she knew that, and knew the price of knowing.

He said he had a plan for her, for the boat, and was gone before she could ask what plan.

When the door shut, Ada went down to the wharf and laid her palm flat against the nameplate, the letters cold and raised. She remembered Tom in the spring, on his knees with the caulking iron, whistling through his teeth, the smell of tar and varnish and his pipe smoke all mixed together in the sun.