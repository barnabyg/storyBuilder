# The Quiet Course

Plan plan-brief-02; schema 1; tier L

Character tomas: Tomas Okafor

Character mercer: Councilor Mercer

Character ildiko: Ildiko Reyes

Character han: Archivist Han

## s1: Routine Audit

Tomas runs a routine maintenance cross-check on the navigation log and finds a checksum that does not reconcile; he treats it as a fault in his own instruments.

Present: tomas, ildiko

Beat s1-b1: Tomas's meticulous nightly audit routine establishes his trust in records over people.

Beat s1-b2: A recurring checksum mismatch appears in the navigation log's maintenance stamps.

Beat s1-b3: Ildiko, a shift-mate, suggests he report it and move on; Tomas refuses to close a ticket he cannot explain.

Fact kf-edits: The navigation log has been edited for decades to hide a course change.; initial holders: mercer

Fact kf-hazard: The original course led toward a hazard the founders concealed.; initial holders: mercer

Causal c1: earlier cause s1 → effect s2

Setup setup-checksum at s1: The recurring checksum mismatch that first draws Tomas's suspicion.

Setup setup-charter at s1: The public charter stating the ship's official heading, later contradicted by backups.

## s2: The Deleted Decade

Tomas reconstructs older log backups and discovers decades of small, careful edits that together conceal a course change.

Present: tomas, han

Beat s2-b1: Archivist Han grants Tomas access to sealed backup media after he cites procedure.

Beat s2-b2: Comparing backups, Tomas finds edits spaced years apart, each erasing a small vector correction.

Beat s2-b3: He realizes the ship has been on a different heading than the public charter states for decades.

Causal c1: earlier cause s1 → effect s2

Causal c2: earlier cause s2 → effect s3

Payoff p1: setup setup-checksum → payoff at s2

Reveal r1: fact kf-edits at s2; holders: tomas (acquired at scene start)

## s3: The Council's Reason

Tomas confronts Councilor Mercer, who admits the council ordered the edits and argues the truth would trigger a mutiny.

Present: tomas, mercer

Beat s3-b1: Mercer neither denies nor threatens; she confirms the edits were authorized.

Beat s3-b2: She explains the original course led toward a hazard the founders hid from passengers.

Beat s3-b3: Mercer asks Tomas to weigh stability against a truth the passengers never consented to receive.

Causal c2: earlier cause s2 → effect s3

Causal c3: earlier cause s3 → effect s4

Setup setup-mercer-appeal at s3: Mercer's argument that truth would cause mutiny, revisited in the final scene.

Payoff p2: setup setup-charter → payoff at s3

Reveal r2: fact kf-hazard at s3; holders: tomas (acquired at scene start)

Knowledge use ku1: mercer uses fact kf-edits at s3

Knowledge use ku2: mercer uses fact kf-hazard at s3

## s4: Weighing the Records

Tomas wrestles with the council's argument, testing it against his own belief that records exist to be trusted.

Present: tomas, ildiko

Beat s4-b1: Ildiko argues the passengers deserve to know where they are going.

Beat s4-b2: Tomas drafts and deletes a report, torn between order and consent.

Beat s4-b3: He decides that a record he cannot trust is worse than a truth that unsettles.

Causal c3: earlier cause s3 → effect s4

Causal c4: earlier cause s4 → effect s5

Knowledge use ku3: tomas uses fact kf-edits at s4

Knowledge use ku4: tomas uses fact kf-hazard at s4

## s5: The Open Channel

Tomas broadcasts the unedited log to the whole ship; the story ends as the announcement finishes, before any reaction.

Present: tomas, mercer, ildiko

Beat s5-b1: Tomas routes the full log through the shipwide channel despite Mercer's final appeal.

Beat s5-b2: The truth is announced: the ship changed course, and the council hid it.

Beat s5-b3: The narration cuts off at the end of the announcement, leaving the passengers' response unknown.

Causal c4: earlier cause s4 → effect s5

Payoff p3: setup setup-mercer-appeal → payoff at s5

Reveal r3: fact kf-edits at s5; holders: ildiko (acquired at scene start)

Knowledge use ku5: tomas uses fact kf-edits at s5

Knowledge use ku6: tomas uses fact kf-hazard at s5

Knowledge use ku7: mercer uses fact kf-edits at s5

Knowledge use ku8: mercer uses fact kf-hazard at s5

State st1 [s1] tomas belief records-are-reliable: known: records are reliable; confidence 0.9; alternatives: (none recorded) → ambiguous: records may be unreliable; confidence 0.5; alternatives: records are reliable; records are being tampered with

State st3 [s2] tomas belief institutional-access-is-clean: known: sealed records are accessed only by proper procedure; confidence 0.8; alternatives: (none recorded) → ambiguous: even proper procedure can conceal a compromise; confidence 0.5; alternatives: Han's request was harmless routine; the archive itself is managed to hide things

Relationship rel2 [s2] tomas, han trust: known: professional reliance on the archive's gatekeeper; confidence 0.7; alternatives: (none recorded) → ambiguous: uneasy collaboration with a shared secret; confidence 0.5; alternatives: Han is protecting Tomas; Han is protecting the archive's secrets

State st4 [s3] tomas belief council-authority-is-honest: known: the council's authority rests on honest records; confidence 0.75; alternatives: (none recorded) → known: the council knowingly authorized concealment; confidence 0.85; alternatives: the edits were a rogue action within the council

State st5 [s3] mercer belief truth-would-cause-mutiny: known: the concealment is a burden she carries alone; confidence 0.6; alternatives: (none recorded) → ambiguous: Tomas now knows, and the argument must be won or the secret lost; confidence 0.5; alternatives: Tomas can be persuaded to keep silent; Tomas will expose the edits regardless

Relationship rel1 [s3] tomas, mercer trust: known: deferential trust in council; confidence 0.7; alternatives: (none recorded) → known: wary confrontation; confidence 0.8; alternatives: (none recorded)

State st2 [s4] tomas value truth-vs-stability: known: stability through trusted records; confidence 0.7; alternatives: (none recorded) → known: consent requires the truth; confidence 0.8; alternatives: stability outweighs truth

State st6 [s4] ildiko belief passengers-deserve-the-truth: ambiguous: the log discrepancy is Tomas's private problem; confidence 0.4; alternatives: it is a routine fault; it is something the council should handle → known: the passengers have a right to know the ship's real course; confidence 0.8; alternatives: the council's silence protects them

State st7 [s4] tomas belief report-handling: known: a report must be filed through proper channels; confidence 0.7; alternatives: (none recorded) → ambiguous: proper channels would bury the finding; confidence 0.55; alternatives: channels could still surface it; only a direct broadcast will be heard

Relationship rel3 [s4] tomas, ildiko trust: known: collegial shift-mate reliance; confidence 0.7; alternatives: (none recorded) → known: confidant bound by a shared dangerous secret; confidence 0.8; alternatives: Ildiko becomes the one who pushes him; Ildiko becomes the one he must protect

State st8 [s5] tomas goal disclosure-method: known: find a way to make the truth heard without destroying order; confidence 0.6; alternatives: file through channels; leak anonymously → known: put the unedited log on the shipwide channel himself; confidence 0.85; alternatives: abort at the last moment

State st9 [s5] mercer belief containment: ambiguous: the secret can still be contained by persuasion or procedure; confidence 0.45; alternatives: Tomas will expose the edits regardless; the council can outlast the crisis → known: the secret is beyond her control and the passengers will judge the council; confidence 0.8; alternatives: the broadcast can be cut before it lands; the passengers will side with the council

State st10 [s5] ildiko belief public-knowledge: ambiguous: the truth should be told, but she does not know if Tomas will tell it; confidence 0.5; alternatives: Tomas will stay silent; the council will preempt him → known: the truth is now public and she is part of having made it so; confidence 0.8; alternatives: the broadcast will be dismissed as a fault

Relationship rel4 [s5] tomas, mercer trust: known: wary confrontation; confidence 0.8; alternatives: (none recorded) → known: irreversible rupture; authority and technician openly opposed before the whole ship; confidence 0.8; alternatives: Mercer yields and joins the disclosure; Mercer contains the damage and Tomas is isolated

Relationship rel5 [s5] tomas, ildiko trust: known: confidant bound by a shared dangerous secret; confidence 0.8; alternatives: (none recorded) → ambiguous: co-conspirators at the moment of exposure, their bond now public and untested; confidence 0.5; alternatives: she stands with him openly; she is exposed alongside him without having chosen it

Constraint brief-ending: human assessment required; literary story canon ending; expected None; The truth is announced, and the story ends before anyone knows how the passengers will react.

arcs arc-tomas [s1, s2, s3, s4, s5] interpretation: Tomas moves from trusting records over people to trusting truth over institutional order; status=known; confidence=0.85

Arc character: tomas

agency trajectory arc-tomas: 1 → 2 → 4; shape=rising; scenes=s1 → s3 → s5; ordinal 0-4

arcs arc-mercer [s3, s4, s5] interpretation: Mercer holds to stability, then loses control of the narrative; status=known; confidence=0.7

Arc character: mercer

agency trajectory arc-mercer: 3 → 2 → 1; shape=falling; scenes=s3 → s4 → s5; ordinal 0-4

reader_affect ra1 [s1, s2, s3, s4, s5] interpretation: suspense building toward an unresolved threshold; status=known; confidence=0.8

mood trajectory ra1: 1 → 2 → 4; shape=rising; scenes=s1 → s3 → s5; ordinal 0-4

reader_affect ra2 [s3] interpretation: uneasy sympathy for Mercer's dilemma coexisting with alarm at the scale of the concealment; status=ambiguous; confidence=0.55

Alternative readings: the council's fear is credible; the council's fear is self-serving

mood trajectory ra2: 2 → 3 → 2; shape=peak; scenes=s2 → s3 → s4; ordinal 0-4

reader_affect ra3 [s4] interpretation: impatience with Tomas's hesitation curdling into anticipation as he deletes the safe report; status=known; confidence=0.65

Alternative readings: sympathy for his procedural instinct; fear that he will choose silence

mood trajectory ra3: 3 → 2 → 4; shape=valley; scenes=s3 → s4 → s5; ordinal 0-4

reader_affect ra4 [s5] interpretation: the release of the broadcast produces a suspended, unresolved affect: relief that the truth is out, held against the absence of any response; status=known; confidence=0.75

Alternative readings: triumph if read as a victory; dread if read as the start of a mutiny

mood trajectory ra4: 2 → 4 → 4; shape=peak; scenes=s4 → s5 → s5; ordinal 0-4

tension t1 [s1, s2, s3, s4, s5] interpretation: tension rises from private doubt to public confrontation; status=known; confidence=0.8

tension trajectory t1: 1 → 3 → 4; shape=rising; scenes=s1 → s3 → s5; ordinal 0-4

tension t2 [s2] interpretation: discovery tightens into complicity as Han's access request forces Tomas to hide his own trail; status=ambiguous; confidence=0.5

Alternative readings: the request is routine and harmless; the request is a test of Tomas's discretion

tension trajectory t2: 1 → 3 → 2; shape=peak; scenes=s1 → s2 → s3; ordinal 0-4

tension t3 [s3] interpretation: the confrontation converts quiet suspicion into an explicit contest of values between two people who both believe they are protecting the passengers; status=known; confidence=0.75

Alternative readings: Mercer is stalling to buy time to contain Tomas

tension trajectory t3: 3 → 4 → 3; shape=peak; scenes=s2 → s3 → s4; ordinal 0-4

tension t4 [s4] interpretation: internal tension: the procedure Tomas has always trusted offers him a way to bury the finding, and drafting the report becomes a test of whether he will take it; status=known; confidence=0.7

Alternative readings: the draft is a genuine attempt to report properly; the draft is a rehearsal for silence

tension trajectory t4: 4 → 2 → 4; shape=valley; scenes=s3 → s4 → s5; ordinal 0-4

tension t5 [s5] interpretation: tension peaks at the moment of transmission and is deliberately left unresolved: the act is complete but its consequence is withheld; status=known; confidence=0.8

Alternative readings: the peak is the confrontation with Mercer before the broadcast; the peak is the broadcast itself

tension trajectory t5: 2 → 4 → 4; shape=peak; scenes=s4 → s5 → s5; ordinal 0-4

themes th-truth [s2, s4, s5] interpretation: truth as a right owed to the governed; status=known; confidence=0.8

themes th-consent [s3, s4, s5] interpretation: consent requires knowing the destination; status=known; confidence=0.8

themes th-trust [s1, s3] interpretation: institutional trust depends on transparent records; status=known; confidence=0.75

themes th-truth-s3 [s3] interpretation: the council's justification reframes concealment as protection, forcing the question of who is competent to decide what passengers may know; status=ambiguous; confidence=0.6

Alternative readings: paternalism is a legitimate duty of the council; withholding the truth is itself a form of harm

themes th-trust-s4 [s4] interpretation: Tomas's trust in procedure is tested against Ildiko's claim that procedure is how the concealment survived; a record kept trustworthy only by those who can edit it is not trustworthy at all; status=known; confidence=0.75

Alternative readings: procedure is neutral and can still carry the truth; procedure is the only protection against chaos

themes th-consent-s5 [s5] interpretation: the broadcast hands the passengers the information consent requires, but the story refuses to certify that consent is now possible; status=ambiguous; confidence=0.6

Alternative readings: disclosure restores the possibility of consent; disclosure only transfers the burden of fear

motifs m-log-audit [s1] interpretation: the navigation log as a trusted record during routine audit; status=known; confidence=0.8

motifs m-log-broadcast [s5] interpretation: the navigation log as a contested record made public; status=known; confidence=0.8

motifs m-sealed-archive [s2] interpretation: the sealed backup archive as a place where official memory is guarded and shaped; status=ambiguous; confidence=0.5

Alternative readings: a neutral vault of procedure; an instrument of concealment

motifs m-charter-s3 [s3] interpretation: the public charter invoked against its own hidden contradiction, becoming a document that indicts the authority that published it; status=known; confidence=0.7

motifs m-draft-report [s4] interpretation: the draft maintenance report as a procedural form that could either carry the truth or bury it, made and unmade in the same shift; status=ambiguous; confidence=0.6

Alternative readings: the report is Tomas's last honest act within the system; the report is a ritual of avoidance he performs before abandoning procedure

motifs m-open-channel [s5] interpretation: the shipwide channel as the inversion of the sealed archive: a place where the record can no longer be edited by its keepers; status=known; confidence=0.75

Alternative readings: the channel is simply a megaphone for one technician; the channel is another instrument the council could reclaim

discourse d1 [s1, s2, s3, s4, s5] interpretation: linear chronological escalation ending on an unresolved beat; status=known; confidence=0.85

discourse d2 [s3] interpretation: the scene withholds the council's reasoning until Mercer speaks, so the reader learns the hazard justification alongside Tomas; status=known; confidence=0.7

discourse d3 [s4] interpretation: the scene slows into private deliberation, staging the draft-and-delete as a visible pause between confrontation and broadcast so the decision reads as chosen rather than forced; status=known; confidence=0.65

Alternative readings: the pause is stalling that weakens momentum; the pause is the story's real turning point

discourse d4 [s5] interpretation: the final scene accelerates through the transmission and then cuts off at the end of the announcement, withholding all reaction and leaving the ending open by design; status=known; confidence=0.8

Alternative readings: the cut is abrupt and reads as truncation; the cut is the story's deliberate final argument

subtext sub1 [s3, s5] interpretation: Mercer's concern for stability may mask the council's fear of losing authority; status=ambiguous; confidence=0.5

Alternative readings: Mercer sincerely fears mutiny; Mercer protects the council's power

subtext sub2 [s2] interpretation: Han's insistence on a routine access code may be a quiet warning that the archive is watched; status=ambiguous; confidence=0.5

Alternative readings: Han is merely following procedure; Han is steering Tomas away from dangerous questions

subtext sub3 [s3] interpretation: Mercer's refusal to threaten Tomas reads as an invitation to share the burden, but may be a calculated appeal to his sense of order; status=ambiguous; confidence=0.5

Alternative readings: she genuinely seeks his judgment; she is managing him with candor

subtext sub4 [s4] interpretation: Ildiko's argument for disclosure may be principled conviction, or may be her own need to be on the right side of a secret she did not choose to learn; status=ambiguous; confidence=0.5

Alternative readings: she speaks from belief in consent; she speaks to resolve her own discomfort

subtext sub5 [s4] interpretation: Tomas's deletion of the draft report reads as a break with procedure, but may also be a final attempt to keep the choice his alone rather than the council's; status=ambiguous; confidence=0.5

Alternative readings: he has decided the system cannot carry the truth; he is still protecting his own control over the outcome

subtext sub6 [s5] interpretation: Tomas's broadcast may be an act of principle or a technician's insistence that a broken record be repaired in the most public way available, and the two motives are indistinguishable in the act; status=ambiguous; confidence=0.5

Alternative readings: he acts for the passengers' right to choose; he acts to restore the record's integrity for its own sake

subtext sub7 [s5] interpretation: Mercer's final appeal may be a last honest attempt to prevent harm, or the reflex of an authority that has run out of arguments; status=ambiguous; confidence=0.5

Alternative readings: she is protecting the passengers from panic; she is protecting the council from accountability

Motif echo me1: m-log-audit → m-log-broadcast (transformation)

Motif echo me2: m-log-audit → m-sealed-archive (transformation)

Motif echo me3: m-sealed-archive → m-charter-s3 (contrast)

Motif echo me4: m-sealed-archive → m-draft-report (transformation)

Motif echo me5: m-draft-report → m-log-broadcast (contrast)

Motif echo me6: m-sealed-archive → m-open-channel (contrast)

Motif echo me7: m-log-audit → m-open-channel (transformation)

human constraint_human_assessment [brief-ending character story]: The truth is announced, and the story ends before anyone knows how the passengers will react.
