The archive was two decks down, behind a door that did not open for maintenance requests. Tomas stood at the counter with his tablet held flat in both hands and recited the clause number before Archivist Han had finished looking up.

"Audit reconciliation, section nine, subsection four. A technician of record may request sealed backup media when a live log fails its own checksum." He kept his voice even. "The live log failed its checksum at 0400 this morning. I'm the technician of record."

Han was old and thin and had the particular stillness of someone who had spent forty years deciding what other people were allowed to remember. He looked at the tablet. He looked at Tomas.

"You could file it as instrument error," Han said. "Most do. It's a quieter form of the same paperwork."

"It isn't instrument error. I checked the instruments twice."

"That's what I mean." Han typed something, and the counter beneath his hands unlocked with a sound like a held breath released. "Nine-four. In future, cite it before I've had my tea. The request will be logged, Technician Okafor. Requests are always logged."

He said it the way a man says look both ways before crossing.

The backup vault was cold and smelled of nothing at all. Tomas pulled the quarterly snapshots back in order — one hundred and twelve of them, four decades of the ship's memory of itself — and laid them side by side in a single wide window, and began to subtract.

The first divergence was small. A vector correction in year eleven, logged as applied, present in the snapshot taken before it and absent in the snapshot taken after. The correction itself was trivial, a nudge of a tenth of a degree. But the log had no record of it being reversed, and yet it was gone.

He found the next one in year twelve. Then year fourteen. Then a cluster around year nineteen.

Each edit was a deletion of a correction, and each deletion moved the ship's true heading a little further from the heading the corrections had been quietly enforcing. Whoever had done this had worked slowly, a few tenths of a degree at a time, and had waited years between some of the strokes — long enough, Tomas understood with a cold spreading through his chest, for the people who might have noticed to rotate off their posts, retire, die.

He built the sum of it in a third window, the way he would have built any other reconciliation: original charter heading, plus every correction that survived, minus every correction that had been erased. The arithmetic took four seconds. He stared at the result for a great deal longer.

The ship was not going where the charter said it was going. It had not been going there for thirty-one years.

Tomas sat very still in the cold, and the vault hummed around him, and he thought about the word *logged*, and about how many times it appeared on the request he had just signed.