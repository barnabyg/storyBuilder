The sealed archive was three decks down, behind a door that had no handle, only a reader. Tomas stood in front of it for a moment with his palms flat against the cold plate, then keyed in his request with the maintenance code he'd carried for four years and never once used.

The door didn't open. A speaker crackled. "It's past shift."

"Archivist Han. It's Tomas Okafor, navigation maintenance. I'm opening a level-three reconciliation on the nav log. Procedure nine-oh-four. I need the cold backups."

A pause. "Nine-oh-four is a fault escalation. You have a fault?"

"I have a checksum that won't reconcile. That's a fault until proven otherwise."

The pause went on longer than it needed to. Tomas watched the little red light above the door and did not let himself wonder what the delay meant. Procedure was procedure. The archive granted access by code and countersignature, and Han was the countersignature, and Han had never in Tomas's experience been anything but exact.

The door slid back. Han stood behind it in a cardigan, holding a mug, looking at him the way archivists looked at technicians who came asking for cold media after shift. "Nine-oh-four," she said, as if tasting it. "You're thorough."

"I try to be."

"Come on, then. Wipe your boots."

The cold room smelled of ozone and old plastic. Han walked him through the racks, pulling the sealed media—thumb-sized wafers in labeled sleeves, each one a year of the ship's memory—and set them in a tray for him. "Sign here," she said, "and here, and the seal stays with me until you're done. If you break a seal before I log it, I'll have your badge."

"Yes, Archivist."

She left him at the reader. The door sighed shut, and he was alone with thirty years of the ship's heading.

He started at the far end, the oldest wafer, and worked forward. The reader was slow; it ground through each year like a man climbing stairs. The navigation log was a dull document, mostly—thrust corrections, mass estimates, the small housekeeping of a ship falling through the dark—and for a while the only thing Tomas found was tedium.

Then he found the first one.

It was a vector correction, dated eleven years back, small enough that it would never have caught his eye on its own: a burn of a few centimeters per second, logged as a trim. But the trim's countersignature didn't match the trim in the backup two years earlier. The earlier record had the same burn, and then a second line, a later amendment—and the amendment had been written by a different hand, in a different format, and it did not appear in the copy he'd just read.

He pulled the next wafer. Then the next.

They were spaced years apart. Each one small. Each one erasing a correction that had, in the original, nudged the ship's heading a fraction of a degree. Alone, any one of them would have read as routine recalibration. Together—

Tomas sat back and did the math twice, because he did not trust the first answer.

The charter, the public charter, the one printed on the wall of every mess hall on the ship, said the *Aletheia* was bound for a star called Kepler-186, four hundred and ninety light-years out, arrival in the second century of the voyage. Every child on the ship could recite it. Tomas had recited it.

But the ship's actual heading, reconstructed from the unedited backups, had been drifting from that line for thirty years. Not toward Kepler-186. Somewhere else. Somewhere the charter did not name.

He looked at the tray of wafers, at the seal he had signed for, and understood that someone had gone to a great deal of trouble to make sure no one ever sat where he was sitting now.

The door behind him hissed. He hadn't heard Han come back.