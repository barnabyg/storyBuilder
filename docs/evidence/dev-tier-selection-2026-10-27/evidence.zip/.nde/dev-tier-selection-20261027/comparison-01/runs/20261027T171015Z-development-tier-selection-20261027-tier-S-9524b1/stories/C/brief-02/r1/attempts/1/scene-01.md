At 22:00, ship time, the night shift changed over in Maintenance Bay Three, and Tomas Okafor began his audit.

He had done it the same way for four years: navigation log first, then the reactor telemetry, then the water reclamation stamps, each checked against the previous cycle's checksums. People drifted through the bay around him, laughing, arguing about the card game in the mess, and he let them drift. People forgot things. People misremembered, rounded, guessed. A record did none of that. A record either reconciled or it didn't, and when it didn't, it told you exactly where to look. He had said as much to Ildiko once, and she had laughed and called him a monk.

The first three checks reconciled. The fourth did not.

It was small — a maintenance stamp on the navigation log, a routine confirmation that the course solution had been verified against the star catalog. The hash came back one digit off from where it should have been. Tomas frowned and reran it. One digit off again, the same digit, in the same place. He pulled his hand terminal's calibration report. Clean. He ran a diagnostic on the bay's reader array. Clean. Which meant the fault was in him, or in his instruments, or in the log itself, and he knew which of those he trusted.

He flagged the stamp and moved on, and found two more before midnight. All on navigation stamps. All the same single-digit drift, spaced irregularly across the past three months, as though someone had been correcting them one at a time and had missed a carry somewhere.

Ildiko came off her shift at 23:40 and leaned on the bench beside him, drinking tea that smelled of burnt sugar. "You're still on the checksums."

"There's a mismatch. Three of them."

"Then write a ticket."

"I did. The ticket says the log is inconsistent with itself and I don't know why."

"So write that." She shrugged. "It's a stamp, Tomas. Stamps get reissued. Somebody fat-fingered a hash two months ago and it propagated. Report it, close it, come eat."

He looked at the three flagged entries on his screen, the identical clean drift of them, patient as a heartbeat. "I don't close tickets I can't explain," he said. "That's the whole point of a ticket."

Ildiko sighed and took her tea away.