The council chamber was smaller than Tomas had imagined, a plain room with a long table and a single viewport showing the slow wheel of stars. Councilor Voss did not offer him a seat. She stood at the head of the table with her hands folded, and when Tomas laid the printouts before her she did not look at them.

"I know what they say," she said. "I've known for a long time that someone would find them."

"Then you know what they are." Tomas kept his voice level. "Forty years of edits. The Meridian changed course and the record was rewritten to hide it. I want to know why."

Voss was quiet for a moment. Then she sat, and the gesture was so tired that it unsettled him more than any denial would have.

"The original destination was a lie," she said. "Not a deliberate one. The survey data was flawed, the models were wrong. When the correction came through, the planet we'd been sailing toward for three generations was a frozen rock with an atmosphere we couldn't breathe. There was nothing there for us."

"So you found another star."

"We found a possibility. It's farther. It's uncertain. But it's something." She met his eyes. "And we decided that telling eight thousand people their whole inheritance had been a mistake would break them. The ship is a sealed world, Tomas. Despair spreads faster than any plague. So we made the record consistent. We gave them a course they could believe in."

"You falsified the logs."

"I protected the voyage."

She leaned forward, and her voice dropped. "You will keep this to yourself. That is not a request. The greater good is not a phrase I use lightly, but it is the only thing holding this ship together. You found a crack. I'm asking you to leave it sealed."