The night shift on Verdance was quiet in the way a held breath is quiet. Tomas Okafor liked it that way. At 22:00, when the day crew's chatter had drained out of the corridors and the ship's lighting dimmed to its sleeping amber, he sat down at his station in the records bay and began his audit.

He began every night the same way: a full sweep of the maintenance logs, node by node, cross-checking each entry against its checksum. It was tedious work, and he knew that most of the technicians skimmed it. He didn't. The logs were the ship's memory, and a ship that forgot itself was just a hull full of strangers drifting in the dark. People forgot things. Records did not. That was the whole point of them.

The sweep ran green through the environmental systems, the hydroponics bays, the water reclamation stacks. Then it hit Navigation.

One maintenance stamp, dated 61 years back, failed its checksum. Tomas frowned and flagged it. A single bad stamp could be a corrupted sector, a cosmic ray strike, ordinary decay. He expected four more like it, scattered at random.

Instead the sweep found another, eleven days after the first. Then another, seven weeks later. Then a cluster of nine. All of them maintenance stamps on the navigation log, all of them failing by the same margin.

He ran the cross-check again. Same result. He ran it a third time, and the third time he found himself leaning back, staring at the amber-lit numbers as though they had personally lied to him.

"You're still here," Ildiko said from the doorway, her shift bag over one shoulder. She had the easy, unbothered air of someone who finished her tasks and left them finished.

"Checksum mismatch," Tomas said. "Recurring. Same delta every time."

"Bad sector?"

"Sixty-one years of bad sectors that all fail the same way? That's not decay. That's a pattern." He pulled the offending stamps onto the main display so she could see the neat, terrible regularity of them.

Ildiko looked for a moment longer than was polite. "Or it's a quirk in the audit tool. You know the old navigation firmware was patched a dozen times. Report it to Systems, let them close it out, come to breakfast."

"I can't close a ticket I can't explain."

"You can't explain half the things you close."

"I close them when the explanation is boring," Tomas said. "This one isn't boring yet."

Ildiko sighed, hitched her bag higher, and left him to it. The door sighed shut behind her. Tomas turned back to the screen, where the mismatches sat in their patient row, and began, very carefully, to pull the older backups.

The sealed archive was three decks down, behind a door that had no handle, only a reader. Tomas stood in front of it for a moment with his palms flat against the cold plate, then keyed in his request with the maintenance code he'd carried for four years and never once used.

The door didn't open. A speaker crackled. "It's past shift."

"Archivist Han. It's Tomas Okafor, navigation maintenance. I'm opening a level-three reconciliation on the nav log. Procedure nine-oh-four. I need the cold backups."

A pause. "Nine-oh-four is a fault escalation. You have a fault?"

"I have a checksum that won't reconcile. That's a fault until proven otherwise."

The pause went on longer than it needed to. Tomas watched the little red light above the door and did not let himself wonder what the delay meant. Procedure was procedure. The archive granted access by code and countersignature, and Han was the countersignature, and Han had never in Tomas's experience been anything but exact.

The door slid back. Han stood behind it in a cardigan, holding a mug, looking at him the way archivists looked at technicians who came asking for cold media after shift. "Nine-oh-four," she said, as if tasting it. "You're thorough."

"I try to be."

"Come on, then. Wipe your boots."

The cold room smelled of ozone and old plastic. Han walked him through the racks, pulling the sealed media—thumb-sized wafers in labeled sleeves, each one a year of the ship's memory—and set them in a tray for him. "Sign here," she said, "and here, and the seal stays with me until you're done. If you break a seal before I log it, I'll have your badge."

"Yes, Archivist."

She left him at the reader. The door sighed shut, and he was alone with thirty years of the ship's heading.

He started at the far end, the oldest wafer, and worked forward. The reader was slow; it ground through each year like a man climbing stairs. The navigation log was a dull document, mostly—thrust corrections, mass estimates, the small housekeeping of a ship falling through the dark—and for a while the only thing Tomas found was tedium.

Then he found the first one.

It was a vector correction, dated eleven years back, small enough that it would never have caught his eye on its own: a burn of a few centimeters per second, logged as a trim. But the trim's countersignature didn't match the trim in the backup two years earlier. The earlier record had the same burn, and then a second line, a later amendment—and the amendment had been written by a different hand, in a different format, and it did not appear in the copy he'd just read.

He pulled the next wafer. Then the next.

They were spaced years apart. Each one small. Each one erasing a correction that had, in the original, nudged the ship's heading a fraction of a degree. Alone, any one of them would have read as routine recalibration. Together—

Tomas sat back and did the math twice, because he did not trust the first answer.

The charter, the public charter, the one printed on the wall of every mess hall on the ship, said the Aletheia was bound for a star called Kepler-186, four hundred and ninety light-years out, arrival in the second century of the voyage. Every child on the ship could recite it. Tomas had recited it.

But the ship's actual heading, reconstructed from the unedited backups, had been drifting from that line for thirty years. Not toward Kepler-186. Somewhere else. Somewhere the charter did not name.

He looked at the tray of wafers, at the seal he had signed for, and understood that someone had gone to a great deal of trouble to make sure no one ever sat where he was sitting now.

The door behind him hissed. He hadn't heard Han come back.

Han stood in the doorway with his kit bag still over his shoulder, and Tomas realized he had been talking to himself, or to the screens, for some minutes.

"Don't," Tomas said. "Whatever you're going to say."

Han set the bag down slowly. "I wasn't going to say anything."

"Good." Tomas pulled the backups off the display, one by one, and stacked them in his head like plates. Forty years of tiny corrections. A heading nudged by a quarter degree, then a quarter more, each edit logged as a routine recalibration, each one signed off by a name he had been taught to trust. "I need to see Mercer."

Han didn't stop him. That was the strange part. Han just watched him go, and Tomas understood, walking the long corridor to the council deck, that Han had known, or guessed, and had decided not to be the one who said it aloud.

Mercer's office was small and warm, crowded with paper she still insisted on keeping. She looked up from her desk as he came in, and her face did something complicated and then settled.

"You found it," she said. Not a question.

"Forty years of edits. The charter says we're bound for Kepler-186. The log says otherwise."

"Sit down, Tomas."

"I'd rather stand."

"That's fine." She folded her hands. "Yes. The council authorized every one of those edits. It began long before me. I've signed my share." She said it plainly, the way she might confirm a shipment of filters. No denial, no threat, no reaching for a comm. It unsettled him more than either would have. "Ask me why."

"Why?"

"The original course," she said, "ran us toward something the founders knew about and chose not to put in the charter. A debris field, a radiation front—the records are partial. What's clear is that they judged the passengers couldn't be told, and they turned us. Quietly. And every council since has kept the turn quiet, because the moment it surfaces, the question isn't the hazard anymore. It's who decided."

Tomas gripped the edge of her desk. "That's not a reason. That's a confession with a preface."

"It's both." Mercer's voice stayed level. "I'm not going to threaten you, Tomas. I'm going to ask you to hold two things at once. Forty thousand people are asleep, or born into a ship they call a promise. Stability is not nothing. It's the only thing keeping the corridors walkable." She paused. "And then there's the truth they never consented to receive. Weigh them. I'd like to know which way you tip."

He looked at her hands, still folded, and understood she genuinely wanted an answer, and that this was somehow the worst thing she had done all morning.

Ildiko found him in the maintenance bay after shift change, when the corridors had emptied and the only sound was the low hum of the scrubbers. He had the unedited log open on the bench display, the course change plotted in patient amber lines.

"You told Mercer," she said. It wasn't a question; the councilor's aide had already been through the deck asking quiet questions.

"I told her I knew."

Ildiko pulled a stool over and sat. She looked at the plot for a long moment, then at him. "Then you know what I think. They've been steering us for forty years and never once asked. My grandmother died believing she'd see the colony. She died in a corridor like this one, and nobody told her she was going somewhere else." She tapped the display. "People deserve to know where they're going. Even if it's bad. Maybe especially then."

He wanted to argue that she didn't understand the hazard, the founders' reasoning, the careful arithmetic of panic. But she was a shift-mate who had covered for him twice this year, and she was not wrong.

After she left, he opened a report form. Navigation Log Discrepancy — Maintenance, Tier 3. He typed the checksum failure, the reconstructed backups, the edit history spanning forty-one years. The form asked him to route it to his section chief, who would route it to Records, who would route it to the council. He stared at the routing field for a long time, then deleted the draft. He opened it again and wrote a shorter version, then deleted that too. Each version was a way of handing the problem upward, and each version would end in the same place: a sealed review, a quiet reassignment, a note in his file. Procedure was how the edits had survived. Procedure was a corridor with no windows.

He thought of his own logbooks, the ones he kept in pencil because he trusted them more than the terminals. A record you couldn't trust wasn't a record. It was a story someone told you and asked you not to check. He would rather have the unsettling truth than a clean file that lied — and if the passengers felt differently, that would be their choice to make, not Mercer's.

He saved the unedited log to a transfer chit, pocketed it, and went to find the broadcast desk.

The broadcast desk was a narrow alcove off the maintenance ring, little more than a console and a stool, and Mercer was already there when he arrived. She had come alone. No security, no aides, just the gray coat and the tired face of a woman who had run out of rooms to lock.

"Tomas." She didn't raise her voice. "The council is meeting in an hour. Give me the chit, and I will put the log before them myself. Full disclosure, my recommendation attached. That is the process working."

"The process has been editing the log for thirty years," Tomas said.

"You're right. Which is why it has to be fixed from inside, by people who know what the fix costs. If you push this out raw, you don't get a hearing. You get a panic. You get people deciding the council lied about everything, including the hull, including the air. You know what happens when a ship's complement stops trusting the people who keep it alive."

"I know what happens when the record can't be trusted," Tomas said. "Everything else follows from that."

Mercer's hand rested on the console edge, close to the cutoff. "The original course ran toward something the founders didn't put in the charter. They chose to turn. Every council since has chosen to keep turning. You can call that a lie. I call it thirty years of nobody dying."

"Then say it out loud," Tomas said. "All of it. If it's that defensible, it will survive being heard."

She looked at him for a long moment, and something in her expression closed, the way a hatch closes.

"I can't let you do this," she said, and reached for the console.

Tomas had already keyed the chit into the auxiliary port. The maintenance override was his by assignment, the one credential no councilor had ever thought worth revoking from a junior technician, and the shipwide channel accepted it without argument. Mercer's hand found the cutoff a half-second too late; the channel was live and locked, and the log began to stream.

"This is Tomas Okafor, maintenance, deck four," he said, and his voice came back to him from the corridor speakers, flat and strange. "What follows is the unedited navigation log of the ship, authenticated against the sealed archive. The ship is not on the course the charter states. It changed course thirty-one years ago, and every council since has ordered the log edited to conceal it. The original destination was judged hazardous by the founders. That judgment was never published. I am publishing it now."

He let the log run. Checksums, timestamps, the long quiet chain of revisions, the course vectors before and after. It took four minutes. Mercer stood with her hand still on the dead cutoff and did not move.

The log ended. Tomas keyed the closing line.

"This is the record as it was kept. It is yours now."

He released the channel. The console light went from red to amber, and the corridor speakers clicked off into silence, and the silence went on, and on, and nothing in it told him what came next.