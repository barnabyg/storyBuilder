The archive smelled of ozone and old plastic. Han's office was a converted storage bay, narrow and cold, its walls lined with racks of sealed media in gray cases.

"You want the navigation backups," Han said. He did not look up from his terminal. "Sealed means sealed, Okafor."

"Under maintenance protocol seven-four," Tomas said, "a log discrepancy exceeding zero-point-zero one percent entitles a certified technician to unsealed read access for reconciliation purposes." He had the citation ready on his tablet. He had rehearsed the sentence twice. "The discrepancy is four percent."

Han was quiet a moment, then took the tablet and read the protocol line by line, the way Tomas liked him for. "Four percent," he said at last. "That's not drift."

"No."

Han keyed in a release code and slid a drawer open. Inside were six chipped polymer discs, each labeled with a decade. "You sign them out one at a time," Han said. "You read them here. Nothing leaves this room."

Tomas took the oldest disc and sat at the reading terminal.

The comparison took him three hours. He wrote a script to align each backup against the next, vector by vector, and set it to flag every difference. The first flags came back small, a fraction of a degree. That was normal; course corrections were logged constantly, tiny nudges to hold the trajectory.

Then he noticed the shape of the edits. They were not corrections. They were removals. Each disc showed a logged vector correction—and the next disc, years later, showed the same correction quietly absent, replaced by a clean line of nominal heading. The timestamps had been rewritten to match. Whoever had done it had been patient. One edit every three or four years, each one covering the one before.

Tomas ran the chain backward, disc by disc, and plotted the headings as they had actually been flown. The line bent away from the charter heading in the very first decade and never bent back. He checked the public charter, the one printed on the wall of every passenger deck, the one children memorized in school. The ship was bound for Kepler's Reach, the charter said, and had been on course from the day of departure.

It had not. For forty years the ship had been flying somewhere else, and the record had been telling everyone otherwise.

Tomas sat very still in the cold room. He had trusted records the way other people trusted their families. A record did not lie to spare your feelings. A record did not have reasons. Somewhere behind him, the terminal hummed, waiting for him to decide what to do next.