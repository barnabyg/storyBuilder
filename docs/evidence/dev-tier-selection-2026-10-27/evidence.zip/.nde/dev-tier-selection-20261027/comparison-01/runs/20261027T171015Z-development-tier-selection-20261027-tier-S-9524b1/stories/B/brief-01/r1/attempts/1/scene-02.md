In the morning she climbed the tower as she always did, though there was no light to tend and no ships to guide. The habit outlasted the job. From the gallery she could see the whole harbour laid out below her, the wharf and the boats and the road curving up past the chapel, and she was high enough that the wind took the edge off the sun.

A city car she didn't know sat at the end of the wharf, grey and clean, and Eli stood at its open window with his hands in his pockets, leaning down to talk to whoever was inside. The wind carried most of it away, but it carried some. She heard *total loss* and then, after a pause, *the surveyor won't ask questions.*

She came down the stairs slowly, one hand on the rail, and crossed the wharf as though she were only going about her morning. Eli turned when he heard her boots on the boards. His face did something quick and badly managed.

"Ada. Morning."

"Morning."

"This is my cousin," he said. "From Plymouth. Just passing through."

The man in the car lifted two fingers from the wheel and didn't smile. Eli's hands had come out of his pockets and they shook, small and steady, the way a man shakes when he's been holding something in too long.

She left them to it and went into the shed for the tide tables, because the tide was what she'd come for. The book lay open on the bench where Eli had been reading it, and there, pencilled in the margin against a date, was a small cross. The new moon. The night the reef off Gull Point would be at its shallowest.

She closed the book on the mark and took it with her.