# The Quiet Course

Plan plan-brief-02; schema 1; tier S

Character tomas: Tomas Okafor

Character mercer: Councilor Mercer

Character ildiko: Ildiko Reyes

Character han: Archivist Han

## s1: Routine Audit

Tomas runs a routine maintenance cross-check on the navigation log and finds a checksum that does not reconcile; he treats it as a fault in his own instruments.

Present: tomas, ildiko

Beat s1-b1: Tomas's meticulous nightly audit routine establishes his trust in records over people.

Beat s1-b2: A recurring checksum mismatch appears in the navigation log's maintenance stamps.

Beat s1-b3: Ildiko, a shift-mate, suggests he report it and move on; Tomas refuses to close a ticket he cannot explain.

## s2: The Deleted Decade

Tomas reconstructs older log backups and discovers decades of small, careful edits that together conceal a course change.

Present: tomas, han

Beat s2-b1: Archivist Han grants Tomas access to sealed backup media after he cites procedure.

Beat s2-b2: Comparing backups, Tomas finds edits spaced years apart, each erasing a small vector correction.

Beat s2-b3: He realizes the ship has been on a different heading than the public charter states for decades.

## s3: The Council's Reason

Tomas confronts Councilor Mercer, who admits the council ordered the edits and argues the truth would trigger a mutiny.

Present: tomas, mercer

Beat s3-b1: Mercer neither denies nor threatens; she confirms the edits were authorized.

Beat s3-b2: She explains the original course led toward a hazard the founders hid from passengers.

Beat s3-b3: Mercer asks Tomas to weigh stability against a truth the passengers never consented to receive.

## s4: Weighing the Records

Tomas wrestles with the council's argument, testing it against his own belief that records exist to be trusted.

Present: tomas, ildiko

Beat s4-b1: Ildiko argues the passengers deserve to know where they are going.

Beat s4-b2: Tomas drafts and deletes a report, torn between order and consent.

Beat s4-b3: He decides that a record he cannot trust is worse than a truth that unsettles.

## s5: The Open Channel

Tomas broadcasts the unedited log to the whole ship; the story ends as the announcement finishes, before any reaction.

Present: tomas, mercer, ildiko

Beat s5-b1: Tomas routes the full log through the shipwide channel despite Mercer's final appeal.

Beat s5-b2: The truth is announced: the ship changed course, and the council hid it.

Beat s5-b3: The narration cuts off at the end of the announcement, leaving the passengers' response unknown.
