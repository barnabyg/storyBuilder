Ildiko found him in the maintenance bay an hour later, still in his coveralls, the screens arranged around him like a jury. She set down her toolkit and read the discrepancy summary over his shoulder without asking permission, because they had shared a shift for four years and permission had stopped being necessary.

"You told Mercer," she said.

"I told Mercer."

"And?"

Tomas pulled up the overlay—the old course, the new one, the decades of small excisions that had bent one into the other. "He says the founders' route ran into something. He wouldn't tell me what. He says the council has kept the ship steady for a hundred years and that if I put this on the public feed, people will tear the council apart and then tear each other apart, and nobody will be left to fly anything."

Ildiko was quiet for a moment. Then she tapped the screen, at the tiny notation that marked the ship's heading. "Where are we going, Tomas? Do you know? Do *they* know? Because I've spent my whole life on this deck, and I just found out I don't know where my own home is pointed." She straightened. "They deserve to know. Everyone down there in the rings, everyone in the nursery decks—they get to know where they're going. That's not mutiny. That's the only thing that makes the rest of it mean anything."

He opened the reporting utility. The form was familiar to the point of boredom—fault class, subsystem, severity, recommended action. He typed the summary: *Navigation log checksum discrepancy, root cause unresolved, possible long-term record alteration.* He looked at it. It was true, and it was careful, and it would travel up the proper channels to a council that already knew every word of it. It would be filed, and closed, and buried so deep the next auditor would need a decade to dig it out. He deleted it. Typed it again. Deleted it again. His finger hovered over the submit key, and the argument ran in his head in Mercer's flat voice: *someone has to hold the wheel.*

But a record you could not trust was worse than no record at all. It was a promise made in someone else's voice. He thought of his father, who had taught him the logs before he taught him the names of the stars, and of the charter's third section, printed on every deck: *The passengers of this vessel are entitled to a true account of its voyage.* Section three had never been amended. It had only been quietly contradicted.

He closed the reporting utility. Then he opened the public address console, and Ildiko watched him do it without a word, her hand flat on the desk beside his.