The kitchen smelled of wet wool and yesterday's coffee. Ada laid the page on the table and smoothed it flat with the heel of her hand. The tide-table, the night's run of tide inked in, the reef marked in her own careful pencil.

Eli looked at it. He didn't touch it.

The back door opened and Ruth came in with a colander of beans, her hands still damp from the garden. She stopped when she saw the page, and then she sat down slowly, as though her knees had given out, and set the colander on the floor beside her chair.

"The bank's given us thirty days," she said. "On the house."

Eli pushed his cup away. "It'll run aground on the reef," he said, quiet, almost gentle. "The insurer pays out. Nobody's on her, nobody gets hurt. That's all it is, Ada. A boat going on the rocks the way boats do." He looked at her. "Say nothing. That's all I'm asking."

Ada stood a moment. Then she went out through the back door, past the beans, down the path.

At the gate, Ruth caught her sleeve. "I'm sorry about Tom's boat," she said.