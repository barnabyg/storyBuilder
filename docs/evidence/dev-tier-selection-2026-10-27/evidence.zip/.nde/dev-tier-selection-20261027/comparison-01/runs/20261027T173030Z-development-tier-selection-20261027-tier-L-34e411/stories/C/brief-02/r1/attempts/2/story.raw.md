Every night at 22:00, ship time, Tomas Okafor audited the records. It was not in his job description, exactly. The maintenance manual asked for weekly spot-checks, and most technicians did them on the last shift of the week, tired and fast, signing off whatever looked close enough. Tomas did his nightly, alone, with the door of the maintenance pod shut, because records were the one thing on the Tarrantine that did not lie. People forgot things. People misremembered, people cut corners and covered for each other, but a log entry was either true or it was not, and the checksums would tell you which.

He worked down the list in the same order every night: life support, then water reclamation, then power distribution, then the navigation log's maintenance stamps. Each subsystem reported its own hash, and the ship's audit ledger kept the running fingerprint of every entry ever written to it. Tonight he traced the columns with his finger, the way his first supervisor had taught him, as if touching the numbers kept you honest.

Life support reconciled. Water reconciled. Power reconciled.

Navigation did not.

The mismatch was small. One maintenance stamp, logged at 03:14 on day 8,402, whose hash did not match the ledger's fingerprint for that entry. Tomas frowned and reran it. Same result. He reran it through the secondary terminal, then through the spare handheld he kept in his drawer for exactly this reason, and each time the numbers came back identical, which meant the fault was not in his instruments.

He pulled the stamp. It was a routine hull-sensor calibration, signed by a technician named Bayo, with a note that read nominal, no correction required. Nothing about it should have been interesting.

He checked yesterday's audit, and the day before's. The same stamp had thrown the same mismatch both times, and he had missed it, both times, because he had been checking the reconciliation summary and the summary had said pass.

"Problem?" Ildiko said from the doorway. She had her jacket half on, on her way out.

"Checksum on a nav stamp. Doesn't reconcile."

She came over and looked at the screen, not closely. "Old entry?"

"Nineteen years old."

"Then it's a legacy hash. They changed the algorithm back when, remember? Half the old stamps don't reconcile if you run them forward." She yawned. "Flag it, log it, let the day shift sort it out. You'll drive yourself mad otherwise."

Tomas shook his head slowly. "I can't close a ticket I can't explain. If it's the algorithm, I should be able to show that. If it's not—"

"Tomas."

"—then something's wrong with the stamp."

Ildiko looked at him for a moment, then shrugged her jacket straight. "It's a number in a machine," she said. "Good night."

The door hissed shut behind her. Tomas turned back to the screen and opened a second window beside the first, and began, very carefully, to compare the entry against the ledger's own record of itself.

The archive was two decks down, behind a door that did not open for maintenance requests. Tomas stood at the counter with his tablet held flat in both hands and recited the clause number before Archivist Han had finished looking up.

"Audit reconciliation, section nine, subsection four. A technician of record may request sealed backup media when a live log fails its own checksum." He kept his voice even. "The live log failed its checksum at 0400 this morning. I'm the technician of record."

Han was old and thin and had the particular stillness of someone who had spent forty years deciding what other people were allowed to remember. He looked at the tablet. He looked at Tomas.

"You could file it as instrument error," Han said. "Most do. It's a quieter form of the same paperwork."

"It isn't instrument error. I checked the instruments twice."

"That's what I mean." Han typed something, and the counter beneath his hands unlocked with a sound like a held breath released. "Nine-four. In future, cite it before I've had my tea. The request will be logged, Technician Okafor. Requests are always logged."

He said it the way a man says look both ways before crossing.

The backup vault was cold and smelled of nothing at all. Tomas pulled the quarterly snapshots back in order — one hundred and twelve of them, four decades of the ship's memory of itself — and laid them side by side in a single wide window, and began to subtract.

The first divergence was small. A vector correction in year eleven, logged as applied, present in the snapshot taken before it and absent in the snapshot taken after. The correction itself was trivial, a nudge of a tenth of a degree. But the log had no record of it being reversed, and yet it was gone.

He found the next one in year twelve. Then year fourteen. Then a cluster around year nineteen.

Each edit was a deletion of a correction, and each deletion moved the ship's true heading a little further from the heading the corrections had been quietly enforcing. Whoever had done this had worked slowly, a few tenths of a degree at a time, and had waited years between some of the strokes — long enough, Tomas understood with a cold spreading through his chest, for the people who might have noticed to rotate off their posts, retire, die.

He built the sum of it in a third window, the way he would have built any other reconciliation: original charter heading, plus every correction that survived, minus every correction that had been erased. The arithmetic took four seconds. He stared at the result for a great deal longer.

The ship was not going where the charter said it was going. It had not been going there for thirty-one years.

Tomas sat very still in the cold, and the vault hummed around him, and he thought about the word logged, and about how many times it appeared on the request he had just signed.

Mercer's office was small and warm, and she did not look surprised to see him. She set down her tea, folded her hands on the desk, and listened while he laid it out—the checksum, the backups, the decades of small amendments that added up to a ship pointed somewhere other than where the charter said it was going.

When he finished, she said, "Yes."

Tomas had prepared for denial. He had prepared for anger, for procedure, for being told he had exceeded his clearance. He had not prepared for yes.

"Say that again," he said.

"The edits were authorized. By this council, and the ones before it." She turned her cup a quarter turn, aligning it with the edge of the desk. "You're the first person in thirty years to find them. I'd hoped the checksums would hold."

"You hoped—" He stopped. "Councilor, the charter is posted in every corridor. It gives a heading. It gives a destination. That heading is a lie."

"The charter gives the heading we chose." Mercer's voice stayed level. "Tomas, sit down. Please. You've been in the vault a long time."

He did not sit. She went on anyway.

"The founders knew what was on the original line. A debris field, a swath of it, wide enough that threading it would have cost the ship more than we could spare. They ran the numbers and they knew the passengers would not vote to go around it—not if it meant adding years, not if it meant arriving to a world their grandchildren would have to be old to see. So they went around it, and they did not tell anyone. The first edits were theirs."

"And you inherited them."

"We inherited them." She looked at him steadily. "And we kept them, because the founders were right about what people do when you take away the thing they were promised."

"You don't know that."

"No. I know that stability is the only thing keeping eleven thousand people from turning on each other in a sealed hull." She leaned back. "You trust records. I understand that; I chose you for maintenance because you trust records. So here is the record, Tomas, honestly, from me: I am asking you to weigh a quiet ship against a truth the passengers never consented to receive. Not because I think they're children. Because I think they're people, and people are frightened, and frightened people in a closed space do damage that takes generations to repair."

"And if they'd wanted to choose?"

"Then they should have been asked a hundred years ago by people who are long dead." Mercer's hands stayed folded. "We're the ones left holding it. What do you want me to do with it?"

Ildiko found him in the maintenance bay an hour later, still in his coveralls, the screens arranged around him like a jury. She set down her toolkit and read the discrepancy summary over his shoulder without asking permission, because they had shared a shift for four years and permission had stopped being necessary.

"You told Mercer," she said.

"I told Mercer."

"And?"

Tomas pulled up the overlay—the old course, the new one, the decades of small excisions that had bent one into the other. "He says the founders' route ran into something. He wouldn't tell me what. He says the council has kept the ship steady for a hundred years and that if I put this on the public feed, people will tear the council apart and then tear each other apart, and nobody will be left to fly anything."

Ildiko was quiet for a moment. Then she tapped the screen, at the tiny notation that marked the ship's heading. "Where are we going, Tomas? Do you know? Do they know? Because I've spent my whole life on this deck, and I just found out I don't know where my own home is pointed." She straightened. "They deserve to know. Everyone down there in the rings, everyone in the nursery decks—they get to know where they're going. That's not mutiny. That's the only thing that makes the rest of it mean anything."

He opened the reporting utility. The form was familiar to the point of boredom—fault class, subsystem, severity, recommended action. He typed the summary: Navigation log checksum discrepancy, root cause unresolved, possible long-term record alteration. He looked at it. It was true, and it was careful, and it would travel up the proper channels to a council that already knew every word of it. It would be filed, and closed, and buried so deep the next auditor would need a decade to dig it out. He deleted it. Typed it again. Deleted it again. His finger hovered over the submit key, and the argument ran in his head in Mercer's flat voice: someone has to hold the wheel.

But a record you could not trust was worse than no record at all. It was a promise made in someone else's voice. He thought of his father, who had taught him the logs before he taught him the names of the stars, and of the charter's third section, printed on every deck: The passengers of this vessel are entitled to a true account of its voyage. Section three had never been amended. It had only been quietly contradicted.

He closed the reporting utility. Then he opened the public address console, and Ildiko watched him do it without a word, her hand flat on the desk beside his.

The console asked for an authorization code, and Tomas typed his. It asked for a second, and he typed that too. Somewhere in the council offices an alarm would be lighting up, a technician's credentials reaching for a channel they were never meant to touch.

Mercer's voice came through the desk speaker, tight and hurried. "Tomas. The channel opens in forty seconds. You can still stop this. Whatever you think you're doing, there are eleven thousand people asleep in the rings who will wake up to a changed sky and no way to—"

"I know what they'll wake up to," Tomas said. "That's the point."

"Listen to me. We have four generations of—"

He pressed the key that dropped her from the line. Ildiko's hand was still flat on the desk, and he saw her knuckles go pale, but she didn't pull it back.

The channel opened.

"All decks," he said. His voice filled the maintenance bay and, he knew, the mess halls and the corridors and the quiet cabins where people were eating or mending clothes or arguing about nothing at all. "This is Technician Tomas Okafor, navigation maintenance. I'm reading you the ship's log. The unedited one."

He read it. Not the whole thing—nobody could read fifty years aloud—but the shape of it: the course the founders had charted, the hazard the council had found waiting there, the turn the ship had made in the dark, and the decades of quiet revisions that had kept the turn out of every public record. He read the dates. He read the names of the technicians who had made the edits, his own predecessor among them, and then the names of the councilors who had ordered it.

"The ship is not going where you were told," he said. "It has not been going there for sixty-one years. I don't know what should be done about that. But it isn't my decision, and it was never theirs to make alone."

He paused. The channel waited, open and empty, and he could hear the soft hiss of a hundred speakers holding the silence with him.

"That's the log," he said. "That's all of it."