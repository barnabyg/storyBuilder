Every night at 22:00, ship time, Tomas Okafor audited the records. It was not in his job description, exactly. The maintenance manual asked for weekly spot-checks, and most technicians did them on the last shift of the week, tired and fast, signing off whatever looked close enough. Tomas did his nightly, alone, with the door of the maintenance pod shut, because records were the one thing on the *Tarrantine* that did not lie. People forgot things. People misremembered, people cut corners and covered for each other, but a log entry was either true or it was not, and the checksums would tell you which.

He worked down the list in the same order every night: life support, then water reclamation, then power distribution, then the navigation log's maintenance stamps. Each subsystem reported its own hash, and the ship's audit ledger kept the running fingerprint of every entry ever written to it. Tonight he traced the columns with his finger, the way his first supervisor had taught him, as if touching the numbers kept you honest.

Life support reconciled. Water reconciled. Power reconciled.

Navigation did not.

The mismatch was small. One maintenance stamp, logged at 03:14 on day 8,402, whose hash did not match the ledger's fingerprint for that entry. Tomas frowned and reran it. Same result. He reran it through the secondary terminal, then through the spare handheld he kept in his drawer for exactly this reason, and each time the numbers came back identical, which meant the fault was not in his instruments.

He pulled the stamp. It was a routine hull-sensor calibration, signed by a technician named Bayo, with a note that read *nominal, no correction required*. Nothing about it should have been interesting.

He checked yesterday's audit, and the day before's. The same stamp had thrown the same mismatch both times, and he had missed it, both times, because he had been checking the reconciliation summary and the summary had said *pass*.

"Problem?" Ildiko said from the doorway. She had her jacket half on, on her way out.

"Checksum on a nav stamp. Doesn't reconcile."

She came over and looked at the screen, not closely. "Old entry?"

"Nineteen years old."

"Then it's a legacy hash. They changed the algorithm back when, remember? Half the old stamps don't reconcile if you run them forward." She yawned. "Flag it, log it, let the day shift sort it out. You'll drive yourself mad otherwise."

Tomas shook his head slowly. "I can't close a ticket I can't explain. If it's the algorithm, I should be able to show that. If it's not—"

"Tomas."

"—then something's wrong with the stamp."

Ildiko looked at him for a moment, then shrugged her jacket straight. "It's a number in a machine," she said. "Good night."

The door hissed shut behind her. Tomas turned back to the screen and opened a second window beside the first, and began, very carefully, to compare the entry against the ledger's own record of itself.