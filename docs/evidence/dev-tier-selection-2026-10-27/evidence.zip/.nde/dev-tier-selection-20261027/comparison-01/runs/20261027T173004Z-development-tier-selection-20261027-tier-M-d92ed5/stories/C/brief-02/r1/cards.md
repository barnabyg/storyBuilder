# The Quiet Course

Plan plan-brief-02; schema 1; tier M

Character tomas: Tomas Okafor

Character mercer: Councilor Mercer

Character ildiko: Ildiko Reyes

Character han: Archivist Han

## s1: Routine Audit

Tomas runs a routine maintenance cross-check on the navigation log and finds a checksum that does not reconcile; he treats it as a fault in his own instruments.

Present: tomas, ildiko

Beat s1-b1: Tomas's meticulous nightly audit routine establishes his trust in records over people.

Beat s1-b2: A recurring checksum mismatch appears in the navigation log's maintenance stamps.

Beat s1-b3: Ildiko, a shift-mate, suggests he report it and move on; Tomas refuses to close a ticket he cannot explain.

Fact kf-edits: The navigation log has been edited for decades to hide a course change.; initial holders: mercer

Fact kf-hazard: The original course led toward a hazard the founders concealed.; initial holders: mercer

Causal c1: earlier cause s1 → effect s2

Setup setup-checksum at s1: The recurring checksum mismatch that first draws Tomas's suspicion.

Setup setup-charter at s1: The public charter stating the ship's official heading, later contradicted by backups.

## s2: The Deleted Decade

Tomas reconstructs older log backups and discovers decades of small, careful edits that together conceal a course change.

Present: tomas, han

Beat s2-b1: Archivist Han grants Tomas access to sealed backup media after he cites procedure.

Beat s2-b2: Comparing backups, Tomas finds edits spaced years apart, each erasing a small vector correction.

Beat s2-b3: He realizes the ship has been on a different heading than the public charter states for decades.

Causal c1: earlier cause s1 → effect s2

Causal c2: earlier cause s2 → effect s3

Payoff p1: setup setup-checksum → payoff at s2

Reveal r1: fact kf-edits at s2; holders: tomas (acquired at scene start)

## s3: The Council's Reason

Tomas confronts Councilor Mercer, who admits the council ordered the edits and argues the truth would trigger a mutiny.

Present: tomas, mercer

Beat s3-b1: Mercer neither denies nor threatens; she confirms the edits were authorized.

Beat s3-b2: She explains the original course led toward a hazard the founders hid from passengers.

Beat s3-b3: Mercer asks Tomas to weigh stability against a truth the passengers never consented to receive.

Causal c2: earlier cause s2 → effect s3

Causal c3: earlier cause s3 → effect s4

Setup setup-mercer-appeal at s3: Mercer's argument that truth would cause mutiny, revisited in the final scene.

Payoff p2: setup setup-charter → payoff at s3

Reveal r2: fact kf-hazard at s3; holders: tomas (acquired at scene start)

Knowledge use ku1: mercer uses fact kf-edits at s3

Knowledge use ku2: mercer uses fact kf-hazard at s3

## s4: Weighing the Records

Tomas wrestles with the council's argument, testing it against his own belief that records exist to be trusted.

Present: tomas, ildiko

Beat s4-b1: Ildiko argues the passengers deserve to know where they are going.

Beat s4-b2: Tomas drafts and deletes a report, torn between order and consent.

Beat s4-b3: He decides that a record he cannot trust is worse than a truth that unsettles.

Causal c3: earlier cause s3 → effect s4

Causal c4: earlier cause s4 → effect s5

Knowledge use ku3: tomas uses fact kf-edits at s4

Knowledge use ku4: tomas uses fact kf-hazard at s4

## s5: The Open Channel

Tomas broadcasts the unedited log to the whole ship; the story ends as the announcement finishes, before any reaction.

Present: tomas, mercer, ildiko

Beat s5-b1: Tomas routes the full log through the shipwide channel despite Mercer's final appeal.

Beat s5-b2: The truth is announced: the ship changed course, and the council hid it.

Beat s5-b3: The narration cuts off at the end of the announcement, leaving the passengers' response unknown.

Causal c4: earlier cause s4 → effect s5

Payoff p3: setup setup-mercer-appeal → payoff at s5

Reveal r3: fact kf-edits at s5; holders: ildiko (acquired at scene start)

Knowledge use ku5: tomas uses fact kf-edits at s5

Knowledge use ku6: tomas uses fact kf-hazard at s5

Knowledge use ku7: mercer uses fact kf-edits at s5

Knowledge use ku8: mercer uses fact kf-hazard at s5

State st1 [s1] tomas belief records-are-reliable: known: records are reliable; confidence 0.9; alternatives: (none recorded) → ambiguous: records may be unreliable; confidence 0.5; alternatives: records are reliable; records are being tampered with

State st3 [s2] tomas belief institutional-access-is-clean: known: sealed records are accessed only by proper procedure; confidence 0.8; alternatives: (none recorded) → ambiguous: even proper procedure can conceal a compromise; confidence 0.5; alternatives: Han's request was harmless routine; the archive itself is managed to hide things

State st4 [s3] tomas belief council-authority-is-honest: known: the council's authority rests on honest records; confidence 0.75; alternatives: (none recorded) → known: the council knowingly authorized concealment; confidence 0.85; alternatives: the edits were a rogue action within the council

State st5 [s3] mercer belief truth-would-cause-mutiny: known: the concealment is a burden she carries alone; confidence 0.6; alternatives: (none recorded) → ambiguous: Tomas now knows, and the argument must be won or the secret lost; confidence 0.5; alternatives: Tomas can be persuaded to keep silent; Tomas will expose the edits regardless

State st6 [s4] ildiko belief passengers-deserve-the-truth: ambiguous: the log discrepancy is Tomas's private problem; confidence 0.4; alternatives: it is a routine fault; it is something the council should handle → known: the passengers have a right to know the ship's real course; confidence 0.8; alternatives: the council's silence protects them

State st7 [s4] tomas belief report-handling: known: a report must be filed through proper channels; confidence 0.7; alternatives: (none recorded) → ambiguous: proper channels would bury the finding; confidence 0.55; alternatives: channels could still surface it; only a direct broadcast will be heard

State st8 [s5] tomas goal disclosure-method: known: find a way to make the truth heard without destroying order; confidence 0.6; alternatives: file through channels; leak anonymously → known: put the unedited log on the shipwide channel himself; confidence 0.85; alternatives: abort at the last moment

State st9 [s5] mercer belief containment: ambiguous: the secret can still be contained by persuasion or procedure; confidence 0.45; alternatives: Tomas will expose the edits regardless; the council can outlast the crisis → known: the secret is beyond her control and the passengers will judge the council; confidence 0.8; alternatives: the broadcast can be cut before it lands; the passengers will side with the council

State st10 [s5] ildiko belief public-knowledge: ambiguous: the truth should be told, but she does not know if Tomas will tell it; confidence 0.5; alternatives: Tomas will stay silent; the council will preempt him → known: the truth is now public and she is part of having made it so; confidence 0.8; alternatives: the broadcast will be dismissed as a fault
