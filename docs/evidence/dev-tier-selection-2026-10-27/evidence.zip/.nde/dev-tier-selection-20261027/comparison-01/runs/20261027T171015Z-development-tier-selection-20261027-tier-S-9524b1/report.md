# Run report: development-tier-selection-20261027-tier-S

- **Status:** succeeded
- **Started:** 2026-10-27T17:10:15.226743+00:00
- **Finished:** 2026-10-27T17:30:04.613204+00:00
- **Git SHA:** `3f29d9cd83e11b038a6dd963b6f7f168c93ed48e` (dirty)
- **Config:** `C:\docs\git\storyBuilder\.nde\dev-tier-selection-20261027\comparison-01\configs\S.yaml` (hash `677fff15f8b4`)
- **Seed:** 1700
- **Cache:** use, 0 hits, 81 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | deepseek | deepseek-flash | deepseek |

## Prompt templates

- `plan_skeleton@1` (sha256 `01a419126a5e`)
- `plan_channels@1` (sha256 `1297b1368ce8`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-01, brief-02 (from `C:\docs\git\storyBuilder\benchmark`)
- **Frozen splits:** none
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 3 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | C | 1 | 0 | 2000 | 0 | no | 0 | failed | 19 | 462320 | 189155 | $0.3657 | $0.3657 | [planning-provenance.json](stories/C/brief-01/r1/planning-provenance.json) [skeleton.json](stories/C/brief-01/r1/skeleton.json) |
| brief-01 | B | 1 | 1878 | 2000 | 1 | yes | 0 | ok | 9 | 6342 | 3422 | $0.0060 | $0.0060 | [outline.json](stories/B/brief-01/r1/outline.json) [story.md](stories/B/brief-01/r1/story.md) [story.raw.md](stories/B/brief-01/r1/story.raw.md) |
| brief-02 | C | 1 | 1920 | 2000 | 1 | yes | 0 | ok | 18 | 186681 | 61218 | $0.1295 | $0.1295 | [cards.html](stories/C/brief-02/r1/cards.html) [cards.md](stories/C/brief-02/r1/cards.md) [ledger.json](stories/C/brief-02/r1/ledger.json) [plan-selection.json](stories/C/brief-02/r1/plan-selection.json) [plan.json](stories/C/brief-02/r1/plan.json) [planning-provenance.json](stories/C/brief-02/r1/planning-provenance.json) [skeleton.json](stories/C/brief-02/r1/skeleton.json) [source-plan.json](stories/C/brief-02/r1/source-plan.json) [story.md](stories/C/brief-02/r1/story.md) [story.raw.md](stories/C/brief-02/r1/story.raw.md) [validation.json](stories/C/brief-02/r1/validation.json) |
| brief-02 | B | 1 | 2166 | 2000 | 1 | yes | 24 | ok | 35 | 84145 | 77530 | $0.1183 | $0.1183 | [outline.json](stories/B/brief-02/r1/outline.json) [story.md](stories/B/brief-02/r1/story.md) [story.original.md](stories/B/brief-02/r1/story.original.md) [story.raw.md](stories/B/brief-02/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 2 | 1 | 37 | 649001 | 250373 | $0.4951 | $0.4951 | $0.2476 |
| B | 2 | 0 | 44 | 90487 | 80952 | $0.1243 | $0.1243 | $0.0621 |

### Failed stories

- C/brief-01 #1: step 'channels-sc-07': Invalid JSON: EOF while parsing a string at line 1 column 61492

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 2 | 37 | 899374 | 449687 |
| B | 2 | 44 | 171439 | 85720 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 10% of the larger, with at most 24 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | 1 | 651475 | 9764 | - | 0 | 651475 | 9764 | no | no story to match: C failed |
| brief-02 | 1 | 247899 | 7766 | B | 24 | 247899 | 161675 | no | not within 10% after 24 revision passes |

0 matched, 2 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-01 repetition 1: unresolved
- C: final `stories/C/brief-01/r1/story.md`, SHA-256 `None`; None words; 651475 tokens; new spend USD 0.365682
- B: final `stories/B/brief-01/r1/story.md`, SHA-256 `effe7e0cdeccbbcbc84dd9c26a311906f73ce754cc321a91c597d4c5b6833779`; 1878 words; 9764 tokens; new spend USD 0.006009
- Unresolved: C: final prose unavailable or failed
- Unresolved: C: final length invalid or differs from saved record
- Unresolved: budget comparison incomplete or unmatched
- Unresolved: actual attributable tokens outside budget tolerance

brief-02 repetition 1: unresolved
- C: final `stories/C/brief-02/r1/story.md`, SHA-256 `c59ada2e31972a5c41a6c86a016031475b9e2dfb7fe4a8daf0a110aad5724ce8`; 1920 words; 247899 tokens; new spend USD 0.129466
- B: final `stories/B/brief-02/r1/story.md`, SHA-256 `14ca81fc7446e9b6d5b3c965c10a51d2109a6a9d69e64a653f150023e4674f68`; 2166 words; 161675 tokens; new spend USD 0.118279
- Unresolved: budget comparison incomplete or unmatched
- Unresolved: actual attributable tokens outside budget tolerance

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 16 | 31.2% | 93.8% | 68.8% | 1 |

## Cost

- New spend this run: $0.6194
- Token cost at list price, including cache hits: $0.6194
- Tokens: 739488 input, 331325 output
- Per-run cap: $1.5000; per-day cap: $3.0000
- Spent today (UTC, all runs): $0.7093

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 81 | 0 | 739488 | 331325 | $0.6194 | $0.6194 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-01/skeleton #1 | 1 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 7382 | 3819 | $0.0068 | 18.38 | 0 |
| C/brief-01/skeleton #1 | 2 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 11241 | 3818 | $0.0080 | 11.79 | 0 |
| C/brief-01/skeleton #1 | 3 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 15146 | 3784 | $0.0091 | 11.86 | 0 |
| C/brief-01/channels-sc-01 #1 | 1 | deepseek-flash | plan_channels@1 | 1082539864 | no | 11306 | 4962 | $0.0093 | 17.64 | 0 |
| C/brief-01/channels-sc-02 #1 | 1 | deepseek-flash | plan_channels@1 | 953394149 | no | 12284 | 6452 | $0.0114 | 23.14 | 0 |
| C/brief-01/channels-sc-02 #1 | 2 | deepseek-flash | plan_channels@1 | 953394149 | no | 18799 | 6298 | $0.0132 | 18.67 | 0 |
| C/brief-01/channels-sc-02 #1 | 3 | deepseek-flash | plan_channels@1 | 953394149 | no | 25129 | 6198 | $0.0150 | 18.11 | 0 |
| C/brief-01/channels-sc-03 #1 | 1 | deepseek-flash | plan_channels@1 | 1955734615 | no | 13520 | 7874 | $0.0135 | 27.21 | 0 |
| C/brief-01/channels-sc-03 #1 | 2 | deepseek-flash | plan_channels@1 | 1955734615 | no | 21454 | 7671 | $0.0156 | 21.95 | 0 |
| C/brief-01/channels-sc-04 #1 | 1 | deepseek-flash | plan_channels@1 | 199251043 | no | 14993 | 9981 | $0.0165 | 34.33 | 0 |
| C/brief-01/channels-sc-04 #1 | 2 | deepseek-flash | plan_channels@1 | 199251043 | no | 25031 | 9754 | $0.0192 | 28.66 | 0 |
| C/brief-01/channels-sc-05 #1 | 1 | deepseek-flash | plan_channels@1 | 1275523251 | no | 17076 | 12205 | $0.0198 | 43.30 | 0 |
| C/brief-01/channels-sc-05 #1 | 2 | deepseek-flash | plan_channels@1 | 1275523251 | no | 29355 | 11830 | $0.0230 | 35.01 | 0 |
| C/brief-01/channels-sc-06 #1 | 1 | deepseek-flash | plan_channels@1 | 1833688629 | no | 19152 | 15432 | $0.0243 | 54.68 | 0 |
| C/brief-01/channels-sc-06 #1 | 2 | deepseek-flash | plan_channels@1 | 1833688629 | no | 34616 | 15077 | $0.0285 | 43.22 | 0 |
| C/brief-01/channels-sc-07 #1 | 1 | deepseek-flash | plan_channels@1 | 1997237674 | no | 22399 | 16000 | $0.0259 | 44.33 | 0 |
| C/brief-01/channels-sc-07 #1 | 2 | deepseek-flash | plan_channels@1 | 1997237674 | no | 38439 | 16000 | $0.0307 | 47.87 | 0 |
| C/brief-01/channels-sc-07 #1 | 3 | deepseek-flash | plan_channels@1 | 1997237674 | no | 54479 | 16000 | $0.0355 | 45.89 | 0 |
| C/brief-01/channels-sc-07 #1 | 4 | deepseek-flash | plan_channels@1 | 1997237674 | no | 70519 | 16000 | $0.0404 | 46.06 | 0 |
| B/brief-01/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 569 | 1147 | $0.0015 | 9.80 | 0 |
| B/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 601 | 269 | $0.0005 | 3.18 | 0 |
| B/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 683 | 363 | $0.0006 | 3.77 | 0 |
| B/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 658 | 256 | $0.0005 | 2.88 | 0 |
| B/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 692 | 230 | $0.0005 | 2.39 | 0 |
| B/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 737 | 282 | $0.0006 | 3.15 | 0 |
| B/brief-01/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 778 | 302 | $0.0006 | 3.39 | 0 |
| B/brief-01/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 786 | 313 | $0.0006 | 3.22 | 0 |
| B/brief-01/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 838 | 260 | $0.0006 | 2.77 | 0 |
| C/brief-02/skeleton #1 | 1 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 7364 | 2515 | $0.0052 | 10.37 | 0 |
| C/brief-02/skeleton #1 | 2 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 9927 | 2528 | $0.0060 | 7.67 | 0 |
| C/brief-02/skeleton #1 | 3 | deepseek-flash | plan_skeleton@1 | 2055141883 | no | 12558 | 2581 | $0.0069 | 8.77 | 0 |
| C/brief-02/channels-s1 #1 | 1 | deepseek-flash | plan_channels@1 | 1310279880 | no | 9960 | 2657 | $0.0062 | 8.79 | 0 |
| C/brief-02/channels-s2 #1 | 1 | deepseek-flash | plan_channels@1 | 1407915137 | no | 9960 | 4442 | $0.0083 | 14.93 | 0 |
| C/brief-02/channels-s2 #1 | 2 | deepseek-flash | plan_channels@1 | 1407915137 | no | 14459 | 4261 | $0.0095 | 12.22 | 0 |
| C/brief-02/channels-s3 #1 | 1 | deepseek-flash | plan_channels@1 | 1438285283 | no | 10468 | 3963 | $0.0079 | 13.29 | 0 |
| C/brief-02/channels-s4 #1 | 1 | deepseek-flash | plan_channels@1 | 206457204 | no | 11266 | 5385 | $0.0098 | 18.37 | 0 |
| C/brief-02/channels-s4 #1 | 2 | deepseek-flash | plan_channels@1 | 206457204 | no | 16707 | 5227 | $0.0113 | 15.27 | 0 |
| C/brief-02/channels-s4 #1 | 3 | deepseek-flash | plan_channels@1 | 206457204 | no | 21968 | 5143 | $0.0128 | 14.99 | 0 |
| C/brief-02/channels-s5 #1 | 1 | deepseek-flash | plan_channels@1 | 1525124974 | no | 12446 | 6728 | $0.0118 | 23.16 | 0 |
| C/brief-02/channels-s5 #1 | 2 | deepseek-flash | plan_channels@1 | 1525124974 | no | 19251 | 6748 | $0.0139 | 19.62 | 0 |
| C/brief-02/channels-s5 #1 | 3 | deepseek-flash | plan_channels@1 | 1525124974 | no | 26050 | 6608 | $0.0157 | 19.15 | 0 |
| C/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 777 | 507 | $0.0008 | 4.90 | 0 |
| C/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 807 | 544 | $0.0009 | 5.34 | 0 |
| C/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 872 | 434 | $0.0008 | 4.66 | 0 |
| C/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 961 | 455 | $0.0008 | 4.78 | 0 |
| C/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 880 | 492 | $0.0009 | 5.02 | 0 |
| B/brief-02/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | no | 554 | 931 | $0.0013 | 6.83 | 0 |
| B/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 532 | 378 | $0.0006 | 3.61 | 0 |
| B/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 608 | 418 | $0.0007 | 4.12 | 0 |
| B/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 617 | 378 | $0.0006 | 4.20 | 0 |
| B/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 665 | 495 | $0.0008 | 4.84 | 0 |
| B/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 705 | 437 | $0.0007 | 4.45 | 0 |
| B/brief-02/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 702 | 346 | $0.0006 | 3.82 | 0 |
| B/brief-02/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2679 | 2450 | $0.0037 | 9.96 | 0 |
| B/brief-02/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 2678 | 2531 | $0.0038 | 11.38 | 0 |
| B/brief-02/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 2759 | 2631 | $0.0040 | 11.83 | 0 |
| B/brief-02/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 2859 | 2631 | $0.0040 | 11.53 | 0 |
| B/brief-02/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 2859 | 2708 | $0.0041 | 11.88 | 0 |
| B/brief-02/revision-05 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1289824051 | no | 2859 | 2631 | $0.0040 | 10.98 | 0 |
| B/brief-02/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 2859 | 2631 | $0.0040 | 11.32 | 0 |
| B/brief-02/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | no | 2859 | 2631 | $0.0040 | 11.55 | 0 |
| B/brief-02/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | no | 2859 | 2631 | $0.0040 | 10.67 | 0 |
| B/brief-02/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | no | 2859 | 2631 | $0.0040 | 11.29 | 0 |
| B/brief-02/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | no | 2859 | 2631 | $0.0040 | 11.11 | 0 |
| B/brief-02/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | no | 2859 | 2631 | $0.0040 | 10.90 | 0 |
| B/brief-02/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | no | 2859 | 2631 | $0.0040 | 11.32 | 0 |
| B/brief-02/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | no | 2859 | 2631 | $0.0040 | 11.24 | 0 |
| B/brief-02/revision-14 #1 | 1 | deepseek-flash | story_revision@1 | 954275669 | no | 2859 | 2633 | $0.0040 | 11.34 | 0 |
| B/brief-02/revision-15 #1 | 1 | deepseek-flash | story_revision@1 | 784163321 | no | 2861 | 3005 | $0.0045 | 14.95 | 0 |
| B/brief-02/revision-15 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1444081430 | no | 2861 | 2633 | $0.0040 | 10.84 | 0 |
| B/brief-02/revision-16 #1 | 1 | deepseek-flash | story_revision@1 | 222805417 | no | 2861 | 2697 | $0.0041 | 12.10 | 0 |
| B/brief-02/revision-16 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 60911096 | no | 2861 | 2649 | $0.0040 | 11.39 | 0 |
| B/brief-02/revision-17 #1 | 1 | deepseek-flash | story_revision@1 | 821015077 | no | 2877 | 2706 | $0.0041 | 11.83 | 0 |
| B/brief-02/revision-17 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 278137146 | no | 2877 | 2649 | $0.0040 | 11.03 | 0 |
| B/brief-02/revision-18 #1 | 1 | deepseek-flash | story_revision@1 | 913302983 | no | 2877 | 2649 | $0.0040 | 11.07 | 0 |
| B/brief-02/revision-19 #1 | 1 | deepseek-flash | story_revision@1 | 733295078 | no | 2877 | 2649 | $0.0040 | 10.92 | 0 |
| B/brief-02/revision-20 #1 | 1 | deepseek-flash | story_revision@1 | 1916088092 | no | 2877 | 2649 | $0.0040 | 11.60 | 0 |
| B/brief-02/revision-21 #1 | 1 | deepseek-flash | story_revision@1 | 1711196134 | no | 2877 | 2649 | $0.0040 | 11.78 | 0 |
| B/brief-02/revision-22 #1 | 1 | deepseek-flash | story_revision@1 | 753832799 | no | 2877 | 2649 | $0.0040 | 10.77 | 0 |
| B/brief-02/revision-23 #1 | 1 | deepseek-flash | story_revision@1 | 1829762830 | no | 2877 | 2650 | $0.0040 | 10.90 | 0 |
| B/brief-02/revision-24 #1 | 1 | deepseek-flash | story_revision@1 | 1562121133 | no | 2878 | 2650 | $0.0040 | 11.20 | 0 |
