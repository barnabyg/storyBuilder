The ship's night cycle dimmed the corridors to a soft amber, but the maintenance bay on Deck Twelve stayed bright and cold. Tomas Okafor liked it that way. At 22:00, when the day shift handed over their unfinished tickets and their excuses, he sat down at the diagnostics console with his tea and began the audit he ran every night, whether the ship needed it or not.

He started with the environmental logs, then the water reclamation stamps, then the reactor's slow heartbeat of readings. Each one he checked against its checksum, the little arithmetic fingerprint that proved a record hadn't been touched since it was written. People forgot things. People rounded numbers, skipped steps, wrote down what they meant to do instead of what they did. The records never did. That was why he trusted them.

The navigation log was last, as always. He scrolled through the maintenance stamps — thruster calibration, star-tracker alignment, the quarterly inertial reference checks — and watched the checksums reconcile one after another, green, green, green. Then a yellow.

He frowned and ran it again. Yellow.

It was the stamp from a routine star-tracker alignment, three weeks back. The record's contents matched its checksum, but the checksum itself didn't match the one archived in the audit ledger. A mismatch of eleven characters. He pulled up the previous quarter's stamp: it reconciled cleanly. The quarter before that: clean. Then he searched backward, and the yellow appeared again, eight months ago, and again before that, at loose intervals, always on navigation maintenance stamps, always small.

He checked his own console's hash library. He re-ran the comparison on a secondary partition. He even dug out the old handheld verifier, though it hadn't been calibrated in a year. The mismatch followed him across all three. He sat back and stared at it, tea going cold.

"It's probably your verifier," said Ildiko, leaning over from the next station. She was halfway through her own shift report and clearly wanted to finish it. "Or the ledger's got a stale hash. Happens."

"Then the ledger's been stale for two years, in a pattern."

"So log it and move on. Maintenance stamps are housekeeping. Nobody died because a star-tracker stamp was off by eleven characters."

Tomas opened the ticket form, then closed it. Whatever this was, it wasn't a fault in his instruments, and it wasn't housekeeping. He couldn't write "checksum mismatch, cause unknown" and sign his name to it — a closed ticket was a claim that the record had been explained. He didn't have an explanation. He only had a question, and the question was growing.

"I'll report it when I know what it is," he said, and pulled the first backup tape from the archive shelf.