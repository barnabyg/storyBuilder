The archive smelled of filtered air and old plastic. Archivist Han met him at the inner door with a clipboard and an expression that suggested he had been expecting someone else.

'Backup media access requires a filed discrepancy,' Han said. 'You have a discrepancy?'

'I have a checksum that won't reconcile.' Tomas held up his slate. 'Section twelve of the maintenance code gives a technician the right to compare live records against sealed backups when a fault is suspected in the primary log. I filed the form at 0400.'

Han read the form the way a man reads a contract he suspects of being a trick. Then he unlocked the cabinet and slid out three spools of sealed tape, each tagged with a decade and a wax seal stamped with the council's mark. 'You log out what you log in,' he said. 'And I'm noting that you asked.'

Tomas threaded the oldest spool first. The tape reader chattered, and the navigation log of forty years ago unrolled across his screen, clean and complete. He ran his reconciliation routine, then the next spool, then the next.

The checksums agreed. All of them. It was the space between them that did not.

Each backup carried a revision marker — a date, a technician's code, a reason field. Routine corrections, they said. Stellar drift. Gyro recalibration. Tomas had made entries like them himself. But when he laid the revisions side by side, the reasons stopped mattering and the arithmetic started speaking. Four years apart. Then three. Then seven. Each edit shaved a fraction of a degree off the recorded heading, no more than the tolerance the log allowed, and folded the correction into the next entry as though it had always been there.

He added them up. He checked the sum twice, then found the public charter in the ship's open records — the heading every passenger had been told at launch, printed in the orientation packet, recited at the first assembly. He laid the charter beside the reconstructed truth.

The difference was small at the start. It was not small now. For at least thirty years, the ship had been pointed somewhere the charter did not name, and every few years someone with proper access had reached into the log and made the lie tidier.

Tomas sat very still in the humming archive. It was not the number that chilled him. It was the patience. Whoever had done this had been careful for longer than Tomas had been alive.

Behind him, Han's chair creaked. 'Find your fault?' the archivist asked.

Tomas saved the comparison and closed the spool. 'Working on it,' he said.