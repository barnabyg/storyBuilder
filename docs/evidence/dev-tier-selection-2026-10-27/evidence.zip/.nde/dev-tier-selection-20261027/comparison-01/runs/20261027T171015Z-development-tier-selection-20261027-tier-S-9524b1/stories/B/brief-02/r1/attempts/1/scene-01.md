The diagnostic on the central data core was supposed to be routine, a low-priority sweep that Tomas Okafor could run while half his attention was on his tea. The Meridian's systems were old but honest, and the audit protocol flagged problems in red so a technician couldn't miss them. Tomas liked that. He liked that the ship told the truth and let him verify it.

Which is why the amber warning on the navigation log's metadata bothered him so much.

A checksum mismatch. Small, but a checksum was a checksum. Either the file was corrupted or someone had rewritten it, and on a ship where every byte was mirrored across three redundant archives, corruption was the rarer explanation.

He queued the redundant archive for comparison, expecting the two copies to reconcile and the warning to clear. Instead the archive returned a clean, untampered file, and the live log returned something else. He set them side by side and scrolled until the differences lit up.

One line. A course-correction record from forty years ago, its trajectory value altered by a fraction of a degree. He checked the arithmetic twice, then a third time, because a fraction of a degree over forty years was not a rounding error. It was a different destination.

Tomas sat back and listened to the hum of the ship around him, the great patient noise of it, and felt something cold settle in his chest.

He took the discrepancy to his supervisor, Halvorsen, who glanced at the screen for perhaps four seconds before waving a hand at it. "Sensor glitch. We see those on the old logs all the time."

"Both copies disagree," Tomas said. "That's not a sensor."

"Drop it," Halvorsen said, already turning back to his console. "It's above your pay grade, Okafor. Drop it."