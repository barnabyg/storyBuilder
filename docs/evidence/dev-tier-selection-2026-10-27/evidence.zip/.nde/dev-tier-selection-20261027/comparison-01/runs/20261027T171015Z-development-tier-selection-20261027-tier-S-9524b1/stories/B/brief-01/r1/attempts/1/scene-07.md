The surveyor came out on the noon tide, a thin man in a borrowed oilskin who walked the reef at low water with a notebook and a face that gave nothing away. He measured the holing twice, photographed the clean line of the gash, and stood a long while looking at the channel marks, which were where they had always been. By the week's end the letter came: the claim was refused, the loss attributed to navigation rather than misadventure, and Eli paid a fine at the constable's office and told anyone who asked that he had misread the channel in the dark, that it was his own foolishness and no one else's.

Ruth took the job at the cannery in town. Ada saw her at the bus stop on the Monday with a plastic lunch pail and her hair pinned back, and Ruth nodded to her, and Ada nodded back.

Frank Dwyer came up the hill on the Thursday. He stood in her kitchen with his hat in his hands and asked her straight whether she had known anything, that night, before it happened.

"Only that the sea does what it does," Ada said.

He looked at her a moment longer than was comfortable, then put his hat on.

When he was gone she took the letter from the drawer—the one she had written to the insurer, never sent, in her careful hand—and fed it to the stove page by page, and carried the ashes up the ninety-two steps and let the wind take them off the gallery into the grey water below.