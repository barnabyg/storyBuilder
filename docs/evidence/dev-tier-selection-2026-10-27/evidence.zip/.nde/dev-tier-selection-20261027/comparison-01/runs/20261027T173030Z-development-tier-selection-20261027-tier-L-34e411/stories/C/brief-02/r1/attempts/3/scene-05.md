Ildiko pulled her chair around to his side of the bench. "You know what happens if you do this," she said. "Not to the ship. To you."

"Probably," Tomas said. He was already keying the log into the public channel queue, the full unedited sequence, every checksum and every amendment, the original course and the hazard the founders had hidden at the end of it. His hands were steady the way they got when the work was clear. "The council won't want me touching the log after this. Maybe they'll want me somewhere else entirely."

"Tomas." Mercer's voice came through the console, thin, worn down. "I'm not asking you to believe me. I'm asking you to wait one shift. Let the council make the announcement on its own terms. Give people a chance to hear it from someone they trust."

"People trust the log," Tomas said. "That's the thing you spent forty years counting on. They trust it because it doesn't lie to them. If I wait, and you soften it, and I wait again, then the log is just another voice with an interest. It stops being the record. It becomes another politician." He toggled the channel open. "I'm not doing this to hurt you. I'm doing it because the record is the only thing on this ship that was ever supposed to be true."

Mercer said something else, but the channel swallowed her. Tomas set the playback to the beginning and pressed send.

"Attention, all decks," the automated voice said, flat and even. "A correction to the navigation log follows. The ship is not on its original course. The course was altered sixty-one years ago. The alteration was concealed from the record by order of the ship's council."

Ildiko's hand found his shoulder. He kept his eyes on the console, on the little bar of the transmission crawling forward.

"The original course led toward a hazard the founders concealed. The current course leads elsewhere. The council has known both facts and withheld them. The unedited log follows."

The bar reached the end. The channel clicked over to the log itself, and Tomas sat very still, and the whole ship listened.