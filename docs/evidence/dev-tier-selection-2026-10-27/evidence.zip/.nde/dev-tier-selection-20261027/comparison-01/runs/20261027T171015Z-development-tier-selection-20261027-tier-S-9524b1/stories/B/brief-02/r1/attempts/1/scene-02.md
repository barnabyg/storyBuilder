Tomas did not drop it.

He told himself it was diligence, not defiance. A records discrepancy was a records discrepancy, and the Meridian's logs were supposed to be immutable, sealed, checksummed against tampering. That was the whole point of a ship that would sail for two hundred years: the truth had to outlast the people who wrote it down. So that night, after his shift, he sat in the maintenance crawlway with his tablet tethered to a deep-storage port and began pulling backups. Cold archives, decades old, the kind nobody had touched since the last physical migration.

The oldest one took a while to decompress. When it opened, he almost missed it.

The course vector didn't match. Not slightly. The ship had been pointed at Gliese 445, a star with a confirmed habitable world, close enough to be a reasonable promise. Then, in the records dated 2155, the vector shifted. The new heading was for a dim red dwarf with two gas giants and, by every survey note attached, nothing worth landing on.

He pulled the next backup. The heading matched the new course. But the version history had a seam in it, a hairline stitch where an entry had been replaced rather than amended. He pulled another backup, ten years later. Another edit. And another, every few years, each one quietly excising the last trace of the old destination.

He traced the credential that signed the edits. It wasn't a navigation key. It was council-level, the highest clearance on the ship.

His hands were cold. He sat in the hum of the crawlway for a long time, then went to find Mira.

She listened without interrupting, her tea going cold in her hands. When he finished, she was quiet for a moment.

"You're sure about the credential," she said.

"I checked it three times."

Mira set the cup down. "Then you understand what you're holding. Be careful, Tomas. People who find things like this don't always get to keep finding them."