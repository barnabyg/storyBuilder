At 22:00 ship time, when the day shift's noise had drained out of the corridors, Tomas Okafor began his audit. He started with the environmental logs, as always: oxygen partial pressures across all forty-one decks, scrubber cycle times, the slow drift of humidity in the hydroponics bays. Every value was checked against its twin, every twin against the checksum in the header. The ship recorded everything, and the records agreed with themselves, and that agreement was the closest thing to honesty Tomas had ever found in people or machinery. People forgot. People rounded. The log did not.

He worked down his list in order, because order was the point. Water reclamation. Power draw. The maintenance ledger, where every repair on the ship was stamped, signed, and hashed. It was there, at 23:40, that the number failed to reconcile.

Tomas frowned at the discrepancy—a checksum mismatch in the maintenance stamps attached to the navigation log. Small. Almost beneath notice. He ran the check again, then a third time on the backup terminal, and the mismatch held steady, the same gap in the same place. It had the look of a fault in his own instruments, a corrupted cache or a stale index, and he told himself so. He cleared the cache and re-ran the audit from the beginning. The number failed again.

"You're still here," Ildiko said from the hatch, her shift bag over one shoulder. She had the easy manner of someone who finished her work when her work was finished. "That's the third night this week."

"Checksum won't reconcile," Tomas said, not looking up. "Navigation maintenance stamps."

"Then log it and go to bed. That's what the ticket system is for."

"I can't close a ticket I can't explain." He turned the screen toward her, though she was already halfway out the door. "It's not random. It repeats. Same offset, every cycle."

Ildiko paused, glanced at the numbers, and shrugged. "So the archive is glitchy. Report it to Records in the morning. They'll re-stamp it and it'll reconcile and you'll have slept."

"Records doesn't re-stamp navigation. Nobody touches navigation but the council."

"Then it's above your pay grade and mine." She tapped the hatch frame twice, a friendly farewell. "Good night, Tomas."

The hatch sealed behind her. Tomas sat in the hum of the empty bay and ran the check a fourth time, then a fifth, watching the same stubborn number refuse to agree with itself.

The archive smelled of filtered air and old plastic. Archivist Han met him at the inner door with a clipboard and an expression that suggested he had been expecting someone else.

'Backup media access requires a filed discrepancy,' Han said. 'You have a discrepancy?'

'I have a checksum that won't reconcile.' Tomas held up his slate. 'Section twelve of the maintenance code gives a technician the right to compare live records against sealed backups when a fault is suspected in the primary log. I filed the form at 0400.'

Han read the form the way a man reads a contract he suspects of being a trick. Then he unlocked the cabinet and slid out three spools of sealed tape, each tagged with a decade and a wax seal stamped with the council's mark. 'You log out what you log in,' he said. 'And I'm noting that you asked.'

Tomas threaded the oldest spool first. The tape reader chattered, and the navigation log of forty years ago unrolled across his screen, clean and complete. He ran his reconciliation routine, then the next spool, then the next.

The checksums agreed. All of them. It was the space between them that did not.

Each backup carried a revision marker — a date, a technician's code, a reason field. Routine corrections, they said. Stellar drift. Gyro recalibration. Tomas had made entries like them himself. But when he laid the revisions side by side, the reasons stopped mattering and the arithmetic started speaking. Four years apart. Then three. Then seven. Each edit shaved a fraction of a degree off the recorded heading, no more than the tolerance the log allowed, and folded the correction into the next entry as though it had always been there.

He added them up. He checked the sum twice, then found the public charter in the ship's open records — the heading every passenger had been told at launch, printed in the orientation packet, recited at the first assembly. He laid the charter beside the reconstructed truth.

The difference was small at the start. It was not small now. For at least thirty years, the ship had been pointed somewhere the charter did not name, and every few years someone with proper access had reached into the log and made the lie tidier.

Tomas sat very still in the humming archive. It was not the number that chilled him. It was the patience. Whoever had done this had been careful for longer than Tomas had been alive.

Behind him, Han's chair creaked. 'Find your fault?' the archivist asked.

Tomas saved the comparison and closed the spool. 'Working on it,' he said.

Mercer's office was smaller than Tomas had expected, and warmer. She listened to the whole account without interrupting, her hands folded on the desk, and when he finished she did not ask him to repeat himself or to show her the spool.

"Which revision did you reach?" she said.

"Forty-one." He had expected denial. The question unsettled him more. "The charter in the public archive says the heading has never changed. The backups say otherwise. There are edits going back thirty years, at least."

"Thirty-eight," Mercer said. "I have the authorization records. Every one of those edits was ordered by this council, under the continuity clause of the charter. You won't find a rogue actor, Tomas. There's no one to arrest."

He sat down slowly, because his legs had gone unreliable. "Why?"

"Because we turned." She said it plainly, without apology. "The founders mapped a route through a debris field — a cluster around a star they logged as unremarkable. The survey drones that went ahead of us found otherwise. The field is dense enough that a hull strike was near certain, and the margins were too thin for a full braking burn. The founders' solution was to change course and amend the public record so no one would know the difference. Then they amended it again each time the lie needed maintenance. We've been doing the same ever since."

"The passengers were never told."

"The passengers were never told," Mercer agreed. "Forty thousand people whose grandparents signed a charter promising one destination now live on a ship bound for another. I've read the founders' minutes. They knew exactly what they were doing, and they did it anyway, because the alternative was a vote they were afraid to hold."

Tomas thought of the charter, the heading printed on every schoolroom wall. "You're asking me to weigh stability against the truth."

"I'm asking you to weigh one harm against another. The truth would break something. I don't know how badly. Neither did the founders." She looked at him steadily, and for the first time he saw how tired she was, as if she had been holding this alone for a long time and had just now set it down between them. "You believe records exist to be trusted. So do I. But these people never consented to receive this. Whatever you decide, Tomas — decide it knowing that."

He found Ildiko in the parts bay, halfway inside an open panel, and told her everything. She listened without interrupting, which was unlike her.

When he finished, she wiped her hands and sat back against the workbench. "You keep saying they never consented," she said. "But consent to what? They're going somewhere either way. The only question is whether they know it." She picked at a smear of grease on her thumb. "My grandmother packed for a destination. She died believing she was almost there. I don't think that was kindness. I think it was theft."

"It kept her calm."

"It kept her quiet." Ildiko looked at him. "You're not weighing order against chaos, Tomas. You're weighing their comfort against their choice. Those aren't the same thing, and you know it."

He went back to his station and opened a report form. He typed the subject line, the summary of the discrepancy, the chain of edits. He wrote that he had confirmed the finding with Councilor Mercer, that the edits were authorized at the council level, and that further action was pending review. He read it over. It was accurate, factual, properly routed. It would land on Mercer's desk by morning, and from there it would go wherever she decided, and the log would stay edited, and the passengers would keep their comfortable theft.

He deleted it.

He wrote it again, shorter this time, and deleted that too. The cursor blinked in the empty field. He sat with his hands off the keyboard and understood, finally, what was bothering him. It wasn't that the council had lied. Institutions lied; he had always known that in the abstract. It was that he had spent his whole career believing a record was a thing that could be relied upon, and now he knew that records could be edited and re-edited until they said whatever someone needed them to say, and there was no way to tell from the outside. A record he couldn't trust wasn't a record. It was a story someone was telling him.

An unsettling truth, at least, could be checked. Could be argued with. Could be chosen.

He closed the report form and opened the shipwide broadcast console instead.

The console chimed twice as Mercer's channel opened. Her voice was tight, controlled, the way it had been in the council room.

"Tomas. The council is meeting now. Give us an hour. We can do this properly—a joint statement, a plan for how the news is delivered. Doors can be opened with some care."

He looked at the log on his screen. Forty years of small, patient edits, each one a door closing quietly.

"An hour for what?" he said. "For you to write the next version?"

"That isn't fair."

"No," he said. "It isn't."

He pressed the channel closed and routed the unedited log into the shipwide broadcast queue. His hands moved without hurry, the way they did on a maintenance panel: one step, then the next, each verified before the next began. He checked the routing twice. He checked that the queue held the full record, not the summary, not the selected excerpts. Then he opened the announcement line.

"This is Tomas Okafor, maintenance technician, deck nine. I'm speaking to everyone aboard." The words came out steadier than he expected. "For the last forty years, the ship's navigation log has been edited. Not lost, not corrupted—edited, deliberately, by the council and its predecessors. The ship is not on the course we were told. It changed course, and the change was concealed."

He paused, because there was one more thing, and Mercer's voice was still in his ears, saying you don't understand what you'll do.

"The council believed the truth would cause a mutiny. That is their reason. I am not going to argue with it. I am giving you the log, unedited, and the backups it was reconstructed from. You can read it yourselves. It's on the public archive now, under my name, so you know where it came from."

He looked at the screen. The queue showed the log, the backups, the reconstruction, all of it, ready.

"Where we are going is a decision that belongs to all of us. It always did."

He pressed send. The console brightened, the shipwide channel took the record, and the carrier tone sounded once through every speaker on every deck—a single clean note, and then the log began to play.