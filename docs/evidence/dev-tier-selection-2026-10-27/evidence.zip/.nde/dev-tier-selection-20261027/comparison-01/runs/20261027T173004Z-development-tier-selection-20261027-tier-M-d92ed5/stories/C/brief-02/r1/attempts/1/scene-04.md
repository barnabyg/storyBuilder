He found Ildiko in the parts bay, halfway inside an open panel, and told her everything. She listened without interrupting, which was unlike her.

When he finished, she wiped her hands and sat back against the workbench. "You keep saying they never consented," she said. "But consent to what? They're going somewhere either way. The only question is whether they know it." She picked at a smear of grease on her thumb. "My grandmother packed for a destination. She died believing she was almost there. I don't think that was kindness. I think it was theft."

"It kept her calm."

"It kept her quiet." Ildiko looked at him. "You're not weighing order against chaos, Tomas. You're weighing their comfort against their choice. Those aren't the same thing, and you know it."

He went back to his station and opened a report form. He typed the subject line, the summary of the discrepancy, the chain of edits. He wrote that he had confirmed the finding with Councilor Mercer, that the edits were authorized at the council level, and that further action was pending review. He read it over. It was accurate, factual, properly routed. It would land on Mercer's desk by morning, and from there it would go wherever she decided, and the log would stay edited, and the passengers would keep their comfortable theft.

He deleted it.

He wrote it again, shorter this time, and deleted that too. The cursor blinked in the empty field. He sat with his hands off the keyboard and understood, finally, what was bothering him. It wasn't that the council had lied. Institutions lied; he had always known that in the abstract. It was that he had spent his whole career believing a record was a thing that could be relied upon, and now he knew that records could be edited and re-edited until they said whatever someone needed them to say, and there was no way to tell from the outside. A record he couldn't trust wasn't a record. It was a story someone was telling him.

An unsettling truth, at least, could be checked. Could be argued with. Could be chosen.

He closed the report form and opened the shipwide broadcast console instead.