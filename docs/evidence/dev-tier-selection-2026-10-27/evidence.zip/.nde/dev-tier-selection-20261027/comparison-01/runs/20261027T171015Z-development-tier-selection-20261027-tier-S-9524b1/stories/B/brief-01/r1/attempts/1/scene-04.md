She brought Frank Dwyer a jar of preserves the next afternoon, the way she did most weeks, and set it on his kitchen table while the kettle came up. He had run the harbour office for forty years and still knew every hull that passed the point.

She told him a thing, not naming Eli, only a thing a keeper might have heard.

Frank turned his cup slowly. A report would mean an investigation, he said. A criminal charge. The Pruitts would lose the house, and there was no version where they didn't. He said the insurer, once it smelled fraud, might refuse to pay a penny. The Marigold would be seized as evidence and sit in a yard for years, rotting under a tarp, and never sail again either way. "Either way," he said again, quieter, and looked out at the water.

Ada walked home along the shore. The tide was slack and the evening had gone still, and there in the shallows lay the boat turned upside down in the water, mast and all, so clear she could have counted the planks. She stood a long while looking at it.