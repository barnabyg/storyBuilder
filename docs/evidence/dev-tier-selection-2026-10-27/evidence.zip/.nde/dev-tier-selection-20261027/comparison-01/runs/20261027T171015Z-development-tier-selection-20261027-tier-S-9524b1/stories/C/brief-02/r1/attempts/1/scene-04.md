He did not go back to his bunk. He went to the maintenance deck, where Ildiko was halfway inside a scrubber housing, and told her everything, because she had a way of hearing a thing before you finished saying it.

She listened without interrupting, which was rare for her, and when he was done she wiped her hands on her coveralls and said, "So the council decided where we go. Without asking."

"To keep us alive," Tomas said. "That's their argument."

"Maybe it's even true." She sat down on an overturned crate. "But Tomas, my grandmother spent her whole life learning to be a farmer on a world she'll never see, because she was told that was the plan. She gave up children for it. If the plan changed, she deserved to know. We all did. Where we're going isn't a maintenance detail. It's the whole reason we're on this ship." She looked at him. "You don't get to carry people and not tell them where."

He went back to his console and opened a report form. *Incident: navigation log integrity, unresolved.* He typed for ten minutes—the checksum, the backups, the pattern of edits, the council's statement—and stopped at the closing line, where he was supposed to recommend a course of action. *Recommend review by*—and there he sat.

He read it back. A careful report, routed to the council, would vanish into a drawer. A careless one would vanish him. He saved it, deleted the closing paragraph, retyped it, deleted it again. The cursor blinked. Order on one side, consent on the other, and the form had a box for neither.

What finally settled it was smaller than either argument. He thought of the log itself—the clean checksums, the tidy decades of edits—and understood that he could no longer read it without wondering. Every course correction, every burn, every entry he'd ever signed off on. A record he could not trust was not a record at all. It was a story someone had chosen for him. He would rather have a truth that unsettled him than a file that lied to him kindly.

He closed the report.