Mercer's office was smaller than Tomas had expected, and warmer. She listened to the whole account without interrupting, her hands folded on the desk, and when he finished she did not ask him to repeat himself or to show her the spool.

"Which revision did you reach?" she said.

"Forty-one." He had expected denial. The question unsettled him more. "The charter in the public archive says the heading has never changed. The backups say otherwise. There are edits going back thirty years, at least."

"Thirty-eight," Mercer said. "I have the authorization records. Every one of those edits was ordered by this council, under the continuity clause of the charter. You won't find a rogue actor, Tomas. There's no one to arrest."

He sat down slowly, because his legs had gone unreliable. "Why?"

"Because we turned." She said it plainly, without apology. "The founders mapped a route through a debris field — a cluster around a star they logged as unremarkable. The survey drones that went ahead of us found otherwise. The field is dense enough that a hull strike was near certain, and the margins were too thin for a full braking burn. The founders' solution was to change course and amend the public record so no one would know the difference. Then they amended it again each time the lie needed maintenance. We've been doing the same ever since."

"The passengers were never told."

"The passengers were never told," Mercer agreed. "Forty thousand people whose grandparents signed a charter promising one destination now live on a ship bound for another. I've read the founders' minutes. They knew exactly what they were doing, and they did it anyway, because the alternative was a vote they were afraid to hold."

Tomas thought of the charter, the heading printed on every schoolroom wall. "You're asking me to weigh stability against the truth."

"I'm asking you to weigh one harm against another. The truth would break something. I don't know how badly. Neither did the founders." She looked at him steadily, and for the first time he saw how tired she was, as if she had been holding this alone for a long time and had just now set it down between them. "You believe records exist to be trusted. So do I. But these people never consented to receive this. Whatever you decide, Tomas — decide it knowing that."