The console chimed twice as Mercer's channel opened. Her voice was tight, controlled, the way it had been in the council room.

"Tomas. The council is meeting now. Give us an hour. We can do this properly—a joint statement, a plan for how the news is delivered. Doors can be opened with some care."

He looked at the log on his screen. Forty years of small, patient edits, each one a door closing quietly.

"An hour for what?" he said. "For you to write the next version?"

"That isn't fair."

"No," he said. "It isn't."

He pressed the channel closed and routed the unedited log into the shipwide broadcast queue. His hands moved without hurry, the way they did on a maintenance panel: one step, then the next, each verified before the next began. He checked the routing twice. He checked that the queue held the full record, not the summary, not the selected excerpts. Then he opened the announcement line.

"This is Tomas Okafor, maintenance technician, deck nine. I'm speaking to everyone aboard." The words came out steadier than he expected. "For the last forty years, the ship's navigation log has been edited. Not lost, not corrupted—edited, deliberately, by the council and its predecessors. The ship is not on the course we were told. It changed course, and the change was concealed."

He paused, because there was one more thing, and Mercer's voice was still in his ears, saying *you don't understand what you'll do.*

"The council believed the truth would cause a mutiny. That is their reason. I am not going to argue with it. I am giving you the log, unedited, and the backups it was reconstructed from. You can read it yourselves. It's on the public archive now, under my name, so you know where it came from."

He looked at the screen. The queue showed the log, the backups, the reconstruction, all of it, ready.

"Where we are going is a decision that belongs to all of us. It always did."

He pressed send. The console brightened, the shipwide channel took the record, and the carrier tone sounded once through every speaker on every deck—a single clean note, and then the log began to play.