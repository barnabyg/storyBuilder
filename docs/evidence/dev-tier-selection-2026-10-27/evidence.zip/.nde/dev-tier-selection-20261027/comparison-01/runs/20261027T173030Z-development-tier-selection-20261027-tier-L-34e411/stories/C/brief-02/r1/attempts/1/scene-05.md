The broadcast desk was a narrow alcove off the maintenance ring, little more than a console and a stool, and Mercer was already there when he arrived. She had come alone. No security, no aides, just the gray coat and the tired face of a woman who had run out of rooms to lock.

"Tomas." She didn't raise her voice. "The council is meeting in an hour. Give me the chit, and I will put the log before them myself. Full disclosure, my recommendation attached. That is the process working."

"The process has been editing the log for thirty years," Tomas said.

"You're right. Which is why it has to be fixed from inside, by people who know what the fix costs. If you push this out raw, you don't get a hearing. You get a panic. You get people deciding the council lied about everything, including the hull, including the air. You know what happens when a ship's complement stops trusting the people who keep it alive."

"I know what happens when the record can't be trusted," Tomas said. "Everything else follows from that."

Mercer's hand rested on the console edge, close to the cutoff. "The original course ran toward something the founders didn't put in the charter. They chose to turn. Every council since has chosen to keep turning. You can call that a lie. I call it thirty years of nobody dying."

"Then say it out loud," Tomas said. "All of it. If it's that defensible, it will survive being heard."

She looked at him for a long moment, and something in her expression closed, the way a hatch closes.

"I can't let you do this," she said, and reached for the console.

Tomas had already keyed the chit into the auxiliary port. The maintenance override was his by assignment, the one credential no councilor had ever thought worth revoking from a junior technician, and the shipwide channel accepted it without argument. Mercer's hand found the cutoff a half-second too late; the channel was live and locked, and the log began to stream.

"This is Tomas Okafor, maintenance, deck four," he said, and his voice came back to him from the corridor speakers, flat and strange. "What follows is the unedited navigation log of the ship, authenticated against the sealed archive. The ship is not on the course the charter states. It changed course thirty-one years ago, and every council since has ordered the log edited to conceal it. The original destination was judged hazardous by the founders. That judgment was never published. I am publishing it now."

He let the log run. Checksums, timestamps, the long quiet chain of revisions, the course vectors before and after. It took four minutes. Mercer stood with her hand still on the dead cutoff and did not move.

The log ended. Tomas keyed the closing line.

"This is the record as it was kept. It is yours now."

He released the channel. The console light went from red to amber, and the corridor speakers clicked off into silence, and the silence went on, and on, and nothing in it told him what came next.