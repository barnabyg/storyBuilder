The night shift on *Verdance* was quiet in the way a held breath is quiet. Tomas Okafor liked it that way. At 22:00, when the day crew's chatter had drained out of the corridors and the ship's lighting dimmed to its sleeping amber, he sat down at his station in the records bay and began his audit.

He began every night the same way: a full sweep of the maintenance logs, node by node, cross-checking each entry against its checksum. It was tedious work, and he knew that most of the technicians skimmed it. He didn't. The logs were the ship's memory, and a ship that forgot itself was just a hull full of strangers drifting in the dark. People forgot things. Records did not. That was the whole point of them.

The sweep ran green through the environmental systems, the hydroponics bays, the water reclamation stacks. Then it hit Navigation.

One maintenance stamp, dated 61 years back, failed its checksum. Tomas frowned and flagged it. A single bad stamp could be a corrupted sector, a cosmic ray strike, ordinary decay. He expected four more like it, scattered at random.

Instead the sweep found another, eleven days after the first. Then another, seven weeks later. Then a cluster of nine. All of them maintenance stamps on the navigation log, all of them failing by the same margin.

He ran the cross-check again. Same result. He ran it a third time, and the third time he found himself leaning back, staring at the amber-lit numbers as though they had personally lied to him.

"You're still here," Ildiko said from the doorway, her shift bag over one shoulder. She had the easy, unbothered air of someone who finished her tasks and left them finished.

"Checksum mismatch," Tomas said. "Recurring. Same delta every time."

"Bad sector?"

"Sixty-one years of bad sectors that all fail the same way? That's not decay. That's a pattern." He pulled the offending stamps onto the main display so she could see the neat, terrible regularity of them.

Ildiko looked for a moment longer than was polite. "Or it's a quirk in the audit tool. You know the old navigation firmware was patched a dozen times. Report it to Systems, let them close it out, come to breakfast."

"I can't close a ticket I can't explain."

"You can't explain half the things you close."

"I close them when the explanation is boring," Tomas said. "This one isn't boring yet."

Ildiko sighed, hitched her bag higher, and left him to it. The door sighed shut behind her. Tomas turned back to the screen, where the mismatches sat in their patient row, and began, very carefully, to pull the older backups.