The diagnostic on the central data core was supposed to be routine, a low-priority sweep Tomas Okafor could run with half his attention on his tea and the other half on the maintenance queue. The Meridian's systems were old but honest, and the audit protocol flagged problems in red so a technician couldn't miss them. Tomas liked that. He liked that the ship told the truth and let him verify it. He had built his whole small career on that principle: records over people, checksums over assurances. People forgot, misremembered, shaded things to spare your feelings. A checksum either matched or it did not.

Which is why the amber warning on the navigation log's metadata bothered him so much.

A checksum mismatch, small and buried in a file header nobody had cause to open, but a checksum was a checksum. Either the file was corrupted or someone had rewritten it, and on a ship where every byte was mirrored across three redundant archives, corruption was the rarer explanation. He queued the redundant archive for comparison, expecting the two copies to reconcile and the warning to clear itself. Instead the archive returned a clean file and the live log returned something else. He set them side by side and scrolled until the differences lit up.

One line. A course-correction record from forty years ago, its trajectory value altered by a fraction of a degree. He checked the arithmetic twice, then a third time, because a fraction of a degree over forty years was not a rounding error. It was a different destination.

Tomas sat back and listened to the hum of the ship around him, the great patient noise of it, and felt something cold settle in his chest. He thought of his mother, who had spent her whole life in the hydroponics bays and never once asked where the water went after it left her hands. He thought of the children in the creche decks, learning the ship's long journey as a kind of scripture. He pulled the discrepancy onto a portable slate so he could look at it without the core's logging software watching, though he could not have said why he wanted that.

He took it to his supervisor, Halvorsen, who glanced at the screen for perhaps four seconds before waving a hand at it. "Sensor glitch. We see those on the old logs all the time."

"Both copies disagree," Tomas said. "That's not a sensor."

"Drop it," Halvorsen said, already turning back to his console. "It's above your pay grade, Okafor. Drop it." His voice had gone flat and careful, and he did not look up again.

Tomas did not drop it. He told himself it was diligence, not defiance. A records discrepancy was a records discrepancy, and the Meridian's logs were supposed to be immutable, sealed, checksummed against tampering. That was the whole point of a ship that would sail for two hundred years: the truth had to outlast the people who wrote it down. So that night, after his shift, he sat in the maintenance crawlway with his tablet tethered to a deep-storage port and began pulling backups. Cold archives, decades old, the kind nobody had touched since the last physical migration.

The oldest one took a while to decompress. When it opened, he almost missed it.

The course vector didn't match. Not slightly. The ship had been pointed at Gliese 445, a star with a confirmed habitable world, close enough to be a reasonable promise. Then, in the records dated 2155, the vector shifted. The new heading was for a dim red dwarf with two gas giants and, by every survey note attached, nothing worth landing on. He pulled the next backup. The heading matched the new course. But the version history had a seam in it, a hairline stitch where an entry had been replaced rather than amended. He pulled another backup, ten years later. Another edit. And another, every few years, each one quietly excising the last trace of the old destination, each one signed by a credential that was not a navigation key but council-level, the highest clearance on the ship.

His hands were cold. He sat in the hum of the crawlway for a long time, then went to find Mira.

She listened without interrupting, her tea going cold in her hands. When he finished, she was quiet for a moment.

"You're sure about the credential," she said. He showed her the signature hash, the council key's unmistakable pattern. "Then you understand what you're holding. Be careful, Tomas. People who find things like this don't always get to keep finding them."

The council chamber was smaller than Tomas had imagined, a plain room with a long table and a single viewport showing the slow wheel of stars. Councilor Voss did not offer him a seat. She stood at the head of the table with her hands folded, and when Tomas laid the printouts before her she did not look at them.

"I know what they say," she said. "I've known for a long time that someone would find them."

"Then you know what they are." Tomas kept his voice level. "Forty years of edits. The Meridian changed course and the record was rewritten to hide it. I want to know why."

Voss was quiet for a moment. Then she sat, and the gesture was so tired that it unsettled him more than any denial would have.

"The original destination was a lie," she said. "Not a deliberate one. The survey data was flawed, the models were wrong. When the correction came through, the planet we'd been sailing toward for three generations was a frozen rock with an atmosphere we couldn't breathe. There was nothing there for us."

"So you found another star."

"We found a possibility. It's farther. It's uncertain. But it's something." She met his eyes. "And we decided that telling eight thousand people their whole inheritance had been a mistake would break them. The ship is a sealed world, Tomas. Despair spreads faster than any plague. So we made the record consistent. We gave them a course they could believe in."

"You falsified the logs."

"I protected the voyage." She leaned forward, and her voice dropped. "You will keep this to yourself. That is not a request. The greater good is not a phrase I use lightly, but it is the only thing holding this ship together. You found a crack. I'm asking you to leave it sealed."

Tomas walked the long way back to his quarters, through corridors that smelled of recycled air and warm wiring. He passed families at their evening meals, children chasing a ball along the walkway, an old man mending a chair. All of them going about lives built on a promise.

Inside his cabin he sat at his desk and called up the ship's charter. It was old text, ratified before launch, buried three menus deep in the public archive where almost no one ever looked. He read it slowly, the way he read everything.

Article Nine. Alterations to the Meridian's declared destination or heading shall require the informed consent of the passenger body, expressed by general ballot.

He read it twice more. Then he opened the navigation logs beside it and laid the dates side by side, and the plain fact of it settled on him like a weight. Forty years of edits. A course change no one had voted on. The council had not merely hidden something; they had broken the founding law of the ship. He thought of Voss's tired face and found, to his surprise, that he believed her fear. He did not think she was lying about the despair. He thought she was wrong about what it licensed.

He thought about copying the files to a public queue. It would take four minutes. He imagined the door of his quarters opening in the night, security in the frame, his name struck from the duty roster, his bunk reassigned. Who would he even be, without the work? He closed the terminal and sat in the dark for a while.

Mira found him in the mess hall the next morning, her tray set down across from his before he could pretend to be busy.

"You look like a man carrying a cracked reactor in his pocket," she said.

He told her, quietly, most of it. She listened without interrupting, which was not her habit.

"I'm not going to tell you it's nothing," she said at last. "But Voss doesn't bluff. If you move, move like you know the floor is thin."

"I keep thinking about Article Nine," he said. "It's not a suggestion. It's the first thing they ever agreed to."

Mira stirred her tea and said nothing, and her silence was its own kind of answer.

That night he began copying everything. Every edit, every checksum, every masked timestamp, into a private store no one would think to audit. It would take weeks. It would take care, and patience, and a way to speak to eleven thousand people at once. He did not yet know how. But he knew he would not leave the crack sealed.

The public address system was old, maintained more out of habit than need, and that was its weakness. Tomas had spent four nights mapping its relay logic from maintenance diagrams no one had updated in twenty years. A junction box in the corridor outside hydroponics served as its master relay, and his credentials opened it without a flicker of alarm. He spliced a small transmitter into the spare channel, wrote a routine that would seize every speaker on the ship at once, and tested it with a two-second tone he hoped no one would notice. No one did.

He recorded the message in a supply closet, whispering into his tablet. He named the edits, the dates, the checksums. He described the course change of forty years ago, the destination the ship no longer sailed toward, the one the council had buried beneath a clean and quiet lie. He kept his voice steady. He said that whatever the passengers decided, they deserved to decide it. When he finished, his hands were shaking, and he saved the file beside the transmitter routine.

They came for him at the end of his shift. Two security officers, polite and unhurried, stood in the maintenance bay doorway as though they had all the time in the world. "Tomas Okafor," one said. "You'll come with us." They took his tablet, his tools, the relay key from his pocket. He did not resist. There was nothing to resist with.

The council chamber was full. Voss sat at the center of the long table and did not look at him as she spoke. "Attempted sabotage of ship systems," she said. "A tampered relay, a forged broadcast. We have the evidence." Tomas stood with his wrists loose at his sides and said what he had said into the tablet. The passengers built this ship's future with their labor. They had a right to know where it was pointed. A few councilors looked away. Most did not.

The vote was quick. Confined to quarters, pending review. Voss finally met his eyes as the officers took his arms. "You'll thank us someday," she said. He did not believe her.

The door to his quarters slid open just wide enough for Mira to slip through, her maintenance uniform rumpled, a data slate clutched against her chest. The guard outside didn't turn around. Tomas sat up on the bunk, and she pressed a finger to her lips before he could speak.

"I copied it," she whispered. "Everything you pulled. The logs, the edits, the course heading from forty years ago. It's on this slate and two backups." She set it on the desk between them. "I read all of it twice. Voss is wrong. Whatever happens out there, it isn't hers to decide for eight thousand people."

Tomas stared at her. "You could be confined too."

"I know." She pulled a thin coil of wire from her pocket and held it up. "But the night maintenance rotation is mine to run, and the guard on this corridor owes me a favor. Come on."

They moved through the service crawlways single file, Mira leading with a penlight clamped in her teeth. At a junction node she spliced his slate into the ship's internal comm array, and Tomas's hands shook as he keyed the sequence. His voice, when he began, came out steadier than he felt. He read the evidence aloud: the original destination, the false hope, the forty years of quiet edits. He gave the coordinates. He told them who had done it and why.

Then he released the files and let the channel stay open.

Mira pulled the splice. In the maintenance node's cramped dark, the two of them sat with their backs against the bulkheads, and the ship's hum went on around them, unchanged and enormous, and they waited.