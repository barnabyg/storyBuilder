At dusk she climbed the tower as she did every night, though the station had been dark for years and no ship on that coast needed her. She set the lamp and lit it anyway, and the old glass threw its slow wheel of light out over the water.

“Well, Tom,” she said, her voice small in the iron room. “They came and took her off the mooring. Signed her away this morning, and I stood there and did it.”

The light turned. She remembered him on the wharf with Eli’s boy, no taller than the bait bucket, Tom’s big hands guiding the small ones over a trap’s latch, patient as the tide. She remembered the two families bent over nets together, the smell of tar and the boys tangling the twine and the laughter when Eli’s wife brought out bread. All of it gone soft at the edges now, like a photograph left in the sun.

She went down and wrote the letter. She was careful with it, each word set down as though she were laying stone. She sealed it and set it on the table beside the tide-table page, and then she sat with it through the dark hours.

At dawn she climbed again. The Marigold lay in the shallows where Eli had moored her, small and patient. Ada looked down at her a long while, and made her choice.