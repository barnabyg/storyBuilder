# Run report: development-tier-selection-20261027-tier-L

- **Status:** succeeded
- **Started:** 2026-10-27T17:30:30.858908+00:00
- **Finished:** 2026-10-27T17:31:58.801810+00:00
- **Git SHA:** `3f29d9cd83e11b038a6dd963b6f7f168c93ed48e` (dirty)
- **Config:** `C:\docs\git\storyBuilder\.nde\dev-tier-selection-20261027\comparison-01\configs\L.yaml` (hash `f37230c222fc`)
- **Seed:** 1700
- **Cache:** use, 76 hits, 15 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | deepseek | deepseek-flash | deepseek |

## Prompt templates

- `plan_skeleton@1` (sha256 `01a419126a5e`)
- `plan_channels@1` (sha256 `1297b1368ce8`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-01, brief-02 (from `C:\docs\git\storyBuilder\benchmark`)
- **Frozen splits:** none
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 3 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | C | 1 | 0 | 2000 | 0 | no | 0 | failed | 19 | 462320 | 189155 | $0.3657 | $0.0000 | [planning-provenance.json](stories/C/brief-01/r1/planning-provenance.json) [skeleton.json](stories/C/brief-01/r1/skeleton.json) |
| brief-01 | B | 1 | 1878 | 2000 | 1 | yes | 0 | ok | 9 | 6342 | 3422 | $0.0060 | $0.0000 | [outline.json](stories/B/brief-01/r1/outline.json) [story.md](stories/B/brief-01/r1/story.md) [story.raw.md](stories/B/brief-01/r1/story.raw.md) |
| brief-02 | C | 1 | 2105 | 2000 | 3 | yes | 0 | ok | 28 | 240904 | 67405 | $0.1532 | $0.0279 | [cards.html](stories/C/brief-02/r1/cards.html) [cards.md](stories/C/brief-02/r1/cards.md) [ledger.json](stories/C/brief-02/r1/ledger.json) [plan-selection.json](stories/C/brief-02/r1/plan-selection.json) [plan.json](stories/C/brief-02/r1/plan.json) [planning-provenance.json](stories/C/brief-02/r1/planning-provenance.json) [skeleton.json](stories/C/brief-02/r1/skeleton.json) [source-plan.json](stories/C/brief-02/r1/source-plan.json) [story.md](stories/C/brief-02/r1/story.md) [story.raw.md](stories/C/brief-02/r1/story.raw.md) [validation.json](stories/C/brief-02/r1/validation.json) |
| brief-02 | B | 1 | 2166 | 2000 | 1 | yes | 24 | ok | 35 | 84145 | 77530 | $0.1183 | $0.0000 | [outline.json](stories/B/brief-02/r1/outline.json) [story.md](stories/B/brief-02/r1/story.md) [story.original.md](stories/B/brief-02/r1/story.original.md) [story.raw.md](stories/B/brief-02/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 2 | 1 | 47 | 703224 | 256560 | $0.5188 | $0.0279 | $0.2594 |
| B | 2 | 0 | 44 | 90487 | 80952 | $0.1243 | $0.0000 | $0.0621 |

### Failed stories

- C/brief-01 #1: step 'channels-sc-07': Invalid JSON: EOF while parsing a string at line 1 column 61492

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 2 | 47 | 959784 | 479892 |
| B | 2 | 44 | 171439 | 85720 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 10% of the larger, with at most 24 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | 1 | 651475 | 9764 | - | 0 | 651475 | 9764 | no | no story to match: C failed |
| brief-02 | 1 | 308309 | 7766 | B | 24 | 308309 | 161675 | no | not within 10% after 24 revision passes |

0 matched, 2 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-01 repetition 1: unresolved
- C: final `stories/C/brief-01/r1/story.md`, SHA-256 `None`; None words; 651475 tokens; new spend USD 0.000000
- B: final `stories/B/brief-01/r1/story.md`, SHA-256 `effe7e0cdeccbbcbc84dd9c26a311906f73ce754cc321a91c597d4c5b6833779`; 1878 words; 9764 tokens; new spend USD 0.000000
- Unresolved: C: final prose unavailable or failed
- Unresolved: C: final length invalid or differs from saved record
- Unresolved: budget comparison incomplete or unmatched
- Unresolved: actual attributable tokens outside budget tolerance

brief-02 repetition 1: unresolved
- C: final `stories/C/brief-02/r1/story.md`, SHA-256 `767fc2fb95bbcd7378bf8a8ab75b9f6554bd15e7f8b78fed4cc46ce82531d59d`; 2105 words; 308309 tokens; new spend USD 0.027899
- B: final `stories/B/brief-02/r1/story.md`, SHA-256 `14ca81fc7446e9b6d5b3c965c10a51d2109a6a9d69e64a653f150023e4674f68`; 2166 words; 161675 tokens; new spend USD 0.000000
- Unresolved: budget comparison incomplete or unmatched
- Unresolved: actual attributable tokens outside budget tolerance

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 16 | 31.2% | 93.8% | 68.8% | 1 |

## Cost

- New spend this run: $0.0279
- Token cost at list price, including cache hits: $0.6431
- Tokens: 793711 input, 337512 output
- Per-run cap: $1.5000; per-day cap: $3.0000
- Spent today (UTC, all runs): $0.7993

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 91 | 76 | 793711 | 337512 | $0.0279 | $0.6431 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-01/skeleton #1 | 1 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 7382 | 3819 | $0.0000 | 18.38 | 0 |
| C/brief-01/skeleton #1 | 2 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 11241 | 3818 | $0.0000 | 11.79 | 0 |
| C/brief-01/skeleton #1 | 3 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 15146 | 3784 | $0.0000 | 11.86 | 0 |
| C/brief-01/channels-sc-01 #1 | 1 | deepseek-flash | plan_channels@1 | 1082539864 | yes | 11306 | 4962 | $0.0000 | 17.64 | 0 |
| C/brief-01/channels-sc-02 #1 | 1 | deepseek-flash | plan_channels@1 | 953394149 | yes | 12284 | 6452 | $0.0000 | 23.14 | 0 |
| C/brief-01/channels-sc-02 #1 | 2 | deepseek-flash | plan_channels@1 | 953394149 | yes | 18799 | 6298 | $0.0000 | 18.67 | 0 |
| C/brief-01/channels-sc-02 #1 | 3 | deepseek-flash | plan_channels@1 | 953394149 | yes | 25129 | 6198 | $0.0000 | 18.11 | 0 |
| C/brief-01/channels-sc-03 #1 | 1 | deepseek-flash | plan_channels@1 | 1955734615 | yes | 13520 | 7874 | $0.0000 | 27.21 | 0 |
| C/brief-01/channels-sc-03 #1 | 2 | deepseek-flash | plan_channels@1 | 1955734615 | yes | 21454 | 7671 | $0.0000 | 21.95 | 0 |
| C/brief-01/channels-sc-04 #1 | 1 | deepseek-flash | plan_channels@1 | 199251043 | yes | 14993 | 9981 | $0.0000 | 34.33 | 0 |
| C/brief-01/channels-sc-04 #1 | 2 | deepseek-flash | plan_channels@1 | 199251043 | yes | 25031 | 9754 | $0.0000 | 28.66 | 0 |
| C/brief-01/channels-sc-05 #1 | 1 | deepseek-flash | plan_channels@1 | 1275523251 | yes | 17076 | 12205 | $0.0000 | 43.30 | 0 |
| C/brief-01/channels-sc-05 #1 | 2 | deepseek-flash | plan_channels@1 | 1275523251 | yes | 29355 | 11830 | $0.0000 | 35.01 | 0 |
| C/brief-01/channels-sc-06 #1 | 1 | deepseek-flash | plan_channels@1 | 1833688629 | yes | 19152 | 15432 | $0.0000 | 54.68 | 0 |
| C/brief-01/channels-sc-06 #1 | 2 | deepseek-flash | plan_channels@1 | 1833688629 | yes | 34616 | 15077 | $0.0000 | 43.22 | 0 |
| C/brief-01/channels-sc-07 #1 | 1 | deepseek-flash | plan_channels@1 | 1997237674 | yes | 22399 | 16000 | $0.0000 | 44.33 | 0 |
| C/brief-01/channels-sc-07 #1 | 2 | deepseek-flash | plan_channels@1 | 1997237674 | yes | 38439 | 16000 | $0.0000 | 47.87 | 0 |
| C/brief-01/channels-sc-07 #1 | 3 | deepseek-flash | plan_channels@1 | 1997237674 | yes | 54479 | 16000 | $0.0000 | 45.89 | 0 |
| C/brief-01/channels-sc-07 #1 | 4 | deepseek-flash | plan_channels@1 | 1997237674 | yes | 70519 | 16000 | $0.0000 | 46.06 | 0 |
| B/brief-01/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 569 | 1147 | $0.0000 | 9.80 | 0 |
| B/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 601 | 269 | $0.0000 | 3.18 | 0 |
| B/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 683 | 363 | $0.0000 | 3.77 | 0 |
| B/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 658 | 256 | $0.0000 | 2.88 | 0 |
| B/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 692 | 230 | $0.0000 | 2.39 | 0 |
| B/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 737 | 282 | $0.0000 | 3.15 | 0 |
| B/brief-01/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 778 | 302 | $0.0000 | 3.39 | 0 |
| B/brief-01/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 786 | 313 | $0.0000 | 3.22 | 0 |
| B/brief-01/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 838 | 260 | $0.0000 | 2.77 | 0 |
| C/brief-02/skeleton #1 | 1 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 7364 | 2515 | $0.0000 | 10.37 | 0 |
| C/brief-02/skeleton #1 | 2 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 9927 | 2528 | $0.0000 | 7.67 | 0 |
| C/brief-02/skeleton #1 | 3 | deepseek-flash | plan_skeleton@1 | 2055141883 | yes | 12558 | 2581 | $0.0000 | 8.77 | 0 |
| C/brief-02/channels-s1 #1 | 1 | deepseek-flash | plan_channels@1 | 1310279880 | yes | 9960 | 2657 | $0.0000 | 8.79 | 0 |
| C/brief-02/channels-s2 #1 | 1 | deepseek-flash | plan_channels@1 | 1407915137 | yes | 9960 | 4442 | $0.0000 | 14.93 | 0 |
| C/brief-02/channels-s2 #1 | 2 | deepseek-flash | plan_channels@1 | 1407915137 | yes | 14459 | 4261 | $0.0000 | 12.22 | 0 |
| C/brief-02/channels-s3 #1 | 1 | deepseek-flash | plan_channels@1 | 1438285283 | yes | 10468 | 3963 | $0.0000 | 13.29 | 0 |
| C/brief-02/channels-s4 #1 | 1 | deepseek-flash | plan_channels@1 | 206457204 | yes | 11266 | 5385 | $0.0000 | 18.37 | 0 |
| C/brief-02/channels-s4 #1 | 2 | deepseek-flash | plan_channels@1 | 206457204 | yes | 16707 | 5227 | $0.0000 | 15.27 | 0 |
| C/brief-02/channels-s4 #1 | 3 | deepseek-flash | plan_channels@1 | 206457204 | yes | 21968 | 5143 | $0.0000 | 14.99 | 0 |
| C/brief-02/channels-s5 #1 | 1 | deepseek-flash | plan_channels@1 | 1525124974 | yes | 12446 | 6728 | $0.0000 | 23.16 | 0 |
| C/brief-02/channels-s5 #1 | 2 | deepseek-flash | plan_channels@1 | 1525124974 | yes | 19251 | 6748 | $0.0000 | 19.62 | 0 |
| C/brief-02/channels-s5 #1 | 3 | deepseek-flash | plan_channels@1 | 1525124974 | yes | 26050 | 6608 | $0.0000 | 19.15 | 0 |
| C/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 2070 | 583 | $0.0013 | 5.77 | 0 |
| C/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 2969 | 841 | $0.0019 | 7.82 | 0 |
| C/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 4251 | 592 | $0.0020 | 5.91 | 0 |
| C/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 4592 | 487 | $0.0020 | 4.94 | 0 |
| C/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 5594 | 647 | $0.0025 | 7.05 | 0 |
| C/brief-02/scene-01 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 2070 | 655 | $0.0014 | 6.27 | 0 |
| C/brief-02/scene-02 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 2957 | 601 | $0.0016 | 5.90 | 0 |
| C/brief-02/scene-03 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 4277 | 563 | $0.0020 | 5.42 | 0 |
| C/brief-02/scene-04 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 4604 | 566 | $0.0021 | 5.49 | 0 |
| C/brief-02/scene-05 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 5605 | 458 | $0.0022 | 4.88 | 0 |
| C/brief-02/scene-01 (attempt 3) #1 | 1 | deepseek-flash | scene_prose@1 | 868820297 | no | 2070 | 584 | $0.0013 | 5.89 | 0 |
| C/brief-02/scene-02 (attempt 3) #1 | 1 | deepseek-flash | scene_prose@1 | 868820297 | no | 2941 | 592 | $0.0016 | 5.65 | 0 |
| C/brief-02/scene-03 (attempt 3) #1 | 1 | deepseek-flash | scene_prose@1 | 868820297 | no | 4298 | 430 | $0.0018 | 4.93 | 0 |
| C/brief-02/scene-04 (attempt 3) #1 | 1 | deepseek-flash | scene_prose@1 | 868820297 | no | 4631 | 565 | $0.0021 | 6.33 | 0 |
| C/brief-02/scene-05 (attempt 3) #1 | 1 | deepseek-flash | scene_prose@1 | 868820297 | no | 5591 | 455 | $0.0022 | 4.90 | 0 |
| B/brief-02/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 554 | 931 | $0.0000 | 6.83 | 0 |
| B/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 532 | 378 | $0.0000 | 3.61 | 0 |
| B/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 608 | 418 | $0.0000 | 4.12 | 0 |
| B/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 617 | 378 | $0.0000 | 4.20 | 0 |
| B/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 665 | 495 | $0.0000 | 4.84 | 0 |
| B/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 705 | 437 | $0.0000 | 4.45 | 0 |
| B/brief-02/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 702 | 346 | $0.0000 | 3.82 | 0 |
| B/brief-02/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | yes | 2679 | 2450 | $0.0000 | 9.96 | 0 |
| B/brief-02/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | yes | 2678 | 2531 | $0.0000 | 11.38 | 0 |
| B/brief-02/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | yes | 2759 | 2631 | $0.0000 | 11.83 | 0 |
| B/brief-02/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | yes | 2859 | 2631 | $0.0000 | 11.53 | 0 |
| B/brief-02/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | yes | 2859 | 2708 | $0.0000 | 11.88 | 0 |
| B/brief-02/revision-05 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1289824051 | yes | 2859 | 2631 | $0.0000 | 10.98 | 0 |
| B/brief-02/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | yes | 2859 | 2631 | $0.0000 | 11.55 | 0 |
| B/brief-02/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | yes | 2859 | 2631 | $0.0000 | 10.67 | 0 |
| B/brief-02/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | yes | 2859 | 2631 | $0.0000 | 11.29 | 0 |
| B/brief-02/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | yes | 2859 | 2631 | $0.0000 | 11.11 | 0 |
| B/brief-02/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | yes | 2859 | 2631 | $0.0000 | 10.90 | 0 |
| B/brief-02/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | yes | 2859 | 2631 | $0.0000 | 11.24 | 0 |
| B/brief-02/revision-14 #1 | 1 | deepseek-flash | story_revision@1 | 954275669 | yes | 2859 | 2633 | $0.0000 | 11.34 | 0 |
| B/brief-02/revision-15 #1 | 1 | deepseek-flash | story_revision@1 | 784163321 | yes | 2861 | 3005 | $0.0000 | 14.95 | 0 |
| B/brief-02/revision-15 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1444081430 | yes | 2861 | 2633 | $0.0000 | 10.84 | 0 |
| B/brief-02/revision-16 #1 | 1 | deepseek-flash | story_revision@1 | 222805417 | yes | 2861 | 2697 | $0.0000 | 12.10 | 0 |
| B/brief-02/revision-16 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 60911096 | yes | 2861 | 2649 | $0.0000 | 11.39 | 0 |
| B/brief-02/revision-17 #1 | 1 | deepseek-flash | story_revision@1 | 821015077 | yes | 2877 | 2706 | $0.0000 | 11.83 | 0 |
| B/brief-02/revision-17 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 278137146 | yes | 2877 | 2649 | $0.0000 | 11.03 | 0 |
| B/brief-02/revision-18 #1 | 1 | deepseek-flash | story_revision@1 | 913302983 | yes | 2877 | 2649 | $0.0000 | 11.07 | 0 |
| B/brief-02/revision-19 #1 | 1 | deepseek-flash | story_revision@1 | 733295078 | yes | 2877 | 2649 | $0.0000 | 10.92 | 0 |
| B/brief-02/revision-20 #1 | 1 | deepseek-flash | story_revision@1 | 1916088092 | yes | 2877 | 2649 | $0.0000 | 11.60 | 0 |
| B/brief-02/revision-21 #1 | 1 | deepseek-flash | story_revision@1 | 1711196134 | yes | 2877 | 2649 | $0.0000 | 11.78 | 0 |
| B/brief-02/revision-22 #1 | 1 | deepseek-flash | story_revision@1 | 753832799 | yes | 2877 | 2649 | $0.0000 | 10.77 | 0 |
| B/brief-02/revision-23 #1 | 1 | deepseek-flash | story_revision@1 | 1829762830 | yes | 2877 | 2650 | $0.0000 | 10.90 | 0 |
| B/brief-02/revision-24 #1 | 1 | deepseek-flash | story_revision@1 | 1562121133 | yes | 2878 | 2650 | $0.0000 | 11.20 | 0 |
