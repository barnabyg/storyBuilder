Mercer's office was small and warm, and she did not look surprised to see him. She set down her tea, folded her hands on the desk, and listened while he laid it out—the checksum, the backups, the decades of small amendments that added up to a ship pointed somewhere other than where the charter said it was going.

When he finished, she said, "Yes."

Tomas had prepared for denial. He had prepared for anger, for procedure, for being told he had exceeded his clearance. He had not prepared for *yes*.

"Say that again," he said.

"The edits were authorized. By this council, and the ones before it." She turned her cup a quarter turn, aligning it with the edge of the desk. "You're the first person in thirty years to find them. I'd hoped the checksums would hold."

"You hoped—" He stopped. "Councilor, the charter is posted in every corridor. It gives a heading. It gives a destination. That heading is a lie."

"The charter gives the heading we chose." Mercer's voice stayed level. "Tomas, sit down. Please. You've been in the vault a long time."

He did not sit. She went on anyway.

"The founders knew what was on the original line. A debris field, a swath of it, wide enough that threading it would have cost the ship more than we could spare. They ran the numbers and they knew the passengers would not vote to go around it—not if it meant adding years, not if it meant arriving to a world their grandchildren would have to be old to see. So they went around it, and they did not tell anyone. The first edits were theirs."

"And you inherited them."

"We inherited them." She looked at him steadily. "And we kept them, because the founders were right about what people do when you take away the thing they were promised."

"You don't know that."

"No. I know that stability is the only thing keeping eleven thousand people from turning on each other in a sealed hull." She leaned back. "You trust records. I understand that; I chose you for maintenance because you trust records. So here is the record, Tomas, honestly, from me: I am asking you to weigh a quiet ship against a truth the passengers never consented to receive. Not because I think they're children. Because I think they're people, and people are frightened, and frightened people in a closed space do damage that takes generations to repair."

"And if they'd wanted to choose?"

"Then they should have been asked a hundred years ago by people who are long dead." Mercer's hands stayed folded. "We're the ones left holding it. What do you want me to do with it?"