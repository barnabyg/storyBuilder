Mercer's office was warm, which Tomas had always found obscene on a ship where heat had to be budgeted. She listened to his whole account without interrupting, her hands folded on the desk, and when he finished she did not deny a single word.

"Yes," she said. "The edits were authorized. By this council, and by the ones before us."

He had prepared for evasion, for indignation, for the careful machinery of denial. Her calm undid him more thoroughly than any threat could have.

"Then you know what it means," he said. "The log is the ship's memory. If it can be rewritten—"

"The founders knew where we were going," Mercer said. "They also knew what was there." She turned her screen toward him and brought up a document he had never seen, sealed with the founders' signatures. "A debris field, Tomas. Not dense, but wide, and moving. The projections from a century ago were not gentle. The founders calculated our chances and decided the passengers could not be asked to bear that knowledge—decades of it, with nothing to do but wait and imagine."

"So they lied."

"They chose a course that goes around it. The ship is safe. It has been safe every day of your life, because of a decision made before you were born."

Tomas pressed his palms flat against his knees to keep them still. "And the passengers? They think we're bound for the original destination. They've built their whole lives around arriving there."

Mercer nodded slowly, as though he had finally said something worth her time. "Now you see the shape of it. If I announce the truth tomorrow, I am telling eighty thousand people their grandparents were lied to, their destination is gone, and their consent was never wanted. What grows in that soil, Tomas? Reason? Or a mob looking for someone to blame?" She leaned back. "You value records because they don't have reasons. But people do, and I am asking you to weigh one against the other: the stability of this ship, against a truth no one aboard ever agreed to receive."