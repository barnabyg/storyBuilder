Tomas walked the long way back to his quarters, through corridors that smelled of recycled air and warm wiring. He passed families at their evening meals, children chasing a ball along the walkway, an old man mending a chair. All of them going about lives built on a promise.

Inside his cabin he sat at his desk and called up the ship's charter. It was old text, ratified before launch, buried three menus deep in the public archive where almost no one ever looked. He read it slowly, the way he read everything.

*Article Nine. Alterations to the Meridian's declared destination or heading shall require the informed consent of the passenger body, expressed by general ballot.*

He read it twice more. Then he opened the navigation logs beside it and laid the dates side by side, and the plain fact of it settled on him like a weight. Forty years of edits. A course change no one had voted on. The council had not merely hidden something; they had broken the founding law of the ship.

He thought about copying the files to a public queue. It would take four minutes. He imagined the door of his quarters opening in the night, security in the frame, his name struck from the duty roster, his bunk reassigned. Who would he even be, without the work? He closed the terminal and sat in the dark for a while.

Mira found him in the mess hall the next morning, her tray set down across from his before he could pretend to be busy.

"You look like a man carrying a cracked reactor in his pocket," she said.

He told her, quietly, most of it. She listened without interrupting, which was not her habit.

"I'm not going to tell you it's nothing," she said at last. "But Voss doesn't bluff. If you move, move like you know the floor is thin."

"I keep thinking about Article Nine," he said. "It's not a suggestion. It's the first thing they ever agreed to."

Mira stirred her tea and said nothing, and her silence was its own kind of answer.

That night he began copying everything. Every edit, every checksum, every masked timestamp, into a private store no one would think to audit. It would take weeks. It would take care, and patience, and a way to speak to eleven thousand people at once. He did not yet know how. But he knew he would not leave the crack sealed.