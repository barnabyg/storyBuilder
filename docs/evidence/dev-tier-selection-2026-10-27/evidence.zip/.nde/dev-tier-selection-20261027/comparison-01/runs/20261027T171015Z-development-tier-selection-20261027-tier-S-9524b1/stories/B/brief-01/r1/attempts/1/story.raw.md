The tower stairs were cold under Ada's hand, the iron rail slick with the damp that came off the water after sundown. She climbed them anyway, as she had every night since the light had been struck from the register, and set her lamp on the old pedestal and lit it by hand. The flame guttered, then held. Below her the harbour lay in its usual scatter of lights, and there at the wharf, small and patient, rode the Marigold, her hull dark against the black water.

She signed the bill of sale at the kitchen table, her pen pressing harder than it needed to. Eli Pruitt sat across from her with his cap in his hands, his face flushed as though he'd run the length of the wharf. His traps had come up empty two seasons running; she knew that, and knew the price of knowing.

He said he had a plan for her, for the boat, and was gone before she could ask what plan.

When the door shut, Ada went down to the wharf and laid her palm flat against the nameplate, the letters cold and raised. She remembered Tom in the spring, on his knees with the caulking iron, whistling through his teeth, the smell of tar and varnish and his pipe smoke all mixed together in the sun.

In the morning she climbed the tower as she always did, though there was no light to tend and no ships to guide. The habit outlasted the job. From the gallery she could see the whole harbour laid out below her, the wharf and the boats and the road curving up past the chapel, and she was high enough that the wind took the edge off the sun.

A city car she didn't know sat at the end of the wharf, grey and clean, and Eli stood at its open window with his hands in his pockets, leaning down to talk to whoever was inside. The wind carried most of it away, but it carried some. She heard total loss and then, after a pause, the surveyor won't ask questions.

She came down the stairs slowly, one hand on the rail, and crossed the wharf as though she were only going about her morning. Eli turned when he heard her boots on the boards. His face did something quick and badly managed.

"Ada. Morning."

"Morning."

"This is my cousin," he said. "From Plymouth. Just passing through."

The man in the car lifted two fingers from the wheel and didn't smile. Eli's hands had come out of his pockets and they shook, small and steady, the way a man shakes when he's been holding something in too long.

She left them to it and went into the shed for the tide tables, because the tide was what she'd come for. The book lay open on the bench where Eli had been reading it, and there, pencilled in the margin against a date, was a small cross. The new moon. The night the reef off Gull Point would be at its shallowest.

She closed the book on the mark and took it with her.

The kitchen smelled of wet wool and yesterday's coffee. Ada laid the page on the table and smoothed it flat with the heel of her hand. The tide-table, the night's run of tide inked in, the reef marked in her own careful pencil.

Eli looked at it. He didn't touch it.

The back door opened and Ruth came in with a colander of beans, her hands still damp from the garden. She stopped when she saw the page, and then she sat down slowly, as though her knees had given out, and set the colander on the floor beside her chair.

"The bank's given us thirty days," she said. "On the house."

Eli pushed his cup away. "It'll run aground on the reef," he said, quiet, almost gentle. "The insurer pays out. Nobody's on her, nobody gets hurt. That's all it is, Ada. A boat going on the rocks the way boats do." He looked at her. "Say nothing. That's all I'm asking."

Ada stood a moment. Then she went out through the back door, past the beans, down the path.

At the gate, Ruth caught her sleeve. "I'm sorry about Tom's boat," she said.

She brought Frank Dwyer a jar of preserves the next afternoon, the way she did most weeks, and set it on his kitchen table while the kettle came up. He had run the harbour office for forty years and still knew every hull that passed the point.

She told him a thing, not naming Eli, only a thing a keeper might have heard.

Frank turned his cup slowly. A report would mean an investigation, he said. A criminal charge. The Pruitts would lose the house, and there was no version where they didn't. He said the insurer, once it smelled fraud, might refuse to pay a penny. The Marigold would be seized as evidence and sit in a yard for years, rotting under a tarp, and never sail again either way. "Either way," he said again, quieter, and looked out at the water.

Ada walked home along the shore. The tide was slack and the evening had gone still, and there in the shallows lay the boat turned upside down in the water, mast and all, so clear she could have counted the planks. She stood a long while looking at it.

At dusk she climbed the tower as she did every night, though the station had been dark for years and no ship on that coast needed her. She set the lamp and lit it anyway, and the old glass threw its slow wheel of light out over the water.

"Well, Tom," she said, her voice small in the iron room. "They came and took her off the mooring. Signed her away this morning, and I stood there and did it."

The light turned. She remembered him on the wharf with Eli's boy, no taller than the bait bucket, Tom's big hands guiding the small ones over a trap's latch, patient as the tide. She remembered the two families bent over nets together, the smell of tar and the boys tangling the twine and the laughter when Eli's wife brought out bread. All of it gone soft at the edges now, like a photograph left in the sun.

She went down and wrote the letter. She was careful with it, each word set down as though she were laying stone. She sealed it and set it on the table beside the tide-table page, and then she sat with it through the dark hours.

At dawn she climbed again. The Marigold lay in the shallows where Eli had moored her, small and patient. Ada looked down at her a long while, and made her choice.

Before dark she saw him come down to the wharf and cast off, and she climbed the tower. The lamp was dark, of course, and the station radio had been dead for years, its speaker giving back nothing but a soft tick when she tried the switch. She stood a moment with her hand on the cold brass, then went down and out to the shed.

The boat's spare bilge pump hung on its nail where Tom had left it. She took it, and a length of good line, and carried them down to the wharf. Eli's skiff lay tied at the foot of the ladder. She set the pump and the coil of line in the bow and weighted them with a scrap of brick, and from her coat pocket took the pencil stub and the back of a tide-table she kept for figures. She wrote: If you're going to do this, do it honestly. She folded it once and tucked it under the line.

From the gallery she watched the Marigold's running lights creep out past the point and turn toward the reef, red and green, small as sparks. Then they stopped. They hung there a long while, drifting, and she could not tell what was happening aboard, and she did not go down.

At dawn the boat lay aground on the reef, canted and holed but not sunk, the swell breaking white along her flank. Eli stood in the shallows with the pump in his hands, looking up at the tower.

The surveyor came out on the noon tide, a thin man in a borrowed oilskin who walked the reef at low water with a notebook and a face that gave nothing away. He measured the holing twice, photographed the clean line of the gash, and stood a long while looking at the channel marks, which were where they had always been. By the week's end the letter came: the claim was refused, the loss attributed to navigation rather than misadventure, and Eli paid a fine at the constable's office and told anyone who asked that he had misread the channel in the dark, that it was his own foolishness and no one else's.

Ruth took the job at the cannery in town. Ada saw her at the bus stop on the Monday with a plastic lunch pail and her hair pinned back, and Ruth nodded to her, and Ada nodded back.

Frank Dwyer came up the hill on the Thursday. He stood in her kitchen with his hat in his hands and asked her straight whether she had known anything, that night, before it happened.

"Only that the sea does what it does," Ada said.

He looked at her a moment longer than was comfortable, then put his hat on.

When he was gone she took the letter from the drawer—the one she had written to the insurer, never sent, in her careful hand—and fed it to the stove page by page, and carried the ashes up the ninety-two steps and let the wind take them off the gallery into the grey water below.

The Marigold came apart on the shingle over three grey days, and on the fourth Eli and his boy hauled the nameplate and the wheelhouse door up the beach on a length of tarpaulin, the brass letters catching the light. Ada watched from her gate. The boy dragged his end with the solemn importance of a man twice his size, and Eli walked backwards, guiding, saying nothing.

At her gate he stopped. He reached into his coat and brought out Tom's compass, the brass dulled to a soft gold, the glass fogged at the edge.

"From the locker," he said. "Thought you'd want it."

She took it and felt its old familiar weight. Eli held her eyes a moment longer than he needed to, and then he nodded, once, and said, "Thank you," and did not say for what, and she did not ask.

At dusk she climbed the ninety-two steps. She stood a while in the lamp room with her hand on the cold housing, then left the lamp unlit and locked the door behind her.

She walked down to the water with the compass in her pocket and stood where the boat used to be tied, and the empty ring in the stone was cold under her fingers, and the tide came in.