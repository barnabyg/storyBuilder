At 22:00, ship time, the night shift changed over in Maintenance Bay Three, and Tomas Okafor began his audit.

He had done it the same way for four years: navigation log first, then the reactor telemetry, then the water reclamation stamps, each checked against the previous cycle's checksums. People drifted through the bay around him, laughing, arguing about the card game in the mess, and he let them drift. People forgot things. People misremembered, rounded, guessed. A record did none of that. A record either reconciled or it didn't, and when it didn't, it told you exactly where to look. He had said as much to Ildiko once, and she had laughed and called him a monk.

The first three checks reconciled. The fourth did not.

It was small — a maintenance stamp on the navigation log, a routine confirmation that the course solution had been verified against the star catalog. The hash came back one digit off from where it should have been. Tomas frowned and reran it. One digit off again, the same digit, in the same place. He pulled his hand terminal's calibration report. Clean. He ran a diagnostic on the bay's reader array. Clean. Which meant the fault was in him, or in his instruments, or in the log itself, and he knew which of those he trusted.

He flagged the stamp and moved on, and found two more before midnight. All on navigation stamps. All the same single-digit drift, spaced irregularly across the past three months, as though someone had been correcting them one at a time and had missed a carry somewhere.

Ildiko came off her shift at 23:40 and leaned on the bench beside him, drinking tea that smelled of burnt sugar. "You're still on the checksums."

"There's a mismatch. Three of them."

"Then write a ticket."

"I did. The ticket says the log is inconsistent with itself and I don't know why."

"So write that." She shrugged. "It's a stamp, Tomas. Stamps get reissued. Somebody fat-fingered a hash two months ago and it propagated. Report it, close it, come eat."

He looked at the three flagged entries on his screen, the identical clean drift of them, patient as a heartbeat. "I don't close tickets I can't explain," he said. "That's the whole point of a ticket."

Ildiko sighed and took her tea away.

The archive smelled of ozone and old plastic. Han's office was a converted storage bay, narrow and cold, its walls lined with racks of sealed media in gray cases.

"You want the navigation backups," Han said. He did not look up from his terminal. "Sealed means sealed, Okafor."

"Under maintenance protocol seven-four," Tomas said, "a log discrepancy exceeding zero-point-zero one percent entitles a certified technician to unsealed read access for reconciliation purposes." He had the citation ready on his tablet. He had rehearsed the sentence twice. "The discrepancy is four percent."

Han was quiet a moment, then took the tablet and read the protocol line by line, the way Tomas liked him for. "Four percent," he said at last. "That's not drift."

"No."

Han keyed in a release code and slid a drawer open. Inside were six chipped polymer discs, each labeled with a decade. "You sign them out one at a time," Han said. "You read them here. Nothing leaves this room."

Tomas took the oldest disc and sat at the reading terminal.

The comparison took him three hours. He wrote a script to align each backup against the next, vector by vector, and set it to flag every difference. The first flags came back small, a fraction of a degree. That was normal; course corrections were logged constantly, tiny nudges to hold the trajectory.

Then he noticed the shape of the edits. They were not corrections. They were removals. Each disc showed a logged vector correction—and the next disc, years later, showed the same correction quietly absent, replaced by a clean line of nominal heading. The timestamps had been rewritten to match. Whoever had done it had been patient. One edit every three or four years, each one covering the one before.

Tomas ran the chain backward, disc by disc, and plotted the headings as they had actually been flown. The line bent away from the charter heading in the very first decade and never bent back. He checked the public charter, the one printed on the wall of every passenger deck, the one children memorized in school. The ship was bound for Kepler's Reach, the charter said, and had been on course from the day of departure.

It had not. For forty years the ship had been flying somewhere else, and the record had been telling everyone otherwise.

Tomas sat very still in the cold room. He had trusted records the way other people trusted their families. A record did not lie to spare your feelings. A record did not have reasons. Somewhere behind him, the terminal hummed, waiting for him to decide what to do next.

Mercer's office was warm, which Tomas had always found obscene on a ship where heat had to be budgeted. She listened to his whole account without interrupting, her hands folded on the desk, and when he finished she did not deny a single word.

"Yes," she said. "The edits were authorized. By this council, and by the ones before us."

He had prepared for evasion, for indignation, for the careful machinery of denial. Her calm undid him more thoroughly than any threat could have.

"Then you know what it means," he said. "The log is the ship's memory. If it can be rewritten—"

"The founders knew where we were going," Mercer said. "They also knew what was there." She turned her screen toward him and brought up a document he had never seen, sealed with the founders' signatures. "A debris field, Tomas. Not dense, but wide, and moving. The projections from a century ago were not gentle. The founders calculated our chances and decided the passengers could not be asked to bear that knowledge—decades of it, with nothing to do but wait and imagine."

"So they lied."

"They chose a course that goes around it. The ship is safe. It has been safe every day of your life, because of a decision made before you were born."

Tomas pressed his palms flat against his knees to keep them still. "And the passengers? They think we're bound for the original destination. They've built their whole lives around arriving there."

Mercer nodded slowly, as though he had finally said something worth her time. "Now you see the shape of it. If I announce the truth tomorrow, I am telling eighty thousand people their grandparents were lied to, their destination is gone, and their consent was never wanted. What grows in that soil, Tomas? Reason? Or a mob looking for someone to blame?" She leaned back. "You value records because they don't have reasons. But people do, and I am asking you to weigh one against the other: the stability of this ship, against a truth no one aboard ever agreed to receive."

He did not go back to his bunk. He went to the maintenance deck, where Ildiko was halfway inside a scrubber housing, and told her everything, because she had a way of hearing a thing before you finished saying it.

She listened without interrupting, which was rare for her, and when he was done she wiped her hands on her coveralls and said, "So the council decided where we go. Without asking."

"To keep us alive," Tomas said. "That's their argument."

"Maybe it's even true." She sat down on an overturned crate. "But Tomas, my grandmother spent her whole life learning to be a farmer on a world she'll never see, because she was told that was the plan. She gave up children for it. If the plan changed, she deserved to know. We all did. Where we're going isn't a maintenance detail. It's the whole reason we're on this ship." She looked at him. "You don't get to carry people and not tell them where."

He went back to his console and opened a report form. Incident: navigation log integrity, unresolved. He typed for ten minutes—the checksum, the backups, the pattern of edits, the council's statement—and stopped at the closing line, where he was supposed to recommend a course of action. Recommend review by—and there he sat.

He read it back. A careful report, routed to the council, would vanish into a drawer. A careless one would vanish him. He saved it, deleted the closing paragraph, retyped it, deleted it again. The cursor blinked. Order on one side, consent on the other, and the form had a box for neither.

What finally settled it was smaller than either argument. He thought of the log itself—the clean checksums, the tidy decades of edits—and understood that he could no longer read it without wondering. Every course correction, every burn, every entry he'd ever signed off on. A record he could not trust was not a record at all. It was a story someone had chosen for him. He would rather have a truth that unsettled him than a file that lied to him kindly.

He closed the report.

He closed the report. Then he opened a channel to the shipwide relay and began routing the full, unedited navigation log through it.

The console chimed almost at once. Mercer's face appeared in the corner of the screen, gray and drawn. "Tomas. You have not sent it yet. I can see the queue."

"I'm sending it."

"Listen to me. One hour. Give me one hour to prepare the council, to draft a statement, to—" Mercer paused, and when he spoke again his voice had lost its usual evenness. "You don't know what happens on the other side of this. Neither do I. That's the point. We've kept them calm for thirty years. You are about to take that away from two thousand people in the time it takes to read a file."

Tomas looked at the queue. The checksum sat at the top of it, clean and whole, waiting.

"They're not cargo," he said. "They get to know where they're going."

"Tomas—"

He pressed send.

The relay took the file and pushed it out through every cabin speaker, every corridor panel, every hand terminal on the ship, the way emergency bulletins went out, prefixed by the soft three-note tone that meant attention, all hands. Tomas heard it echo down the maintenance corridor outside his door, faint and multiplied, the whole ship waking at once.

Then the voice of the ship's automated reader, flat and unhurried, began:

"Navigation log, full archive, unedited. Published by maintenance technician T. Okafor under emergency disclosure protocol. The vessel has not followed its filed course since year nineteen. On the order of the ship's council, the recorded heading was altered in successive revisions over a period of thirty-one years to conceal a change of course made in year nineteen. The destination of this ship is not the destination recorded in the public charter. The current heading and the original change of course are appended below in full. The council of this ship authorized and directed the concealment. The record you are hearing is the record as it was kept, before alteration."

The reader paused, the smallest gap, the way it did before a list.

"Appended: original course order, year nineteen. Signed, Captain—"

Tomas sat with his hands flat on the console and listened to the ship hear it.