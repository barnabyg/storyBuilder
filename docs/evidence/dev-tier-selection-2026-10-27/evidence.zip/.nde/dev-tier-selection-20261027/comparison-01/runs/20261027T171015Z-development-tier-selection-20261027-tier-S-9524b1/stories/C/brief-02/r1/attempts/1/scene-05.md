He closed the report. Then he opened a channel to the shipwide relay and began routing the full, unedited navigation log through it.

The console chimed almost at once. Mercer's face appeared in the corner of the screen, gray and drawn. "Tomas. You have not sent it yet. I can see the queue."

"I'm sending it."

"Listen to me. One hour. Give me one hour to prepare the council, to draft a statement, to—" Mercer paused, and when he spoke again his voice had lost its usual evenness. "You don't know what happens on the other side of this. Neither do I. That's the point. We've kept them calm for thirty years. You are about to take that away from two thousand people in the time it takes to read a file."

Tomas looked at the queue. The checksum sat at the top of it, clean and whole, waiting.

"They're not cargo," he said. "They get to know where they're going."

"Tomas—"

He pressed send.

The relay took the file and pushed it out through every cabin speaker, every corridor panel, every hand terminal on the ship, the way emergency bulletins went out, prefixed by the soft three-note tone that meant *attention, all hands*. Tomas heard it echo down the maintenance corridor outside his door, faint and multiplied, the whole ship waking at once.

Then the voice of the ship's automated reader, flat and unhurried, began:

*"Navigation log, full archive, unedited. Published by maintenance technician T. Okafor under emergency disclosure protocol. The vessel has not followed its filed course since year nineteen. On the order of the ship's council, the recorded heading was altered in successive revisions over a period of thirty-one years to conceal a change of course made in year nineteen. The destination of this ship is not the destination recorded in the public charter. The current heading and the original change of course are appended below in full. The council of this ship authorized and directed the concealment. The record you are hearing is the record as it was kept, before alteration."*

The reader paused, the smallest gap, the way it did before a list.

*"Appended: original course order, year nineteen. Signed, Captain—"*

Tomas sat with his hands flat on the console and listened to the ship hear it.