Mercer's office was small and warm, which Tomas had always taken as evidence of humility. She listened to him without interrupting, her hands folded on the desk, and when he finished she did not deny anything.

"Authorized," she said. "By the council, in closed session. The first edit was made before I was born, and I have signed off on every one since I took this seat."

The calm of it stopped him. He had prepared for evasion, for a lecture on procedure. He had not prepared for paperwork.

"The charter," he said. "The drawing in the commons. Origin to destination, one line."

"The charter shows where we tell people we are going." Mercer turned her screen toward him and brought up a star field, then a thin red line that ran out past the edge of it. "The founders' course led here. A debris field from a collapsed companion star—gravel at orbital speeds, too diffuse to see until you're in it. The survey drones found it eleven years out. The founders ran the numbers and concluded the ship would not survive the crossing. So they turned us, and they wrote a new line into the log, and they told no one."

"Why not tell them?"

"Because the founders were elected on that destination. The whole compact of this ship is that we are going somewhere. Pull the destination out from under a hundred thousand people and you don't get a debate. You get a mutiny, or worse—you get a generation that stops believing in the voyage at all. The ship needs hands. It needs people who believe the work means something."

Tomas looked at the red line. Eleven degrees off, and no one had ever seen it.

"You're asking me to weigh something," he said.

"I'm asking you to weigh it honestly." Mercer's voice had not risen once. "Stability against a truth these people never agreed to carry. I have carried it for twenty years. I am not certain I was right to. But I am certain that a maintenance technician deciding it alone, at night, is not how a ship should choose."