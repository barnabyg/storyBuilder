The Marigold came apart on the shingle over three grey days, and on the fourth Eli and his boy hauled the nameplate and the wheelhouse door up the beach on a length of tarpaulin, the brass letters catching the light. Ada watched from her gate. The boy dragged his end with the solemn importance of a man twice his size, and Eli walked backwards, guiding, saying nothing.

At her gate he stopped. He reached into his coat and brought out Tom's compass, the brass dulled to a soft gold, the glass fogged at the edge.

"From the locker," he said. "Thought you'd want it."

She took it and felt its old familiar weight. Eli held her eyes a moment longer than he needed to, and then he nodded, once, and said, "Thank you," and did not say for what, and she did not ask.

At dusk she climbed the ninety-two steps. She stood a while in the lamp room with her hand on the cold housing, then left the lamp unlit and locked the door behind her.

She walked down to the water with the compass in her pocket and stood where the boat used to be tied, and the empty ring in the stone was cold under her fingers, and the tide came in.