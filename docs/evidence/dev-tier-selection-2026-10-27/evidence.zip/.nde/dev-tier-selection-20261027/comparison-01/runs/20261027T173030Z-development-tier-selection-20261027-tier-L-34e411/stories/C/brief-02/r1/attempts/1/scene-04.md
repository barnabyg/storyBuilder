Ildiko found him in the maintenance bay after shift change, when the corridors had emptied and the only sound was the low hum of the scrubbers. He had the unedited log open on the bench display, the course change plotted in patient amber lines.

"You told Mercer," she said. It wasn't a question; the councilor's aide had already been through the deck asking quiet questions.

"I told her I knew."

Ildiko pulled a stool over and sat. She looked at the plot for a long moment, then at him. "Then you know what I think. They've been steering us for forty years and never once asked. My grandmother died believing she'd see the colony. She died in a corridor like this one, and nobody told her she was going somewhere else." She tapped the display. "People deserve to know where they're going. Even if it's bad. Maybe especially then."

He wanted to argue that she didn't understand the hazard, the founders' reasoning, the careful arithmetic of panic. But she was a shift-mate who had covered for him twice this year, and she was not wrong.

After she left, he opened a report form. *Navigation Log Discrepancy — Maintenance, Tier 3.* He typed the checksum failure, the reconstructed backups, the edit history spanning forty-one years. The form asked him to route it to his section chief, who would route it to Records, who would route it to the council. He stared at the routing field for a long time, then deleted the draft. He opened it again and wrote a shorter version, then deleted that too. Each version was a way of handing the problem upward, and each version would end in the same place: a sealed review, a quiet reassignment, a note in his file. Procedure was how the edits had survived. Procedure was a corridor with no windows.

He thought of his own logbooks, the ones he kept in pencil because he trusted them more than the terminals. A record you couldn't trust wasn't a record. It was a story someone told you and asked you not to check. He would rather have the unsettling truth than a clean file that lied — and if the passengers felt differently, that would be their choice to make, not Mercer's.

He saved the unedited log to a transfer chit, pocketed it, and went to find the broadcast desk.