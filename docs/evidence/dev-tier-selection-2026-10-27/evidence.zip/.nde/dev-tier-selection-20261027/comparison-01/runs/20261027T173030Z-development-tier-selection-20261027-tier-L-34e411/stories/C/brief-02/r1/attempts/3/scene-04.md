Ildiko found him in the maintenance bay at the end of the shift, hunched over a diagnostic slate he wasn't using. She didn't ask whether it was true. He had told her enough on the walk down, and she had listened without interrupting, which was its own kind of answer.

"So the founders pointed us at something bad," she said. "And instead of telling anyone, the council turned the ship around in the dark and kept the log pretty."

"That's the shape of it."

She was quiet a moment. Then: "My grandmother used to say we were bound for a place where the soil was already waiting for us. She died believing it. Everyone down there is living on a promise somebody wrote down before we were born." She turned her cup slowly on the bench. "If the promise is a lie, they deserve to know it's a lie. You don't get to decide for ten thousand people what they can carry. They're not cargo, Tomas. They're passengers. There's a difference, and it's the whole difference."

He pulled up the standard maintenance discrepancy form. It was a good form—he had always liked it. Clear fields, an audit trail, a named recipient, a procedure for escalation. He typed the summary line: *Navigation log checksum variance, historical, unresolved.* He typed the body, describing the backups, the edits, the reconstructed course. His hands were steady. The form asked for a severity classification, and he hovered over it, because the categories were all wrong. There was no box for *the ship is not going where you were told.* He saved the draft, read it back, and thought about how it would travel: to the shift supervisor, to the maintenance chief, to the council's records office, where a clerk would route it to a councilor who already knew. The form was a door that opened into a room he had already stood in.

He deleted it. The confirmation prompt asked if he was sure. He was not sure of anything except that he had just done something irreversible, and that the doing of it felt less like a fall than like setting down a weight.

He opened a blank document and began again, not a report. A statement. Names, dates, checksums, the full reconstructed log attached and unedited. He would read it aloud on the general channel at the start of the next watch, when the ship was between shifts and most people were awake.

"A record you can't trust isn't a record," he said, mostly to himself. "It's just a story someone's telling you. And I'd rather they told me a hard one than a kind one."

Ildiko watched him for a moment, then pulled her chair around to his side of the bench.