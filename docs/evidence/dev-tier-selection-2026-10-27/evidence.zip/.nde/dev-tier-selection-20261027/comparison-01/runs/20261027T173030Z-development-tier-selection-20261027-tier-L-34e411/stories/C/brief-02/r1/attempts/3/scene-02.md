The archive was kept cold, and Han kept it that way. Tomas found the archivist at the far end of the vault, seated at a desk that had been old when the ship was young, entering something into a ledger by hand.

"Tape access," Tomas said. "Sealed backups, navigation log, going back sixty years."

Han did not look up. "Sealed means sealed. You want the open shelf, it's down the corridor."

"I need the sealed set. Maintenance cross-check found a checksum that doesn't reconcile, and the current log is clean, so the discrepancy has to be in the retention chain. Procedure seven-four says a maintenance ticket can pull sealed media if the open record fails reconciliation." He had written the citation on a slip of paper and slid it across the desk. "Here's the ticket number. You can check it."

Han read the slip the way a man reads something he already knows. "Seven-four," he said. "Nobody's used seven-four in nine years."

"I'm using it now."

The archivist rose and went to the racks, and Tomas heard him key a code, then another, then a third, each one a small flat tone in the cold. Han pulled four spools and set them on the desk. He did not hand them over at once.

"These don't leave the room," Han said. "You read them here. And when you're done, you tell me what you found before you tell anyone else. That's not procedure. That's me asking."

Tomas agreed, because the alternative was to argue, and he wanted the tapes more than he wanted the argument.

He read them at the spare terminal, spooling each year against the one before it. The first comparison showed nothing. The second showed nothing. It was the third, the oldest against the newest, where the drift appeared: a line of vector correction here, a decimal there, each one small enough to be a rounding artifact and each one dated years apart from the next. He checked the edit timestamps. Twenty-two years. Thirty-four. Forty-one. Forty-nine. Never two in the same year, never two in the same decade. Whoever had done this had been patient the way a gardener is patient.

He summed the corrections by hand, twice, then a third time on the terminal, and the sum was a heading. Not the heading on the public charter, the one printed on the mess-hall wall beside the departure date and the destination and the little drawing of a sun. A different heading, off by eleven degrees, held steady for decades.

Tomas sat back. The cold of the archive came through his sleeves. He thought, absurdly, of the charter drawing, the neat line from origin to destination, and how a line eleven degrees off would still look, at a glance, like a line that went where it was supposed to go.