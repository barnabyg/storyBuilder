The ship's night cycle dimmed the corridors to a soft amber, but the maintenance bay on Deck Twelve stayed bright and cold. Tomas Okafor liked it that way. At 22:00, when the day shift handed over their unfinished tickets and their excuses, he sat down at the diagnostics console with his tea and began the audit he ran every night, whether the ship needed it or not.

He started with the environmental logs, then the water reclamation stamps, then the reactor's slow heartbeat of readings. Each one he checked against its checksum, the little arithmetic fingerprint that proved a record hadn't been touched since it was written. People forgot things. People rounded numbers, skipped steps, wrote down what they meant to do instead of what they did. The records never did. That was why he trusted them.

The navigation log was last, as always. He scrolled through the maintenance stamps — thruster calibration, star-tracker alignment, the quarterly inertial reference checks — and watched the checksums reconcile one after another, green, green, green. Then a yellow.

He frowned and ran it again. Yellow.

It was the stamp from a routine star-tracker alignment, three weeks back. The record's contents matched its checksum, but the checksum itself didn't match the one archived in the audit ledger. A mismatch of eleven characters. He pulled up the previous quarter's stamp: it reconciled cleanly. The quarter before that: clean. Then he searched backward, and the yellow appeared again, eight months ago, and again before that, at loose intervals, always on navigation maintenance stamps, always small.

He checked his own console's hash library. He re-ran the comparison on a secondary partition. He even dug out the old handheld verifier, though it hadn't been calibrated in a year. The mismatch followed him across all three. He sat back and stared at it, tea going cold.

"It's probably your verifier," said Ildiko, leaning over from the next station. She was halfway through her own shift report and clearly wanted to finish it. "Or the ledger's got a stale hash. Happens."

"Then the ledger's been stale for two years, in a pattern."

"So log it and move on. Maintenance stamps are housekeeping. Nobody died because a star-tracker stamp was off by eleven characters."

Tomas opened the ticket form, then closed it. Whatever this was, it wasn't a fault in his instruments, and it wasn't housekeeping. He couldn't write "checksum mismatch, cause unknown" and sign his name to it — a closed ticket was a claim that the record had been explained. He didn't have an explanation. He only had a question, and the question was growing.

"I'll report it when I know what it is," he said, and pulled the first backup tape from the archive shelf.

The archive was kept cold, and Han kept it that way. Tomas found the archivist at the far end of the vault, seated at a desk that had been old when the ship was young, entering something into a ledger by hand.

"Tape access," Tomas said. "Sealed backups, navigation log, going back sixty years."

Han did not look up. "Sealed means sealed. You want the open shelf, it's down the corridor."

"I need the sealed set. Maintenance cross-check found a checksum that doesn't reconcile, and the current log is clean, so the discrepancy has to be in the retention chain. Procedure seven-four says a maintenance ticket can pull sealed media if the open record fails reconciliation." He had written the citation on a slip of paper and slid it across the desk. "Here's the ticket number. You can check it."

Han read the slip the way a man reads something he already knows. "Seven-four," he said. "Nobody's used seven-four in nine years."

"I'm using it now."

The archivist rose and went to the racks, and Tomas heard him key a code, then another, then a third, each one a small flat tone in the cold. Han pulled four spools and set them on the desk. He did not hand them over at once.

"These don't leave the room," Han said. "You read them here. And when you're done, you tell me what you found before you tell anyone else. That's not procedure. That's me asking."

Tomas agreed, because the alternative was to argue, and he wanted the tapes more than he wanted the argument.

He read them at the spare terminal, spooling each year against the one before it. The first comparison showed nothing. The second showed nothing. It was the third, the oldest against the newest, where the drift appeared: a line of vector correction here, a decimal there, each one small enough to be a rounding artifact and each one dated years apart from the next. He checked the edit timestamps. Twenty-two years. Thirty-four. Forty-one. Forty-nine. Never two in the same year, never two in the same decade. Whoever had done this had been patient the way a gardener is patient.

He summed the corrections by hand, twice, then a third time on the terminal, and the sum was a heading. Not the heading on the public charter, the one printed on the mess-hall wall beside the departure date and the destination and the little drawing of a sun. A different heading, off by eleven degrees, held steady for decades.

Tomas sat back. The cold of the archive came through his sleeves. He thought, absurdly, of the charter drawing, the neat line from origin to destination, and how a line eleven degrees off would still look, at a glance, like a line that went where it was supposed to go.

Mercer's office was small and warm, which Tomas had always taken as evidence of humility. She listened to him without interrupting, her hands folded on the desk, and when he finished she did not deny anything.

"Authorized," she said. "By the council, in closed session. The first edit was made before I was born, and I have signed off on every one since I took this seat."

The calm of it stopped him. He had prepared for evasion, for a lecture on procedure. He had not prepared for paperwork.

"The charter," he said. "The drawing in the commons. Origin to destination, one line."

"The charter shows where we tell people we are going." Mercer turned her screen toward him and brought up a star field, then a thin red line that ran out past the edge of it. "The founders' course led here. A debris field from a collapsed companion star—gravel at orbital speeds, too diffuse to see until you're in it. The survey drones found it eleven years out. The founders ran the numbers and concluded the ship would not survive the crossing. So they turned us, and they wrote a new line into the log, and they told no one."

"Why not tell them?"

"Because the founders were elected on that destination. The whole compact of this ship is that we are going somewhere. Pull the destination out from under a hundred thousand people and you don't get a debate. You get a mutiny, or worse—you get a generation that stops believing in the voyage at all. The ship needs hands. It needs people who believe the work means something."

Tomas looked at the red line. Eleven degrees off, and no one had ever seen it.

"You're asking me to weigh something," he said.

"I'm asking you to weigh it honestly." Mercer's voice had not risen once. "Stability against a truth these people never agreed to carry. I have carried it for twenty years. I am not certain I was right to. But I am certain that a maintenance technician deciding it alone, at night, is not how a ship should choose."

Ildiko found him in the maintenance bay at the end of the shift, hunched over a diagnostic slate he wasn't using. She didn't ask whether it was true. He had told her enough on the walk down, and she had listened without interrupting, which was its own kind of answer.

"So the founders pointed us at something bad," she said. "And instead of telling anyone, the council turned the ship around in the dark and kept the log pretty."

"That's the shape of it."

She was quiet a moment. Then: "My grandmother used to say we were bound for a place where the soil was already waiting for us. She died believing it. Everyone down there is living on a promise somebody wrote down before we were born." She turned her cup slowly on the bench. "If the promise is a lie, they deserve to know it's a lie. You don't get to decide for ten thousand people what they can carry. They're not cargo, Tomas. They're passengers. There's a difference, and it's the whole difference."

He pulled up the standard maintenance discrepancy form. It was a good form—he had always liked it. Clear fields, an audit trail, a named recipient, a procedure for escalation. He typed the summary line: Navigation log checksum variance, historical, unresolved. He typed the body, describing the backups, the edits, the reconstructed course. His hands were steady. The form asked for a severity classification, and he hovered over it, because the categories were all wrong. There was no box for the ship is not going where you were told. He saved the draft, read it back, and thought about how it would travel: to the shift supervisor, to the maintenance chief, to the council's records office, where a clerk would route it to a councilor who already knew. The form was a door that opened into a room he had already stood in.

He deleted it. The confirmation prompt asked if he was sure. He was not sure of anything except that he had just done something irreversible, and that the doing of it felt less like a fall than like setting down a weight.

He opened a blank document and began again, not a report. A statement. Names, dates, checksums, the full reconstructed log attached and unedited. He would read it aloud on the general channel at the start of the next watch, when the ship was between shifts and most people were awake.

"A record you can't trust isn't a record," he said, mostly to himself. "It's just a story someone's telling you. And I'd rather they told me a hard one than a kind one."

Ildiko watched him for a moment, then pulled her chair around to his side of the bench.

Ildiko pulled her chair around to his side of the bench. "You know what happens if you do this," she said. "Not to the ship. To you."

"Probably," Tomas said. He was already keying the log into the public channel queue, the full unedited sequence, every checksum and every amendment, the original course and the hazard the founders had hidden at the end of it. His hands were steady the way they got when the work was clear. "The council won't want me touching the log after this. Maybe they'll want me somewhere else entirely."

"Tomas." Mercer's voice came through the console, thin, worn down. "I'm not asking you to believe me. I'm asking you to wait one shift. Let the council make the announcement on its own terms. Give people a chance to hear it from someone they trust."

"People trust the log," Tomas said. "That's the thing you spent forty years counting on. They trust it because it doesn't lie to them. If I wait, and you soften it, and I wait again, then the log is just another voice with an interest. It stops being the record. It becomes another politician." He toggled the channel open. "I'm not doing this to hurt you. I'm doing it because the record is the only thing on this ship that was ever supposed to be true."

Mercer said something else, but the channel swallowed her. Tomas set the playback to the beginning and pressed send.

"Attention, all decks," the automated voice said, flat and even. "A correction to the navigation log follows. The ship is not on its original course. The course was altered sixty-one years ago. The alteration was concealed from the record by order of the ship's council."

Ildiko's hand found his shoulder. He kept his eyes on the console, on the little bar of the transmission crawling forward.

"The original course led toward a hazard the founders concealed. The current course leads elsewhere. The council has known both facts and withheld them. The unedited log follows."

The bar reached the end. The channel clicked over to the log itself, and Tomas sat very still, and the whole ship listened.