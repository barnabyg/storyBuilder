# Development tier comparison

Comparison 11f1ba60ff57cb44ce8b5abcd22341fc188d830cbd30cc288c3cf6e54d60df58

Generation/budget status: incomplete

Owner dev judgement status: pending

LLM diagnostics cannot choose a tier or establish literary realisation.

## Tier S

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 19 | 651475 | 0.36568200 | 0 | False | False |
| brief-01 r0 | B | 9 | 9764 | 0.00600900 | 1878 | True | beat outline |
| brief-02 r0 | C | 18 | 247899 | 0.12946590 | 1920 | True | True |
| brief-02 r0 | B | 35 | 161675 | 0.11827950 | 2166 | True | beat outline |

Realisation ['brief-02']: owner pending; assessed 0/0; missing 0; unknown 0; alignment scene-aligned; stale [].

## Tier M

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 19 | 651475 | 0.00000000 | 0 | False | False |
| brief-01 r0 | B | 9 | 9764 | 0.00000000 | 1878 | True | beat outline |
| brief-02 r0 | C | 18 | 252207 | 0.00555480 | 1985 | True | True |
| brief-02 r0 | B | 35 | 161675 | 0.00000000 | 2166 | True | beat outline |

Realisation ['brief-02']: owner pending; assessed 0/11; missing 11; unknown 0; alignment scene-aligned; stale [].

## Tier L

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 19 | 651475 | 0.00000000 | 0 | False | False |
| brief-01 r0 | B | 9 | 9764 | 0.00000000 | 1878 | True | beat outline |
| brief-02 r0 | C | 28 | 308309 | 0.02789880 | 2105 | True | True |
| brief-02 r0 | B | 35 | 161675 | 0.00000000 | 2166 | True | beat outline |

Realisation ['brief-02']: owner pending; assessed 0/21; missing 21; unknown 0; alignment scene-aligned; stale [].

## Owner development judgements

[]

## Synthetic test-only judgements

[]

## Pending/problems

S: C/brief-01: selected prose unavailable: [Errno 2] No such file or directory: 'C:\\docs\\git\\storyBuilder\\.nde\\dev-tier-selection-20261027\\comparison-01\\runs\\20261027T171015Z-development-tier-selection-20261027-tier-S-9524b1\\stories\\C\\brief-01\\r1\\story.md'

S: C/brief-01: invalid length or incomplete budget

S: brief-01: plan invalid or missing

S: brief-01: unmatched experimental budgets

S: brief-02: unmatched experimental budgets

M: C/brief-01: selected prose unavailable: [Errno 2] No such file or directory: 'C:\\docs\\git\\storyBuilder\\.nde\\dev-tier-selection-20261027\\comparison-01\\runs\\20261027T173004Z-development-tier-selection-20261027-tier-M-d92ed5\\stories\\C\\brief-01\\r1\\story.md'

M: C/brief-01: invalid length or incomplete budget

M: brief-01: plan invalid or missing

M: brief-01: unmatched experimental budgets

M: brief-02: unmatched experimental budgets

L: C/brief-01: selected prose unavailable: [Errno 2] No such file or directory: 'C:\\docs\\git\\storyBuilder\\.nde\\dev-tier-selection-20261027\\comparison-01\\runs\\20261027T173030Z-development-tier-selection-20261027-tier-L-34e411\\stories\\C\\brief-01\\r1\\story.md'

L: C/brief-01: invalid length or incomplete budget

L: brief-01: plan invalid or missing

L: brief-01: unmatched experimental budgets

L: brief-02: unmatched experimental budgets
