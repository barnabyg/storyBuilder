"""Check only this task's loopback reader and persist its lifecycle reference."""
import json
import urllib.error
import urllib.request
from pathlib import Path

root=Path(__file__).resolve().parent
for page in (root/'public').glob('*.html'):
    with urllib.request.urlopen('http://127.0.0.1:18764/'+page.name,timeout=10) as response:
        assert response.status==200 and response.read()==page.read_bytes()
try:
    urllib.request.urlopen('http://127.0.0.1:18764/private/presentation-key.json',timeout=10)
    raise AssertionError('Private mapping exposed')
except urllib.error.HTTPError as error:
    assert error.code==404
path=root/'review-state.json'
state=json.loads(path.read_text(encoding='utf-8'))
state['reader_server_session_id']=89139
state['reader_http_checks']='Seven pages match checked files; private mapping returns 404.'
path.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Seven served pages verified; private mapping inaccessible; reading remains unstarted.')
