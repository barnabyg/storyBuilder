# Realisation review

Final story SHA-256: 1648e70c4d1eebc019d34ede7fb71a188e630c530bd06e53986fe40c6b880f89

Plan SHA-256: 5712d8b12bf3afb62ef2cf5df69a23e2efe9cbd650e05b05af0c80ef0a424147

Selected scene outputs match final prose.

Owner assessments pending. Planned intentions do not establish literary accuracy.

belief:st-tomas-doubt scenes ['s1']: {"id": "st-tomas-doubt", "scene_id": "s1", "character_id": "tomas", "kind": "belief", "key": "log-integrity", "before": {"value": "Navigation records are accurate and trustworthy", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The navigation log may have been altered by someone", "status": "known", "confidence": null, "alternatives": []}}

belief:st-tomas-belief-s2 scenes ['s2']: {"id": "st-tomas-belief-s2", "scene_id": "s2", "character_id": "tomas", "kind": "belief", "key": "log-integrity", "before": {"value": "The navigation log may have been altered by someone", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The log was deliberately edited for decades to hide a course change", "status": "known", "confidence": null, "alternatives": []}}

belief:st-tomas-belief-s3 scenes ['s3']: {"id": "st-tomas-belief-s3", "scene_id": "s3", "character_id": "tomas", "kind": "belief", "key": "institutional-trust", "before": {"value": "The council is a guardian of the ship's records", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The council is the author of the lie and cannot be trusted with the truth", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-tomas-halden-s2 scenes ['s2']: {"id": "rel-tomas-halden-s2", "scene_id": "s2", "participant_ids": ["tomas", "archivist-halden"], "key": "trust", "before": {"value": "Distant colleagues who share only routine archival requests", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Cautious co-conspirators bound by a shared secret", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-tomas-vey-s3 scenes ['s3']: {"id": "rel-tomas-vey-s3", "scene_id": "s3", "participant_ids": ["tomas", "councilor-vey"], "key": "trust", "before": {"value": "A junior technician and a distant authority he has never had reason to doubt", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Adversaries who each see the other as a threat to the ship's stability", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-tomas-soto-s4 scenes ['s4']: {"id": "rel-tomas-soto-s4", "scene_id": "s4", "participant_ids": ["tomas", "engineer-soto"], "key": "trust", "before": {"value": "Colleagues who share tools and shifts but never confide", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Two people who respect each other's warning yet cannot agree on what to do", "status": "known", "confidence": null, "alternatives": []}}

reveal:rev-course-halden scenes ['s2']: {"id": "rev-course-halden", "kind": "reveal", "fact_id": "fact-course-change", "scene_id": "s2", "holder_ids": ["archivist-halden"]}

reveal:rev-order-tomas scenes ['s3']: {"id": "rev-order-tomas", "kind": "reveal", "fact_id": "fact-council-order", "scene_id": "s3", "holder_ids": ["tomas"]}

reveal:rev-order-soto scenes ['s4']: {"id": "rev-order-soto", "kind": "reveal", "fact_id": "fact-council-order", "scene_id": "s4", "holder_ids": ["engineer-soto"]}

tension:tens-s1 scenes ['s1']: {"id": "tens-s1", "kind": "interpretation", "scene_ids": ["s1"], "reading": {"value": "Quiet unease as a small clerical error hints at something deliberate beneath the ship's orderly routine", "status": "known", "confidence": null, "alternatives": []}, "evidence": [], "trajectory": null}

tension:tens-s2 scenes ['s2']: {"id": "tens-s2", "kind": "interpretation", "scene_ids": ["s2"], "reading": {"value": "Dread deepens as the sealed backup proves the error is not an error but a long, patient lie", "status": "known", "confidence": null, "alternatives": []}, "evidence": [], "trajectory": null}

tension:tens-s3 scenes ['s3']: {"id": "tens-s3", "kind": "interpretation", "scene_ids": ["s3"], "reading": {"value": "Confrontation sharpens as the lie acquires a face and a justification, and neither side yields", "status": "known", "confidence": null, "alternatives": []}, "evidence": [], "trajectory": null}

tension:tens-s4 scenes ['s4']: {"id": "tens-s4", "kind": "interpretation", "scene_ids": ["s4"], "reading": {"value": "Squeeze of pressure as both reward and warning close in, and Tomas's refusal becomes its own kind of danger", "status": "known", "confidence": null, "alternatives": []}, "evidence": [], "trajectory": null}

tension:tens-s5 scenes ['s5']: {"id": "tens-s5", "kind": "interpretation", "scene_ids": ["s5"], "reading": {"value": "The broadcast releases the built pressure into open uncertainty, tension held rather than resolved as the ship waits.", "status": "known", "confidence": null, "alternatives": []}, "evidence": [], "trajectory": null}

## Final prose

The audit ran every sixty days, and in four years Tomas had never seen it return anything but green.

He sat in the narrow maintenance alcove off the navigation deck, a cup of cold tea at his elbow, and watched the progress bar crawl across the terminal. Navigation logs were the largest single dataset on the Ashgrove—forty-one years of position fixes, star sightings, thruster burns, and drift corrections, appended every six hours by a system that had never once complained. The audit hashed it in chunks. Each chunk got a checksum. Each checksum got compared against the value written when the chunk was sealed.

Chunk 11,882 flashed amber.

Tomas leaned in. Amber was not red. Amber meant verify. He pulled the report and read the line twice: stored hash ending in 4F2A, computed hash ending in 4F2B. One character. He had seen one-character mismatches before, and every one of them had come down to a bad memory sector or a clock skew in the checksum routine itself.

He ran the diagnostic. The checksum routine passed. He ran it again with a fresh seed. It passed again.

"All right," he said, to nobody.

He checked the sensor feeds that fed chunk 11,882—the star tracker and the inertial platform. Both reported nominal. He cross-referenced their timestamps against the log's own entries and found no gap, no duplicate, no out-of-order write. A sensor fault would have left fingerprints: a dropped frame, a repeated reading, a drift the platform's own self-test would have caught. There were none.

He pulled the raw bytes of the chunk and held them against the hash by hand, the way an instructor had once made him do it as an exercise, and got the same result. The stored checksum did not match the stored contents.

Which was impossible, unless someone had written to the chunk after it was sealed.

Tomas sat back. The alcove hummed with the ship's deep ventilation, the sound he had fallen asleep to his whole life. Somewhere above him, eleven thousand people went about their shifts, trusting that the deck beneath them was headed where the council said it was headed, because the records said so. He had always liked that. Records did not have moods. Records did not lie.

He looked at the amber line for a long moment, then opened a new workspace and saved a copy of the chunk, untouched, to his personal partition. Routine, he told himself. Verification. He would finish the audit, note the anomaly, and hand it up the chain in the morning.

But he did not close the terminal. He sat in the cold blue light and began, carefully, to look at what chunk 11,882 actually contained.

Halden arrived at the archive annex twenty minutes after Tomas's message, still in a work jacket with a tea stain on the sleeve, and found Tomas standing at the sealed cabinet with his hands folded behind his back like a man waiting at a funeral.

"Nobody's opened this in my tenure," Halden said. "I want that on the record."

"Put it on the record," Tomas said.

The archive's seal broke with a soft, official click. Inside, on a spool of self-contained storage, sat the navigation log as it had existed sixty years ago—quarterly snapshots, checksummed at write, never touched since. Halden mounted it to an isolated terminal, keyed in a verification code from memory, and stepped back. The backup's checksum resolved clean on the first pass. The living log, three meters away on the same network, did not.

"Read-only," Halden said. "Whatever you find, we don't touch the originals."

Tomas put both logs side by side on the screen and let the comparison routine run. It worked slowly, chunk by chunk, the way he preferred to work, and it began to disagree with itself almost immediately. Not a single corruption—a pattern. One entry in every ninety days, always in the same section, always rewritten cleanly, always re-signed with the same administrative credential. The edits were years old. Then decades.

He pulled the earliest one and opened the raw telemetry beside it. The old log said the ship had held its heading, 0.4 degrees off the galactic plane, since launch. The backup said otherwise. On a date sixty-one years past, the ship had begun to turn—a slow, deliberate arc across eleven weeks, small enough per day that no single day's telemetry looked wrong. By the end of it, the Resolution was pointed somewhere else entirely.

Tomas sat back. His chair creaked.

"They didn't just edit the log," he said. "They edited the sky. Every course projection since—every star chart the school kids get—it's all been built on the edited version."

Halden was quiet for a long moment. Then, quietly: "I've had three requests for this spool in eleven years. All of them withdrawn before I could pull it."

Tomas looked up.

"I filed them anyway," Halden said. "I just didn't file the withdrawals."

The council chamber was smaller than Tomas had expected, a converted equipment bay with a long table bolted to the deck and a single viewport showing nothing but the dark. Councilor Vey sat alone at the far end, her hands folded, as though she had been waiting for him since before he was born.

"You asked to see me about a filing irregularity," she said. "The archivist tells me it's more than that."

"The log's been edited," Tomas said. "Not corrupted. Edited. Forty years of course corrections, and every checksum after them rewritten to match. Someone went to a great deal of trouble to make the lie consistent."

Vey did not blink. "Yes. We did."

He had rehearsed a dozen ways she might deny it. None of them had prepared him for the ease of the admission.

"Then you know what it means," he said. "Every passenger aboard this ship believes we're bound for—"

"I know what they believe." Vey's voice stayed level. "I also know what they'd do if they learned the truth. When the course was changed, there was nearly a riot. Not a protest. A riot. People tried to seize the engine room. Two died. The council at the time made a choice: let the ship tear itself apart over a destination it could no longer reach, or keep the destination they could live with."

"So you kept lying."

"We kept the peace." She leaned forward, and for the first time something entered her face that looked like fear rather than authority. "You think I'm protecting the council's authority. I'm protecting four thousand people who don't have anywhere else to go. Tell them the truth now and you hand them a grievance with nothing to spend it on but each other."

Tomas thought of the backup, sealed and honest, holding everything the living log had erased. A ledger could be trusted or betrayed. He had spent his whole career on the trusting side of that line.

"They have a right to know where they're going," he said. "Even if it's nowhere. Even if it frightens them. You don't get to decide that for them and call it peace."

Vey regarded him for a long moment. "You're a junior technician," she said quietly. "You've never had to make a decision that costs lives."

"No," Tomas said. "I've only had to keep the records honest. It seems I'm the last one doing it."

Vey did not raise his voice. That was the first thing Tomas noticed. The councilor folded his hands on the table like a man settling in for a long and reasonable conversation, and his voice was the voice of the ship's morning announcements, calm and measured and certain of its own authority.

"You've done the ship a service," Vey said. "A technician who checks his work is worth ten who don't. That's why I'm offering you the post of Lead Archivist. Halden's health is failing. The position comes with council observer status, quarters on the quiet deck, and a voice in the room where decisions are made."

Tomas looked at the table between them. The offer was real. He could see it in the careful way Vey had prepared it, the way a man prepares a gift he expects to be thanked for.

"In exchange," Tomas said.

"In exchange for what you already know how to do. Keep the records. Keep them orderly. Keep them quiet." Vey's hands unfolded. "The log is a tool, Technician. It tells the ship what the ship needs to hear. That has been true longer than either of us has been alive."

"It tells them a lie."

"It tells them a course. The course we set when the old one stopped being survivable. You weren't there. Neither was I. But the people who were made a choice, and they made it so that ten thousand people wouldn't wake up one morning and tear each other apart over a decision they couldn't unmake."

Soto spoke from the doorway. He had come in without knocking and stood with his cap in his hands, and his voice was rough, as though he had been arguing with himself the whole walk down.

"He's not wrong, Tomas." Soto turned the cap over. "I've run the numbers on the water reclamation for thirty years. I know what a system looks like when it's about to come apart. This ship is held together by people believing the next shift will be like the last. You pull that out, you don't get a debate. You get panic. You get people who stop showing up to the pumps because they've decided it doesn't matter anymore."

"So I should lie to them too," Tomas said.

"I'm saying think about what you're holding before you open your hand." Soto met his eyes, and there was something in his face that might have been fear for the ship, or might have been a man asking to be spared a decision he did not want to make. "I've worked beside you eight years. I've never once known what you were thinking. But I know you're not a fool. Don't become one now."

Vey had not moved. His hands were still folded, and he watched Tomas the way a man watches a gauge that has begun to drift.

Tomas stood up. The chair scraped back, and in the small room it sounded louder than it should have.

"The record is not a tool," he said. "It's a promise. Every person on this ship was promised a destination and a reason. If the reason changed, they're owed the truth of it. Not a version of it that keeps them calm."

He looked at Soto, and then at Vey, and neither of them said anything, and the silence in the room was the silence of a door closing.

"I won't take the post," Tomas said. "And I won't keep it quiet."

The public channel terminal in Maintenance Bay 3 was a plain grey console, scarred by decades of coffee rings, and Tomas had used it a hundred times to post shift schedules and water-recycler bulletins. He logged in with his own credentials, because he had decided that if he was going to do this, he would not hide behind an anonymous relay.

He attached the backup file first — the sealed original, checksum intact, timestamped before the first edit — then the live log alongside it, and the comparison report he had built in the small hours, every altered line flagged in red. For a moment his finger hovered over the transmit key. Somewhere above him, three thousand people were eating breakfast and complaining about the noise from the next cabin and assuming the ship was going where it had always said it was going.

He pressed the key.

The console chimed once, softly, the way it chimed for any routine bulletin, and the packet went out across the ship's internal network — every deck, every mess hall screen, every cabin terminal, every handheld the crew carried in their coveralls.

Tomas sat back and watched the progress bar fill. At eighty percent he heard the first door open down the corridor. At ninety-five, footsteps. When it reached a hundred, the console displayed the confirmation in its usual green: DELIVERED — ALL NODES. He logged out, folded his hands on the desk, and waited.

The corridor outside was filling with voices, low and overlapping, none of them yet loud. A woman said something he couldn't make out and someone else answered her. The mess hall screen two decks up would be showing it now — the red lines, the dates, the quiet column of years in which the ship had been going somewhere other than where they had been told.

His handheld buzzed against his hip. He didn't look at it. It buzzed again, then stopped, then started up a third time in a rhythm that suggested more than one person was trying to reach him at once.

The bay's wall speaker carried the ship's ambient hum, and beneath it, faintly, the sound of the public channel running its automatic playback loop, reading the announcement aloud in the flat synthesized voice used for all shipwide notices. It had reached the section on the course correction. It would take another four minutes to finish.

Tomas listened. The footsteps in the corridor had stopped moving, as though everyone out there had paused at once to hear the rest.
