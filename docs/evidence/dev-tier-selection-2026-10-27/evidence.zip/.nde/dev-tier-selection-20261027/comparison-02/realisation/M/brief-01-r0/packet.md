# Realisation review

Final story SHA-256: 0d487a10db1f9dc484271cbcf0298718277356ab2fb7f37a0a285c37b725a8ee

Plan SHA-256: 4a8491d9a8356fdef3061ad0f6e8b14bfc4ed95e6177a7dd2a80c5a31dd48f38

Selected scene outputs match final prose.

Owner assessments pending. Planned intentions do not establish literary accuracy.

belief:st-ada-belief scenes ['sc-02']: {"id": "st-ada-belief", "scene_id": "sc-02", "character_id": "ada-venn", "kind": "belief", "key": "miles-intent", "before": {"value": "Miles means to fish the boat honestly", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Miles means to sink the boat for the insurance", "status": "known", "confidence": null, "alternatives": []}}

belief:st-ada-belief-2 scenes ['sc-03']: {"id": "st-ada-belief-2", "scene_id": "sc-03", "character_id": "ada-venn", "kind": "belief", "key": "miles-motive", "before": {"value": "Miles is a schemer taking easy money", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Miles is a desperate neighbour with no way out", "status": "known", "confidence": null, "alternatives": []}}

reveal:rev-scuttle scenes ['sc-02']: {"id": "rev-scuttle", "kind": "reveal", "fact_id": "fact-scuttle", "scene_id": "sc-02", "holder_ids": ["ada-venn"]}

reveal:rev-debt scenes ['sc-03']: {"id": "rev-debt", "kind": "reveal", "fact_id": "fact-debt", "scene_id": "sc-03", "holder_ids": ["ada-venn"]}

## Final prose

The cash came out of Miles's jacket pocket in a fold of ones and fives, soft at the corners from handling. He counted it twice on the dock box between them, licking his thumb, and Ada watched his hands do the work his father's hands had done at the co-op for thirty years. The evening light lay flat on the harbour. Gulls were settling on the pilings, and somewhere behind the boathouses a dog was barking itself hoarse.

"Twenty-eight hundred," Miles said. "That's the whole of it."

"It's the whole of it," Ada said.

He pushed the money across the dock box. She didn't count it. She had known the figure for weeks; she had known it the way she knew the tide tables, by heart, without wanting to. The Ellen Rose sat at the slip behind him, her paint gone chalky, her name half worn away. Daniel had painted that name on in the spring of their second year, and she had stood on the dock with a brush in her own hand and told him the letters were crooked. They had been crooked. He had said the fish wouldn't mind.

Miles had a pen. He was the sort of man who came prepared, and she did not hold it against him, though she noticed.

"Sign there," he said, and then, quieter, "Ada. You don't have to do this tonight."

"Tonight's as good as any."

She signed. The pen scratched. It was a sound like a nail drawn across a board, and then it was over and the boat was his and the money was in her coat pocket and the light was going.

They said the things neighbours say. He hoped she'd keep well. She said she would. He walked up the ramp with his hands in his pockets and did not look back at the boat, which she thought was either kindness or else a man already thinking of other things.

She stood a while. Then she took the key from her coat, the spare she had never put in the envelope with the papers, and turned it over once in her palm — brass, warm from her pocket, worn smooth at the bit — and put it back where it had been.

The tower steps were seventy-two. She climbed them as she climbed them every night, her hand on the rail, her breath finding its rhythm by the fortieth step. At the top the lamp turned its slow circuit though the station had been dark for nine years, and the sea went on being the sea.

The co-op store smelled of rope and old coffee. Ada had come for a tin of lamp oil she no longer needed, out of nine years of habit, and she was at the counter paying when the deckhand from the fuel dock came in with his boots still wet.

"Venn's boat," he said to no one in particular, loud enough for the whole store to hear. "Saw her out on the mooring this afternoon. Pretty thing." He rocked back on his heels. "Shame, though. She'd be worth more underwater than she is afloat, the way the season's been."

The woman at the till laughed and said something about fishermen's arithmetic. The deckhand laughed too, and bought his cigarettes, and went out into the dark.

Ada stood with her coin in her hand. The till waited. She set the coin down and took her oil and did not remember the walk to the fuel dock.

Miles was there, coiling a line off the pump. When he saw her he grinned, the wide grateful grin he had shown her at the signing, and said she oughtn't to be out this late, and asked after her knees.

"Who else knows?" she said.

The grin stayed a moment too long, like a coat on the wrong hook. Then it came apart. In the yellow light of the dock lamp she saw his face go young and frightened, the face of the boy who used to sit on her husband's stern with a handline, and he looked at the water and then at her and said nothing at all, which was answer enough.

June's kitchen smelled of woodsmoke and the paraffin she still used when the electric bill couldn't be met. She didn't offer tea. She just turned from the stove and gestured at the table as though she were showing Ada a catch.

The notices lay fanned like a hand of cards: the hydro, the bank, the feed store, a final demand from the county for the taxes on the wharf lot. Some were pink. One had a red stripe across the top. Ada read the top figure on the county letter and then read it again, and June stood with her back to the sink and her arms folded, not hiding them and not explaining them either.

"We're not asking," June said. "I want that plain. Miles would die before he asked."

"I know it."

"He's got the boat now. That's the whole of it." She looked out the window at the dark, where the harbor light made its slow turn. "He says it'll come right."

Ada looked at the notices. She thought of the deckhand's face under the dock lamp, young and frightened, and of what a boat is worth when it goes onto the rocks, and what a man is worth when he has nothing left to sell but his father-in-law's old hull and a story about the weather.

"June," she said. "Has he been sleeping?"

"Not since the spring."

Ada nodded slowly. She put her cup down without having drunk from it. There was a thing she could say, and it would come out of her mouth like a stone and lie on that table among the pink papers, and June would look at her the way she had looked at her across this same table when they were girls, and it would be the truth, and it would be the end of something.

She said nothing.

At the door June caught her arm, briefly, the way she used to. "You'd tell me," she said. "If there was something."

The wind was up along the seawall and the water slapped at the stones. Ada walked with her collar turned and her hands deep in her pockets, past the empty moorings, past the shed where her husband had kept his tools and where the padlock now hung on a hasp that no longer mattered, and she did not look back at the lit kitchen window, though she felt it on her shoulders the whole way home.

She found Miles on the pier at first light, mending a net he did not need, his big hands slow and careful over the mesh. He did not look surprised to see her. He set the net down and waited, and she understood that he had known she would come, had perhaps been waiting all night.

"The Ellen Rose," she said. "You mean to put her on the rocks."

He looked at the water, then back at her. "Aye."

No denial, no shuffling story. She had half hoped for one, some lie she could argue with and take apart. "The insurance."

"It's owed. I've got until the end of the month."

"You could have told me."

"What would you have said?" He rubbed his thumb along a splice, back and forth. "There's nothing left to sell, Ada. The house is spoken for. June's been to the bank twice. It's the boat or the roof, and the roof's got the children under it."

She stood with the wind working at her coat and found she had no answer that was not his answer already.

He did not ask her to keep quiet. That was the worst of it. He turned back to his net and left the choice lying there on the pier between them.

She went to the tower because there was nowhere else to go with it. The door was stiff with salt and she shouldered it open, and climbed the spiral the way she had climbed it for forty years, her hand finding each rail without her looking. In the lamp room the great lens stood dark, the mechanism dead since the station was decommissioned, the prisms dulled with dust. She set her palms to the old brass wheel and turned it by hand, slow, and the lens caught what light there was and threw it out across the grey water, a pale sweep that lit nothing, guided no one, went out over the empty moorings and the far rocks and came around again. She turned it until her arms ached, and the light went on sweeping, faithful and useless, out into the coming dark.

She saw the running lights go out.

It was a small thing, from the lamp room, a green and a red pinprick winking off the water one after the other, and then nothing where the Ellen Rose had been. The tide was making, the wind offshore, and the rocks at the point lay black and patient under a moonless sky. Ada's hand went to the radio, the old VHF still wired to the decommissioned panel, dead and cold beneath her fingers, and to the phone in her pocket, and she stood with the both of them unanswered and watched the dark where the boat was.

She could have raised the coast guard out of the harbour in twenty minutes. She could have had a light on it, a voice on the radio, a story told and a scheme broken open, and Miles Hark in the morning with his debt and his shame laid out for the whole parish to see. Her thumb rested on the screen. Then she put the phone away.

She went down the spiral and out along the shingle, and the sea was already working. She heard it before she saw it, the grind and groan of a hull against stone, the slap and suck of the swell in a broken belly, and by the time she reached the point Miles was there and June beside him, the two of them standing in their coats with the spray coming up over their boots. Neither of them turned. Ada came and stood at June's shoulder and June's hand found hers and held it, and the three of them watched the boat come apart.

The mast went first, leaning slow and then all at once, and a wave took the wheelhouse and the wheelhouse did not come back. Planks peeled off into the white water and rode the backwash in, and somewhere in the wreck the last of the fuel bled out in a rainbow sheen, and the Ellen Rose, which Ada's husband had built with his own hands in a shed behind the house, was a scatter of lumber on the rocks.

June was crying, quietly, the way you cry when you have been afraid a long time. Miles said nothing at all. His face in the dark was the face of a man who had done a thing and would have to live in it.

Ada took the spare key from her pocket, the one she had never handed over, and turned it once in her fingers. Then she let it go into the sea, and stood with them, and watched the tide take the rest.
