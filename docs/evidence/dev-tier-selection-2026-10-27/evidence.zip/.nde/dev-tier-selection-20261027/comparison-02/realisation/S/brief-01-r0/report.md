# Realisation evidence

packet_sha256: 77c166a84fc64b0b9031c38bde90ccd5f9292f45d04d7be971fc0b52d282c167

story_sha256: a1ac930370f3ab40773b5b8b3e3151af7c25cc7288f0c12ad8f3443f10a262d9

plan_sha256: 5364b72cfd94a2565a4011d659cefc67accb3901a553b5ca3557a2697f7c631a

sample: ['brief-01']

denominator: 0

assessed: 0

missing: 0

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: No belief/relationship/reveal/tension channels are represented.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
