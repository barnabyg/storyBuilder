# Realisation evidence

packet_sha256: 6b608dbafa1d46f93b353006000f744f6b1fb9b28a7a1acc49282485925c0b6e

story_sha256: 0d487a10db1f9dc484271cbcf0298718277356ab2fb7f37a0a285c37b725a8ee

plan_sha256: 4a8491d9a8356fdef3061ad0f6e8b14bfc4ed95e6177a7dd2a80c5a31dd48f38

sample: ['brief-01']

denominator: 4

assessed: 0

missing: 4

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
