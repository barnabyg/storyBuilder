# Realisation review

Final story SHA-256: 11c514c5dc20cb8bcff4e3a7be73a561916360f4d382f6b8bd007635864ce97d

Plan SHA-256: 75690e132ad26da658c54f219f992f68d0f7d1ad21c35f7cc91cbe0115bfeb24

Selected scene outputs match final prose.

Owner assessments pending. Planned intentions do not establish literary accuracy.

belief:st-ada-belief scenes ['sc-02']: {"id": "st-ada-belief", "scene_id": "sc-02", "character_id": "ada-venn", "kind": "belief", "key": "miles-intent", "before": {"value": "Miles means to fish the boat honestly", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Miles means to sink the boat for the insurance", "status": "known", "confidence": null, "alternatives": []}}

belief:st-ada-belief-2 scenes ['sc-03']: {"id": "st-ada-belief-2", "scene_id": "sc-03", "character_id": "ada-venn", "kind": "belief", "key": "miles-motive", "before": {"value": "Miles is a schemer taking easy money", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "Miles is a desperate neighbour with no way out", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-miles scenes ['sc-01']: {"id": "rel-ada-miles", "scene_id": "sc-01", "participant_ids": ["ada-venn", "miles-hark"], "key": "neighbourly trust", "before": {"value": "warm, lifelong neighbourly trust", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "warm trust shaded by a transaction and an unspoken reserve", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-miles-2 scenes ['sc-02']: {"id": "rel-ada-miles-2", "scene_id": "sc-02", "participant_ids": ["ada-venn", "miles-hark"], "key": "neighbourly trust", "before": {"value": "warm trust shaded by a transaction and an unspoken reserve", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "trust gone wary, holding a secret she has not named to him", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-june scenes ['sc-03']: {"id": "rel-ada-june", "scene_id": "sc-03", "participant_ids": ["ada-venn", "june-hark"], "key": "neighbourly trust", "before": {"value": "easy neighbourly warmth, kept at the door", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "warmth made heavier by shared knowledge Ada chooses to carry alone", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-miles-3 scenes ['sc-04']: {"id": "rel-ada-miles-3", "scene_id": "sc-04", "participant_ids": ["ada-venn", "miles-hark"], "key": "neighbourly trust", "before": {"value": "trust gone wary, holding a secret she has not named to him", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "the secret named between them, trust stripped to plain honesty", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-miles-4 scenes ['sc-05']: {"id": "rel-ada-miles-4", "scene_id": "sc-05", "participant_ids": ["ada-venn", "miles-hark"], "key": "neighbourly trust", "before": {"value": "the secret named between them, trust stripped to plain honesty", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "trust kept by silence, a debt of mercy neither will speak of", "status": "known", "confidence": null, "alternatives": []}}

relationship:rel-ada-june-2 scenes ['sc-05']: {"id": "rel-ada-june-2", "scene_id": "sc-05", "participant_ids": ["ada-venn", "june-hark"], "key": "neighbourly trust", "before": {"value": "warmth made heavier by shared knowledge Ada chooses to carry alone", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "warmth restored, standing shoulder to shoulder on the shingle", "status": "known", "confidence": null, "alternatives": []}}

reveal:rev-scuttle scenes ['sc-02']: {"id": "rev-scuttle", "kind": "reveal", "fact_id": "fact-scuttle", "scene_id": "sc-02", "holder_ids": ["ada-venn"]}

reveal:rev-debt scenes ['sc-03']: {"id": "rev-debt", "kind": "reveal", "fact_id": "fact-debt", "scene_id": "sc-03", "holder_ids": ["ada-venn"]}

tension:tens-sale scenes ['sc-01']: {"id": "tens-sale", "kind": "interpretation", "scene_ids": ["sc-01"], "reading": {"value": "Quiet dread under the ordinary business of a cash sale at dusk.", "status": "known", "confidence": null, "alternatives": ["relief that the boat is finally gone", "grief surfacing as numbness"]}, "evidence": [], "trajectory": null}

tension:tens-secret scenes ['sc-02']: {"id": "tens-secret", "kind": "interpretation", "scene_ids": ["sc-02"], "reading": {"value": "A joke taken seriously: the moment Ada learns the boat she sold is meant to drown.", "status": "known", "confidence": null, "alternatives": ["a drunk's empty talk", "a rumour she can dismiss"]}, "evidence": [], "trajectory": null}

tension:tens-kitchen scenes ['sc-03']: {"id": "tens-kitchen", "kind": "interpretation", "scene_ids": ["sc-03"], "reading": {"value": "Charity and complicity in the same room: Ada holds a secret over the table where it is most needed.", "status": "known", "confidence": null, "alternatives": ["simple neighbourly sympathy", "a debt story that changes nothing"]}, "evidence": [], "trajectory": null}

tension:tens-pier scenes ['sc-04']: {"id": "tens-pier", "kind": "interpretation", "scene_ids": ["sc-04"], "reading": {"value": "The scheme spoken aloud between them leaves no cover: Ada must answer for what she will do with it.", "status": "known", "confidence": null, "alternatives": ["Miles denying it and retreating", "Ada walking away without an answer"]}, "evidence": [], "trajectory": null}

tension:tens-shore scenes ['sc-05']: {"id": "tens-shore", "kind": "interpretation", "scene_ids": ["sc-05"], "reading": {"value": "The lights go dark and Ada holds still, the choice made in not lifting the phone.", "status": "known", "confidence": null, "alternatives": ["a last-minute call to the coast guard", "the boat righting itself"]}, "evidence": [], "trajectory": null}

## Final prose

The tide was out, and the boat sat low against the pilings, listing a little to port the way she always had, the paint gone chalky where the sun worked on it. Ada stood at the end of the dock with her hands in her coat pockets and watched Miles Hark count the money.

He counted it twice. The first time quickly, thumbing the bills like cards, and the second time slower, laying each one flat on the hatch cover between them so the wind couldn't take it. Twenties, mostly, some tens, a few fifties that looked like they'd been folded a long time. The evening light made the whole stack the color of weak tea.

"It's all there," he said, not looking up. "I counted at the bank."

"I know it's there, Miles. I'm watching you count it."

He laughed a little, the way he did when he was embarrassed, and pushed the last of it across to her. His hands were red and cracked at the knuckles. He'd been hauling traps since he was twelve, same as his father, same as his father's father, and now he was buying her dead husband's boat with a shoebox worth of cash on a Tuesday in October.

She signed the papers on the hatch cover, using the flat of her palm for a desk. The pen skipped. Her name came out crooked, Ada Venn, the way it always did now, as though the letters had to be reminded where to go.

"You'll want the key," she said.

"I've got the spare from the marina office. Unless you—"

"No," she said. "That's fine."

The key was in her coat pocket, the little brass one with the tag Tom had cut from a bleach bottle and scratched her name into, because he lost everything and she found everything. She closed her fingers around it and did not take it out.

They said goodnight. Miles walked up the ramp with the papers under his arm, and she watched him go, and then she walked the other way, up the shingle to the tower.

It was decommissioned now, the light gone out of it years back, but she climbed it every night anyway, the same iron stairs, the same count of steps. From the gallery she could see the whole bay, the boat at the dock, the lights coming on one by one along the shore. The wind had a cold edge to it. She stood with her hands in her pockets and the key against her palm, warm from her own blood, and she stayed until the last light was gone from the water.

The co-op smelled of diesel and wet rope and the sweetish rot of bait. Ada had come for a tin of coffee and a bag of salt, and she stood at the counter while the girl rang her up, and behind her the deckhands from the Maud were loud at the back table, three of them, their jackets still on.

"Worth more underwater," one of them said, and laughed, a wet laugh, and the others laughed with him. "That's what I told him. Scrap value's nothing. Sink her neat and proper and she's worth a fortune."

The girl slid the coffee across. Ada took it and did not turn around.

"Shut up, Denny," another said, quieter. "You've had too much."

"I've had just enough. You ask me, it's the smartest thing anyone round here's done in years. Old Venn's boat, too, that's the joke of it. She'd turn in her—" He stopped, or the others stopped him. Ada heard the scrape of a chair.

She paid. She said goodnight to the girl. Outside the wind had come round to the northeast and the dark was complete.

She found Miles at the fuel dock, filling cans. He was in his good coat, the one with the collar, and when he saw her his face opened into a grin, wide and easy, the grin she had known since he was a boy running errands for his mother.

"Ada. Cold one."

"Cold one," she said.

He kept talking, about the weather, about the price of fuel, and she watched him over the top of it, and she saw it—the way the grin was something he was holding rather than something he had, the way his eyes kept going past her to the dark water and the boat and back. Fear sat behind his face like a man behind a curtain.

"Big plans, then," she said.

"Big plans," he said, and the grin did not move.

She walked home along the shore road with her hands in her pockets, and the key was in her right pocket, the spare she had never handed over, and it was cold now, and she held it anyway.

June Hark's kitchen smelled of wet wool and last night's haddock. She had put the kettle on before Ada was through the door, and she did not sit down. Instead she swept a hand across the table, and the papers there shifted and settled like gulls on a wall.

"I'm not asking," June said. "I want you to see it, that's all. So you know it isn't greed. So you know what it is."

The notices were from the bank, from the fuel merchant, from the hospital in St. John's. Some were months old and soft at the folds from being carried in a purse. Ada read them the way she read weather: not one by one but all together, the shape of what was coming. The house was mortgaged twice. The truck was three payments behind. There was a figure at the bottom of the last page, underlined twice, that June's hand had not made.

"Thirty-one thousand," June said quietly. "And that's before the interest eats it."

Ada set the papers down square, one atop the other, and did not say what she was thinking. She was thinking of a deckhand with whiskey on his breath and a buyer who meant to put a good boat on the rocks. She was thinking that June did not know. That was the thing she could not get past—June, who had brought casseroles for a month after the funeral, who had sat with her through the first winter, who did not know what her own son meant to do with the money.

"He's got a plan," June said. "Miles. He says it's all arranged." She smiled, and the smile was tired and trusting, and it was worse than any bill on the table. "I don't ask him what. I've stopped asking."

Ada took her tea and did not drink it. Outside the window the harbour was going grey and the water was flat as a plate.

"It'll come right," she said. It was the sort of thing you said.

She walked home along the seawall with her collar up. The wind was off the water and cold. Her right hand found the key in her pocket without her meaning it to, and she held it, and it pressed against her hip through the cloth, and she thought of the notices spread on the table like a hand of cards, and of the boat her husband had built with his own hands out of larch and stubbornness, and she said nothing to anyone, because there was no one to say it to.

She found him on the pier the next morning, mending a pot with wire, though the pot did not need mending and they both knew it.

"Miles," she said. "The boat."

His hands stopped. He looked at the wire, at the water, at last at her. "You heard."

"Rudy had a drink in him and no sense in his head. He told me you mean to put her on the Iron Rocks."

Miles set the pot down. He did not deny it, did not reach for a story. He wiped his palms on his thighs and stood straight, and she saw how thin he had got, how the coat hung off him.

"June doesn't know the half of it," he said. "It's not the boat I'm after. It's the policy. I signed it over clean, I'll not drag you into it. Whatever comes, it comes on me."

"You'd sink her for the money and stand there telling me plain."

"I'd rather tell you plain than lie to you, Ada. I've no excuse to offer. There isn't one that holds water."

She looked at the key in her hand, the spare she had never handed over, and felt the weight of it. Then she put it back in her pocket and went up the hill.

The tower door was stiff with rust. She climbed the spiral in the dark, the old smell of salt and cold iron, and at the top the lamp sat dead behind its glass, the light long since taken out of the world. She laid her hands on the mechanism and turned it, one slow revolution, then another, the great lens catching nothing, throwing nothing. The sea went on being dark, and she turned the dead lamp by hand, and the turning was all there was.

She saw the running lights go out.

One moment there were two small points of white and one of red, moving out past the point; the next there was only the dark, and the sea, and the low complaint of the swell against the rocks. Ada stood at the lamp with her hand still on the dead mechanism. Her phone lay on the sill where she had set it down an hour ago, and she did not reach for it. The lights did not come back on. Somewhere below, the engine would be silent now, or cut, and the boat would be turning in the current, drifting toward the shelf where her husband had fished forty years and never once struck. She knew the water there. She knew what it did to a hull.

She went down the spiral faster than she had come up, and out along the shingle with her coat open and the cold coming through her shoes.

Miles and June were already there, standing a little apart, not touching. June had her arms folded against the wind and her face turned out to sea. Miles stood with his hands loose at his sides, and when Ada came up he glanced at her once and then away, and neither of them said anything at all.

The boat struck at the turn of the tide. They heard it before they saw it—the tearing, the long groan of timber giving—and then the white of the broken water showed where the hull had opened on the rocks. The mast went over slowly, like a thing too tired to stand, and the sea went on working at what was left.

Ada put her hand in her pocket. The spare key was there, warm from her hip, and she held it a moment, then let it fall into the weed at her feet, where the tide would find it or not.

June made a small sound. Ada took her arm, and after a moment June leaned into her, and Miles stood on June's other side, and the three of them watched the boat come apart in the dark, and said nothing, and stayed.
