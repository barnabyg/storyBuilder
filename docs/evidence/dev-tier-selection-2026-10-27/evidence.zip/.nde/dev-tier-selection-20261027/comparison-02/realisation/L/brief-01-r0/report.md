# Realisation evidence

packet_sha256: 804c0dbc0903e1f0965f05d54ed51bac4b4c15b9e2d8d2bf8b96bb5647f5ae23

story_sha256: 11c514c5dc20cb8bcff4e3a7be73a561916360f4d382f6b8bd007635864ce97d

plan_sha256: 75690e132ad26da658c54f219f992f68d0f7d1ad21c35f7cc91cbe0115bfeb24

sample: ['brief-01']

denominator: 15

assessed: 0

missing: 15

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
