# Realisation review

Final story SHA-256: e65400bfd7500d965d65baaf770fe970c12ae5a61c82ca7aeae4a05af8a4d79f

Plan SHA-256: 7eb31c62410236468a205e0f4976e924a4c40a6880259a4d08fc3fb115e9b852

Selected scene outputs match final prose.

Owner assessments pending. Planned intentions do not establish literary accuracy.

belief:st-tomas-doubt scenes ['s1']: {"id": "st-tomas-doubt", "scene_id": "s1", "character_id": "tomas", "kind": "belief", "key": "log-integrity", "before": {"value": "Navigation records are accurate and trustworthy", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The navigation log may have been altered by someone", "status": "known", "confidence": null, "alternatives": []}}

belief:st-tomas-belief-s2 scenes ['s2']: {"id": "st-tomas-belief-s2", "scene_id": "s2", "character_id": "tomas", "kind": "belief", "key": "log-integrity", "before": {"value": "The navigation log may have been altered by someone", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The log was deliberately edited for decades to hide a course change", "status": "known", "confidence": null, "alternatives": []}}

belief:st-tomas-belief-s3 scenes ['s3']: {"id": "st-tomas-belief-s3", "scene_id": "s3", "character_id": "tomas", "kind": "belief", "key": "institutional-trust", "before": {"value": "The council is a guardian of the ship's records", "status": "known", "confidence": null, "alternatives": []}, "after": {"value": "The council is the author of the lie and cannot be trusted with the truth", "status": "known", "confidence": null, "alternatives": []}}

reveal:rev-course-halden scenes ['s2']: {"id": "rev-course-halden", "kind": "reveal", "fact_id": "fact-course-change", "scene_id": "s2", "holder_ids": ["archivist-halden"]}

reveal:rev-order-tomas scenes ['s3']: {"id": "rev-order-tomas", "kind": "reveal", "fact_id": "fact-council-order", "scene_id": "s3", "holder_ids": ["tomas"]}

reveal:rev-order-soto scenes ['s4']: {"id": "rev-order-soto", "kind": "reveal", "fact_id": "fact-council-order", "scene_id": "s4", "holder_ids": ["engineer-soto"]}

## Final prose

The audit was supposed to take forty minutes. Tomas had done it every second Tuesday for three years, and he could have run it in his sleep: pull the navigation log's daily digest, compare it against the checksum registry, confirm the two matched, file the confirmation, go to lunch. The log was the ship's memory. It did not lie, and it did not forget.

At minute thirty-eight the console flagged a mismatch.

Tomas leaned back and read the line again. A single character off, buried in a block of hexadecimal that most of the crew would have scrolled past. He assumed a bit flip in the sensor buffer. That happened; the old arrays drifted, and a technician who chased every ghost wasted a shift. He queued a re-read of the affected block from the secondary array and waited.

The secondary returned the same checksum. The stored contents did not match it.

He checked the timestamp on the flagged entry, then the one before it, then the digest for the week. The mismatch was not confined to a single block. It appeared in eleven places, scattered across the month like stones dropped in a stream, and each time the stored contents had been altered after the checksum was written. A sensor fault would have corrupted the reading. This had corrupted the record of the reading.

He ran the registry check a third time on a clean terminal, with the navigation array physically disconnected, feeding the log through the maintenance bus instead. The result did not change.

For a while he simply sat with it. The maintenance bay hummed around him, and somewhere aft a pump cycled through its slow rhythm. He had spent his career trusting the log more than he trusted most people, and the log had always earned it. Now a number sat out of place, small and patient, and it had been sitting there long enough that no one had noticed.

He opened a fresh work order, typed checksum discrepancy, navigation log, unresolved, and then deleted it before he saved. He would not file this yet. He did not know what it was, but he knew what it was not: it was not a sensor fault, and it was not going to fix itself.

The archive was kept cold, and Halden kept it that way on purpose. She sat behind a desk that had been old when the ship was new, and she looked at Tomas the way she looked at everyone, as if he were a form she had already decided not to stamp.

"A sealed backup," he said. "Navigation, forty years back. I need it."

"You need it." She turned a page of something. "The current log is the authoritative record. You know that."

"The current log doesn't match its own checksum."

That stopped her. She looked up, and for a moment something moved behind her face that was not annoyance. Then it was gone.

"Come with me," she said.

The vault was a room of drawers, each with a mechanical seal. Halden worked a key and a lever, and the drawer came out slow and heavy. Inside, wrapped in anti-static film, was a single cartridge with a lead seal and a date stamped into the metal, and a signature Tomas did not recognize.

"Read-only," she said. "Once I break the seal, I log it. That log goes to the council."

"Do it."

She broke the seal. Tomas carried the cartridge back to his bench and jacked it in, and for a while there was only the hum of the reader and his own breathing.

The backup did not match the current log.

It was not close. The current log showed a ship holding a steady heading for a century and a half, patient and dull, every correction a small trim against drift. The backup showed the same steady heading, and then, on a date sixty-one years ago, a burn. A long burn, three weeks of it, and then a new heading, and a course that was not the one the ship had been launched on.

Tomas pulled the maintenance logs for that year. He found the burn itself, logged as a thruster test, signed off by a name that had been retired for decades. Then he pulled the following year, and the year after, and each one had a small edit, a line adjusted, a heading smoothed, so that the current log did not show a turn at all. It showed a straight line that had never been flown.

Sixty-one years of small, patient edits. Someone had been maintaining the lie the way he maintained the ship.

He sat back. His hands were steady, which surprised him. He thought of the passengers asleep in their tiers, dreaming of a destination that was not where they were going, and he understood that he had stopped looking for who had done this. He wanted to know why.

The council chamber was small and windowless, its walls lined with the same grey acoustic padding as everywhere else on the ship. Councilor Vey sat alone at the head of the table, a thin woman with grey hair pulled back so tightly it looked painful. She did not offer Tomas a seat.

"Your access logs show you've been in the archive," she said. "I assume this isn't a social call."

Tomas placed his tablet on the table and turned it toward her. The checksum mismatch glowed on the screen, alongside the backup comparison he had spent the night assembling. Vey looked at it for a long moment. Her expression did not change.

"How long have you known?" he asked.

"Longer than you've been alive." She folded her hands. "The council ordered the edits. Every council, going back six generations. I won't pretend otherwise."

Tomas had expected denial. The admission landed harder than a lie would have. "Why?"

"Because forty years into the voyage, the original council learned we were off course. A navigation error compounded by a failed burn. Correcting it was possible. Correcting it publicly was not." Vey's voice stayed flat, practiced. "Word got out among the first passengers. There was nearly a mutiny. People had signed on for a specific destination, and the idea that it had slipped away from them—" She shook her head. "The council of that era made a choice. Edit the log, hold the course correction quietly, and let the ship arrive where it arrived. Every council since has upheld it."

"So you decided for them."

"We decided for the ship. A mutiny in deep space isn't a protest, Technician. It's a death sentence for everyone aboard, including the ones who started it."

Tomas looked down at his tablet. He thought of the sleeper tiers, the thousands of people whose entire lives were a promise made by someone else. "They're going to wake up at a star they never agreed to. They'll have no idea."

"They'll wake up alive."

"That isn't the same thing." He met her eyes. "Passengers have a right to know where they're going. That's not a courtesy you extend when it's convenient. It's the whole reason they got on the ship."

Vey was quiet. Then she said, "You understand what you're asking me to weigh."

"I understand what you've already done," Tomas said.

Vey leaned back in her chair and folded her hands. "You're a junior technician, Tomas. Second shift, deck nine, checksum verification. Do you know how many people in this room started exactly there?" She didn't wait. "Two. And one of them is sitting at this table."

"Councilor—"

"Listen before you decide." She slid a slate across the table toward him. "The navigation department needs a deputy archivist. Records integrity. It's a real post, not a courtesy title. The work is important, and it is done in a room where the log is handled with the care it deserves. The pay is better. The quarters are better. And the person who holds it doesn't spend their evenings wondering whether an old checksum was worth the trouble."

Tomas looked at the slate but didn't touch it. "In exchange for what?"

"In exchange for nothing you aren't already doing. You maintain records. You keep them in order. You don't broadcast a forty-year-old clerical dispute to four thousand people who can't do anything about it."

"Twenty years," Tomas said. "Twenty-three, by the dates."

Vey's mouth tightened. "The point stands."

Soto, who had said nothing since Tomas entered, finally spoke up. His voice was quiet, and tired. "Tomas. I've been on the council a long time. I know what the passengers think of us, and I know what they'll think when they hear the log was doctored. They'll assume the worst, because the worst is easier to believe. Some of them will want to turn us around. Some of them will want to break something." He rubbed his eyes. "There are people aboard who have never seen an argument that didn't end in a broken door. You give them this, and you give them a reason."

"You're telling me the truth will fracture the ship," Tomas said.

"I'm telling you it might. I don't know. Neither do you." Soto looked at him steadily. "That's the thing about a secret, Tomas. You can't put it back once it's out. You can only decide whether you're certain enough to live with what comes after."

Tomas stood. He left the slate on the table.

The maintenance bay was empty at third shift, which was why he had chosen it. Tomas sat at the auxiliary console with the slate he had carried out of the council chamber and a cable he had made himself, bypassing the deck-level relay so that nothing would pass through a node anyone could quietly throttle.

The original log sat in his hand like something alive. Forty-one years of course corrections, burn windows, and star fixes, and underneath all of it the buried truth: a turn made in the dark, decades before he was born, and a record sanded smooth afterward by people who had decided the passengers could not be trusted with their own destination.

He keyed the public channel. Every deck, every mess hall, every bunkroom speaker and wall screen. The channel that had only ever carried water rationing and drill schedules.

"This is Tomas Okafor, maintenance, deck nine." His voice sounded strange to him, too steady. "What follows is the unedited navigation record of this ship, verified against the sealed archive. I am not going to explain it. I am going to read it to you, and then it will be on your screens, and you can read it yourselves."

He read for eleven minutes. The dates. The heading. The burn that had never been logged. The checksum mismatch he had found on an ordinary Tuesday, because a routine audit had asked a routine question and the answer had been wrong.

When he finished, he set the slate down and looked at the bay around him—the tool racks, the coolant lines, the scuffed floor he had swept a thousand times.

Then he heard it. Not shouting. Not yet. Just the ship, all of it at once, going quiet.
