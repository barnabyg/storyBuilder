# Realisation evidence

packet_sha256: d32a47636db7b55557fe8afd610f38064363c49bc37fbfcb378ee2a1c7aa2e2b

story_sha256: 1648e70c4d1eebc019d34ede7fb71a188e630c530bd06e53986fe40c6b880f89

plan_sha256: 5712d8b12bf3afb62ef2cf5df69a23e2efe9cbd650e05b05af0c80ef0a424147

sample: ['brief-02']

denominator: 14

assessed: 0

missing: 14

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
