# Realisation evidence

packet_sha256: 334824eabad8187bed3b6e5c8b5e67e4de0d662c33d6e3101866031c29313edb

story_sha256: dbe8aee85f078d7921eb6852909d796090eb397d8fccab16a7c1cbe3ec8dd990

plan_sha256: e0db5ed27a7ee754f862c9527d626d925c59cb49c9d89957bb8de1102425cc3d

sample: ['brief-02']

denominator: 0

assessed: 0

missing: 0

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: No belief/relationship/reveal/tension channels are represented.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
