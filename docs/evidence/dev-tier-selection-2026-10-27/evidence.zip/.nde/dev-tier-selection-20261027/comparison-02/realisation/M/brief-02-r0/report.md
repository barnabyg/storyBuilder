# Realisation evidence

packet_sha256: f6c530350cbf8b9d189738fe43a03f63a6c043163bd44af82144c883bf2c9980

story_sha256: e65400bfd7500d965d65baaf770fe970c12ae5a61c82ca7aeae4a05af8a4d79f

plan_sha256: 7eb31c62410236468a205e0f4976e924a4c40a6880259a4d08fc3fb115e9b852

sample: ['brief-02']

denominator: 6

assessed: 0

missing: 6

unknown: 0

realised: 0

owner_status: pending

alignment: scene-aligned

plan_kind: narrative

channel_note: Assess the listed represented intentions.

stale: []

synthetic_test_only_assessments: 0

diagnostic_only_estimates: 0

unresolved_diagnostic_estimates: 0
