# Run report: development-tier-selection-20261027-compact-attempt02-tier-S

- **Status:** succeeded
- **Started:** 2026-10-27T17:26:47.269794+00:00
- **Finished:** 2026-10-27T17:32:15.116118+00:00
- **Git SHA:** `3f29d9cd83e11b038a6dd963b6f7f168c93ed48e` (dirty)
- **Config:** `C:\docs\git\storyBuilder\.nde\dev-tier-selection-20261027\comparison-02\configs\S.yaml` (hash `a087b6673a60`)
- **Seed:** 1700
- **Cache:** use, 30 hits, 38 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | deepseek | deepseek-flash | deepseek |

## Prompt templates

- `plan_skeleton@2` (sha256 `0da31dbfa52d`)
- `plan_channels@2` (sha256 `01ada4fa319c`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-01, brief-02 (from `C:\docs\git\storyBuilder\benchmark`)
- **Frozen splits:** none
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 3 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | C | 1 | 1936 | 2000 | 1 | yes | 0 | ok | 12 | 71239 | 18914 | $0.0441 | $0.0441 | [cards.html](stories/C/brief-01/r1/cards.html) [cards.md](stories/C/brief-01/r1/cards.md) [ledger.json](stories/C/brief-01/r1/ledger.json) [plan-selection.json](stories/C/brief-01/r1/plan-selection.json) [plan.json](stories/C/brief-01/r1/plan.json) [planning-provenance.json](stories/C/brief-01/r1/planning-provenance.json) [skeleton.json](stories/C/brief-01/r1/skeleton.json) [source-plan.json](stories/C/brief-01/r1/source-plan.json) [story.md](stories/C/brief-01/r1/story.md) [story.raw.md](stories/C/brief-01/r1/story.raw.md) [validation.json](stories/C/brief-01/r1/validation.json) |
| brief-01 | B | 1 | 2183 | 2000 | 1 | yes | 13 | ok | 23 | 44977 | 39018 | $0.0603 | $0.0543 | [outline.json](stories/B/brief-01/r1/outline.json) [story.md](stories/B/brief-01/r1/story.md) [story.original.md](stories/B/brief-01/r1/story.original.md) [story.raw.md](stories/B/brief-01/r1/story.raw.md) |
| brief-02 | C | 1 | 1912 | 2000 | 1 | yes | 0 | ok | 12 | 70794 | 19677 | $0.0449 | $0.0449 | [cards.html](stories/C/brief-02/r1/cards.html) [cards.md](stories/C/brief-02/r1/cards.md) [ledger.json](stories/C/brief-02/r1/ledger.json) [plan-selection.json](stories/C/brief-02/r1/plan-selection.json) [plan.json](stories/C/brief-02/r1/plan.json) [planning-provenance.json](stories/C/brief-02/r1/planning-provenance.json) [skeleton.json](stories/C/brief-02/r1/skeleton.json) [source-plan.json](stories/C/brief-02/r1/source-plan.json) [story.md](stories/C/brief-02/r1/story.md) [story.raw.md](stories/C/brief-02/r1/story.raw.md) [validation.json](stories/C/brief-02/r1/validation.json) |
| brief-02 | B | 1 | 2150 | 2000 | 1 | yes | 13 | ok | 21 | 43948 | 40013 | $0.0612 | $0.0000 | [outline.json](stories/B/brief-02/r1/outline.json) [story.md](stories/B/brief-02/r1/story.md) [story.original.md](stories/B/brief-02/r1/story.original.md) [story.raw.md](stories/B/brief-02/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 2 | 0 | 24 | 142033 | 38591 | $0.0889 | $0.0889 | $0.0445 |
| B | 2 | 0 | 44 | 88925 | 79031 | $0.1215 | $0.0543 | $0.0608 |

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 2 | 24 | 180624 | 90312 |
| B | 2 | 44 | 167956 | 83978 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 10% of the larger, with at most 24 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | 1 | 90153 | 9764 | B | 13 | 90153 | 83995 | yes |  |
| brief-02 | 1 | 90471 | 7766 | B | 13 | 90471 | 83961 | yes |  |

2 matched, 0 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-01 repetition 1: comparable
- C: final `stories/C/brief-01/r1/story.md`, SHA-256 `a1ac930370f3ab40773b5b8b3e3151af7c25cc7288f0c12ad8f3443f10a262d9`; 1936 words; 90153 tokens; new spend USD 0.044068
- B: final `stories/B/brief-01/r1/story.md`, SHA-256 `d5390a779f512c93b3f551ad9101219e291fb648a67fb76d14d29e5d4d6bb57a`; 2183 words; 83995 tokens; new spend USD 0.054306

brief-02 repetition 1: comparable
- C: final `stories/C/brief-02/r1/story.md`, SHA-256 `dbe8aee85f078d7921eb6852909d796090eb397d8fccab16a7c1cbe3ec8dd990`; 1912 words; 90471 tokens; new spend USD 0.044851
- B: final `stories/B/brief-02/r1/story.md`, SHA-256 `c21bd182a8906c1552971e6474e3caf945e60efbc372058c3ba9e2a1be78c9bc`; 2150 words; 83961 tokens; new spend USD 0.000000

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 14 | 85.7% | 100.0% | 14.3% | 0 |

## Cost

- New spend this run: $0.1432
- Token cost at list price, including cache hits: $0.2104
- Tokens: 230958 input, 117622 output
- Per-run cap: $1.5000; per-day cap: $3.0000
- Spent today (UTC, all runs): $0.7961

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 68 | 30 | 230958 | 117622 | $0.1432 | $0.2104 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-01/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7469 | 733 | $0.0031 | 4.51 | 0 |
| C/brief-01/channels-sc-01 #1 | 1 | deepseek-flash | plan_channels@2 | 1082539864 | no | 8489 | 1475 | $0.0043 | 6.20 | 0 |
| C/brief-01/channels-sc-02 #1 | 1 | deepseek-flash | plan_channels@2 | 953394149 | no | 9074 | 1925 | $0.0050 | 6.76 | 0 |
| C/brief-01/channels-sc-03 #1 | 1 | deepseek-flash | plan_channels@2 | 1955734615 | no | 9524 | 2547 | $0.0059 | 9.38 | 0 |
| C/brief-01/channels-sc-03 #1 | 2 | deepseek-flash | plan_channels@2 | 1955734615 | no | 12114 | 2547 | $0.0067 | 8.22 | 0 |
| C/brief-01/channels-sc-04 #1 | 1 | deepseek-flash | plan_channels@2 | 199251043 | no | 10146 | 3232 | $0.0069 | 11.57 | 0 |
| C/brief-01/channels-sc-05 #1 | 1 | deepseek-flash | plan_channels@2 | 1275523251 | no | 10831 | 4071 | $0.0081 | 14.21 | 0 |
| C/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 646 | 538 | $0.0008 | 5.63 | 0 |
| C/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 732 | 513 | $0.0008 | 5.14 | 0 |
| C/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 730 | 444 | $0.0008 | 4.67 | 0 |
| C/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 751 | 432 | $0.0007 | 4.30 | 0 |
| C/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 733 | 457 | $0.0008 | 4.80 | 0 |
| B/brief-01/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 569 | 1147 | $0.0000 | 9.80 | 0 |
| B/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 601 | 269 | $0.0000 | 3.18 | 0 |
| B/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 683 | 363 | $0.0000 | 3.77 | 0 |
| B/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 658 | 256 | $0.0000 | 2.88 | 0 |
| B/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 692 | 230 | $0.0000 | 2.39 | 0 |
| B/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 737 | 282 | $0.0000 | 3.15 | 0 |
| B/brief-01/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 778 | 302 | $0.0000 | 3.39 | 0 |
| B/brief-01/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 786 | 313 | $0.0000 | 3.22 | 0 |
| B/brief-01/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 838 | 260 | $0.0000 | 2.77 | 0 |
| B/brief-01/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | no | 2508 | 2414 | $0.0036 | 11.25 | 0 |
| B/brief-01/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | no | 2657 | 2485 | $0.0038 | 11.01 | 0 |
| B/brief-01/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | no | 2728 | 2525 | $0.0038 | 11.32 | 0 |
| B/brief-01/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | no | 2768 | 2525 | $0.0039 | 10.97 | 0 |
| B/brief-01/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | no | 2768 | 2510 | $0.0038 | 10.79 | 0 |
| B/brief-01/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | no | 2753 | 2524 | $0.0039 | 11.21 | 0 |
| B/brief-01/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | no | 2767 | 2524 | $0.0039 | 10.67 | 0 |
| B/brief-01/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | no | 2767 | 2593 | $0.0039 | 11.56 | 0 |
| B/brief-01/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | no | 2836 | 2593 | $0.0040 | 10.90 | 0 |
| B/brief-01/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | no | 2836 | 2625 | $0.0040 | 11.67 | 0 |
| B/brief-01/revision-10 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1187348875 | no | 2836 | 2543 | $0.0039 | 12.22 | 0 |
| B/brief-01/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | no | 2786 | 2543 | $0.0039 | 10.79 | 0 |
| B/brief-01/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | no | 2786 | 2596 | $0.0040 | 12.02 | 0 |
| B/brief-01/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | no | 2839 | 2596 | $0.0040 | 11.11 | 0 |
| C/brief-02/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | no | 7451 | 684 | $0.0031 | 3.88 | 0 |
| C/brief-02/channels-s1 #1 | 1 | deepseek-flash | plan_channels@2 | 1310279880 | no | 8424 | 1391 | $0.0042 | 5.84 | 0 |
| C/brief-02/channels-s2 #1 | 1 | deepseek-flash | plan_channels@2 | 1407915137 | no | 8971 | 2112 | $0.0052 | 7.48 | 0 |
| C/brief-02/channels-s2 #1 | 2 | deepseek-flash | plan_channels@2 | 1407915137 | no | 11133 | 2106 | $0.0059 | 6.84 | 0 |
| C/brief-02/channels-s3 #1 | 1 | deepseek-flash | plan_channels@2 | 1438285283 | no | 9686 | 2885 | $0.0064 | 10.04 | 0 |
| C/brief-02/channels-s4 #1 | 1 | deepseek-flash | plan_channels@2 | 206457204 | no | 10465 | 3714 | $0.0076 | 12.30 | 0 |
| C/brief-02/channels-s5 #1 | 1 | deepseek-flash | plan_channels@2 | 1525124974 | no | 11294 | 4401 | $0.0087 | 14.31 | 0 |
| C/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 609 | 471 | $0.0007 | 4.65 | 0 |
| C/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 700 | 491 | $0.0008 | 4.88 | 0 |
| C/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 683 | 455 | $0.0008 | 4.49 | 0 |
| C/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 684 | 519 | $0.0008 | 4.79 | 0 |
| C/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 694 | 448 | $0.0007 | 4.76 | 0 |
| B/brief-02/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 554 | 931 | $0.0000 | 6.83 | 0 |
| B/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 532 | 378 | $0.0000 | 3.61 | 0 |
| B/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 608 | 418 | $0.0000 | 4.12 | 0 |
| B/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 617 | 378 | $0.0000 | 4.20 | 0 |
| B/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 665 | 495 | $0.0000 | 4.84 | 0 |
| B/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 705 | 437 | $0.0000 | 4.45 | 0 |
| B/brief-02/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 702 | 346 | $0.0000 | 3.82 | 0 |
| B/brief-02/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | yes | 2679 | 2450 | $0.0000 | 9.96 | 0 |
| B/brief-02/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | yes | 2678 | 2531 | $0.0000 | 11.38 | 0 |
| B/brief-02/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | yes | 2759 | 2631 | $0.0000 | 11.83 | 0 |
| B/brief-02/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | yes | 2859 | 2631 | $0.0000 | 11.53 | 0 |
| B/brief-02/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | yes | 2859 | 2708 | $0.0000 | 11.88 | 0 |
| B/brief-02/revision-05 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1289824051 | yes | 2859 | 2631 | $0.0000 | 10.98 | 0 |
| B/brief-02/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | yes | 2859 | 2631 | $0.0000 | 11.55 | 0 |
| B/brief-02/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | yes | 2859 | 2631 | $0.0000 | 10.67 | 0 |
| B/brief-02/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | yes | 2859 | 2631 | $0.0000 | 11.29 | 0 |
| B/brief-02/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | yes | 2859 | 2631 | $0.0000 | 11.11 | 0 |
| B/brief-02/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | yes | 2859 | 2631 | $0.0000 | 10.90 | 0 |
| B/brief-02/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | yes | 2859 | 2631 | $0.0000 | 11.24 | 0 |
