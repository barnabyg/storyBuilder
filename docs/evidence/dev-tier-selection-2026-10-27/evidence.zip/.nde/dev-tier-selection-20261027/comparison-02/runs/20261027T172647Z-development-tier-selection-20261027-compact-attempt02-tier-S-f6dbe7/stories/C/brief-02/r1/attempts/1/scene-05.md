The maintenance bay was empty at third shift, and the terminal in front of Tomas held two files: the log as it stood, and the log as it had been. He had spent two hours building the broadcast packet, checking and rechecking the manifest of destinations — every screen on every deck, the mess halls, the school corridors, the infirmary waiting room, the council chamber itself. There was no procedure for this. He wrote one, short, and attached it as the first frame so that no one would have to wonder what they were looking at.

He thought about the wording the way he thought about a torque spec, tightening it until nothing wobbled. *The navigation record below is unedited. It was changed in 2189 and kept changed until today. The ship is not going where you were told.*

His finger hovered. He remembered what the councilor had said about panic, about the delicate machinery of a settled mind, and he understood that she was not wrong, only that being right about the danger did not make the silence hers to keep. A person could bear a hard truth. What they could not bear, he had decided, was being managed.

He pressed the key.

The confirmation came back green. Across the ship, in the dark of sleep shifts, screens woke. He watched the progress bar on the public channel fill deck by deck — E, D, C — each one a small green light like a pulse. Somewhere a child would see a wall start talking about course corrections. Somewhere a woman would drop a cup. He did not let himself imagine the rest.

The bar reached A and stopped. The packet had gone out whole, checksum intact, the first honest record the ship had transmitted in forty-one years.

Tomas sat back. The bay hummed around him, the old familiar note of air moving through ductwork. Down the corridor he heard a door open, and then another, and then a voice — he could not tell whose — saying something he could not make out.

The announcement finished. The ship, all of it, from the engine decks to the observation ring, went quiet in a way he had never heard it go quiet before, and waited.