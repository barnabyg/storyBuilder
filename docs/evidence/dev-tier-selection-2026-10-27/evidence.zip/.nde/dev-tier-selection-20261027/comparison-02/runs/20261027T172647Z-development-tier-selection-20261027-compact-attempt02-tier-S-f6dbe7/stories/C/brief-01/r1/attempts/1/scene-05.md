The running lights went out at a quarter past two.

Ada had been watching them since midnight from the gallery, her coat buttoned wrong, the wind working at her hair. One moment there were three small points of green and red and white, moving south along the shelf the way Tom had taught her to read a vessel's intention. The next there was nothing but the sea's blackness and the faint phosphor of breaking water over the shoal.

She went inside. The radio sat on the shelf where it had sat for thirty years, and beside it the handset, and the number for the coast guard station at Brindle Point written on a card in Tom's slanted hand. She looked at the card a long time. Then she turned off the radio and put the card in the drawer with the spare wicks.

By the time she came down the tower the sound had begun — a grinding, then a great wooden coughing, then a crack that carried over the water like a gunshot. She walked out along the beach with her lamp still lit, though there was no need of it, and found them standing where the shingle steepened, Miles with his hands at his sides and June's face turned up toward the tower, as if she expected someone to be there.

The boat lay broadside in the surf, and the tide was lifting it and dropping it, and each drop took something away. The wheelhouse went first. Ada saw the window frames Tom had planed by hand, the ones he'd refused to replace with aluminium, go under and come up in pieces. Then the hull opened along the seam where the garboards met, and the sea came in with a sound like a held breath let go.

She stood beside them. Nobody spoke. June's hand found hers, cold and hard, and Ada held it. Miles wept without noise, his shoulders going, and Ada watched her husband's boat come apart in the dark and did not look away, because it was the last of him and she owed it her eyes.

When the deck broke, the locker floated free — Tom's old toolbox, the green one, riding the swell a moment before it went. Ada thought of going in. She didn't.

The tide did the rest.