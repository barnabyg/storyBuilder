The council chamber was small and plain, the sort of room that had been a storage closet before the ship's founders ran out of better uses for it. Councilor Vey sat alone at the table, which Tomas took as a deliberate choice: no witnesses, no minutes, nothing on the record but whatever she decided to remember.

He put the slate down between them and turned it around. The checksums glowed in their patient rows.

"I ran the comparison twice," he said. "Forty-one years of edits. Someone with root access has been quietly rewriting where we're going. I want to know who, and I want to know why."

Vey looked at the slate for a long moment. She did not look surprised, and that told him more than anything she could have said.

"It was the council," she said. "Before my time, and with my vote since. The order comes from this table, and it will keep coming from this table."

"Why?"

"Because of what the original burn did." She folded her hands. "It moved us toward a system we cannot reach in the lifetimes of anyone aboard and cannot survive if we arrive. The founders' arithmetic was wrong. When the first council understood that, they understood something else too: there are twelve thousand people in this hull who would rather turn the ship around and die trying than spend their lives crawling toward nothing. So the log was corrected. Quietly. Every time a navigator got curious."

"You lied to them."

"We kept them working," Vey said. "There is no mutiny in a ship that believes it has a destination. That is not cruelty, Okafor. That is maintenance, same as your job."

Tomas looked at the divergence point again, the moment the ship had turned away from where its passengers believed they were going.

"They have a right to know where they're going," he said. "You made that choice for them, and you keep making it every day. It isn't yours to make."

"It is precisely ours to make. That's what a council is."

"Then call a vote," he said. "Tell them the truth and let them decide."

Vey was quiet, and something in her face closed like a hatch.