# The Quiet Course

Plan brief-02; schema 1; tier S

Character tomas: Tomas Okafor

Character councilor-vey: Councilor Vey

Character archivist-halden: Archivist Halden

Character engineer-soto: Engineer Soto

## s1: A Number Out of Place

Tomas notices a checksum mismatch in the navigation log during routine maintenance.

Present: tomas

Beat s1-b1: A routine audit flags a checksum mismatch in the navigation log.

Beat s1-b2: Tomas confirms the discrepancy is real and not a sensor fault.

## s2: The Archived Truth

Tomas compares the log against an old backup and finds decades of edits.

Present: tomas, archivist-halden

Beat s2-b1: Halden retrieves a sealed backup that contradicts the current log.

Beat s2-b2: Tomas reconstructs a course change made decades ago and quietly hidden.

## s3: The Council's Reason

Tomas confronts the council and learns the edits were deliberate.

Present: tomas, councilor-vey

Beat s3-b1: Vey admits the council ordered the edits to prevent a mutiny.

Beat s3-b2: Tomas insists the passengers have a right to know their destination.

## s4: Pressure to Bury It

The council offers Tomas silence and status; he refuses.

Present: tomas, councilor-vey, engineer-soto

Beat s4-b1: Vey offers Tomas a promotion in exchange for his silence.

Beat s4-b2: Soto warns Tomas that exposing the truth could fracture the ship.

## s5: The Announcement

Tomas releases the original log to the ship's public channel.

Present: tomas

Beat s5-b1: Tomas broadcasts the unedited navigation record to every deck.

Beat s5-b2: The story ends as the announcement finishes and the ship waits.
