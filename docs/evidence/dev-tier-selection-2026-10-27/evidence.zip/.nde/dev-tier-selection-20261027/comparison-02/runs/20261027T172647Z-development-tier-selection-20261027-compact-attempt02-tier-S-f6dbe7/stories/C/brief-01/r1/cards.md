# The Last Haul

Plan plan-brief-01; schema 1; tier S

Character ada-venn: Ada Venn

Character miles-hark: Miles Hark

Character june-hark: June Hark

## sc-01: Sold at the Slip

Ada signs the boat away on the dock at dusk.

Present: ada-venn, miles-hark

Beat b-01a: Ada watches Miles count out the last of the cash for her husband's boat.

Beat b-01b: She pockets the key she never handed over and climbs the tower as always.

## sc-02: The Slip of a Tongue

A drunk deckhand lets slip the plan to scuttle the boat.

Present: ada-venn, miles-hark

Beat b-02a: At the co-op, a deckhand jokes that the boat will be worth more underwater.

Beat b-02b: Ada finds Miles at the fuel dock and sees the fear behind his grin.

## sc-03: Debt on the Kitchen Table

Ada learns why Miles needs the insurance money.

Present: ada-venn, june-hark

Beat b-03a: June Hark shows Ada the overdue notices spread across her table.

Beat b-03b: Ada says nothing of the scuttling plan and walks home along the seawall.

## sc-04: The Light Sweeps Empty

Ada weighs the truth against the neighbour she has known all her life.

Present: ada-venn, miles-hark

Beat b-04a: Ada confronts Miles on the pier and he admits the scheme without excuse.

Beat b-04b: She climbs the decommissioned tower and turns the dead lamp by hand.

## sc-05: Running Aground

The boat goes onto the rocks and Ada chooses what to save.

Present: ada-venn, miles-hark, june-hark

Beat b-05a: Ada sees the running lights go dark and does not call the coast guard.

Beat b-05b: On the shingle she stands beside Miles and June as the hull breaks apart.
