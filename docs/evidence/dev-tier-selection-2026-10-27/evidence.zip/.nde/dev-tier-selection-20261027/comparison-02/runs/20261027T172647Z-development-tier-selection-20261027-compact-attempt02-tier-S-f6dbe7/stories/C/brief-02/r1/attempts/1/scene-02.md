The archive annex was kept cold, and Halden kept it that way on purpose. She was a small woman with gray braids pinned tight against her skull, and she regarded Tomas over her desk like a customs officer deciding whether to open a crate.

"A sealed backup," she repeated. "Of the navigation log."

"Quarterly verification copy. The ones the charter requires we keep." Tomas set his tablet on the desk between them. "I'm not asking for anything restricted. It's a public record. Just sealed."

"Public records don't need a technician to request them at shift change." But she was already turning to her terminal, and her fingers moved with the unhurried certainty of someone who had spent forty years finding things. "Which quarter?"

He told her. She went still for a moment, then nodded slowly, as if he had confirmed something she had long suspected and never said aloud.

The retrieval took eleven minutes. The backup came up on her desk screen as a wall of numbers, and Halden turned the screen toward him without a word and stepped back, arms folded, watching him rather than it.

Tomas laid the two logs side by side. Current on the left, sealed backup on the right. For the first hundred lines they matched line for line. Then, at a timestamp forty-one years old, the current log read *course nominal* and the backup read *course adjustment, 0.31 degrees starboard, burn duration nine minutes.*

He scrolled. The correction propagated forward, quietly, through every subsequent entry. Each quarter's log had been recalculated to match the new heading, the old burn smoothed away like a wrinkle pressed out of cloth. The edits were careful. Competent. Whoever had done this understood the log's internal grammar better than Tomas did.

He pulled the raw telemetry—fuel consumption, thruster thermal records, the unglamorous ledger of what the ship had actually done—and ran it against the backup. The numbers agreed. The ship had turned. Forty-one years ago, in the dark, it had turned.

He sat back. The annex hummed around him, cold and patient.

"Someone's been writing our history," Halden said quietly, "for longer than you've been alive."

Tomas looked at the divergence point, then at the destination vector the old burn implied, and did not say what it pointed toward. Not yet.