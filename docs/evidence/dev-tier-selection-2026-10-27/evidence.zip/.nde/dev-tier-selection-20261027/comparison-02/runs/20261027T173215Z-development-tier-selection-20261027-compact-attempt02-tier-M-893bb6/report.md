# Run report: development-tier-selection-20261027-compact-attempt02-tier-M

- **Status:** succeeded
- **Started:** 2026-10-27T17:32:15.300857+00:00
- **Finished:** 2026-10-27T17:33:31.418657+00:00
- **Git SHA:** `3f29d9cd83e11b038a6dd963b6f7f168c93ed48e` (dirty)
- **Config:** `C:\docs\git\storyBuilder\.nde\dev-tier-selection-20261027\comparison-02\configs\M.yaml` (hash `367fa995a2fe`)
- **Seed:** 1700
- **Cache:** use, 61 hits, 15 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | deepseek | deepseek-flash | deepseek |

## Prompt templates

- `plan_skeleton@2` (sha256 `0da31dbfa52d`)
- `plan_channels@2` (sha256 `01ada4fa319c`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-01, brief-02 (from `C:\docs\git\storyBuilder\benchmark`)
- **Frozen splits:** none
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 3 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | C | 1 | 1901 | 2000 | 1 | yes | 0 | ok | 12 | 74192 | 18816 | $0.0448 | $0.0047 | [cards.html](stories/C/brief-01/r1/cards.html) [cards.md](stories/C/brief-01/r1/cards.md) [ledger.json](stories/C/brief-01/r1/ledger.json) [plan-selection.json](stories/C/brief-01/r1/plan-selection.json) [plan.json](stories/C/brief-01/r1/plan.json) [planning-provenance.json](stories/C/brief-01/r1/planning-provenance.json) [skeleton.json](stories/C/brief-01/r1/skeleton.json) [source-plan.json](stories/C/brief-01/r1/source-plan.json) [story.md](stories/C/brief-01/r1/story.md) [story.raw.md](stories/C/brief-01/r1/story.raw.md) [validation.json](stories/C/brief-01/r1/validation.json) |
| brief-01 | B | 1 | 2183 | 2000 | 1 | yes | 13 | ok | 23 | 44977 | 39018 | $0.0603 | $0.0000 | [outline.json](stories/B/brief-01/r1/outline.json) [story.md](stories/B/brief-01/r1/story.md) [story.original.md](stories/B/brief-01/r1/story.original.md) [story.raw.md](stories/B/brief-01/r1/story.raw.md) |
| brief-02 | C | 1 | 1859 | 2000 | 2 | yes | 0 | ok | 17 | 81695 | 21836 | $0.0507 | $0.0097 | [cards.html](stories/C/brief-02/r1/cards.html) [cards.md](stories/C/brief-02/r1/cards.md) [ledger.json](stories/C/brief-02/r1/ledger.json) [plan-selection.json](stories/C/brief-02/r1/plan-selection.json) [plan.json](stories/C/brief-02/r1/plan.json) [planning-provenance.json](stories/C/brief-02/r1/planning-provenance.json) [skeleton.json](stories/C/brief-02/r1/skeleton.json) [source-plan.json](stories/C/brief-02/r1/source-plan.json) [story.md](stories/C/brief-02/r1/story.md) [story.raw.md](stories/C/brief-02/r1/story.raw.md) [validation.json](stories/C/brief-02/r1/validation.json) |
| brief-02 | B | 1 | 2151 | 2000 | 2 | yes | 15 | ok | 24 | 52529 | 48284 | $0.0737 | $0.0000 | [outline.json](stories/B/brief-02/r1/outline.json) [story.md](stories/B/brief-02/r1/story.md) [story.original.md](stories/B/brief-02/r1/story.original.md) [story.raw.md](stories/B/brief-02/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 2 | 0 | 29 | 155887 | 40652 | $0.0955 | $0.0144 | $0.0478 |
| B | 2 | 0 | 47 | 97506 | 87302 | $0.1340 | $0.0000 | $0.0670 |

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 2 | 29 | 196539 | 98270 |
| B | 2 | 47 | 184808 | 92404 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 10% of the larger, with at most 24 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-01 | 1 | 93008 | 9764 | B | 13 | 93008 | 83995 | yes |  |
| brief-02 | 1 | 103531 | 7766 | B | 15 | 103531 | 100813 | yes |  |

2 matched, 0 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-01 repetition 1: comparable
- C: final `stories/C/brief-01/r1/story.md`, SHA-256 `0d487a10db1f9dc484271cbcf0298718277356ab2fb7f37a0a285c37b725a8ee`; 1901 words; 93008 tokens; new spend USD 0.004707
- B: final `stories/B/brief-01/r1/story.md`, SHA-256 `d5390a779f512c93b3f551ad9101219e291fb648a67fb76d14d29e5d4d6bb57a`; 2183 words; 83995 tokens; new spend USD 0.000000

brief-02 repetition 1: comparable
- C: final `stories/C/brief-02/r1/story.md`, SHA-256 `e65400bfd7500d965d65baaf770fe970c12ae5a61c82ca7aeae4a05af8a4d79f`; 1859 words; 103531 tokens; new spend USD 0.009733
- B: final `stories/B/brief-02/r1/story.md`, SHA-256 `cfd056b7e23e8ad4e147163a3afc4e8691b86e178cfed9e8016cb16571587f05`; 2151 words; 100813 tokens; new spend USD 0.000000

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 14 | 85.7% | 100.0% | 14.3% | 0 |

## Cost

- New spend this run: $0.0144
- Token cost at list price, including cache hits: $0.2296
- Tokens: 253393 input, 127954 output
- Per-run cap: $1.5000; per-day cap: $3.0000
- Spent today (UTC, all runs): $0.8106

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek/deepseek-flash | 76 | 61 | 253393 | 127954 | $0.0144 | $0.2296 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-01/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | yes | 7469 | 733 | $0.0000 | 4.51 | 0 |
| C/brief-01/channels-sc-01 #1 | 1 | deepseek-flash | plan_channels@2 | 1082539864 | yes | 8489 | 1475 | $0.0000 | 6.20 | 0 |
| C/brief-01/channels-sc-02 #1 | 1 | deepseek-flash | plan_channels@2 | 953394149 | yes | 9074 | 1925 | $0.0000 | 6.76 | 0 |
| C/brief-01/channels-sc-03 #1 | 1 | deepseek-flash | plan_channels@2 | 1955734615 | yes | 9524 | 2547 | $0.0000 | 9.38 | 0 |
| C/brief-01/channels-sc-03 #1 | 2 | deepseek-flash | plan_channels@2 | 1955734615 | yes | 12114 | 2547 | $0.0000 | 8.22 | 0 |
| C/brief-01/channels-sc-04 #1 | 1 | deepseek-flash | plan_channels@2 | 199251043 | yes | 10146 | 3232 | $0.0000 | 11.57 | 0 |
| C/brief-01/channels-sc-05 #1 | 1 | deepseek-flash | plan_channels@2 | 1275523251 | yes | 10831 | 4071 | $0.0000 | 14.21 | 0 |
| C/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 987 | 519 | $0.0009 | 5.29 | 0 |
| C/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1304 | 326 | $0.0008 | 3.41 | 0 |
| C/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1369 | 488 | $0.0010 | 4.97 | 0 |
| C/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1409 | 441 | $0.0010 | 4.18 | 0 |
| C/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1476 | 512 | $0.0011 | 4.88 | 0 |
| B/brief-01/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 569 | 1147 | $0.0000 | 9.80 | 0 |
| B/brief-01/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 601 | 269 | $0.0000 | 3.18 | 0 |
| B/brief-01/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 683 | 363 | $0.0000 | 3.77 | 0 |
| B/brief-01/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 658 | 256 | $0.0000 | 2.88 | 0 |
| B/brief-01/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 692 | 230 | $0.0000 | 2.39 | 0 |
| B/brief-01/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 737 | 282 | $0.0000 | 3.15 | 0 |
| B/brief-01/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 778 | 302 | $0.0000 | 3.39 | 0 |
| B/brief-01/scene-07 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 786 | 313 | $0.0000 | 3.22 | 0 |
| B/brief-01/scene-08 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 838 | 260 | $0.0000 | 2.77 | 0 |
| B/brief-01/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | yes | 2508 | 2414 | $0.0000 | 11.25 | 0 |
| B/brief-01/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | yes | 2657 | 2485 | $0.0000 | 11.01 | 0 |
| B/brief-01/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | yes | 2728 | 2525 | $0.0000 | 11.32 | 0 |
| B/brief-01/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | yes | 2768 | 2525 | $0.0000 | 10.97 | 0 |
| B/brief-01/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | yes | 2768 | 2510 | $0.0000 | 10.79 | 0 |
| B/brief-01/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | yes | 2753 | 2524 | $0.0000 | 11.21 | 0 |
| B/brief-01/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | yes | 2767 | 2524 | $0.0000 | 10.67 | 0 |
| B/brief-01/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | yes | 2767 | 2593 | $0.0000 | 11.56 | 0 |
| B/brief-01/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | yes | 2836 | 2593 | $0.0000 | 10.90 | 0 |
| B/brief-01/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | yes | 2836 | 2625 | $0.0000 | 11.67 | 0 |
| B/brief-01/revision-10 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1187348875 | yes | 2836 | 2543 | $0.0000 | 12.22 | 0 |
| B/brief-01/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | yes | 2786 | 2543 | $0.0000 | 10.79 | 0 |
| B/brief-01/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | yes | 2786 | 2596 | $0.0000 | 12.02 | 0 |
| B/brief-01/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | yes | 2839 | 2596 | $0.0000 | 11.11 | 0 |
| C/brief-02/skeleton #1 | 1 | deepseek-flash | plan_skeleton@2 | 2055141883 | yes | 7451 | 684 | $0.0000 | 3.88 | 0 |
| C/brief-02/channels-s1 #1 | 1 | deepseek-flash | plan_channels@2 | 1310279880 | yes | 8424 | 1391 | $0.0000 | 5.84 | 0 |
| C/brief-02/channels-s2 #1 | 1 | deepseek-flash | plan_channels@2 | 1407915137 | yes | 8971 | 2112 | $0.0000 | 7.48 | 0 |
| C/brief-02/channels-s2 #1 | 2 | deepseek-flash | plan_channels@2 | 1407915137 | yes | 11133 | 2106 | $0.0000 | 6.84 | 0 |
| C/brief-02/channels-s3 #1 | 1 | deepseek-flash | plan_channels@2 | 1438285283 | yes | 9686 | 2885 | $0.0000 | 10.04 | 0 |
| C/brief-02/channels-s4 #1 | 1 | deepseek-flash | plan_channels@2 | 206457204 | yes | 10465 | 3714 | $0.0000 | 12.30 | 0 |
| C/brief-02/channels-s5 #1 | 1 | deepseek-flash | plan_channels@2 | 1525124974 | yes | 11294 | 4401 | $0.0000 | 14.31 | 0 |
| C/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1183 | 535 | $0.0010 | 4.86 | 0 |
| C/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1485 | 374 | $0.0009 | 3.57 | 0 |
| C/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1588 | 452 | $0.0010 | 4.08 | 0 |
| C/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1490 | 493 | $0.0010 | 4.47 | 0 |
| C/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | no | 1371 | 392 | $0.0009 | 3.83 | 0 |
| C/brief-02/scene-01 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 1183 | 443 | $0.0009 | 13.41 | 0 |
| C/brief-02/scene-02 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 1529 | 533 | $0.0011 | 5.55 | 0 |
| C/brief-02/scene-03 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 1591 | 506 | $0.0011 | 5.11 | 0 |
| C/brief-02/scene-04 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 1484 | 466 | $0.0010 | 4.23 | 0 |
| C/brief-02/scene-05 (attempt 2) #1 | 1 | deepseek-flash | scene_prose@1 | 2133861582 | no | 1367 | 349 | $0.0008 | 3.61 | 0 |
| B/brief-02/outline #1 | 1 | deepseek-flash | beat_outline@1 | 1700 | yes | 554 | 931 | $0.0000 | 6.83 | 0 |
| B/brief-02/scene-01 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 532 | 378 | $0.0000 | 3.61 | 0 |
| B/brief-02/scene-02 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 608 | 418 | $0.0000 | 4.12 | 0 |
| B/brief-02/scene-03 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 617 | 378 | $0.0000 | 4.20 | 0 |
| B/brief-02/scene-04 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 665 | 495 | $0.0000 | 4.84 | 0 |
| B/brief-02/scene-05 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 705 | 437 | $0.0000 | 4.45 | 0 |
| B/brief-02/scene-06 #1 | 1 | deepseek-flash | scene_prose@1 | 1700 | yes | 702 | 346 | $0.0000 | 3.82 | 0 |
| B/brief-02/revision-01 #1 | 1 | deepseek-flash | story_revision@1 | 699523483 | yes | 2679 | 2450 | $0.0000 | 9.96 | 0 |
| B/brief-02/revision-02 #1 | 1 | deepseek-flash | story_revision@1 | 268967481 | yes | 2678 | 2531 | $0.0000 | 11.38 | 0 |
| B/brief-02/revision-03 #1 | 1 | deepseek-flash | story_revision@1 | 799162603 | yes | 2759 | 2631 | $0.0000 | 11.83 | 0 |
| B/brief-02/revision-04 #1 | 1 | deepseek-flash | story_revision@1 | 926389354 | yes | 2859 | 2631 | $0.0000 | 11.53 | 0 |
| B/brief-02/revision-05 #1 | 1 | deepseek-flash | story_revision@1 | 31500958 | yes | 2859 | 2708 | $0.0000 | 11.88 | 0 |
| B/brief-02/revision-05 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1289824051 | yes | 2859 | 2631 | $0.0000 | 10.98 | 0 |
| B/brief-02/revision-06 #1 | 1 | deepseek-flash | story_revision@1 | 1995769393 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-07 #1 | 1 | deepseek-flash | story_revision@1 | 1217963479 | yes | 2859 | 2631 | $0.0000 | 11.55 | 0 |
| B/brief-02/revision-08 #1 | 1 | deepseek-flash | story_revision@1 | 509456745 | yes | 2859 | 2631 | $0.0000 | 10.67 | 0 |
| B/brief-02/revision-09 #1 | 1 | deepseek-flash | story_revision@1 | 817715791 | yes | 2859 | 2631 | $0.0000 | 11.29 | 0 |
| B/brief-02/revision-10 #1 | 1 | deepseek-flash | story_revision@1 | 260015431 | yes | 2859 | 2631 | $0.0000 | 11.11 | 0 |
| B/brief-02/revision-11 #1 | 1 | deepseek-flash | story_revision@1 | 1731874683 | yes | 2859 | 2631 | $0.0000 | 10.90 | 0 |
| B/brief-02/revision-12 #1 | 1 | deepseek-flash | story_revision@1 | 492880195 | yes | 2859 | 2631 | $0.0000 | 11.32 | 0 |
| B/brief-02/revision-13 #1 | 1 | deepseek-flash | story_revision@1 | 1492306984 | yes | 2859 | 2631 | $0.0000 | 11.24 | 0 |
| B/brief-02/revision-14 #1 | 1 | deepseek-flash | story_revision@1 | 954275669 | yes | 2859 | 2633 | $0.0000 | 11.34 | 0 |
| B/brief-02/revision-15 #1 | 1 | deepseek-flash | story_revision@1 | 784163321 | yes | 2861 | 3005 | $0.0000 | 14.95 | 0 |
| B/brief-02/revision-15 (attempt 2) #1 | 1 | deepseek-flash | story_revision@1 | 1444081430 | yes | 2861 | 2633 | $0.0000 | 10.84 | 0 |
