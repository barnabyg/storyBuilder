June's house smelled of wet wool and old cooking oil, and she cleared a chair for Ada by shifting a basket of mending onto the floor. The table was already covered. Notices, a dozen of them, fanned across the oilcloth like a bad hand of cards: the electric, the fuel company, the clinic in Bar Harbor, a red-edged letter from the bank that June turned face-down without being asked.

"I'm not showing you this for pity," June said. She stood with her back to the sink, arms folded, a woman holding herself together by the elbows. "Miles doesn't know I've kept them. He thinks I burn them. But I wanted one person on this island to understand what we're standing in, so that when the talk starts—" She stopped. "There'll be talk."

Ada looked at the papers without touching them. The dates went back to spring. The clinic bill was the largest.

"When his back went," June said, "the boat payments didn't. And the boat was all we had that could be sold." She laughed, one short note. "Only nobody's buying a dragger off a man who can't haul. So." She spread her hands over the notices, then gathered them into a stack, squared the edges, and put them in a drawer, and it was the tidiness of the gesture that undid Ada more than the numbers.

She drank the tea June gave her. She said the weather would hold. She said she'd heard the fuel dock had a new pump. She said nothing about the deckhand, nothing about the word scuttle, nothing about the way the boy had said it, easy as breathing, with his hand on the rail of her husband's boat.

At the door June took her arm. "You sold to him fair," she said. "I want you to know I know that."

Ada walked home along the seawall with the wind at her shoulder. Below, the tide was making, and the Marrow swung on her mooring, still whole, still hers in the only way that mattered now. Ada did not stop to look at her. She had learned that much.