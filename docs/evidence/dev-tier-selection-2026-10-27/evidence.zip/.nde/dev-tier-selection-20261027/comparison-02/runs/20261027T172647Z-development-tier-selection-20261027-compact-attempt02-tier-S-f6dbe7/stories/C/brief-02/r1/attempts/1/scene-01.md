The audit ran at 0300, ship time, the way it always did. Tomas Okafor did not need to be awake for it. The maintenance scheduler woke him anyway, because he had written the scheduler, and he had written it to wake him.

He sat up in his bunk with the tablet against his knees and watched the status lines scroll. Hull integrity, nominal. Water reclamation, nominal. Atmosphere, twelve checks, all nominal. He liked the litany. It was the closest thing the *Atacama* had to a heartbeat, and after four years on the maintenance rotation he could read it the way other people read faces.

Then the navigation log entry came up amber.

Tomas frowned and tapped it. The audit compared the log's rolling checksum against the value stored at the last certified write. They matched for six hundred and eleven days, and then, at a timestamp he did not recognize, they diverged by a single digit.

He checked the obvious causes first. A dropped write during a power dip, a clock skew between the log server and the audit server, a corrupted page of flash. He pulled the raw block and read it by hand. The checksum itself was intact. The record had been written cleanly, by a process with the right credentials, and the checksum had been computed after the record was written. It was not damage. It was an edit.

He ran the comparison twice more from the terminal in the corridor, standing barefoot on the cold deck plate because he did not want to wake his bunkmate. Same result. He ran a sensor-integrity sweep on the log server's own clock and storage, and the sweep came back clean, and he sat with that for a moment, because a sensor fault would have been easy. A sensor fault would have been nothing.

He looked down the corridor at the dark doors of the sleepers and then back at the amber line, the single digit out of place, patient as a splinter under the skin.

He saved the raw block to his private partition, noted the time, and did not report it. Not yet. Reporting it would mean handing it to someone, and Tomas had learned to trust records more than people, which meant he wanted to know exactly what the record said before he let a person touch it.