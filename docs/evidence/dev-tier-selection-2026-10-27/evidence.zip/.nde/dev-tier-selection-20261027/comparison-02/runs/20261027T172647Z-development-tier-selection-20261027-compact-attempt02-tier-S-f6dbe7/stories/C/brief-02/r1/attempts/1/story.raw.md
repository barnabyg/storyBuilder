The audit ran at 0300, ship time, the way it always did. Tomas Okafor did not need to be awake for it. The maintenance scheduler woke him anyway, because he had written the scheduler, and he had written it to wake him.

He sat up in his bunk with the tablet against his knees and watched the status lines scroll. Hull integrity, nominal. Water reclamation, nominal. Atmosphere, twelve checks, all nominal. He liked the litany. It was the closest thing the Atacama had to a heartbeat, and after four years on the maintenance rotation he could read it the way other people read faces.

Then the navigation log entry came up amber.

Tomas frowned and tapped it. The audit compared the log's rolling checksum against the value stored at the last certified write. They matched for six hundred and eleven days, and then, at a timestamp he did not recognize, they diverged by a single digit.

He checked the obvious causes first. A dropped write during a power dip, a clock skew between the log server and the audit server, a corrupted page of flash. He pulled the raw block and read it by hand. The checksum itself was intact. The record had been written cleanly, by a process with the right credentials, and the checksum had been computed after the record was written. It was not damage. It was an edit.

He ran the comparison twice more from the terminal in the corridor, standing barefoot on the cold deck plate because he did not want to wake his bunkmate. Same result. He ran a sensor-integrity sweep on the log server's own clock and storage, and the sweep came back clean, and he sat with that for a moment, because a sensor fault would have been easy. A sensor fault would have been nothing.

He looked down the corridor at the dark doors of the sleepers and then back at the amber line, the single digit out of place, patient as a splinter under the skin.

He saved the raw block to his private partition, noted the time, and did not report it. Not yet. Reporting it would mean handing it to someone, and Tomas had learned to trust records more than people, which meant he wanted to know exactly what the record said before he let a person touch it.

The archive annex was kept cold, and Halden kept it that way on purpose. She was a small woman with gray braids pinned tight against her skull, and she regarded Tomas over her desk like a customs officer deciding whether to open a crate.

"A sealed backup," she repeated. "Of the navigation log."

"Quarterly verification copy. The ones the charter requires we keep." Tomas set his tablet on the desk between them. "I'm not asking for anything restricted. It's a public record. Just sealed."

"Public records don't need a technician to request them at shift change." But she was already turning to her terminal, and her fingers moved with the unhurried certainty of someone who had spent forty years finding things. "Which quarter?"

He told her. She went still for a moment, then nodded slowly, as if he had confirmed something she had long suspected and never said aloud.

The retrieval took eleven minutes. The backup came up on her desk screen as a wall of numbers, and Halden turned the screen toward him without a word and stepped back, arms folded, watching him rather than it.

Tomas laid the two logs side by side. Current on the left, sealed backup on the right. For the first hundred lines they matched line for line. Then, at a timestamp forty-one years old, the current log read course nominal and the backup read course adjustment, 0.31 degrees starboard, burn duration nine minutes.

He scrolled. The correction propagated forward, quietly, through every subsequent entry. Each quarter's log had been recalculated to match the new heading, the old burn smoothed away like a wrinkle pressed out of cloth. The edits were careful. Competent. Whoever had done this understood the log's internal grammar better than Tomas did.

He pulled the raw telemetry—fuel consumption, thruster thermal records, the unglamorous ledger of what the ship had actually done—and ran it against the backup. The numbers agreed. The ship had turned. Forty-one years ago, in the dark, it had turned.

He sat back. The annex hummed around him, cold and patient.

"Someone's been writing our history," Halden said quietly, "for longer than you've been alive."

Tomas looked at the divergence point, then at the destination vector the old burn implied, and did not say what it pointed toward. Not yet.

The council chamber was small and plain, the sort of room that had been a storage closet before the ship's founders ran out of better uses for it. Councilor Vey sat alone at the table, which Tomas took as a deliberate choice: no witnesses, no minutes, nothing on the record but whatever she decided to remember.

He put the slate down between them and turned it around. The checksums glowed in their patient rows.

"I ran the comparison twice," he said. "Forty-one years of edits. Someone with root access has been quietly rewriting where we're going. I want to know who, and I want to know why."

Vey looked at the slate for a long moment. She did not look surprised, and that told him more than anything she could have said.

"It was the council," she said. "Before my time, and with my vote since. The order comes from this table, and it will keep coming from this table."

"Why?"

"Because of what the original burn did." She folded her hands. "It moved us toward a system we cannot reach in the lifetimes of anyone aboard and cannot survive if we arrive. The founders' arithmetic was wrong. When the first council understood that, they understood something else too: there are twelve thousand people in this hull who would rather turn the ship around and die trying than spend their lives crawling toward nothing. So the log was corrected. Quietly. Every time a navigator got curious."

"You lied to them."

"We kept them working," Vey said. "There is no mutiny in a ship that believes it has a destination. That is not cruelty, Okafor. That is maintenance, same as your job."

Tomas looked at the divergence point again, the moment the ship had turned away from where its passengers believed they were going.

"They have a right to know where they're going," he said. "You made that choice for them, and you keep making it every day. It isn't yours to make."

"It is precisely ours to make. That's what a council is."

"Then call a vote," he said. "Tell them the truth and let them decide."

Vey was quiet, and something in her face closed like a hatch.

Vey folded her hands on the table. "You're a junior technician, Okafor. Second grade. How long have you been at that rank?"

"Six years."

"Six years." She said it as though the number had been weighed and found wanting. "That's a long time to be overlooked. And with Halloran retiring next cycle, the maintenance division is going to need a chief. Somebody who understands the systems. Somebody careful." She let the pause do its work. "Somebody who knows when a thing is finished and doesn't keep picking at it."

Tomas said nothing.

"The appointment is the council's to make," Vey went on. "It could be made quietly. It could be made this week. You'd have a seat at this table, eventually. A voice in how the ship is run." She leaned back. "Or you could keep pulling at threads and see where you end up. I'd rather it were the first thing."

"It's the same offer," Tomas said. "Only bigger."

"It's the only offer you'll get."

Soto, who had said nothing through the whole of it, cleared his throat. He was old, and he looked older now, his face gray under the light. "Tomas. Listen to me a moment, and then I'll leave you be." He glanced at Vey, who gave him nothing, and went on anyway. "I've been on this ship forty years. I've watched people build lives out of what they were told. My mother did. Her mother did. They don't know a course was changed because they never needed to know. You tell them now, and it isn't information you're handing them. It's a hole in the floor. Everything they stood on goes with it." He tapped the table once, softly. "You think the truth is a gift. Sometimes it's just a weight, and people who never asked to carry it will break under it."

"They can carry what they choose to," Tomas said. "That's the difference."

Soto looked at him for a long time, then shook his head and stood. "Then you've already decided," he said, and walked out.

Vey watched him go. When the hatch closed she turned back to Tomas, and her voice was almost gentle. "Take the week. Think about it. I'll want an answer."

Tomas stood. "You'll have it sooner than that," he said, and left her sitting alone with her hands folded on the table.

The maintenance bay was empty at third shift, and the terminal in front of Tomas held two files: the log as it stood, and the log as it had been. He had spent two hours building the broadcast packet, checking and rechecking the manifest of destinations — every screen on every deck, the mess halls, the school corridors, the infirmary waiting room, the council chamber itself. There was no procedure for this. He wrote one, short, and attached it as the first frame so that no one would have to wonder what they were looking at.

He thought about the wording the way he thought about a torque spec, tightening it until nothing wobbled. The navigation record below is unedited. It was changed in 2189 and kept changed until today. The ship is not going where you were told.

His finger hovered. He remembered what the councilor had said about panic, about the delicate machinery of a settled mind, and he understood that she was not wrong, only that being right about the danger did not make the silence hers to keep. A person could bear a hard truth. What they could not bear, he had decided, was being managed.

He pressed the key.

The confirmation came back green. Across the ship, in the dark of sleep shifts, screens woke. He watched the progress bar on the public channel fill deck by deck — E, D, C — each one a small green light like a pulse. Somewhere a child would see a wall start talking about course corrections. Somewhere a woman would drop a cup. He did not let himself imagine the rest.

The bar reached A and stopped. The packet had gone out whole, checksum intact, the first honest record the ship had transmitted in forty-one years.

Tomas sat back. The bay hummed around him, the old familiar note of air moving through ductwork. Down the corridor he heard a door open, and then another, and then a voice — he could not tell whose — saying something he could not make out.

The announcement finished. The ship, all of it, from the engine decks to the observation ring, went quiet in a way he had never heard it go quiet before, and waited.