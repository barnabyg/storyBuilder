The co-op store smelled of rope and diesel and the sweetish rot of old bait. Ada had come down for a tin of coffee and a bag of salt, and she stood at the counter with her purse open while the clerk weighed out the coffee from the bin, and the two deckhands from the Marrow came in loud off the evening tide.

They were young and salt-cured and half drunk, the way crews were on a boat's last night in a port. One of them, a boy with a sun-scorched neck, set his bottle on the counter and leaned on it and grinned at her.

"Evening, Miz Venn. Sorry about the old girl."

"She's not gone yet," Ada said.

"Gone enough." He laughed, too bright. "Miles says she'll be worth more underwater than afloat. Says the sea's a better buyer than any of us." The other deckhand dug an elbow into his ribs, hard, and the boy blinked and seemed to remember himself. "Joke," he said. "Only a joke."

Ada paid for her coffee and her salt and did not hurry out. On the step she stood a moment in the cooling air and heard the water working at the pilings, and the boy's voice came through the screen door behind her, mumbling something to his mate that she could not make out and did not need to.

Miles was at the fuel dock, hosing the deck of his truck, the water sheeting black off the boards. He saw her and straightened and put on his grin, that wide one he had worn since he was a boy and had broken her kitchen window with a ball and sworn it was the wind.

"Ada. You're out late."

"Ran out of coffee." She looked at him. The grin was there, but it was working too hard, holding itself up, and behind it his eyes were afraid, small and darting, the way a man's eyes go when the arithmetic has beaten him and he is only waiting for the sum to be read aloud. He looked older than he had at the signing. He looked like his father had at the end.

"Cold tonight," he said, for something to say.

"Cold," she agreed.

She went up the hill with her coffee and her salt, and she did not look back at the fuel dock, and she did not look at the water, where the Marrow lay at her mooring and the last light went out of her rail by rail.