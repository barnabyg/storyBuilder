Vey folded her hands on the table. "You're a junior technician, Okafor. Second grade. How long have you been at that rank?"

"Six years."

"Six years." She said it as though the number had been weighed and found wanting. "That's a long time to be overlooked. And with Halloran retiring next cycle, the maintenance division is going to need a chief. Somebody who understands the systems. Somebody careful." She let the pause do its work. "Somebody who knows when a thing is finished and doesn't keep picking at it."

Tomas said nothing.

"The appointment is the council's to make," Vey went on. "It could be made quietly. It could be made this week. You'd have a seat at this table, eventually. A voice in how the ship is run." She leaned back. "Or you could keep pulling at threads and see where you end up. I'd rather it were the first thing."

"It's the same offer," Tomas said. "Only bigger."

"It's the only offer you'll get."

Soto, who had said nothing through the whole of it, cleared his throat. He was old, and he looked older now, his face gray under the light. "Tomas. Listen to me a moment, and then I'll leave you be." He glanced at Vey, who gave him nothing, and went on anyway. "I've been on this ship forty years. I've watched people build lives out of what they were told. My mother did. Her mother did. They don't know a course was changed because they never needed to know. You tell them now, and it isn't information you're handing them. It's a hole in the floor. Everything they stood on goes with it." He tapped the table once, softly. "You think the truth is a gift. Sometimes it's just a weight, and people who never asked to carry it will break under it."

"They can carry what they choose to," Tomas said. "That's the difference."

Soto looked at him for a long time, then shook his head and stood. "Then you've already decided," he said, and walked out.

Vey watched him go. When the hatch closed she turned back to Tomas, and her voice was almost gentle. "Take the week. Think about it. I'll want an answer."

Tomas stood. "You'll have it sooner than that," he said, and left her sitting alone with her hands folded on the table.