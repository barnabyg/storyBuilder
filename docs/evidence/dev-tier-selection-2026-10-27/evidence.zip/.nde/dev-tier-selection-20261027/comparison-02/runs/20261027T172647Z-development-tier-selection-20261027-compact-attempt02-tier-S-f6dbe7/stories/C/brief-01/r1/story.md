The light was already thinning when Miles Hark came down the dock with the envelope. Ada stood beside the Marrow, her hand flat on the gunwale, feeling the cold seep up through the old wood. Forty-one years her husband had kept this boat, and it still smelled of him—of diesel and salt and the cheap pipe tobacco he'd sworn he'd given up.

Miles didn't meet her eyes. He counted the bills out onto the capstan crate between them, licking his thumb at each one, and she watched his hands instead of his face. Good hands. Steady hands, once. His father had crewed for Tom in the bad winter of 'eighty-nine, and Tom had come home saying the boy had the sea in him.

"Twenty-eight hundred," Miles said. "That's the lot."

"It's the lot," she agreed.

He pushed the money across. She didn't count it. She folded it into her coat pocket, and they stood a moment in the wind, neither of them saying the things that had been said already, down at the co-op, in the church porch, over the fence between their gardens.

"She'll want a coat of paint," Ada said at last.

"She'll get one."

"Don't let her sit idle, Miles. A boat that sits idle goes sour."

He nodded, and then he was climbing aboard, and Ada stepped back onto the boards and let him have her. The key was in her pocket, on its ring with the brass tag Tom had stamped himself—M. VENN, MARROW, PENRHYN. She had meant to hand it over. She had meant to, and then Miles had started counting, and she had understood, watching his thumb go lick-lick, that she was not ready to watch him start the engine.

So she kept it.

She walked the length of the dock and up the path, past the garden gate she did not open, and on to the tower. The door was stiff with rust, as it always was. The stairs went up in their slow spiral, a hundred and twelve of them, and she climbed them the way she climbed them every night since the light was decommissioned—by feel, by count, by the remembered pressure of Tom's hand at her back on the narrow turns.

At the top, the lamp stood dark and cold and enormous. She put her palm against the housing and looked out at the water, where the Marrow sat small and pale in the last of the light, and the key lay heavy in her pocket like a coin she had no business keeping.

The co-op store smelled of rope and diesel and the sweetish rot of old bait. Ada had come down for a tin of coffee and a bag of salt, and she stood at the counter with her purse open while the clerk weighed out the coffee from the bin, and the two deckhands from the Marrow came in loud off the evening tide.

They were young and salt-cured and half drunk, the way crews were on a boat's last night in a port. One of them, a boy with a sun-scorched neck, set his bottle on the counter and leaned on it and grinned at her.

"Evening, Miz Venn. Sorry about the old girl."

"She's not gone yet," Ada said.

"Gone enough." He laughed, too bright. "Miles says she'll be worth more underwater than afloat. Says the sea's a better buyer than any of us." The other deckhand dug an elbow into his ribs, hard, and the boy blinked and seemed to remember himself. "Joke," he said. "Only a joke."

Ada paid for her coffee and her salt and did not hurry out. On the step she stood a moment in the cooling air and heard the water working at the pilings, and the boy's voice came through the screen door behind her, mumbling something to his mate that she could not make out and did not need to.

Miles was at the fuel dock, hosing the deck of his truck, the water sheeting black off the boards. He saw her and straightened and put on his grin, that wide one he had worn since he was a boy and had broken her kitchen window with a ball and sworn it was the wind.

"Ada. You're out late."

"Ran out of coffee." She looked at him. The grin was there, but it was working too hard, holding itself up, and behind it his eyes were afraid, small and darting, the way a man's eyes go when the arithmetic has beaten him and he is only waiting for the sum to be read aloud. He looked older than he had at the signing. He looked like his father had at the end.

"Cold tonight," he said, for something to say.

"Cold," she agreed.

She went up the hill with her coffee and her salt, and she did not look back at the fuel dock, and she did not look at the water, where the Marrow lay at her mooring and the last light went out of her rail by rail.

June's house smelled of wet wool and old cooking oil, and she cleared a chair for Ada by shifting a basket of mending onto the floor. The table was already covered. Notices, a dozen of them, fanned across the oilcloth like a bad hand of cards: the electric, the fuel company, the clinic in Bar Harbor, a red-edged letter from the bank that June turned face-down without being asked.

"I'm not showing you this for pity," June said. She stood with her back to the sink, arms folded, a woman holding herself together by the elbows. "Miles doesn't know I've kept them. He thinks I burn them. But I wanted one person on this island to understand what we're standing in, so that when the talk starts—" She stopped. "There'll be talk."

Ada looked at the papers without touching them. The dates went back to spring. The clinic bill was the largest.

"When his back went," June said, "the boat payments didn't. And the boat was all we had that could be sold." She laughed, one short note. "Only nobody's buying a dragger off a man who can't haul. So." She spread her hands over the notices, then gathered them into a stack, squared the edges, and put them in a drawer, and it was the tidiness of the gesture that undid Ada more than the numbers.

She drank the tea June gave her. She said the weather would hold. She said she'd heard the fuel dock had a new pump. She said nothing about the deckhand, nothing about the word scuttle, nothing about the way the boy had said it, easy as breathing, with his hand on the rail of her husband's boat.

At the door June took her arm. "You sold to him fair," she said. "I want you to know I know that."

Ada walked home along the seawall with the wind at her shoulder. Below, the tide was making, and the Marrow swung on her mooring, still whole, still hers in the only way that mattered now. Ada did not stop to look at her. She had learned that much.

She found him on the pier at first light, mending a pot buoy with the slow hands of a man who had not slept. Miles Hark had been her husband's friend for thirty years, and he did not look up when she stopped in front of him.

"Tell me," Ada said.

He set the needle down. For a moment she thought he would lie, and she was ready for it. But he only looked at the water and said, "The bank takes the house in March. It's the last thing I can do."

"Run her aground."

"Off the point, on a falling tide. They'll rule it a grounding. The insurance covers the hull." He wiped his palms on his trousers. "I know what she is to you. I know it, Ada. I'm not asking you to forgive it."

"You're not asking me anything."

"No." He picked the needle up again, though he did not sew. "That's the trouble."

She could have gone to the harbourmaster. One word, and the claim would be investigated, the scheme undone, Miles and his family finished. She stood with the wind pulling at her coat and understood that the truth had two edges, and both of them cut.

She left him without a word and walked the shore road to the station. The tower stood where it had always stood, whitewashed and useless. Inside, the spiral stairs smelled of salt and cold stone. She climbed them as she climbed them every night, her hand on the rail where John's hand had worn it smooth.

At the top, the lamp sat dark in its cage of glass. Decommissioned years ago, the mechanism seized, the light stripped out. Ada set her palms against the old brass and turned it by hand, and it moved, stiff and groaning, one slow revolution after another. The lenses caught what grey morning there was and threw it out across the water in a pale, useless sweep. Out past the point, the Marrow swung on her mooring.

Ada turned the dead lamp until her arms ached, and let the light fall on nothing.

The running lights went out at a quarter past two.

Ada had been watching them since midnight from the gallery, her coat buttoned wrong, the wind working at her hair. One moment there were three small points of green and red and white, moving south along the shelf the way Tom had taught her to read a vessel's intention. The next there was nothing but the sea's blackness and the faint phosphor of breaking water over the shoal.

She went inside. The radio sat on the shelf where it had sat for thirty years, and beside it the handset, and the number for the coast guard station at Brindle Point written on a card in Tom's slanted hand. She looked at the card a long time. Then she turned off the radio and put the card in the drawer with the spare wicks.

By the time she came down the tower the sound had begun — a grinding, then a great wooden coughing, then a crack that carried over the water like a gunshot. She walked out along the beach with her lamp still lit, though there was no need of it, and found them standing where the shingle steepened, Miles with his hands at his sides and June's face turned up toward the tower, as if she expected someone to be there.

The boat lay broadside in the surf, and the tide was lifting it and dropping it, and each drop took something away. The wheelhouse went first. Ada saw the window frames Tom had planed by hand, the ones he'd refused to replace with aluminium, go under and come up in pieces. Then the hull opened along the seam where the garboards met, and the sea came in with a sound like a held breath let go.

She stood beside them. Nobody spoke. June's hand found hers, cold and hard, and Ada held it. Miles wept without noise, his shoulders going, and Ada watched her husband's boat come apart in the dark and did not look away, because it was the last of him and she owed it her eyes.

When the deck broke, the locker floated free — Tom's old toolbox, the green one, riding the swell a moment before it went. Ada thought of going in. She didn't.

The tide did the rest.
