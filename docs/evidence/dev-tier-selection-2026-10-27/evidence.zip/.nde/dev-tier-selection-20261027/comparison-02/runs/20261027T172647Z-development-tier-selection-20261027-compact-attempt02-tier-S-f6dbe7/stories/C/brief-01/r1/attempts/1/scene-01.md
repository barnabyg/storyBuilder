The light was already thinning when Miles Hark came down the dock with the envelope. Ada stood beside the *Marrow*, her hand flat on the gunwale, feeling the cold seep up through the old wood. Forty-one years her husband had kept this boat, and it still smelled of him—of diesel and salt and the cheap pipe tobacco he'd sworn he'd given up.

Miles didn't meet her eyes. He counted the bills out onto the capstan crate between them, licking his thumb at each one, and she watched his hands instead of his face. Good hands. Steady hands, once. His father had crewed for Tom in the bad winter of 'eighty-nine, and Tom had come home saying the boy had the sea in him.

"Twenty-eight hundred," Miles said. "That's the lot."

"It's the lot," she agreed.

He pushed the money across. She didn't count it. She folded it into her coat pocket, and they stood a moment in the wind, neither of them saying the things that had been said already, down at the co-op, in the church porch, over the fence between their gardens.

"She'll want a coat of paint," Ada said at last.

"She'll get one."

"Don't let her sit idle, Miles. A boat that sits idle goes sour."

He nodded, and then he was climbing aboard, and Ada stepped back onto the boards and let him have her. The key was in her pocket, on its ring with the brass tag Tom had stamped himself—*M. VENN, MARROW, PENRHYN*. She had meant to hand it over. She had meant to, and then Miles had started counting, and she had understood, watching his thumb go lick-lick, that she was not ready to watch him start the engine.

So she kept it.

She walked the length of the dock and up the path, past the garden gate she did not open, and on to the tower. The door was stiff with rust, as it always was. The stairs went up in their slow spiral, a hundred and twelve of them, and she climbed them the way she climbed them every night since the light was decommissioned—by feel, by count, by the remembered pressure of Tom's hand at her back on the narrow turns.

At the top, the lamp stood dark and cold and enormous. She put her palm against the housing and looked out at the water, where the *Marrow* sat small and pale in the last of the light, and the key lay heavy in her pocket like a coin she had no business keeping.