She found him on the pier at first light, mending a pot buoy with the slow hands of a man who had not slept. Miles Hark had been her husband's friend for thirty years, and he did not look up when she stopped in front of him.

"Tell me," Ada said.

He set the needle down. For a moment she thought he would lie, and she was ready for it. But he only looked at the water and said, "The bank takes the house in March. It's the last thing I can do."

"Run her aground."

"Off the point, on a falling tide. They'll rule it a grounding. The insurance covers the hull." He wiped his palms on his trousers. "I know what she is to you. I know it, Ada. I'm not asking you to forgive it."

"You're not asking me anything."

"No." He picked the needle up again, though he did not sew. "That's the trouble."

She could have gone to the harbourmaster. One word, and the claim would be investigated, the scheme undone, Miles and his family finished. She stood with the wind pulling at her coat and understood that the truth had two edges, and both of them cut.

She left him without a word and walked the shore road to the station. The tower stood where it had always stood, whitewashed and useless. Inside, the spiral stairs smelled of salt and cold stone. She climbed them as she climbed them every night, her hand on the rail where John's hand had worn it smooth.

At the top, the lamp sat dark in its cage of glass. Decommissioned years ago, the mechanism seized, the light stripped out. Ada set her palms against the old brass and turned it by hand, and it moved, stiff and groaning, one slow revolution after another. The lenses caught what grey morning there was and threw it out across the water in a pale, useless sweep. Out past the point, the Marrow swung on her mooring.

Ada turned the dead lamp until her arms ached, and let the light fall on nothing.