The tower stairs were cold under Ada's hand, the iron rail slick with the damp that came off the water after sundown. She climbed them anyway, as she had every night since the light had been struck from the register, and set her lamp on the old pedestal and lit it by hand. The flame guttered, then held. Below her the harbour lay in its usual scatter of lights, and there at the wharf, small and patient, rode the Marigold, her hull dark against the black water.

She had signed the bill of sale that afternoon at the kitchen table, her pen pressing harder than it needed to. Eli Pruitt had sat across from her with his cap in his hands, his face flushed as though he had run the length of the wharf. His traps had come up empty two seasons running; she knew that, and knew the price of knowing. He had said he had a plan for her, for the boat, and was gone before she could ask what plan. When the door shut she had gone down to the wharf and laid her palm flat against the nameplate, the letters cold and raised. She remembered Tom in the spring, on his knees with the caulking iron, whistling through his teeth, the smell of tar and varnish and his pipe smoke all mixed together in the sun. He had built her to outlast them both, he said, and she had laughed at him and handed him the pot of varnish.

In the morning she climbed the tower as she always did, though there was no light to tend and no ships to guide. The habit outlasted the job. From the gallery she could see the whole harbour laid out below her, the wharf and the boats and the road curving up past the chapel. A city car she didn't know sat at the end of the wharf, grey and clean, and Eli stood at its open window with his hands in his pockets, leaning down to talk to whoever was inside. The wind carried most of it away, but it carried some. She heard total loss and then, after a pause, the surveyor won't ask questions. She stood very still with her hands on the rail and made herself hear it again, and the second time it was no different.

She came down the stairs slowly, one hand on the rail, and crossed the wharf as though she were only going about her morning. Eli turned when he heard her boots on the boards. His face did something quick and badly managed.

"Ada. Morning."

"Morning."

"This is my cousin," he said. "From Plymouth. Just passing through."

The man in the car lifted two fingers from the wheel and didn't smile. Eli's hands had come out of his pockets and they shook, small and steady, the way a man shakes when he has been holding something in too long. She left them to it and went into the shed for the tide tables, because the tide was what she had come for. The book lay open on the bench where Eli had been reading it, and there, pencilled in the margin against a date, was a small cross. The new moon. The night the reef off Gull Point would be at its shallowest. She closed the book on the mark and took it with her.

She did not go to him that day. She went home and sat with it, and the sitting was worse than the knowing. Toward evening she walked down through the lanes to the Pruitts' and found them at their kitchen table, the tea gone cold between them, Ruth's hands folded on the oilcloth as though she had been sitting that way a long while. The colander stood on the floor by the sink with the potatoes half done in it, and the sight of it, of the ordinary work of a life interrupted, was somehow worse than the debt itself. Ada laid the tide-table page on the table and smoothed it flat with the heel of her hand.

Eli looked at it. He didn't touch it.

"The bank's given us thirty days," Ruth said. "On the house."

Eli pushed his cup away. "It'll run aground on the reef," he said, quiet, almost gentle. "The insurer pays out. Nobody's on her, nobody gets hurt. That's all it is, Ada. A boat going on the rocks the way boats do." He looked at her. "Say nothing. That's all I'm asking."

Ada stood a moment. Then she went out through the back door, down the path, past the bean rows going over. At the gate, Ruth caught her sleeve. "I'm sorry about Tom's boat," she said, and her voice caught on the name, and Ada understood that she meant it, and that it changed nothing.

She brought Frank Dwyer a jar of preserves the next afternoon, the way she did most weeks, and set it on his kitchen table while the kettle came up. He had run the harbour office for forty years and still knew every hull that passed the point. She told him a thing, not naming Eli, only a thing a keeper might have heard. Frank turned his cup slowly. A report would mean an investigation, he said. A criminal charge. The Pruitts would lose the house, and there was no version where they didn't. He said the insurer, once it smelled fraud, might refuse to pay a penny. The Marigold would be seized as evidence and sit in a yard for years, rotting under a tarp, and never sail again either way. "Either way," he said again, quieter, and looked out at the water.

Ada walked home along the shore. The tide was slack and the evening had gone still, and there in the shallows lay the boat turned upside down in the water, mast and all, so clear she could have counted the planks. She stood a long while looking at it. It was only a reflection, she knew—the Marigold riding at her mooring, doubled and inverted by the calm—but she stood until the light went off the water, because it seemed to her she was being shown something and ought to look at it properly.

That night she did not climb the tower. She sat at her kitchen table with a sheet of paper and a pen and wrote to the insurer, naming the reef and the date and the man from Plymouth, and signed it, and sealed it, and set it on the table beside the tide-table page. Then she sat with it through the dark hours, the stove ticking as it cooled, and did not sleep.

At dawn she climbed the tower with the letter in her coat pocket. The Marigold lay at her mooring, small and patient, and the reef waited off Gull Point, and she understood that she could send the one and not change the other, or hold her tongue and watch the boat break, and that whichever way she turned she would lose a thing she could not get back. She thought of Tom's hands on the caulking iron and she thought of Ruth's colander set down on the floor, and the two pictures would not lie still together in her mind. She thought, too, of the boy, Eli's boy, who was nine and had been out with his father on the Marigold every summer since he could hold a line, and who would learn, one way or another, what his father had done.

She went down and took the letter from her pocket and read it through twice, standing in the shed with the tide tables. Then she put it back in her pocket and went to the wharf, where Eli's skiff lay tied at the foot of the ladder. Tom's spare bilge pump hung on its nail in the shed where he had left it. She took it, and a length of good line, and set them in the skiff's bow, weighted with a scrap of brick. From her coat she took the pencil stub and the back of a tide-table she kept for figures. She wrote: If you're going to do this, do it honestly. She folded it once and tucked it under the line, and then she went home and put the letter in the kitchen drawer.

Before dark she saw Eli come down to the wharf and find what she had left him. He stood a long time with the paper in his hand. Then he cast off, and she climbed the tower.

The station radio had been dead for years, its speaker giving back nothing but a soft tick when she tried the switch. She stood a moment with her hand on the cold brass, then went out to the gallery and watched. From there she saw the Marigold's running lights creep out past the point and turn toward the reef, red and green, small as sparks. Then they stopped. They hung there a long while, drifting, and she could not tell what was happening aboard, and she did not go down. She stood at the rail with the wind off the water and her hands gripping the cold iron, and it seemed to her that she was keeping a kind of watch, though there was nothing left to keep watch over.

Near midnight the lights came about and stood back for the harbour, and she let out her breath and went down to her bed.

But the sea does what it does. The weather came up in the small hours, a squall out of the southwest with no warning on it, and by morning the Marigold lay aground on the reef after all, canted and holed, the swell breaking white along her flank. Eli stood in the shallows with the pump in his hands, looking up at the tower. He had turned back, and the storm had taken her anyway, and there was no insurance in the world would pay for a boat lost in a squall with her owner safe ashore and her pumps in his hands.

The surveyor came out on the noon tide, a thin man in a borrowed oilskin who walked the reef at low water with a notebook and a face that gave nothing away. He measured the holing twice, photographed the clean line of the gash, and stood a long while looking at the channel marks, which were where they had always been. He asked Eli why a man would take his boat out on a night like that, and Eli said he had misread the channel in the dark, that it was his own foolishness and no one else's. The surveyor wrote it down. The claim was refused, the loss attributed to navigation rather than misadventure, and Eli paid a fine at the constable's office and told anyone who asked the same story he had told the surveyor.

Ruth took the job at the cannery in town. Ada saw her at the bus stop on the Monday with a plastic lunch pail and her hair pinned back, and Ruth nodded to her, and Ada nodded back.

Frank Dwyer came up the hill on the Thursday. He stood in her kitchen with his hat in his hands and asked her straight whether she had known anything, that night, before it happened.

"Only that the sea does what it does," Ada said.

He looked at her a moment longer than was comfortable, then put his hat on. When he was gone she took the letter from the drawer and fed it to the stove page by page, and carried the ashes up the steps and let the wind take them off the gallery into the grey water below.

The Marigold came apart on the shingle over three grey days, and on the fourth Eli and his boy hauled the nameplate and the wheelhouse door up the beach on a length of tarpaulin, the brass letters catching the light. Ada watched from her gate. The boy dragged his end with the solemn importance of a man twice his size, and Eli walked backwards, guiding, saying nothing.

At her gate he stopped. He reached into his coat and brought out Tom's compass, the brass dulled to a soft gold, the glass fogged at the edge.

"From the locker," he said. "Thought you'd want it."

She took it and felt its old familiar weight. Eli held her eyes a moment longer than he needed to, and then he nodded, once, and said, "Thank you," and did not say for what, and she did not ask.

At dusk she climbed the steps one last time. She stood a while in the lamp room with her hand on the cold housing, then left the lamp unlit and locked the door behind her. She walked down to the water with the compass in her pocket and stood where the boat used to be tied, and the empty ring in the stone was cold under her fingers, and the tide came in.