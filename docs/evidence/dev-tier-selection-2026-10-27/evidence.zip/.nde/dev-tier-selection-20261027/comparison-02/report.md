# Development tier comparison

Comparison ecdb10521db9a142cfd0cfd656ab1c9e84caf4d662d67d3e389ea478a136803a

Generation/budget status: incomplete

Owner dev judgement status: pending

LLM diagnostics cannot choose a tier or establish literary realisation.

## Tier S

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 12 | 90153 | 0.04406850 | 1936 | True | True |
| brief-01 r0 | B | 23 | 83995 | 0.05430570 | 2183 | True | beat outline |
| brief-02 r0 | C | 12 | 90471 | 0.04485060 | 1912 | True | True |
| brief-02 r0 | B | 21 | 83961 | 0.00000000 | 2150 | True | beat outline |

Realisation ['brief-01']: owner pending; assessed 0/0; missing 0; unknown 0; alignment scene-aligned; stale [].

Realisation ['brief-02']: owner pending; assessed 0/0; missing 0; unknown 0; alignment scene-aligned; stale [].

## Tier M

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 12 | 93008 | 0.00470670 | 1901 | True | True |
| brief-01 r0 | B | 23 | 83995 | 0.00000000 | 2183 | True | beat outline |
| brief-02 r0 | C | 17 | 103531 | 0.00973290 | 1859 | True | True |
| brief-02 r0 | B | 24 | 100813 | 0.00000000 | 2151 | True | beat outline |

Realisation ['brief-01']: owner pending; assessed 0/4; missing 4; unknown 0; alignment scene-aligned; stale [].

Realisation ['brief-02']: owner pending; assessed 0/6; missing 6; unknown 0; alignment scene-aligned; stale [].

## Tier L

| Brief | Condition | Calls | Tokens | New USD | Words | Length | Plan |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- |
| brief-01 r0 | C | 12 | 98015 | 0.00621510 | 1889 | True | True |
| brief-01 r0 | B | 24 | 89430 | 0.00396690 | 2183 | True | beat outline |
| brief-02 r0 | C | 22 | 130203 | 0.02124540 | 2229 | False | True |
| brief-02 r0 | B | 28 | 122990 | 0.00000000 | 2165 | True | beat outline |

Realisation ['brief-01']: owner pending; assessed 0/15; missing 15; unknown 0; alignment scene-aligned; stale [].

Realisation ['brief-02']: owner pending; assessed 0/14; missing 14; unknown 0; alignment scene-aligned; stale [].

## Owner development judgements

[]

## Synthetic test-only judgements

[]

## Pending/problems

L: C/brief-02: invalid length or incomplete budget
