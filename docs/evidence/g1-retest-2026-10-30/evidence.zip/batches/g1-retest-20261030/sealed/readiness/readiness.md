# Gate readiness: ready

Cohort: g1-retest-M-B-20261030-v1

## brief-11, repetition 0

- C: 2065 words; 82453 generation tokens; SHA-256 ef2e01ea31656d7a4b47261cb29b9df1d4740a0357ad617234d3d44d52d63033

- B: 2005 words; 20028 generation tokens; SHA-256 c61da82a32618e2ce826b66843347a45ea8413bc816402ba56cf1529e78c408b

## brief-12, repetition 0

- C: 2013 words; 86647 generation tokens; SHA-256 329e572be2c4582dc804597867ac7e6928c2b4c4c50c04e20586d6662db72f8c

- B: 2009 words; 21815 generation tokens; SHA-256 e3ce9ca6d3ec033763658d073fe0b43c4eac0190e0d1ec03f95365cf9a49cb1c

## brief-13, repetition 0

- C: 2070 words; 81197 generation tokens; SHA-256 37aac19d7570b0699cd359ac27fd19efafcd42bd8ef501ecb132327bbef95d2c

- B: 2161 words; 20959 generation tokens; SHA-256 3a32fc9e1c8c4f6bb93ee9e417de9ab91d336c54cd524af634fba96d0570c287

## brief-14, repetition 0

- C: 2070 words; 83500 generation tokens; SHA-256 0c68fe51c2eaf8def0ed101e4238fac7886685a8d383e3d0fa509d705d4eef5e

- B: 2056 words; 22599 generation tokens; SHA-256 a9530d3f87d2c076d35caaaabf6e060e68639491899917768edbbed5d0f7436b
