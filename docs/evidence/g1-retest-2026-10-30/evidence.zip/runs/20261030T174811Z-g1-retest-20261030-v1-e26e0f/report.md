# Run report: g1-retest-20261030-v1

- **Status:** succeeded
- **Started:** 2026-10-30T17:48:11.800798+00:00
- **Finished:** 2026-10-30T18:31:46.367696+00:00
- **Git SHA:** `8deee9ea3904c8136e09c6469016e54041404868`
- **Config:** `C:\docs\git\storyBuilder\configs\g1-retest-20261030.yaml` (hash `b95b83fe6ece`)
- **Seed:** 1800
- **Cache:** use, 0 hits, 92 misses

## Models

| Role | Provider | Model | Family |
| --- | --- | --- | --- |
| planner | openai | gpt-6.1-sol | openai |

## Prompt templates

- `plan_skeleton@2` (sha256 `0da31dbfa52d`)
- `plan_channels@2` (sha256 `01ada4fa319c`)
- `scene_prose@1` (sha256 `85c441293379`)
- `beat_outline@1` (sha256 `a73e82a57365`)
- `story_revision@1` (sha256 `778ffb95c765`)

## Stories

- **Briefs:** brief-11, brief-12, brief-13, brief-14 (from `C:\docs\git\storyBuilder\benchmark`)
- **Frozen splits:** test `2db6ccf7caf9`
- **Conditions:** C (`baseline_c`), B (`baseline_b`)
- **Repetitions:** 1

Token cost is at list price, cache hits included; new spend is what this run paid.

Words are counted on the normalised story; the length tolerance is ± 10%, with at most 8 attempts. Attempts are those of the story's final generation: its last revision pass, if any.

| Brief | Condition | Rep | Words | Target | Attempts | In range | Revisions | Status | Calls | Input tokens | Output tokens | Token cost | New spend | Files |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-11 | C | 1 | 2065 | 2000 | 1 | yes | 2 | ok | 13 | 64304 | 18149 | $0.3101 | $0.3101 | [cards.html](stories/C/brief-11/r1/cards.html) [cards.md](stories/C/brief-11/r1/cards.md) [ledger.json](stories/C/brief-11/r1/ledger.json) [plan-selection.json](stories/C/brief-11/r1/plan-selection.json) [plan.json](stories/C/brief-11/r1/plan.json) [planning-provenance.json](stories/C/brief-11/r1/planning-provenance.json) [skeleton.json](stories/C/brief-11/r1/skeleton.json) [source-plan.json](stories/C/brief-11/r1/source-plan.json) [story.md](stories/C/brief-11/r1/story.md) [story.original.md](stories/C/brief-11/r1/story.original.md) [story.raw.md](stories/C/brief-11/r1/story.raw.md) [validation.json](stories/C/brief-11/r1/validation.json) |
| brief-11 | B | 1 | 2005 | 2000 | 1 | yes | 2 | ok | 9 | 10629 | 9399 | $0.1152 | $0.1152 | [outline.json](stories/B/brief-11/r1/outline.json) [story.md](stories/B/brief-11/r1/story.md) [story.original.md](stories/B/brief-11/r1/story.original.md) [story.raw.md](stories/B/brief-11/r1/story.raw.md) |
| brief-12 | C | 1 | 2013 | 2000 | 2 | yes | 2 | ok | 14 | 65924 | 20723 | $0.3391 | $0.3391 | [cards.html](stories/C/brief-12/r1/cards.html) [cards.md](stories/C/brief-12/r1/cards.md) [ledger.json](stories/C/brief-12/r1/ledger.json) [plan-selection.json](stories/C/brief-12/r1/plan-selection.json) [plan.json](stories/C/brief-12/r1/plan.json) [planning-provenance.json](stories/C/brief-12/r1/planning-provenance.json) [skeleton.json](stories/C/brief-12/r1/skeleton.json) [source-plan.json](stories/C/brief-12/r1/source-plan.json) [story.md](stories/C/brief-12/r1/story.md) [story.original.md](stories/C/brief-12/r1/story.original.md) [story.raw.md](stories/C/brief-12/r1/story.raw.md) [validation.json](stories/C/brief-12/r1/validation.json) |
| brief-12 | B | 1 | 2009 | 2000 | 1 | yes | 2 | ok | 10 | 11615 | 10200 | $0.1252 | $0.1252 | [outline.json](stories/B/brief-12/r1/outline.json) [story.md](stories/B/brief-12/r1/story.md) [story.original.md](stories/B/brief-12/r1/story.original.md) [story.raw.md](stories/B/brief-12/r1/story.raw.md) |
| brief-13 | C | 1 | 2070 | 2000 | 1 | yes | 2 | ok | 13 | 63475 | 17722 | $0.3042 | $0.3042 | [cards.html](stories/C/brief-13/r1/cards.html) [cards.md](stories/C/brief-13/r1/cards.md) [ledger.json](stories/C/brief-13/r1/ledger.json) [plan-selection.json](stories/C/brief-13/r1/plan-selection.json) [plan.json](stories/C/brief-13/r1/plan.json) [planning-provenance.json](stories/C/brief-13/r1/planning-provenance.json) [skeleton.json](stories/C/brief-13/r1/skeleton.json) [source-plan.json](stories/C/brief-13/r1/source-plan.json) [story.md](stories/C/brief-13/r1/story.md) [story.original.md](stories/C/brief-13/r1/story.original.md) [story.raw.md](stories/C/brief-13/r1/story.raw.md) [validation.json](stories/C/brief-13/r1/validation.json) |
| brief-13 | B | 1 | 2161 | 2000 | 1 | yes | 2 | ok | 10 | 11348 | 9611 | $0.1188 | $0.1188 | [outline.json](stories/B/brief-13/r1/outline.json) [story.md](stories/B/brief-13/r1/story.md) [story.original.md](stories/B/brief-13/r1/story.original.md) [story.raw.md](stories/B/brief-13/r1/story.raw.md) |
| brief-14 | C | 1 | 2070 | 2000 | 1 | yes | 2 | ok | 13 | 64446 | 19054 | $0.3194 | $0.3194 | [cards.html](stories/C/brief-14/r1/cards.html) [cards.md](stories/C/brief-14/r1/cards.md) [ledger.json](stories/C/brief-14/r1/ledger.json) [plan-selection.json](stories/C/brief-14/r1/plan-selection.json) [plan.json](stories/C/brief-14/r1/plan.json) [planning-provenance.json](stories/C/brief-14/r1/planning-provenance.json) [skeleton.json](stories/C/brief-14/r1/skeleton.json) [source-plan.json](stories/C/brief-14/r1/source-plan.json) [story.md](stories/C/brief-14/r1/story.md) [story.original.md](stories/C/brief-14/r1/story.original.md) [story.raw.md](stories/C/brief-14/r1/story.raw.md) [validation.json](stories/C/brief-14/r1/validation.json) |
| brief-14 | B | 1 | 2056 | 2000 | 1 | yes | 2 | ok | 10 | 11658 | 10941 | $0.1327 | $0.1327 | [outline.json](stories/B/brief-14/r1/outline.json) [story.md](stories/B/brief-14/r1/story.md) [story.original.md](stories/B/brief-14/r1/story.original.md) [story.raw.md](stories/B/brief-14/r1/story.raw.md) |

### Per condition

| Condition | Stories | Failed | Calls | Input tokens | Output tokens | Token cost | New spend | Token cost per story |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | 4 | 0 | 53 | 258149 | 75648 | $1.2728 | $1.2728 | $0.3182 |
| B | 4 | 0 | 39 | 45250 | 40151 | $0.4920 | $0.4920 | $0.1230 |

## Generation budget

Generation tokens are the input and output tokens of every call a story made: structured-output repairs, length regenerations and revision passes included.

| Condition | Stories | Calls | Generation tokens | Tokens per story |
| --- | --- | --- | --- | --- |
| C | 4 | 53 | 333797 | 83449 |
| B | 4 | 39 | 85401 | 21350 |

## Equal budget

C and B are matched per brief and repetition: the cheaper story gets revision passes until the generation-token budgets are within ± 90% of the larger, with at most 2 passes.

| Brief | Rep | C before | B before | Revised | Passes | C after | B after | Matched | Reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| brief-11 | 1 | 71213 | 8918 | both | 2 | 82453 | 20028 | yes |  |
| brief-12 | 1 | 68734 | 10062 | both | 2 | 86647 | 21815 | yes |  |
| brief-13 | 1 | 69946 | 9813 | both | 2 | 81197 | 20959 | yes |  |
| brief-14 | 1 | 71762 | 10886 | both | 2 | 83500 | 22599 | yes |  |

4 matched, 0 not matched.

## Final selected comparison

Experimental tokens include cache hits and all attributable calls. New provider spend counts only calls paid in this run.

brief-11 repetition 1: comparable
- C: final `stories/C/brief-11/r1/story.md`, SHA-256 `ef2e01ea31656d7a4b47261cb29b9df1d4740a0357ad617234d3d44d52d63033`; 2065 words; 82453 tokens; new spend USD 0.310098
- B: final `stories/B/brief-11/r1/story.md`, SHA-256 `c61da82a32618e2ce826b66843347a45ea8413bc816402ba56cf1529e78c408b`; 2005 words; 20028 tokens; new spend USD 0.115248

brief-12 repetition 1: comparable
- C: final `stories/C/brief-12/r1/story.md`, SHA-256 `329e572be2c4582dc804597867ac7e6928c2b4c4c50c04e20586d6662db72f8c`; 2013 words; 86647 tokens; new spend USD 0.339078
- B: final `stories/B/brief-12/r1/story.md`, SHA-256 `e3ce9ca6d3ec033763658d073fe0b43c4eac0190e0d1ec03f95365cf9a49cb1c`; 2009 words; 21815 tokens; new spend USD 0.125230

brief-13 repetition 1: comparable
- C: final `stories/C/brief-13/r1/story.md`, SHA-256 `37aac19d7570b0699cd359ac27fd19efafcd42bd8ef501ecb132327bbef95d2c`; 2070 words; 81197 tokens; new spend USD 0.304170
- B: final `stories/B/brief-13/r1/story.md`, SHA-256 `3a32fc9e1c8c4f6bb93ee9e417de9ab91d336c54cd524af634fba96d0570c287`; 2161 words; 20959 tokens; new spend USD 0.118806

brief-14 repetition 1: comparable
- C: final `stories/C/brief-14/r1/story.md`, SHA-256 `0c68fe51c2eaf8def0ed101e4238fac7886685a8d383e3d0fa509d705d4eef5e`; 2070 words; 83500 tokens; new spend USD 0.319432
- B: final `stories/B/brief-14/r1/story.md`, SHA-256 `a9530d3f87d2c076d35caaaabf6e060e68639491899917768edbbed5d0f7436b`; 2056 words; 22599 tokens; new spend USD 0.132726

## Structured output

| Model | Calls | First-attempt validity | Validity after repair | Repair rate | Failed |
| --- | --- | --- | --- | --- | --- |
| openai/gpt-6.1-sol | 28 | 100.0% | 100.0% | 0.0% | 0 |

## Cost

- New spend this run: $1.7648
- Token cost at list price, including cache hits: $1.7648
- Tokens: 303399 input, 115799 output
- Per-run cap: $3.0000; per-day cap: $4.0000
- Spent today (UTC, all runs): $2.6709

| Model | Calls | Cache hits | Input tokens | Output tokens | New spend | Token cost |
| --- | --- | --- | --- | --- | --- | --- |
| openai/gpt-6.1-sol | 92 | 0 | 303399 | 115799 | $1.7648 | $1.7648 |

## Calls

| Call | Attempt | Model | Template | Seed | Cached | Input tokens | Output tokens | Cost | Latency (s) | Retries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C/brief-11/skeleton #1 | 1 | gpt-6.1-sol | plan_skeleton@2 | 1447420481 | no | 7379 | 931 | $0.0241 | 19.61 | 0 |
| C/brief-11/channels-s1 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1546499648 | no | 8417 | 1308 | $0.0299 | 13.99 | 0 |
| C/brief-11/channels-s2 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 548731511 | no | 8769 | 1620 | $0.0337 | 15.16 | 0 |
| C/brief-11/channels-s3 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1201224871 | no | 9021 | 1841 | $0.0365 | 14.90 | 0 |
| C/brief-11/channels-s4 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1909266908 | no | 9232 | 2002 | $0.0385 | 15.20 | 0 |
| C/brief-11/channels-s5 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 784637237 | no | 9414 | 2372 | $0.0425 | 18.73 | 0 |
| C/brief-11/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1103 | 523 | $0.0074 | 18.46 | 0 |
| C/brief-11/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1288 | 539 | $0.0080 | 19.52 | 0 |
| C/brief-11/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1286 | 536 | $0.0079 | 21.20 | 0 |
| C/brief-11/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1248 | 527 | $0.0078 | 17.84 | 0 |
| C/brief-11/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1293 | 564 | $0.0082 | 19.22 | 0 |
| B/brief-11/outline #1 | 1 | gpt-6.1-sol | beat_outline@1 | 1800 | no | 622 | 1206 | $0.0133 | 28.98 | 0 |
| B/brief-11/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 614 | 434 | $0.0056 | 14.22 | 0 |
| B/brief-11/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 661 | 480 | $0.0061 | 16.60 | 0 |
| B/brief-11/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 682 | 495 | $0.0063 | 16.27 | 0 |
| B/brief-11/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 745 | 477 | $0.0063 | 14.18 | 0 |
| B/brief-11/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 796 | 474 | $0.0063 | 13.45 | 0 |
| B/brief-11/scene-06 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 816 | 416 | $0.0058 | 11.79 | 0 |
| C/brief-11/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2918 | 2725 | $0.0331 | 76.23 | 0 |
| C/brief-11/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2936 | 2661 | $0.0325 | 54.15 | 0 |
| B/brief-11/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2822 | 2799 | $0.0336 | 76.84 | 0 |
| B/brief-11/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2871 | 2618 | $0.0319 | 53.83 | 0 |
| C/brief-12/skeleton #1 | 1 | gpt-6.1-sol | plan_skeleton@2 | 1447420481 | no | 7374 | 1042 | $0.0252 | 25.86 | 0 |
| C/brief-12/channels-s1 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1546499648 | no | 8345 | 1089 | $0.0276 | 12.11 | 0 |
| C/brief-12/channels-s2 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 548731511 | no | 8519 | 1373 | $0.0308 | 11.79 | 0 |
| C/brief-12/channels-s3 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1201224871 | no | 8812 | 1628 | $0.0339 | 14.67 | 0 |
| C/brief-12/channels-s4 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1909266908 | no | 8979 | 1856 | $0.0365 | 14.34 | 0 |
| C/brief-12/channels-s5 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 784637237 | no | 9282 | 2176 | $0.0403 | 21.39 | 0 |
| C/brief-12/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 970 | 533 | $0.0073 | 19.46 | 0 |
| C/brief-12/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1034 | 515 | $0.0072 | 17.21 | 0 |
| C/brief-12/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1209 | 552 | $0.0079 | 18.43 | 0 |
| C/brief-12/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1225 | 555 | $0.0080 | 18.83 | 0 |
| C/brief-12/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1147 | 519 | $0.0075 | 18.83 | 0 |
| B/brief-12/outline #1 | 1 | gpt-6.1-sol | beat_outline@1 | 1800 | no | 619 | 1711 | $0.0183 | 42.66 | 0 |
| B/brief-12/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 615 | 378 | $0.0050 | 13.51 | 0 |
| B/brief-12/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 667 | 378 | $0.0051 | 13.54 | 0 |
| B/brief-12/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 674 | 369 | $0.0050 | 12.48 | 0 |
| B/brief-12/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 721 | 369 | $0.0051 | 12.47 | 0 |
| B/brief-12/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 766 | 394 | $0.0055 | 11.75 | 0 |
| B/brief-12/scene-06 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 769 | 408 | $0.0056 | 14.91 | 0 |
| B/brief-12/scene-07 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 823 | 401 | $0.0057 | 12.90 | 0 |
| C/brief-12/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2932 | 3009 | $0.0360 | 89.94 | 0 |
| C/brief-12/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 3048 | 3055 | $0.0366 | 81.98 | 0 |
| C/brief-12/revision-02 (attempt 2) #1 | 1 | gpt-6.1-sol | story_revision@1 | 754375484 | no | 3048 | 2821 | $0.0343 | 79.37 | 0 |
| B/brief-12/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2875 | 3034 | $0.0361 | 91.99 | 0 |
| B/brief-12/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 3086 | 2758 | $0.0338 | 72.53 | 0 |
| C/brief-13/skeleton #1 | 1 | gpt-6.1-sol | plan_skeleton@2 | 1447420481 | no | 7371 | 835 | $0.0231 | 18.60 | 0 |
| C/brief-13/channels-s1 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1546499648 | no | 8356 | 1307 | $0.0298 | 16.14 | 0 |
| C/brief-13/channels-s2 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 548731511 | no | 8665 | 1518 | $0.0325 | 15.60 | 0 |
| C/brief-13/channels-s3 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1201224871 | no | 8843 | 1729 | $0.0350 | 15.60 | 0 |
| C/brief-13/channels-s4 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1909266908 | no | 9124 | 1981 | $0.0381 | 16.29 | 0 |
| C/brief-13/channels-s5 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 784637237 | no | 9382 | 2185 | $0.0406 | 17.56 | 0 |
| C/brief-13/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1248 | 551 | $0.0080 | 19.30 | 0 |
| C/brief-13/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1226 | 518 | $0.0076 | 20.71 | 0 |
| C/brief-13/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1289 | 551 | $0.0081 | 20.10 | 0 |
| C/brief-13/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1175 | 535 | $0.0077 | 17.44 | 0 |
| C/brief-13/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1046 | 511 | $0.0072 | 17.68 | 0 |
| B/brief-13/outline #1 | 1 | gpt-6.1-sol | beat_outline@1 | 1800 | no | 620 | 1400 | $0.0152 | 33.90 | 0 |
| B/brief-13/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 637 | 412 | $0.0054 | 13.93 | 0 |
| B/brief-13/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 643 | 368 | $0.0050 | 13.13 | 0 |
| B/brief-13/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 700 | 366 | $0.0051 | 12.26 | 0 |
| B/brief-13/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 740 | 369 | $0.0052 | 10.91 | 0 |
| B/brief-13/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 747 | 383 | $0.0053 | 14.21 | 0 |
| B/brief-13/scene-06 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 782 | 418 | $0.0057 | 14.29 | 0 |
| B/brief-13/scene-07 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 805 | 423 | $0.0058 | 13.84 | 0 |
| C/brief-13/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2938 | 2679 | $0.0327 | 79.29 | 0 |
| C/brief-13/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2812 | 2822 | $0.0338 | 62.95 | 0 |
| B/brief-13/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2842 | 2620 | $0.0319 | 75.24 | 0 |
| B/brief-13/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2832 | 2852 | $0.0342 | 69.87 | 0 |
| C/brief-14/skeleton #1 | 1 | gpt-6.1-sol | plan_skeleton@2 | 1447420481 | no | 7381 | 1138 | $0.0261 | 29.83 | 0 |
| C/brief-14/channels-s1 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1546499648 | no | 8418 | 1241 | $0.0292 | 12.72 | 0 |
| C/brief-14/channels-s2 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 548731511 | no | 8693 | 1650 | $0.0339 | 16.12 | 0 |
| C/brief-14/channels-s3 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1201224871 | no | 9014 | 1902 | $0.0370 | 17.77 | 0 |
| C/brief-14/channels-s4 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 1909266908 | no | 9272 | 2095 | $0.0395 | 18.70 | 0 |
| C/brief-14/channels-s5 #1 | 1 | gpt-6.1-sol | plan_channels@2 | 784637237 | no | 9457 | 2341 | $0.0423 | 19.32 | 0 |
| C/brief-14/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1195 | 548 | $0.0079 | 21.69 | 0 |
| C/brief-14/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1212 | 554 | $0.0080 | 20.99 | 0 |
| C/brief-14/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1188 | 621 | $0.0086 | 21.28 | 0 |
| C/brief-14/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1311 | 614 | $0.0088 | 22.97 | 0 |
| C/brief-14/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 1359 | 558 | $0.0083 | 19.12 | 0 |
| B/brief-14/outline #1 | 1 | gpt-6.1-sol | beat_outline@1 | 1800 | no | 625 | 2020 | $0.0215 | 52.38 | 0 |
| B/brief-14/scene-01 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 654 | 448 | $0.0058 | 16.34 | 0 |
| B/brief-14/scene-02 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 691 | 423 | $0.0056 | 15.10 | 0 |
| B/brief-14/scene-03 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 711 | 457 | $0.0060 | 15.75 | 0 |
| B/brief-14/scene-04 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 746 | 375 | $0.0052 | 13.38 | 0 |
| B/brief-14/scene-05 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 782 | 459 | $0.0062 | 15.30 | 0 |
| B/brief-14/scene-06 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 821 | 420 | $0.0058 | 14.79 | 0 |
| B/brief-14/scene-07 #1 | 1 | gpt-6.1-sol | scene_prose@1 | 1800 | no | 833 | 421 | $0.0059 | 12.21 | 0 |
| C/brief-14/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 3037 | 2934 | $0.0354 | 88.49 | 0 |
| C/brief-14/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2909 | 2858 | $0.0344 | 66.97 | 0 |
| B/brief-14/revision-01 #1 | 1 | gpt-6.1-sol | story_revision@1 | 1639199717 | no | 2920 | 2838 | $0.0342 | 81.55 | 0 |
| B/brief-14/revision-02 #1 | 1 | gpt-6.1-sol | story_revision@1 | 346088630 | no | 2875 | 3080 | $0.0365 | 78.58 | 0 |
