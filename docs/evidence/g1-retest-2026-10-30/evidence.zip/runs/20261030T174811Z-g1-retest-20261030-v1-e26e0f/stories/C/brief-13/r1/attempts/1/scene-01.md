Leena photographed the first flower with a scale beside it, then took a second image wide enough to include the tray number. The blossom was white, folded like a scrap of clean laundry between two leaves. There were six more on the neighboring plants.

She checked the sowing date.

Twenty-three days early.

Behind her, the greenhouse fans drew moisture from the air with their usual soft whistle. Nothing smelled scorched or sick. Roots hung pale in their channels; nutrient solution ticked through a valve. Beyond the small inspection window lay gray ground that had never supported anything.

Leena moved down the rack, photographing each flowering plant before touching a leaf.

The radiation storm had passed during sleep shift. A minor event, according to the station bulletin. She pulled the dosimeter record onto her tablet and matched its timestamps to the greenhouse tray map. The rack nearest the outer shielding had registered the highest dose, still below their intervention threshold. Most of the flowers were there.

Most, not all.

She enlarged the map. Two flowering plants stood farther inside, beside plants with no visible buds. It was the kind of pattern that invited an explanation before it deserved one.

“Leena?”

Commander Imani stood in the hatch, one hand hooked through the restraint beside it. She looked from the tablet to the flowers.

“They’re early,” Leena said. “By three weeks.”

“From the storm?”

“After the storm. I don’t know about from.”

Imani came closer. “What does it do to harvest?”

“If the pods set normally, we might get beans early. We might get fewer. Flowering doesn’t tell us that yet.”

The next protein shipment was forty-one days out. Leena knew because she had built the planting schedule around it.

“Could this reach the seed bank?” Imani asked.

“A flowering change isn’t an infection.”

“That wasn’t my question.”

“No.” Leena lowered the tablet. “We don’t know what caused it. I can’t rule out a disease or a handling problem.”

Imani glanced toward the inner hatch, beyond which their replacement seed lay in cold storage. “Then the crop goes into the sterilizer at shift change.”

Leena’s fingers tightened around the tablet. She had come farther than anyone in her old department to work without hearing that caution was just indecision.

“That leaves us short,” she said.

“Losing the bank leaves us short for years. Show me a safe alternative before shift change. One that protects the seed stock, not just these plants.”

“How long?”

“Five hours.”

After Imani left, Leena looked again at the photographs. Seven flowers, sharp and white. She opened a new record and entered the time.