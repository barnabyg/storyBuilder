Imani added a second authorization field beneath Leena’s name.

“Two signatures to open either enclosure,” she said. “Mine or the engineer’s, as well as yours. A failed seal ends that sample.”

Leena read the amended lines. Once, she would have heard only the restriction.

“Agreed.”

Imani signed. “Proceed.”

They worked through the last hour of the shift. The engineer brought two transparent culture chambers from stores and fitted each with its own filtered air line and sealed drainage reservoir. Neither would return water to the greenhouse loop. Leena selected two plants from opposite ends of the affected tray, recording their positions before she touched them.

One had three white flowers. The other had a single bloom tucked beneath a leaf.

She lifted each root plug into a separate chamber. Imani checked the labels against the tray map; the engineer tested the seals. They waited together while the pressure readings settled.

Only after both chambers passed did Imani release the sterilization cycle for the remaining crop.

Leena helped load the plants into the treatment vessel. Their stems bent against her gloves. There were unopened buds she had not counted, and she felt the old impulse to ask for another hour.

Instead she checked the vessel inventory against the number destroyed.

The lid locked. On its small display, the temperature began to rise.

By the time they finished cleaning the empty bed, revised ration allowances were posted beside the galley hatch. The missing beans had become smaller portions and another week of stored protein. Someone had penciled the new meal quantities underneath, then checked the arithmetic twice.

In the observation rack, the engineer installed ordinary dwarf beans from an unaffected tray. Their chambers matched the other two: light, temperature, water, handling. Leena checked the settings while he read them aloud.

“Anything else?” he asked.

She looked at the four chambers. “Not that I know of.”

At the terminal, she opened a log with crew-wide access. She attached the original assay files, including the conflicting results, then entered the failed replication. Under observations, she recorded flower counts and leaf condition. Under unknowns, she wrote that the cause of early flowering remained undetermined.

She left yield and inheritance unestimated.

Imani stood beside her as she entered the next inspection time.

“If nothing changes?” the commander asked.

“We record that too.”

Leena saved the entry. Behind them, a fan started inside one of the sealed chambers. The single flower trembled in the airflow, and then held still.