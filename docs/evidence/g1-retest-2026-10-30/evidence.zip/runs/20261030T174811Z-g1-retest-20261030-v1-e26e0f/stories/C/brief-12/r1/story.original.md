The breaker snapped back before Ruth could take her thumb away.

Behind her, someone on the stairs said, "Again?"

"Give me a minute."

Ruth kept her voice level. Six years as superintendent had taught her that people could wait longer if they didn't hear you worrying. She wiped her hand on her shorts and looked at the labels inside the hallway panel. Someone had plugged an air conditioner into the outlet meant for the vacuum. Someone always did.

The stairwell was crowded with tenants hoping the roof door might be open. Children sat on the steps, their shirts damp down the spine. Mrs. Ortiz held a packet of frozen peas against her neck.

"Who's running an extension cord from the second-floor landing?" Ruth asked.

Nobody answered.

A green bird swooped past her ear.

Ruth ducked. The parrot landed on the panel door and gripped its metal edge, panting with its beak open. Above them, a little boy shouted, "That's Elena's!"

"Don't chase it."

Ruth shut the panel carefully, shifting the bird onto its outer edge. She borrowed Mrs. Ortiz's dish towel and held it below the parrot's feet.

"Come on, handsome."

It stepped onto the towel, then bit her knuckle through the cloth. She folded the towel loosely around its wings.

"Very handsome," she said through her teeth.

A man on the second floor reluctantly went to unplug his air conditioner. This time the breaker held. Lights came on above the stairs, yellow and weak. From behind the panel came a steady hum Ruth didn't remember hearing before.

Her phone buzzed. Her daughter had sent: Can we sleep with the door open tonight?

Ruth typed, When I get upstairs. Lock it for now.

The bird twisted its head toward her.

"Open the basement door."

Several people laughed. Ruth looked down at it.

"What was that?"

"Open the basement door."

Elena lived on the first floor, where the basement stair began. The bird might have learned it from anyone carrying laundry. Ruth had heard it imitate a microwave for twenty minutes.

Still, she carried it downstairs.

The basement entrance was boarded shut.

Three pale lengths of lumber crossed the old door, their screw heads bright. Sawdust lay on the bottom step. Yesterday she had gone through that door to fetch a mop bucket.

"Open the basement door," the parrot said against her wrist.

Ruth touched the nearest board. A splinter caught her fingertip.

She put her ear to the narrow gap beside the frame and held still, listening past the hum.

"What do you think you're doing?"

Ruth straightened too fast and caught her shoulder on the pipe above the door. Voss stood on the landing, his shirt dark under the arms. She hadn't heard the street door.

"There's a bird loose," she said.

"So catch it."

"It came up from here. It keeps saying—"

"I don't care what it says."

The parrot shifted on the banister behind him, lifting one foot into its breast feathers. Ruth kept her hand against the doorframe. The new boards smelled sharp in the basement heat.

"Who put these up?"

"I did. People were getting in."

"Which people?"

"Ruth. The basement is empty."

Behind the boards, the electrical hum rose, held, then dropped to its old pitch. She looked toward the meter room. That morning she had reset the second-floor breaker twice and told Mrs. Chen to unplug one of her fans. Voss had said an electrician would come when an electrician could come.

"I ought to check the panel," she said.

"The panel's not behind that door."

"I could take one board off. Make sure nothing's—"

"Touch those boards and I call the police."

He said it quietly. Ruth glanced down at the screwdriver in her hand. She had taken it from her belt without remembering.

"For doing my job?"

"For breaking into a secured area after the owner told you not to."

From upstairs came the scrape of someone dragging furniture, then a child crying. Usually Ruth would already be climbing toward the noise, sorting out whose chair had blocked whose doorway. She knew how to turn a complaint into a favor. She had done it for Voss for eleven years.

He came down another step.

"Your apartment comes with the position," he said. "You understand that, don't you?"

She thought of her son at the kitchen table, doing summer worksheets with a damp washcloth around his neck. Their lease was a page attached to her employment agreement. She had never asked anyone to look at it.

"Yes," she said.

Voss waited.

Ruth slid the screwdriver into her pocket, then the flat pry bar hanging from her belt. Their weight pulled at her trousers.

"I'm going upstairs."

"Good. Take care of your family."

She passed him without answering. At her own door she stopped long enough to smooth her face.

Her son looked up from the table. "Did you fix it?"

"No," she said, closing the door behind her. "Not yet."

Ruth stayed by the door until her child's footsteps retreated down the hall. Then she took the stubby screwdriver from her pocket.

She would only check the vent. That was not the same as opening the basement. It was the sort of distinction she had made for Voss for years.

On the half-landing, she knelt beside the grille. Heat breathed through its slots, carrying a smell of hot dust. She loosened the screws into her cupped palm and lifted the grille away.

"Hello?"

A scrape came from below, then a woman's voice.

"Is he still there?"

"Who?"

"Voss."

Ruth lowered herself onto one elbow. The duct turned beyond her reach.

"He's gone. This is Ruth. The superintendent."

"My bird," the woman said. "Did you find him? Green, with a yellow head?"

"Yes."

"I'm Elena. He's mine."

Ruth knew the name. Cash in an envelope, slid under the office door. No apartment number, just BASEMENT written in Voss's square handwriting on the rent sheet. Ruth had entered the payments without asking which room.

"Are you hurt?"

"I can't get the door open."

Somewhere behind the wall, a motor started. Its blades scraped, gathered speed, then stopped with a dull click.

"Tell me what happened."

"I said I wouldn't pay the increase. There's no window. The sink backs up. I told him I'd call the city." Elena paused to breathe. "He came down to talk. Then he went outside and shut me in. I heard the drill. He put something across the door."

Ruth looked toward the basement entrance. The fresh strip of plywood Voss had called a repair ran from the door onto its frame.

"When?"

"This morning. I thought he'd come back."

The motor tried again. Ruth recognized it now: the extractor beside the electrical room, the one she had asked Voss to replace in June. He had told her to oil it.

"Is that fan near you?"

"Through the wall. It keeps stopping. The wall's too hot to lean against."

Ruth pressed her hand against the duct. Warm metal. Above her, the landing light dimmed, recovered, dimmed again.

She pictured her child upstairs, the refrigerator holding one carton of milk and tomorrow's lunch. Voss had made clear how quickly those rooms could stop belonging to them.

"Ruth?"

"I'm here."

"Please don't go away."

Ruth set the grille flat on the landing so it could not fall back across the opening.

"I have to get help," she said. "I'm not leaving you down there."

Ruth climbed to the second floor with one hand sliding along the hot banister. Outside Mrs. Chen's apartment, her child sat on the tiles, holding a frozen washcloth against the back of his neck.

"Stay here with Mrs. Chen."

"Are we in trouble?"

She knelt. Behind him, the apartment fan slowed, caught, and sped up again.

"Someone needs help. I need to know where you are."

Mrs. Chen opened her door wider. She looked at Ruth's face and asked no questions.

Ruth called emergency services from the landing.

"Fire department. There's a woman trapped behind a sealed basement door. Elena. She's conscious, but the electrical room is beside her and there's a burning smell. The lights keep dropping."

The dispatcher asked for the address. Ruth gave it, then repeated the basement entrance location. When asked whether the owner knew, she looked down through the stairwell.

"He knows."

Voss stood at the foot of the stairs. By the time she reached the first floor, he had moved onto the bottom step, one hand braced against the wall.

"You've made your call," he said. "Now go upstairs."

"They need access."

"I'll handle access."

She could not get past him without touching him. He seemed to be waiting for that.

Over his shoulder, the basement light flickered. Ruth smelled the sharp, hot-plastic smell again.

For years she had knocked softly, spoken privately, told tenants she would take care of things. Now she struck the metal banister with her keys.

"Come downstairs," she shouted. "Everyone who can. Bring your phones. Leave the stairs clear."

Voss's face changed.

"Think about where your boy sleeps."

She almost lowered her voice. Instead she called, "Elena is locked in the basement. The fire department is coming. I need witnesses."

Doors opened above them.

Ruth found the maintenance message thread with her thumb. There were his instructions after Elena disputed the rent increase: fit the exterior hasp; close the corridor vent; no basement access without his permission. Beneath them were Ruth's replies. Done. Done. Done.

She took screenshots and sent them to the tenants' group, including her own answers.

Phones began chiming overhead.

"That's private correspondence," Voss said.

Mr. Ahmed came down first, phone raised. Two others followed. Voss stepped sideways as they gathered, leaving enough room for Ruth to pass.

At the basement door she knocked.

"Elena. It's Ruth. Your neighbors are here."

She waited, afraid that this time there would be no answer.

Then came a faint knock from inside. Behind her, someone began recording.

Ruth knocked back, twice.

When the firefighters reached the landing, she took them down herself. "Beside the electrical room. The door looks like part of the wall."

One firefighter caught her arm before she could touch it. Heat came through the painted plywood. She stepped aside and showed him where the old frame began.

The first blow shook dust from the stair treads. At the second, someone inside cried out.

"Low on the left," Ruth said. "She's right behind it."

They worked more carefully after that. Ruth stood where Elena could hear her and kept saying her name.

They brought her out on a carry sheet, one bare foot showing beneath a gray blanket. Her eyes were open. In the crowded courtyard, tenants made a narrow passage between folding chairs and shopping carts. Ruth followed until a paramedic knelt beside Elena and fitted a mask over her mouth.

Then every window above them went dark. The exhaust fan over the basement steps wound down, and the building became strangely quiet.

Elena caught Ruth's wrist. Her grip was weak but deliberate.

"Bird?"

"Out," Ruth said. "He's out."

Voss arrived through the side gate with his phone pressed to his ear. He stopped when he saw the camera pointed toward him.

"It was an accidental sealing," he told the fire captain. "Contractors. A misunderstanding about which rooms were occupied."

Ruth felt Elena's fingers tighten.

Voss turned to her. "Your staff keys. Now."

For years, that voice had sent her to leaking ceilings with a bucket before anyone called an inspector. It had kept her son's bed in the small apartment behind the laundry room.

She took out her phone instead.

The messages were still there: Leave that door closed. Elena can discuss arrears with me. Then, after Ruth's first question that afternoon: Don't involve anyone else.

Below them were her own replies about patched wiring, a bypassed breaker, repairs she had never reported because Voss had promised proper work next month.

The captain gave her an address to send them to.

"All of it?" she asked.

"Send what you have."

She selected the whole conversation.

Voss held out his hand for the keys. Ruth placed them in his palm after the file had gone.

Across the courtyard, her son stood beside a neighbor, holding their parrot in a borrowed cage. He looked toward the dark laundry-room windows.

"Can we go home?"

Ruth's phone showed Delivered. It did not tell her what would happen next.
