Mina folded the towels in thirds, then in half, keeping the worn borders inside. Since Joseph’s death she had come in forty minutes early to do this. At home there were too few things to put in order. Here, even on the last morning, a trolley waited.

She made twelve stacks of eight before remembering that the baths would close at noon. She returned four stacks to the cupboard.

Behind them lay Joseph’s striped towel. During his illness she had washed it with the bathhouse linen, though personal washing was prohibited. Afterward she had kept it there. In the cupboard it remained a towel somebody might come to collect.

She shut the door.

In reception, a yellow auction label covered the first three letters of ADEYEMI.

Mina lifted one corner. Adhesive stretched from the paper to the glaze. On the inventory beside the desk she found LOT 47: DECORATIVE CERAMIC PANEL. BUYER TO ARRANGE REMOVAL.

The panel was a wall. A painted tree spread around the warm-room doorway, its branches carrying donors’ names into the cream tiles beyond. More names turned the corner beneath the window. Above two blue birds was the date 1926.

Daniel arrived carrying coffee and a folder. Before the closure he had been the board’s treasurer, a man Mina saw quarterly. Lately he was there every day.

“This needs correcting.”

He read the entry. “The auction company assessed it.”

“They photographed the tree. Not the rest.”

He followed her finger around the corner.

“You can’t take the picture without cutting through the names.”

“The building’s coming down, Mina.”

“Then don’t sell it as something that comes off.”

He put his coffee on her list of missing locker keys.

“The housing trust signs the transfer this afternoon. Their funding depends on starting next month. We can’t reopen the argument about the baths.”

“I’m asking you to cross out one line.”

“And then what?”

She had imagined that identifying the mistake would be enough.

“The board meets at three,” he said. “Bring us something we can consider. But finish the handover first. The enhanced payment depends on it.”

The statutory payment would cover little more than Joseph’s funeral had cost. She knew the larger amount to the penny; she had written it beside six months of mortgage payments in a notebook at home.

She moved Daniel’s coffee.

At nine, Mr Bell came for the sandals he had left in his locker. While she fetched them, he stood before the tree.

“My mother’s on there.”

“Which name?”

“Dock Labourers’ Benevolent Fund. She did their books. They wouldn’t put a woman’s name.”

For twenty-seven years Mina had known he took two towels and returned one dry.

“Would you come back at three?”

“What for?”

She showed him the inventory.

“Are we trying to keep the place open?”

“No,” she said, more sharply than she intended.

After he left, she opened her appointment book. Some numbers had crosses beside them. Others had been copied through so many books that she was no longer certain of the names.

She rang Ruth first.

“Have you still got the photograph of your father by the tree?”

“Yes.”

“Can you bring it?”

“Mina, what are you doing?”

“Trying to get them to listen.”

She called six others. One number belonged to a takeaway now. Mrs Saye, who folded her towel lengthwise before undressing, could come only if she was home before her carer arrived. Mina wrote down the time, then rang Mr Bell again to ask about a lift.

Between calls she issued the last locker keys. She counted the float twice before remembering that Daniel had taken seventeen pounds to buy milk.

Ruth arrived with her photograph between two pieces of cereal-box cardboard. Mina had ruled a sheet of paper and written: We request that closure be suspended pending consultation.

Ruth read it without removing her coat.

“No.”

“We need time.”

“You told Mr Bell it wasn’t about reopening.”

“It only says suspended.”

“My daughter needs one of those flats.”

Mina put down her pen.

“She and the boys have been in her sister’s front room since March. Mattresses up before breakfast, down again after the television goes off.”

“You never said.”

“You always had my towel ready.”

Someone in the changing room dropped a locker key. Mina resisted the impulse to go and retrieve it.

Ruth took out the photograph. Her father stood beneath the tree in wide trousers, holding his hat under JOSEPH MENSAH.

“Two weeks’ wages,” she said. “My mother brought it up whenever we needed shoes. I want his name kept. I won’t sign something that makes my daughter wait.”

Mina looked at the name. Her own Joseph, coming to meet her after work for the first time, had pointed to it and said she must have been expecting him.

She turned the petition over.

“What would you sign?”

At noon she gave the last bather ten extra minutes, then locked the entrance behind him.

Leah, the housing trust’s architect, was waiting by the delivery door. She had come to inspect the service access and photograph the meters.

“Before you start,” Mina said, “will you look at something?”

Leah stood close to the mural, then stepped back.

“I thought this was being salvaged.”

“So did whoever wrote the catalogue.”

Mina showed her ADELAIDE PRICE, beginning inside the green border and ending three tiles beyond it. AND HER SISTERS crossed a repaired seam below.

“Our survey marks this as decorative finish,” Leah said.

“It is decorative.”

“I mean they haven’t recorded how much wall it occupies.”

Mina nearly asked whose fault that was. Instead she fetched the laundry’s folding table.

On Leah’s plan, the warm room was bicycle storage. The pool had become a courtyard. Mina kept searching for the cupboard, although she understood why it wasn’t there.

“Could people walk through here?” She traced the delivery route from the front entrance to Bell Lane. “This was a public way before they built the laundry.”

Leah opened another drawing.

“The passage used to run alongside this wall?”

“There’s a blocked doorway behind the drying racks.”

They went to look. Mina had hung sheets there for years without considering the stone lintel above them.

Back at the table, Leah measured the plan.

“We could move the cycle store entrance. Keep a strip open beside the wall.”

“Would it cost a flat?”

“No. Two cycle spaces, perhaps. But the wall needs support once the roof comes off. And protection from weather. It’s not just deciding not to knock it down.”

She made two calls. Mina filled the linen sacks while Leah spoke to the engineer.

When Mina returned, a figure had been pencilled in the margin.

“An allowance,” Leah said. “Not a quotation. It would take most of our entrance contingency.”

“What was that for?”

“Things we don’t know about yet.”

Mina nodded. She knew about keeping money for those.

At two, Ruth sat at the reception desk calling people back.

“No, the baths are closing,” she said. “We’re asking for the whole wall. All the names. A passage anybody can use.”

Mina brought her a clean sheet.

By half past two, eleven former patrons were in reception. Mrs Saye sat near the radiator, which had already begun to cool. Mr Bell had brought a handwritten account of his mother’s work, with the fund’s name underlined.

Daniel drew Mina into the office.

“Did you use the customer records?”

“My appointment book.”

“It isn’t yours.”

Her handwriting, her corrections, her crosses after funerals. She had never thought of it as anything else.

“I asked them to come. They could say no.”

“We’re transferring people’s information to the council archive under an agreement. You can’t use it to organise a protest.”

“I didn’t know how else to reach them.”

“Have you finished the handover?”

“The meters still need reading.”

He shut his folder.

“I’m not withholding your pay because you disagree with me. But I have to certify that you’ve completed the work. You’ve spent the morning doing this.”

She wanted to tell him how many mornings she had arrived early, how often she had stayed. Instead she took the meter sheet from its hook.

“Read the numbers out, then.”

In the service room he held his phone torch while she wrote. She checked each figure against his voice. It steadied her enough to go upstairs.

The board had put six chairs on one side of the table and three on the other. Mina remained standing until the chair asked someone to fetch more.

Leah explained the proposal. She did not call it simple. There would be an engineer’s method, temporary bracing, a roof over the passage, drainage. The entire mural needed photographing before demolition began.

“What if it won’t stand independently?” the trust’s director asked.

“Then it must be dismantled and reinstated. Every tile numbered. Same extent, same arrangement.”

“And if the cost exceeds the allowance?”

Mina watched Leah’s pencil stop.

“We’d need to find the difference,” Leah said. “The preliminary advice is that retention is feasible. I can’t give you certainty this afternoon.”

Daniel looked at the former patrons.

“And none of you will oppose demolition once this is agreed?”

Mr Bell opened his mouth, then closed it.

Ruth placed the photograph on the table.

“My daughter’s applied for one of your flats. I’m not here to stop the homes.”

Mrs Saye asked whether the passage would have a gate.

“For security at night,” Leah said.

“A residents’ key?”

“No,” Mina said, then looked at the director. “That needs to be written down.”

He took the plan and studied it.

Daniel turned to her. “You’ve made people think we can promise this today.”

“You can withdraw it from auction. You can put preservation into the transfer.”

“The baths will still close,” the chair said.

Mina could see the warm-room door through the glass partition. Its bottom edge was dark from generations of wet hands pushing where there was no plate.

“Yes.”

“Today.”

“They’re already closed.”

Downstairs, someone tried the outer door, rattled it once, then stopped.

The secretary opened the draft transfer. For nearly an hour they worked on the wording: the complete mural, including the return beneath the window; public access between both streets during fixed daily hours; responsibility for maintenance. If it had to come down, it had to go back up in the passage before the homes were occupied.

Mina asked twice about the names beyond the painted border.

The trust’s director accepted the condition. The board voted to withdraw lot 47 and approve the amended transfer. Daniel struck through the auction entry, initialled it and emailed a photograph to the auctioneer.

Mrs Saye needed to leave. Mr Bell gathered her coat before anyone could make a speech.

Afterward, Daniel handed Mina the inspection form.

“Leave it with the keys. I’ll certify the handover when I lock up.”

She waited until he met her eyes.

“For payroll?”

“For payroll.”

By the time everyone had gone, the light had moved across reception. Ruth wrapped her photograph in cardboard.

“Come for supper Sunday.”

Mina began to say she would see, then asked what time.

She made her final round alone.

Every locker stood open. On an upper shelf she found a hairpin and put it in the lost-property tin. She added the tin to the handover list.

The drained pool showed every patch. Without moving water, the crooked line of tiles at the shallow end was plain. Someone had laid them that way and the baths had opened, and people had swum over them for years.

She checked the taps, the windows, the service-room latch. In the linen cupboard she took out Joseph’s towel. It smelled of the same powder as all the others. She folded it once to fit her bag.

At reception she signed the form. The appointment book lay beside it. She left that too.

The yellow label was still on the mural. She fetched a damp cloth and held it against the paper until it softened. Underneath, a rectangle of adhesive dulled ADEYEMI. She cleaned it off, working carefully at the edges of the letters.

Then she read the next name.

Outside, a bicycle clicked down Bell Lane. One day she would be able to follow that sound through here, without a key, without anyone expecting her to fetch a towel.

She switched off the lights and went out to wait for Daniel.