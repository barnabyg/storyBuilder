Ruth climbed to the second floor with one hand sliding along the hot banister. Outside Mrs. Chen’s apartment, her child sat on the tiles, holding a frozen washcloth against the back of his neck.

“Stay here with Mrs. Chen.”

“Are we in trouble?”

She knelt. Behind him, the apartment fan slowed, caught, and sped up again.

“Someone needs help. I need to know where you are.”

Mrs. Chen opened her door wider. She looked at Ruth’s face and asked no questions.

Ruth called emergency services from the landing.

“Fire department. There’s a woman trapped behind a sealed basement door. Elena. She’s conscious, but the electrical room is beside her and there’s a burning smell. The lights keep dropping.”

The dispatcher asked for the address. Ruth gave it, then repeated the basement entrance location. When asked whether the owner knew, she looked down through the stairwell.

“He knows.”

Voss stood at the foot of the stairs. By the time she reached the first floor, he had moved onto the bottom step, one hand braced against the wall.

“You’ve made your call,” he said. “Now go upstairs.”

“They need access.”

“I’ll handle access.”

She could not get past him without touching him. He seemed to be waiting for that.

Over his shoulder, the basement light flickered. Ruth smelled the sharp, hot-plastic smell again.

For years she had knocked softly, spoken privately, told tenants she would take care of things. Now she struck the metal banister with her keys.

“Come downstairs,” she shouted. “Everyone who can. Bring your phones. Leave the stairs clear.”

Voss’s face changed.

“Think about where your boy sleeps.”

She almost lowered her voice. Instead she called, “Elena is locked in the basement. The fire department is coming. I need witnesses.”

Doors opened above them.

Ruth found the maintenance message thread with her thumb. There were his instructions after Elena disputed the rent increase: fit the exterior hasp; close the corridor vent; no basement access without his permission. Beneath them were Ruth’s replies. Done. Done. Done.

She took screenshots and sent them to the tenants’ group, including her own answers.

Phones began chiming overhead.

“That’s private correspondence,” Voss said.

Mr. Ahmed came down first, phone raised. Two others followed. Voss stepped sideways as they gathered, leaving enough room for Ruth to pass.

At the basement door she knocked.

“Elena. It’s Ruth. Your neighbors are here.”

She waited, afraid that this time there would be no answer.

Then came a faint knock from inside. Behind her, someone began recording.