Then he noticed the grease.

It lay in a black crescent along the compass’s rim, quite unlike the pale wax on the conservation bench.

“May I?”

Inês turned the custody tray towards him without letting go.

“Looking,” she said. “Not borrowing. You always confused those.”

Ten minutes later, kneeling beside the ship display’s open service hatch, Nuno found the same black grease along the mouth of the drive slot. Above it, the warning about loose objects had been partly covered by a label thanking the principal donor.

He held the tray near the opening. The crescent on the brass matched the greasy lip.

“Something’s been getting acquainted,” he said.

Inês closed the hatch.

“That is why it stays in custody.”

“I’m not asking you to put it back. I’m asking you to help me show what happens.”

“With that ship on top? No.”

“Without it.”

She studied him.

It was an uncomfortable novelty, being assessed for caution.

“We lift the ship onto its conservation cradle,” he said. “You supervise. Power isolated until you say otherwise. Then we test the drive with something expendable.”

“You?”

“I was hoping for a washer.”

At last she fetched the padded trolley.

They had settled the ship safely into its cradle when Marta appeared. Her gaze went from the empty plinth to the compass tray.

“Excellent. You’ve recovered it.”

“We’ve moved it six metres,” said Inês. “There’s a log.”

Marta drew Nuno aside.

“The reward is still available. I can describe it as a consultancy payment. The compass was misplaced during maintenance, you found it, and we needn’t trouble anyone with the details.”

“Including the instruction you signed to run the unfinished display?”

Her smile held, though apparently at considerable expense.

“The gala opens in forty minutes.”

Nuno looked at the waiting cradle. He could take the money, return to his tour and spend the evening pointing out other people’s historical errors.

“No consultancy,” he said. “And no convenient thief.”

Marta’s eyes flicked towards Inês.

“Especially not her.”

Back in the workshop, Inês opened the security terminal.

“My installer account still has export access,” she said. “They remembered to remove my name from the exhibition panel, but not that.”

At Nuno’s request, she selected the full camera recording, including the minutes before and after the excerpt he had been shown.

The download bar advanced with institutional reluctance.

Nuno waited until two complete copies had saved.

Then he picked up the tray.

“Now,” he said, “let’s give the mechanism a chance to tell its own story.”