Ruth looked past her, towards the entrance. “Ask Leah what can stay without costing anyone a flat.”

The architect had been waiting beside the towel counter with a roll of drawings under her arm. Mina had left her there while she finished the telephone calls. Now she lifted the counter flap.

“Come and see what they’ve put in the sale.”

At the mural, Leah read the auction label, then stepped back to take in the blue trees, the yellow sun above the painted pool.

“Not just that,” Mina said.

She put one finger beside the narrow green border. The name ADELAIDE PRICE began inside it and ended three tiles beyond, on what looked from a distance like ordinary cream wall. Below it, the smaller letters of AND HER SISTERS crossed a repaired seam.

“They paid by the letter, some of them. The man doing it ran out of room.”

Leah bent to look. Mina showed her another name turning the corner, its final letters tucked beneath the window ledge.

“The photograph in the catalogue stops here.” Mina traced the border without touching it. “If they cut out the picture, they cut through the names.”

Leah set down her drawings.

“I hadn’t seen these.”

Mina nearly said that no one had asked her. Instead she fetched the folding table from the laundry and wiped it before Leah spread out the plan.

The new building lay over the old one in thin grey lines. Where Mina expected the warm room, there were bicycle stores.

“This wall isn’t carrying the roof,” Leah said. “We’d still need an engineer to check how it could be supported during demolition.”

Mina pointed to the strip beside it. “That was the delivery entrance. Straight through to Bell Lane.”

Leah followed it on the drawing. She measured, rubbed something out, then drew two parallel lines around the retained wall.

“A public passage, possibly. Keep the whole return here. Move the cycle-store door.” She paused. “I can’t promise this today.”

Behind them Ruth was calling people back.

“No, not a petition to reopen. The wall, all the names. Somewhere anyone can walk in and see them.”

Mina heard her ask permission to write down each name. She had not thought to do that herself.

“Public,” Mina said. “Not somewhere you need a resident’s key.”

Leah wrote the word beside the new lines.

“Opening hours, maintenance, access—that would all need agreeing.”

At the edge of the table, Mina smoothed a curl in the paper. Her wedding ring tapped the proposed passageway.

“Put those on the drawing too,” she said.