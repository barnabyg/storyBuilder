“What do you think you’re doing?”

Ruth straightened too fast and caught her shoulder on the pipe above the door. Voss stood on the landing, his shirt dark under the arms. She hadn’t heard the street door.

“There’s a bird loose,” she said.

“So catch it.”

“It came up from here. It keeps saying—”

“I don’t care what it says.”

The parrot shifted on the banister behind him, lifting one foot into its breast feathers. Ruth kept her hand against the doorframe. The new boards smelled sharp in the basement heat.

“Who put these up?”

“I did. People were getting in.”

“Which people?”

“Ruth. The basement is empty.”

Behind the boards, the electrical hum rose, held, then dropped to its old pitch. She looked toward the meter room. That morning she had reset the second-floor breaker twice and told Mrs. Chen to unplug one of her fans. Voss had said an electrician would come when an electrician could come.

“I ought to check the panel,” she said.

“The panel’s not behind that door.”

“I could take one board off. Make sure nothing’s—”

“Touch those boards and I call the police.”

He said it quietly. Ruth glanced down at the screwdriver in her hand. She had taken it from her belt without remembering.

“For doing my job?”

“For breaking into a secured area after the owner told you not to.”

From upstairs came the scrape of someone dragging furniture, then a child crying. Usually Ruth would already be climbing toward the noise, sorting out whose chair had blocked whose doorway. She knew how to turn a complaint into a favor. She had done it for Voss for eleven years.

He came down another step.

“Your apartment comes with the position,” he said. “You understand that, don’t you?”

She thought of her son at the kitchen table, doing summer worksheets with a damp washcloth around his neck. Their lease was a page attached to her employment agreement. She had never asked anyone to look at it.

“Yes,” she said.

Voss waited.

Ruth slid the screwdriver into her pocket, then the flat pry bar hanging from her belt. Their weight pulled at her trousers.

“I’m going upstairs.”

“Good. Take care of your family.”

She passed him without answering. At her own door she stopped long enough to smooth her face.

Her son looked up from the table. “Did you fix it?”

“No,” she said, closing the door behind her. “Not yet.”