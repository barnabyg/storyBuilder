“This,” said Nuno Vale, as the model carrack rolled above its painted Atlantic, “recreates the experience of rounding the Cape. Courage, uncertainty, and a noise from underneath which the captain assures us is normal.”

His tourists laughed. Nuno liked a laugh. It moved people along without making them feel moved.

The ship was three metres long, elaborately rigged, and borrowed from a collector whose name appeared on almost everything in the museum except the fire extinguishers. Beneath its motorised platform, a steel arm travelled back and forth through an unfinished casing.

KEEP LOOSE OBJECTS CLEAR, said a yellow label.

Nuno lifted a child’s dangling souvenir medal away from the gap.

“Portugal has lost enough treasure at sea.”

Once, those fingers had removed watches without troubling their owners. Now they protected watches, counted tourists, and retrieved spectacles from inaccessible places. He had spent fourteen years becoming a man to whom strangers handed their bags.

Director Marta Falcão intercepted him beside the navigation exhibit.

“Your group can look at the maps.”

“They’ve paid for stories.”

“Tell them the maps are wrong.”

He sent twelve people towards a coastline on which nobody agreed.

“The pocket compass is missing,” Marta said.

Its case stood beside the carrack. A round hollow interrupted the blue velvet.

“Perhaps it’s gone exploring.”

She held out her phone.

In the security clip, visitors crowded around the moving ship. A woman in a green scarf leaned forward. Her hand closed near the platform’s edge; a flash of brass disappeared against her coat.

Inês.

Nuno had last seen her stepping off the number twenty-eight tram with three wallets and an expression of disappointment in public transport. Sixteen years ago. When he had finally stopped stealing, he had tried to find her, but not very hard. He had been afraid she would ask whether being respectable suited him.

“Do you recognise her?” Marta asked.

He watched again. Inês had braced her other hand against the platform. She had never needed two hands for something so small.

“I might.”

“Good. There’s a thousand-euro reward for its return before the gala.”

“Have you called the police?”

“Our principal donor arrives at seven. He lent us the ship. His grandmother donated the compass. I would prefer to show him both.”

Under the painted waves, something clacked.

“Is it meant to do that?”

“It’s a sailing ship. They creak.”

“Usually in the wooden parts.”

Marta lowered her phone.

“At seven I have to explain this to the trustees. If I haven’t got the compass, I’ll have to give them her picture.”

In Marta’s office, gala brochures lay in glossy stacks. On the cover, the carrack sailed unsupported through a sea cropped free of machinery. Beside it sat a small brass circle.

Nuno picked one up.

“When was this taken?”

“This morning.”

“The compass wasn’t in its case.”

“The photographer wanted the two objects together. The glass reflected his lights.”

“So you put it on the moving platform.”

“It wasn’t moving then.”

Beneath the brochures lay a contractor’s checklist. Reading upside down had once been essential to Nuno’s work.

Guard panel awaiting fitting. Secure all loose objects. Motor overload cutout requires adjustment.

Below, in Marta’s handwriting: Demonstration required for press and gala.

She slid a brochure over it.

“The installers assured me the demonstration could proceed.”

“Did they write that down too?”

“Nuno, I have a trustee demanding assurances, a donor demanding movement, and a caterer who has discovered that our loading bay is historical. Can you help me or not?”

He looked again at the woman’s closed hand on the paused video.

“Let me speak to her.”

“And how do you know where to find her?”

He enlarged the image. Beneath the green scarf was the corner of a museum badge.

“I’m a guide. I notice things.”

Inês was in the workshop behind the temporary galleries, filing a curved metal panel. Her scarf hung beside a badge reading DISPLAY INSTALLER.

“You’ve gone respectable,” Nuno said.

She looked up.

“So have you. Apparently they pay you to talk now.”

“An oversight I hope they won’t notice.”

He had imagined this reunion occasionally. In none of his versions had she been wearing safety glasses.

“The compass,” he said.

“Ah. Which version have you heard?”

“The one with a reward.”

“That’s new.”

She opened a cupboard and brought out a shallow tray. The compass lay on tissue, a black smear along its rim. Beside it was a carbon-copy receipt.

“Temporary deposit in conservation,” she said. “Time, condition, signatures. There was nobody in here, so I fetched the conservation assistant from lunch. She wasn’t pleased. Neither was her soup.”

“An unusually thorough theft.”

“We’ve both lost our touch.”

She had started with shop fittings, then exhibition cases. Museum work paid badly but usually required fewer Sunday mornings. She liked making things stay where she put them.

“Does Marta know it’s here?”

“I emailed her the receipt and incident form. She replied, ‘Return object and cease delaying rehearsal.’”

“Did you reply?”

“With photographs.”

Nuno considered Marta’s covered checklist.

“Give it to me. I’ll put it in the case. She can call it a misunderstanding.”

“And run the ship tonight?”

“It’s running now.”

Inês put down the tray.

“No. I disconnected it.”

They heard the distant clack through the floor.

Upstairs, two electricians were taping a cable to the skirting. Beside the ship, caterers had begun building a pyramid of champagne glasses.

Inês went straight to the switch.

“The director said the plug had come loose,” an electrician protested.

“It had a label on it.”

“She said you were being cautious.”

“I was.”

She unplugged the cable, threaded it through the open casing and secured it with a padlock from her tool belt.

Marta arrived as if pulled by a wire.

“What are you doing?”

“Finishing my warning.”

“The ship has been running all afternoon.”

“That isn’t a test.”

Marta saw the tray in Nuno’s hands.

“You’ve recovered it.”

“It was in conservation.”

“Excellent. Then we can settle this.”

She drew him aside.

“The compass was misplaced during installation. You found it. I can put the reward through as a consultancy fee.”

“And Inês?”

“No names need be mentioned.”

Across the room, Inês was inspecting the platform. One of the electricians knelt beside her. The other stood with the injured dignity of a man who had followed instructions.

“Will you keep the ship off?” Nuno asked.

Marta glanced at the champagne glasses.

“For the reception, perhaps we can have a brief demonstration.”

There it was: the little bargain. Take the money, restore the object, let everybody keep the story they needed. Nuno had made a living from bargains like that. The person who lost usually discovered it later.

“She says she sent you an incident report.”

“I haven’t opened every attachment today.”

“But you found time for the theft video.”

Marta’s face tightened.

“She removed an object without authorisation. I needed to know where it had gone.”

“You could have asked her.”

“I’m asking you to help me avoid a scandal.”

“So am I.”

He gave her back the tray.

“I want the full recording.”

Security occupied a cupboard behind the cloakroom. Its officer was eating a pear over a paper towel.

“Before and after,” Nuno said. “Not just the hand.”

The officer glanced at Marta, then opened the original file.

They watched an assistant put the compass beside the ship. The photographer adjusted his lights. Marta moved the yellow warning label out of the frame.

“I put it back,” she said.

The officer ran the footage forward.

Visitors arrived. An attendant started the model. The compass trembled on the polished platform, then shifted a little with each roll.

Inês appeared behind a school group.

“Slow it down,” Nuno said.

The compass slid towards the unfinished edge. Inês reached across, caught it and struck her wrist against the steel lip. For a moment she stood with her fist against her coat.

Nuno recognised the movement now: not concealment. Pain.

She opened her hand to an attendant, pointed beneath the platform, then stopped the ship. A minute later she walked away carrying the compass openly.

“I sent the close-up because you asked for the moment the object was taken,” the officer told Marta.

Nobody spoke.

Then Marta said, “That establishes that she didn’t steal it.”

“It establishes she helped,” Nuno said.

“I accept that.”

“Will the trustees?”

“I can correct the description.”

“And the ship?”

Her patience broke.

“A loose compass does not mean a three-metre model is about to collapse. The compass is back in its case. Whatever happened, the problem has been removed.”

Nuno thought of the black crescent on the brass rim. In the clip, the compass had reached the slot before Inês caught it.

“What happens,” he asked, “if she doesn’t get there?”

Inês refused to test anything beneath the borrowed carrack.

They fetched its padded delivery cradle. The electricians lifted while Nuno steadied the bowsprit and Marta, deprived of a useful place to stand, was given a strap.

“Please don’t pull,” Inês said.

“I’m not pulling.”

“Good. Keep doing that.”

Without the ship, the platform looked embarrassingly ordinary: plywood waves, steel brackets, cables gathered with plastic ties. One support rested against a stop scarcely wider than Nuno’s thumb.

Inês fitted a hand crank to the disconnected drive.

“The motor cutout should stop it if the linkage jams,” she said. “It hasn’t been adjusted. That was in the report.”

Marta looked at the platform.

“Yes.”

From a box of offcuts, Inês chose a wooden disc. She measured it against the compass and trimmed its edge.

Nuno put the original safely in its velvet hollow. Then he laid the wooden substitute where the photographer’s assistant had left the compass.

Inês turned the crank.

The platform inclined. The disc slid towards the gap, caught briefly on the greasy lip, then dropped between the moving linkage and its frame.

The crank stopped.

“Jammed,” Marta said.

Inês nodded.

“Now the motor keeps pushing.”

She applied a little pressure. With the linkage trapped, one side of the platform lifted clear of its stop.

Nuno looked at the empty brackets which, ten minutes earlier, had held the collector’s ship. Beyond them stood the champagne pyramid. Behind that, the place marked out for the donor’s welcome photograph.

He took a step and caught the platform before it could tilt farther.

Inês eased the crank backwards. The support settled with a heavy click.

For once, Marta did not look at her watch.

“So,” Nuno said, still holding the plywood sea, “the theft prevented a shipwreck.”

Inês removed the wooden disc. Its edge was crushed.

“The real one wouldn’t have given much.”

Marta sat on the delivery cradle.

Outside, someone tested the microphone.

“Welcome,” it boomed. “Sorry. Welcome.”

“Can it be made safe tonight?” Marta asked.

“Stationary,” Inês said. “Level, supported, disconnected. Tomorrow we finish the guard and cutout.”

Marta nodded.

“And before anyone touches it,” Nuno said, “you explain why.”

She looked towards the doorway, where the electricians and two caterers had become very interested in their shoes.

“I’ll tell the trustees an installer prevented serious damage.”

“Her name is Inês Rocha.”

“I know her name.”

“Then use it.”

Marta stood.

“I owe you an apology,” she told Inês.

“Yes,” Inês said.

It was not a comfortable silence, but Nuno left it alone.

When the doors opened, the carrack stood magnificent above a sea that had unexpectedly become calm. Marta intercepted the principal donor before he could ask why. She brought him to Inês, indicated the compass, then showed him the damaged wooden disc.

Nuno could not hear everything. He heard “my decision” quite clearly.

“And the thousand euros?” Inês asked him later.

“Workshop safety budget.”

“You gave away my reward?”

“I recovered it.”

“From a cupboard.”

“Difficult lock. Already open.”

She smiled then, properly, and he saw the woman from the tram.

“You could have told me you worked here,” he said.

“You could have looked harder.”

“Yes.”

He let that stand too.

“Coffee tomorrow?”

“Provided you don’t offer to make me disappear.”

At the navigation exhibit, a donor beckoned. Nuno gathered the waiting guests around the carrack.

“This vessel,” he announced, “has survived storms, neglect, and preparations for tonight’s reception.”

They laughed.

“Fortunately, someone was watching the small things.”

He stepped aside so they could see Inês, who was explaining the mechanism to a little girl with a souvenir medal firmly tucked inside her shirt.