The secretary read the added paragraph aloud. The complete mural, including its border and every donor’s name, would remain in place within the new passageway. Access from the street would be free, with daily opening hours fixed in the agreement. The preservation condition would bind any future owner.

“Not just the centre panel,” Mina said.

“The complete mural,” the secretary repeated, and turned the screen so she could see.

Leah laid her drawing beside the agreement. On the plan, the passage ran where people had once queued for towels. Beyond it were the stairs to the flats.

Daniel read both pages before signing. Then he took the auction inventory and drew a line through the mural’s entry, initialling the margin. He passed it to the secretary to replace the posted copy.

Mina watched the ink dry. She had expected to feel something larger.

“You’ll have copies,” the secretary told her.

“Yes. Thank you.”

The chair moved to the next item. There were costs still to approve, a survey to commission. Mina gathered her bag without interrupting.

By the time she returned, the bathhouse had been closed for forty minutes. The notice on the outer door gave no date for reopening. Inside, the afternoon light reached across the entrance floor, showing the places her mop had missed along the skirting.

She began at the changing rooms.

Every locker stood open. She checked them anyway, passing her hand along the upper shelves where spectacles and wedding rings had sometimes been left. In the smallest cubicle she found a hairpin. She put it in the lost-property tin, then stood holding the lid. At last she closed it.

The pools were drained. Without water, the deep end seemed less deep, its sloping floor exposed beneath the lights. She checked the taps, the windows, the service-room latch. There was no reason to hurry and no reason to take longer.

In the linen cupboard lay her husband’s spare towel, kept behind the clean stack through the months of his illness and the months after. He had disliked the bathhouse towels, their stiff narrow hems.

She took it out. One corner had folded under itself. Her hands began the familiar work of bringing the edges together, then stopped.

She left it unfolded on the changing-room bench.

At the mural she paused long enough to read three names she knew and one she did not. Soon people would pass here carrying shopping, pushing prams, looking for an address. They would not need her to hand them anything.

Mina switched off the entrance lights and went outside to lock the door.