The second leaf gave her nothing.

Leena checked the extraction controls, then the reagent lot. Both passed. On the screen, the stress-response marker sat close to baseline, nowhere near the sharp rise in the first sample. She ran the calculation again without changing any inputs.

The same flat result appeared.

She had wanted the first signal to mean that the beans were managing the storm’s damage: slowing repair elsewhere, advancing reproduction, making a workable adjustment to a hostile place. But injured plants could flower early too. A last expenditure, not an improvement.

One leaf supported her hope. Another did not. Neither told her what would fill a pod.

She was still looking at the traces when Pavel came through the greenhouse door carrying a tablet against his chest.

“I need a yield estimate.”

“You have the schedule.”

“I have a schedule that assumes those trays produce beans in five weeks.” He nodded toward the sealed growing enclosure. White flowers stood above the dwarf plants. “If they set now, can we hold the harvest?”

“I don’t know if they’ll set.”

Pavel put the tablet beside her screen. He had removed the anomalous crop from the food budget entirely. A red column ran down the right side.

“We can cover most of it with stores. Not all. We fall below the reserve minimum eleven days before the next delivery.”

Leena scrolled through his figures. No arithmetic mistake offered itself.

“Replacing them today wouldn’t close that gap,” she said.

“No. Replacing them yesterday wouldn’t either. But I could have started adjusting portions yesterday.”

Commander Imani entered while he was speaking. She stopped beside the bench, read the budget, then looked at Leena’s assay display.

“Which result is this?”

“The repeat.”

Imani opened Leena’s progress report on her wrist screen. “You wrote that the initial screening suggested a coordinated stress response.”

“It did.”

“And these?”

Leena could have explained tissue variation, sampling noise, the weakness of any conclusion drawn from so few plants. Each explanation was true. None answered the question.

“They conflict.”

“They aren’t in the report.”

“I wanted to settle it before—”

“Before I saw it?”

The ventilation hummed through the pause. Leena remembered committee rooms on Earth, how quickly a qualification became a reason to stop listening. She had learned to arrive with every loose end tied down.

Here, Pavel had been counting meals from what she chose to tell them.

“I thought another assay would clarify it,” she said.

Imani glanced at the clock above the enclosure. “Shift change is still the deadline.”

Leena lowered her eyes to the two traces. She had kept the uncertainty at her bench. It had reached everyone anyway.