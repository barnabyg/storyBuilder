Marta did not agree. She arranged the papers on her desk into a rectangle, which Nuno recognised as the administrative equivalent of folding one’s arms.

He bent over the gala brochure instead.

In its photograph, the museum’s great model ship sailed above a delighted school party. Beneath the hull, the machinery had been cropped out, leaving the vessel apparently sustained by Portuguese achievement. At the edge of the picture, something small and golden caught the light.

“May I?”

He picked up the magnifier beside Marta’s letter opener.

“Our visitors generally admire the ship,” she said.

“I’ve always supported the smaller attractions.”

The compass lay on the narrow ledge beside the drive slot. Not in its little velvet hollow, not behind glass: beside the opening through which the display’s mechanism travelled. The warning Nuno had made a joke about on his tour—KEEP LOOSE OBJECTS CLEAR—was visible just below it.

“When was this taken?”

“This morning. Before we opened.”

“An excellent likeness of a loose object.”

Marta reached for the brochure. A sheet came with it, caught beneath the glossy cover, and slid across the desk.

Nuno steadied it with two fingers. Once, those fingers had extracted wallets on moving trams. Now they prevented office accidents. Reinvention deserved more applause.

The sheet was a workshop checklist. Several boxes remained empty. One line read: Drive-slot guard awaiting fitting. Below it, in blue ink: Run display for press and gala preparation. Guard to follow.

Marta’s signature occupied more space than the instruction.

“The contractors are behind,” she said, taking the sheet. “We cannot postpone the entire museum whenever someone lacks a screw.”

“Certainly not. Lisbon would close.”

She put the checklist in a drawer.

Nuno glanced back at the security monitor. Inês leaned into frame, her hand descending; then the clip stopped with her face turned towards the camera.

“Could I see the full recording? A minute before this. A minute after.”

“You’ve seen her take it.”

“I’ve seen her hand move. Hands have a surprisingly broad repertoire.”

“I need a culprit, Senhor Vale, not a seminar.”

Outside, someone tested a microphone. A tremendous, apologetic cough filled the corridor.

“The donors arrive at seven,” Marta continued. “Bring me the compass before then, and the reward is yours. Otherwise I circulate that image to every newspaper and police contact I have.”

Nuno set down the magnifier.

“A face is difficult to uncirculate.”

“Then you’d better speak to her quickly.”

He smiled his professional smile: warm, reassuring, and giving absolutely nothing away.

“Now that,” he said, “is something I can do.”