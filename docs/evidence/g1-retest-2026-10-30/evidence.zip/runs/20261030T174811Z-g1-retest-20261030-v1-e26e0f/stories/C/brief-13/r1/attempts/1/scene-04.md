There were twenty-three minutes left before shift change.

Leena sent the assay files to the crew channel without removing the failed run. She included the calibration logs, the greenhouse dosimeter readings, and the progress report she had sent that morning. Beside its claim of consistent results, she marked the two traces that contradicted it.

The commander watched the files open on the galley screen. The engineer stood by the water dispenser, holding an empty cup.

“I should have given you these when I got them,” Leena said. “I thought I could resolve the disagreement before anyone needed to act on it.”

“We were already acting on it,” the commander said.

“Yes.”

She kept her hands away from the screen. She wanted to point out the stronger trace, explain why she had trusted it. Instead she waited while they read.

“The flowers are early,” she said at last. “That’s the observation. It doesn’t establish that the storm caused the change. It doesn’t prove the plants are safe, and it doesn’t prove they’ve adapted usefully. Early flowering could leave us with fewer beans, or none.”

“So your recommendation is destruction?”

“My recommendation is to retain two plants for a test. Not to return the crop to production.”

She opened a blank work order.

“The spare root-study chamber has its own air loop and waste reservoir. No connection to greenhouse drainage. Two flowering plants, each in a sealed growth vessel. Two matched controls from the unaffected batch—same cultivar, sowing date, substrate, and light cycle.”

“The chamber’s return valve leaks,” the engineer said.

Leena stopped typing.

“Then independence is a requirement, not an assumption. If you can’t certify the loop before transfer, this proposal fails.”

The engineer set down the cup and leaned toward the screen.

Leena entered sampling dates: baseline at transfer, then days three, seven, fourteen, and twenty-one. Flower counts, pollen viability, leaf damage, pod set. Genetic assays with the failed replication attached, not replaced.

“Destruction thresholds go in writing before anything moves,” she said. “A failed containment check. Any pollen detected outside a growth vessel. A positive result in the chamber’s waste trap. No discretionary extension from me.”

“And if the results disagree again?” the commander asked.

“They stay in the record. No release to production or the seed bank. We review them together.”

The commander looked at the remaining time, then back at her.

“Put down who can stop the test.”

Leena added a line beneath the thresholds.

“Any of us,” she said, and turned the screen so they could amend it.