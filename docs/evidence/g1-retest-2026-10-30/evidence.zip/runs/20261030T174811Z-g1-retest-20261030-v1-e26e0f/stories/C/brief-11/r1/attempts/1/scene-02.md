The numbers had outlasted several of the people beside them. Mina turned past her own small crosses in the margins and dialed Ruth.

Daniel had warned her not to use the desk telephone to organize opposition. Until she signed the closing documents, she was still an employee; her severance depended on completing her duties. She kept the receiver low, though there was nobody in reception to overhear.

“They’ve put the mural on the auction list,” she said.

“The whole wall?”

“It says removable. Have you still got your photographs?”

“I’ve got the one of my father.”

“Bring it, please. Anything showing the names.”

She called six more numbers. One had been disconnected. Mr. Bell wanted to know whether he could collect the sandals he had left in locker nineteen. A woman Mina remembered by her habit of folding her towel lengthwise said she would come if someone could bring her back before her carer arrived.

Before Ruth arrived, Mina ruled a sheet of paper with a pencil and wrote across the top: We request that the closure be suspended and the baths reopened. Beneath it she left space for names.

Ruth came carrying a photograph between two pieces of cereal-box cardboard. She wore her good raincoat, the one she used to hang inside out so the lining could dry while she bathed.

In the picture, a younger man stood beside the mural with his palm resting under a blue tile. JOSEPH MENSAH, it read. His trouser cuffs were wide; he looked faintly embarrassed by the attention.

“He gave two weeks’ wages,” Ruth said. “My mother mentioned it whenever we needed shoes.”

Mina placed the petition beside the photograph and offered her pen.

Ruth read the heading twice.

“No,” she said.

“We need names before the meeting.”

“Not under that.”

Mina kept the pen extended for another moment, then laid it down.

“My daughter’s applied for one of those flats,” Ruth said. “She and the boys are in her sister’s front room. Every morning they put the mattresses away before anyone can have breakfast.”

“You never said.”

“You always had my towel ready.”

From upstairs came the scrape of furniture being moved. Mina looked at the photograph again. She had known Ruth’s preferred hook, the temperature she complained about, which knee made the steps difficult.

“I want his name kept,” Ruth said. “I don’t want them selling it to somebody for a kitchen. But I won’t sign away her chance.”

Mina drew the petition back. On a clean sheet she wrote Ruth’s name, then stopped.

“What would you be willing to ask for?” she said.