The breaker snapped back before Ruth could take her thumb away.

Behind her, someone on the stairs said, “Again?”

“Give me a minute.”

Ruth kept her voice level. Six years as superintendent had taught her that people could wait longer if they didn’t hear you worrying. She wiped her hand on her shorts and looked at the labels inside the hallway panel. Someone had plugged an air conditioner into the outlet meant for the vacuum. Someone always did.

The stairwell was crowded with tenants hoping the roof door might be open. Children sat on the steps, their shirts damp down the spine. Mrs. Ortiz held a packet of frozen peas against her neck.

“Who’s running an extension cord from the second-floor landing?” Ruth asked.

Nobody answered.

A green bird swooped past her ear.

Ruth ducked. The parrot landed on the panel door and gripped its metal edge, panting with its beak open. Above them, a little boy shouted, “That’s Elena’s!”

“Don’t chase it.”

Ruth shut the panel carefully, shifting the bird onto its outer edge. She borrowed Mrs. Ortiz’s dish towel and held it below the parrot’s feet.

“Come on, handsome.”

It stepped onto the towel, then bit her knuckle through the cloth. She folded the towel loosely around its wings.

“Very handsome,” she said through her teeth.

A man on the second floor reluctantly went to unplug his air conditioner. This time the breaker held. Lights came on above the stairs, yellow and weak. From behind the panel came a steady hum Ruth didn’t remember hearing before.

Her phone buzzed. Her daughter had sent: Can we sleep with the door open tonight?

Ruth typed, When I get upstairs. Lock it for now.

The bird twisted its head toward her.

“Open the basement door.”

Several people laughed. Ruth looked down at it.

“What was that?”

“Open the basement door.”

Elena lived on the first floor, where the basement stair began. The bird might have learned it from anyone carrying laundry. Ruth had heard it imitate a microwave for twenty minutes.

Still, she carried it downstairs.

The basement entrance was boarded shut.

Three pale lengths of lumber crossed the old door, their screw heads bright. Sawdust lay on the bottom step. Yesterday she had gone through that door to fetch a mop bucket.

“Open the basement door,” the parrot said against her wrist.

Ruth touched the nearest board. A splinter caught her fingertip.

She put her ear to the narrow gap beside the frame and held still, listening past the hum.