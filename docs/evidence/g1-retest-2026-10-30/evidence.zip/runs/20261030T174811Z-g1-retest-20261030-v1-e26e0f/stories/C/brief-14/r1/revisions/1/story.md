"This," said Nuno Vale, as the model carrack lurched above its painted Atlantic, "recreates the experience of rounding the Cape. Courage, uncertainty, and a worrying noise from underneath."

His tourists laughed. Nuno liked a laugh: it moved people along without making them feel moved.

The ship was three metres long, gilded, elaborately rigged, and borrowed from a collector whose name appeared on almost everything except the emergency exits. Its motorised platform rolled gently from side to side. Through a gap in the unfinished casing, a steel linkage travelled back and forth.

KEEP LOOSE OBJECTS CLEAR, said a yellow label.

Nuno lifted a child's dangling souvenir medal away from the gap.

"Portugal has lost enough treasure at sea."

Once, those fingers had removed watches without troubling their owners. Now they protected watches, counted tourists, and pointed out azulejos. He had spent fourteen years becoming a man people entrusted with their bags.

Director Marta intercepted him beside the navigation display.

"Your group can look at the maps."

"They've paid for stories."

"Tell them the maps are disputed."

He dispatched twelve people towards a coastline on which nobody agreed.

"The brass compass is missing," Marta said.

Its glass case stood beside the ship. Within it, a biscuit-sized hollow interrupted the velvet.

"Perhaps it's gone exploring."

"Nuno."

She showed him a security clip on her phone. Visitors crowded around the moving carrack. A woman in a green scarf leaned forward. Her hand closed above the platform's edge; something yellow disappeared towards her coat.

Inês.

He had last seen her on the number twenty-eight tram, stepping off with three wallets and an expression of mild disappointment in public transport. That had been sixteen years ago. He had looked for her once, after he stopped stealing, but not very hard. He had been afraid she would laugh.

"Do you recognise her?" Marta asked.

He watched the clip again. Inês's other hand was braced against the platform. She had never needed to brace herself to lift a compass.

"I may be able to find her."

"There's a thousand-euro reward. Quietly, before the gala."

"What have security said?"

"They gave me this."

"And the police?"

"I would prefer a recovered object to a museum full of police. Our principal donor arrives at seven."

Behind them the linkage made a sharp metallic clack.

"Does it always do that?" Nuno asked.

"It's a sailing ship. They creak."

He glanced at the steel beneath the painted waves.

"An impressive commitment to authenticity."

In Marta's office, the gala brochures lay in glossy stacks. The cover showed the carrack apparently sustained by Portuguese achievement: the photographer had cropped away its machinery.

At the edge of the photograph, beside the ship, sat a small brass circle.

Nuno picked up a brochure.

"When was this taken?"

"This morning."

"The compass wasn't in its case."

"The glass reflected the lights. I asked them to put it beside the model."

"On the moving platform?"

"It wasn't moving then."

Under the brochures lay a contractor's checklist. Nuno could read upside down; it had once been essential to his work.

Guard panel awaiting fitting. Secure all loose display objects. Motor overload cutout pending adjustment.

Below that, in Marta's expansive handwriting: Demonstration required for press and gala.

She noticed his attention and covered the sheet with the brochure.

"The contractors assured me it would run."

"Did they put that in writing?"

"They put everything in writing. It's why nothing gets finished."

"May I see more of the recording?"

"You've seen her take it."

"I've seen her close her hand. There are innocent reasons."

"Then bring me one."

Her phone vibrated. She silenced it without looking.

"At seven, I must tell the trustees what happened. If the compass isn't back, I'll have to give them her picture."

Nuno placed the brochure carefully on the desk.

"Let me speak to her first."

He found Inês in the conservation workshop. Her scarf hung on a peg beside a museum badge reading DISPLAY INSTALLER. She was filing the edge of a curved metal panel.

"You've gone respectable," he said.

"So have you. Apparently they pay you to talk now."

"An oversight I'm hoping they won't notice."

She inspected the panel against the light.

"The compass," he said.

"Ah."

"I've seen the video."

"Which bit?"

He stopped smiling.

Inês put down the file and brought him a shallow tray. The compass lay on white tissue, a black smear along its brass rim. Beside it was a numbered receipt.

"Time received," she said. "Condition. Temporary location. My signature. Conservation assistant's signature."

"An unusually thorough way to steal something."

"I'm aware. We've both lost our touch."

She had worked on shop fittings, she told him, then exhibition cases, then museum installations. She liked work that stayed where she put it.

"Mostly," she added.

"Does Marta know it's here?"

"I sent her the incident form. She replied, 'Return object and cease delaying rehearsal.' I told her the display needed isolating first."

"And she decided it was stolen?"

"She decided it wasn't where she wanted it."

Nuno looked at the panel on the bench. It curved to fit the open side of the platform.

"Give me the compass. I'll put it in the case. She can call it a misunderstanding."

"And restart the ship."

"She's already running it."

Inês's face changed.

"I disconnected it."

They heard the distant clack through the floor.

For a moment neither spoke.

Then Inês took off her safety glasses.

Nuno followed her upstairs, feeling suddenly foolish about his proposed happy ending. He had offered her exactly what Marta had: make the awkward thing disappear.

A caterer was arranging champagne glasses beside the carrack. Two electricians stood near a trailing cable. The ship rolled above them.

Inês went straight to the switch and turned it off.

One electrician protested. "The director said the plug had come loose."

"The plug had been labelled."

"She said you were being cautious."

"I am," said Inês. "It's a professional qualification."

She unplugged the cable, looped it through the open guard panel and secured both with her own padlock.

Marta arrived at considerable speed.

"What are you doing?"

"Keeping your ship upright."

"It's been running all afternoon."

"So has a crack in a ceiling, until it hasn't."

Marta saw Nuno holding the conservation tray.

"Excellent. You've recovered it."

"It wasn't far away."

"Then we can settle this."

She drew him towards the navigation case.

"The compass was misplaced during installation. You found it. I can put the reward through as a consultancy fee."

"And Inês?"

"No names need be mentioned."

Nuno looked towards his former accomplice. She was checking the platform supports while the electricians watched with the affronted expressions of men who had obeyed instructions.

He could take the money. Marta would retain her guide; Inês would retain her job if she kept quiet; the ship would make its handsome little voyage. It was the sort of arrangement he had once admired.

"First," he said, "I want to see the full recording."

Marta's expression tightened.

"The gala opens in thirty minutes."

"Then we should stop watching the short version."

Security occupied a cupboard behind the cloakroom. Its sole officer was eating a pear over a paper towel.

At Marta's request he brought up the footage.

"Not the export," Nuno said. "The original."

Marta said nothing.

The officer wound backwards. They saw a photographer taking pictures; an assistant placing the compass on the platform; Marta moving a warning label so it would not appear in the photograph.

Then visitors arrived. Someone started the model.

"There," Nuno said.

The compass trembled on the polished surface. With each roll it travelled a little farther towards the edge.

Inês appeared behind a school group. She looked down, stepped forward—

"Slow it."

The compass slid towards the open slot.

Her hand darted out.

She caught it, knocked her wrist against the steel lip, and stood holding it in her closed fist. Then she turned towards the camera and pointed sharply downwards.

"Keep going."

She stopped the platform. She spoke to an attendant, showed him the compass, and walked away with it in her open palm.

The security officer swallowed his pear.

"I only sent the close-up because you asked for the moment it disappeared."

Marta studied the monitor.

Nuno had expected satisfaction. Instead he felt the old, sour recognition of a trick performed badly. Show them a hand. Let them supply the theft.

"You knew she'd taken it to conservation," he said.

"I knew she said she had."

"There's a receipt."

"I hadn't read every attachment."

"But you had time to ask for a picture that made her look like a thief."

Marta folded her arms.

"If a loose object was on the platform, she was right to remove it. That does not mean the entire attraction is unsafe."

"No," Nuno said. "It doesn't. So let's find out before you put a borrowed ship back on it."

Inês refused to test anything beneath the carrack.

With the electricians and a padded trolley, they transferred the model to its delivery cradle. Marta stood by the door, checking her watch until Inês asked her to hold a strap. After that she had to watch the ship.

Without it, the platform looked embarrassingly domestic: plywood waves, steel supports, cables tied together with plastic.

Inês fitted a hand crank to the disconnected drive.

Nuno showed her the black crescent on the compass.

"From the edge?"

She nodded. "It was already touching."

From a box of packing offcuts she chose a wooden disc, measured it against the compass, and trimmed it with a knife.

"The same size," Marta observed.

"I'd rather not use the original," said Inês.

Nuno put the real compass safely in its velvet hollow.

Then he laid the wooden disc where the photographer had left it.

Inês turned the crank. The empty platform inclined. The disc slid, caught against the greasy lip, and dropped into the slot.

The crank stopped.

"That," Marta said, "is inconvenient."

"The motor doesn't get tired when it meets inconvenience."

Inês pressed the crank a fraction farther. With the linkage trapped, the force went into the platform support. One side lifted off its stop.

Above it stood the empty brackets that, ten minutes earlier, had held the collector's ship.

Beyond them, at precisely the wrong distance, waited the caterer's pyramid of champagne glasses.

Nuno pictured gilded masts descending through three hundred flutes towards the trustees.

He let the picture settle.

"So she didn't take the compass away from the museum," he said. "She took it out of the machinery."

Inês eased the crank backwards. The support settled with a heavy click.

Marta still held the unused lifting strap.

For the first time that afternoon, she did not mention seven o'clock.

"Can it be made safe tonight?"

"Stationary," Inês said. "Level, supported, and disconnected. The guard and cutout get finished tomorrow."

Marta nodded once.

"And the report?" Nuno asked.

She looked at the compass in its case, then at the crippled little wooden substitute.

"The compass was removed by a member of staff who prevented serious damage."

"Her name is Inês Rocha."

"I know her name."

"Put it in."

Outside, somebody tested the microphone.

"Welcome," it boomed. "Sorry. Welcome."

Marta handed Inês the strap.

"I'll need your help explaining the delay."

"You'll have it," Inês said. "I'm not explaining a theft."

"And the reward?" Nuno asked.

Marta looked at him.

"A thousand euros buys a useful amount of caution. Give it to the workshop."

When the doors opened, the carrack stood level and magnificent above a sea that had miraculously become calm.

Marta introduced Inês to the principal donor. Nuno saw her indicate the compass, then the ship. This time, she seemed to be telling the whole story.

"You could have told me you worked here," he murmured as Inês passed him.

"You could have looked harder."

He accepted that.

"Coffee tomorrow?"

"Provided you don't make me disappear afterwards."

He gathered the first donors around the display.

"This vessel," he announced, "has survived storms, neglect, and preparations for tonight's reception."

They laughed.

"Luckily," he went on, "someone was watching the small things."

This time he did not move them along.
