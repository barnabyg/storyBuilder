Mina folded the towels in thirds, then in half, keeping the worn borders inside. Since her husband’s death she had come in forty minutes early to do this. At home there were too few things to put in order; here, even on the last morning, a trolley waited.

She made twelve stacks of eight before remembering that the baths would close at noon. There would be no afternoon swimmers, no Friday sisters feeling through the piles for the oldest towels. She removed four stacks and put them back in the cupboard.

Behind them lay the striped towel Joseph used to bring on Saturdays. During his illness she had washed it with the bathhouse linen, though personal washing was prohibited. Afterward she had kept it there. At home someone would eventually have asked whether she wanted it put away.

She shut the cupboard and wheeled the trolley into reception.

A yellow auction label covered the first three letters of ADEYEMI.

She lifted a corner with her thumbnail. A thread of adhesive stretched from the paper to the blue glaze.

On the inventory pinned beside the desk she found LOT 47. DECORATIVE CERAMIC PANEL. BUYER TO ARRANGE REMOVAL.

The panel was a wall. Its painted tree spread around the entrance to the warm room, carrying names along the branches and out into the cream tiles beyond. Above it, between two improbable blue birds, was the date 1926.

Daniel came in carrying coffee and a folder. He had been the board’s treasurer before the closure made him, as he put it, responsible for everything.

“This needs correcting,” Mina said.

He read the entry. “The auction company assessed it.”

“The names go round the corner.”

He looked round the corner.

“They can’t take the picture without cutting through them.”

“The building is being demolished.”

“Then don’t sell it as something that comes off.”

He set his coffee on her list of missing locker keys.

“The housing trust has a grant deadline. We cannot start reopening decisions.”

“I’m asking you to cross out one line.”

“And then what happens to it?”

She had no answer ready. Until that moment she had imagined that identifying the mistake would be enough.

“The board meets here at three,” he said. “Bring me something we can actually consider. Not another demand to save the baths.”

At the stairs he stopped.

“And please finish the handover. The final payment requires it.”

Mina knew the amount of her severance to the penny. She had written it beside six months of mortgage payments in a notebook at home.

She moved his coffee off the key list.

At nine, Mr Bell arrived with a shopping bag for his sandals. He stood before the mural while she fetched them.

“My mother’s on there,” he said.

Mina looked up. “Which one?”

“Dock labourers’ benevolent fund. She did their books. They wouldn’t put a woman’s name.”

For twenty-seven years she had known he needed two towels and returned one dry. She had never known what his mother did.

“Would you come back at three?” she asked.

“What for?”

She showed him the inventory.

He read it twice, then folded his sandals into the bag. “Are we trying to keep this place open?”

“No,” she said, and found she disliked him for making her answer.

After he left, she took out the old appointment book in which she kept the regulars’ telephone numbers. Some had small crosses beside them. Others had been copied so often that the original names had become guesses.

She called Ruth first.

“Have you still got the photograph of your father by the tree?”

“Yes.”

“Can you bring it?”

“Mina, what are you doing?”

“Trying to get them to listen.”

She called six more people. One number had been disconnected. A woman she remembered by her habit of folding her towel lengthwise said she could come only if someone brought her home before her carer arrived. Mina wrote this down. Then she rang Mr Bell again and asked whether he could give someone a lift.

Between calls she issued the last locker keys and took the cash drawer to the office. She was seventeen pounds short until she remembered that Daniel had bought milk from the float.

Ruth arrived with her photograph protected between pieces of cereal-box cardboard. Mina had ruled a sheet of paper and written across the top: We request that the closure be suspended pending consultation.

Ruth read it without taking off her coat.

“No.”

“It only says suspended.”

“You told Mr Bell it wasn’t about reopening.”

“We need time.”

“My daughter needs somewhere to live.”

Mina put down her pen.

“She’s applied for one of those flats. She and the boys have been in her sister’s front room since March. They put the mattresses away every morning before breakfast.”

“You never said.”

“You always had my towel ready.”

Behind them someone knocked a locker door shut. Mina straightened the petition against the edge of the desk.

Ruth slid out the photograph. Her father stood beneath the tree in wide trousers, one palm resting under JOSEPH MENSAH.

“Two weeks’ wages,” she said. “My mother mentioned it whenever we needed shoes. I want his name kept. I won’t sign something that makes my daughter wait another year.”

Mina looked at the name. When her own Joseph first came to meet her after work, he had claimed it as proof that she had been expecting him.

She turned the petition face down.

“What would you sign?”

At noon Mina locked the entrance behind the last bather. He had asked whether he could have another five minutes, and she had given him ten.

Leah, the housing trust’s architect, arrived while Mina was counting towels into the linen contractor’s sacks. She had come to photograph the meter readings and inspect the delivery entrance.

“Before you do that,” Mina said, “will you look at something?”

Leah stood close to the mural, then stepped back. “I thought this was being salvaged.”

“So did whoever wrote the catalogue.”

Mina showed her where ADELAIDE PRICE began inside the green border and finished three tiles beyond it. AND HER SISTERS crossed a repaired seam below. Another name turned the corner beneath the window ledge.

“The sale photograph stops here.”

Leah rubbed her forehead. “Our survey marks this as decorative finish.”

“It is decorative.”

“I mean they didn’t record the extent.”

Mina nearly asked whose fault that was. Instead she fetched the folding table from the laundry.

On Leah’s plan, the warm room had become bicycle storage. The pool was a courtyard. Mina kept looking for the doorway to her cupboard, though she understood why it wasn’t there.

“Could people walk through here?” She traced the delivery route to Bell Lane.

“That’s the service access.”

“It used to be an entrance. Before they built the laundry.”

Leah checked another drawing. “The wall isn’t supporting the roof. It might be possible to retain it independently.”

“With a passage beside it?”

“Possibly. But there’s bracing, weather protection, a new foundation detail. It isn’t just deciding not to knock it down.”

“Would it cost a flat?”

Leah looked at her, then measured something.

“No. Not on this line. We’d lose two cycle spaces and move a door.”

She made a call. Mina went back to the linen sacks. When she returned, Leah had written a figure in the margin.

“That’s a provisional allowance, not a price. It would take most of the entrance contingency.”

“What was that for?”

“Things we don’t know about yet.”

Mina nodded. She understood that kind of money.

Ruth sat at the desk calling people back.

“No, the baths are closing,” she said into the receiver. “The whole wall. All the names. Somewhere you can go without asking permission.”

Mina brought her a clean sheet.

At half past two Daniel came down and found eleven former patrons in reception. Mr Bell had brought the woman who needed to be home by five. Ruth was holding up her photograph for a young trustee who had never been inside the baths before.

Daniel drew Mina aside.

“I asked for a proposal, not a demonstration.”

“There is a proposal.”

“Did you use the customer records?”

“My appointment book.”

“That belongs to the baths.”

She had thought of it as hers: her handwriting, her corrections, the crosses she had made after funerals.

“I rang them,” she said. “They’ve agreed to have their names on the request.”

“You’re still on duty. I can’t sign off your handover if you haven’t done it.”

“The keys are counted. The linen’s bagged. The meters need reading.”

“Then read them.”

She handed Ruth the petition and went with him into the service room. He read the numbers aloud while she wrote. Neither mentioned the meeting.

Upstairs, the board had arranged six chairs on one side of the table and three on the other. Mina remained standing until the chair asked someone to fetch more.

Leah explained the passage. She did not call it simple. She described the engineer’s inspection, the demolition sequence, the maintenance obligation. The trust’s director asked what would happen if the wall proved unsafe.

“We’d need an agreed method of dismantling and reinstating it,” Leah said. “Every tile recorded. But in-situ retention is preferable.”

“And if the costs rise?”

No one answered immediately.

Ruth placed the photograph on the table.

“My daughter’s on your housing list,” she said. “I’m not here to stop the homes.”

The director looked at her application number, which Ruth had written on the back of an envelope, then pushed it gently back.

“This won’t affect her place.”

“I know. I’m telling you because both things matter.”

Daniel turned to Mina. “You’ve given people the impression we can promise this today.”

“I told them you could decide not to sell it.”

“And preserving it?”

She looked at Leah’s pencilled route through the building. It passed the place where she had stood every working morning for twenty-seven years.

“You can make it part of the transfer. Before there’s nothing left to discuss.”

“The baths will still close,” the chair said.

“Yes.”

“Today.”

“Yes,” Mina said. “They’re already closed.”

The room was quiet enough for her to hear someone downstairs trying the outer door.

The chair asked for the draft transfer on the secretary’s laptop. They spent forty minutes on the wording. Public access from both streets, during fixed daily hours. No resident’s key. The complete mural, including the names beyond the border and around the return. An obligation to maintain it, binding on future owners.

Mina had to ask twice about the names.

The board voted to withdraw lot 47 and require preservation within the public passageway as a condition of the transfer. The trust’s director agreed to the revised terms, subject to the structural method being approved.

Daniel crossed out the auction entry and initialled it.

Afterward he gave Mina the handover form.

“You haven’t signed the final room inspection.”

“I haven’t done it yet.”

“Leave it on the desk when you have.”

“And the payment?”

He looked tired. “Payroll needs the completed form on Monday.”

She put it in her pocket. She would have to wait until Monday to know whether that was an answer.

By the time the last person left, the light had moved across reception. Mr Bell took his passenger home. Ruth wrapped the photograph in its cardboard again.

“Come for supper Sunday,” she said.

Mina began to say she would see, then asked, “What time?”

She made her final round alone.

Every locker stood open. She checked the upper shelves, where people left spectacles, rings, once an envelope containing a week’s wages. In the smallest cubicle she found a hairpin. She put it in the lost-property tin and wrote the tin on the handover list.

The drained pool showed every patch and repair. Without the water’s movement she could see the crooked line of tiles along the shallow end, the work of someone long dead who had either not noticed or not had time to make it right.

She checked the taps, the windows, the service-room latch.

In the linen cupboard she took out Joseph’s towel. It smelled of the same washing powder as all the others. She folded it once so it would fit in her bag.

At reception she signed the inspection form and left the keys beside it, keeping only the outer-door key for Daniel to collect.

The yellow label was still on the mural. This time she fetched a damp cloth and worked slowly until the paper loosened. A pale rectangle of adhesive remained over ADEYEMI. She cleaned that off too.

She read the name beneath it, then the next one.

Outside, someone was wheeling a bicycle down Bell Lane. For a moment she followed the sound along the route of the future passage, past the wall and out the other side. Then she switched off the lights, stepped into the street, and locked the baths.