At three, Mina laid the signed request before the board secretary. The sheets had curled in the damp office; she had flattened them beneath the first-aid box. Now one corner lifted again.

“Twenty-three signatures,” she said. “For keeping the whole wall where it stands, with public access through the new building.”

Daniel turned the first page without reading it.

“You approached these people as an employee?”

“I’ve known some of them thirty years.”

“That isn’t what I asked.”

Behind her, Ruth shifted a chair. Mina kept her hands on the table, where everyone could see them.

“Yes.”

“During your working hours?”

“Yes. I telephoned them from the office. I asked Ruth to bring the sheets round.”

“The board relied on you to manage an orderly closure. Your severance agreement includes cooperation with that process.”

She had read the agreement at her kitchen table, leaving the other place clear although there was no longer anyone to sit there. She knew the sum to the penny.

“I understand,” she said. “Ruth didn’t organize it. I did.”

Daniel pushed the papers toward the secretary. “Then we should be careful about presenting this as an independent expression of public opinion.”

“They signed what’s written there,” Mina said. “They didn’t sign away their opinions because I asked them.”

Leah unrolled the drawing before Daniel could answer. She weighted one end with her phone.

“The passage follows the existing entrance bay. We can retain the wall and brace it during demolition without retaining the wet rooms.” She indicated a narrow band beside the proposed courtyard. “There’s an allowance for unforeseen entrance and access works. We can use part of that contingency for the passageway. It will reduce what’s available elsewhere, but it doesn’t remove any homes.”

“How firm is that estimate?” a board member asked.

“Preliminary. The structural survey is still required.”

Mina looked at the drawn doorway. Leah had added opening hours beside it, and a note requiring the names to remain visible.

“I’m not asking you to approve a drawing and hope,” Mina said. “Please make it a condition of the transfer. The complete mural stays in place. The passage is public, without a purchase or an appointment. Someone has to be responsible for maintaining it.”

“And the baths?” Daniel asked.

“The baths close tonight.”

Saying it before them was different from knowing it alone.

“I’ll finish the closure,” she said. “This request doesn’t ask you to keep them open.”

The chair drew the papers closer and asked the secretary to bring up the draft transfer terms.