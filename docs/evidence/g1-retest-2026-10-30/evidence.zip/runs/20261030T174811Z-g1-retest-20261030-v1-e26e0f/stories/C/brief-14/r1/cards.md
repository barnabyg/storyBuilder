# A Small Matter of Direction

Plan brief-14; schema 1; tier M

Character nuno: Nuno Vale

Character ines: Inês Rocha

Character marta: Marta Seabra

## s1: The Reward Has Conditions

A missing compass interrupts Nuno's Lisbon museum tour.

Present: nuno, marta

Beat s1b1: Nuno jokes tourists past a juddering motorized ship display whose warning label forbids loose objects near its exposed drive slot.

Beat s1b2: Director Marta offers a recovery reward before the donor gala and shows footage of Nuno's former accomplice Inês apparently pocketing the tiny brass compass.

Fact fact-marta-authorization: Marta signed an instruction to run the unfinished display.; initial holders: marta

Fact fact-compass-rescue: Inês removed the sliding compass to prevent it jamming the drive and toppling the ship.; initial holders: ines

Setup setup-drive-slot at s1: The juddering ship display and loose-object warning establish a mechanical hazard beneath the comic tour patter.

## s2: An Inconveniently Good View

Nuno finds signs that the theft story has been edited.

Present: nuno, marta

Beat s2b1: Nuno spots the compass beside the drive slot in a publicity photograph and finds Marta's signed instruction to run the unfinished display.

Beat s2b2: When he requests the full recording, Marta demands a culprit instead and threatens to circulate Inês's face before the gala.

Reveal reveal-authorization-s2: fact fact-marta-authorization at s2; holders: nuno (acquired at scene start)

## s3: Professional Courtesy

Nuno tracks Inês to the museum's conservation workshop.

Present: nuno, ines

Beat s3b1: After mistaking three tourist wallets for his own, Nuno finds Inês working legitimately as the display installer.

Beat s3b2: Inês shows him the compass in a logged conservation tray but refuses its return while Marta insists on restarting the unsafe platform.

Causal cause-s3-s4: earlier cause s3 → effect s4

## s4: No Convenient Culprit

Nuno chooses a demonstrable explanation over a discreet handover.

Present: nuno, ines, marta

Beat s4b1: Matching grease on the compass to the drive slot, Nuno persuades Inês to help test the mechanism with the valuable ship removed.

Beat s4b2: Nuno declines Marta's reward-for-silence offer and secures the complete recording through Inês's installer access.

Causal cause-s3-s4: earlier cause s3 → effect s4

Causal cause-s4-s5: earlier cause s4 → effect s5

## s5: The Museum Corrects Its Course

The supposed theft proves to have prevented the museum's flagship exhibit from crashing.

Present: nuno, ines, marta

Beat s5b1: Before the gala opens, Nuno combines footage of Inês intercepting the sliding compass with a hand-cranked dummy test showing how it would jam the drive and topple the ship.

Beat s5b2: Faced with her signed instruction and the conservation log, Marta credits Inês's rescue, disconnects the motor, and lets Nuno guide donors past a magnificently stationary ship.

Causal cause-s4-s5: earlier cause s4 → effect s5

Payoff payoff-drive-slot-s5: setup setup-drive-slot → payoff at s5

Reveal reveal-compass-rescue-s5: fact fact-compass-rescue at s5; holders: marta (acquired at scene start)

State state-nuno-s1 [s1] nuno goal respectable_life: known: Keep his respectable guiding career separate from his criminal past.; confidence unrecorded; alternatives: (none recorded) → known: Recover the compass discreetly without exposing Inês or his own past.; confidence unrecorded; alternatives: (none recorded)

State state-marta-s1 [s1] marta goal gala_reputation: known: Present a successful museum gala.; confidence unrecorded; alternatives: (none recorded) → known: Secure the compass's return before donors arrive and contain the scandal.; confidence unrecorded; alternatives: (none recorded)

State state-nuno-s2 [s2] nuno belief theft_account: known: The footage appears to show Inês stealing the compass.; confidence unrecorded; alternatives: (none recorded) → known: Suspects Marta's theft account conceals a display-management mistake; Inês's motive remains unproven.; confidence unrecorded; alternatives: (none recorded)

State state-ines-s3 [s3] ines goal legitimate_work: known: Do honest installation work without being defined by her past.; confidence unrecorded; alternatives: (none recorded) → known: Keep the compass in logged custody until its return cannot enable an unsafe restart.; confidence unrecorded; alternatives: (none recorded)

State state-nuno-s4 [s4] nuno goal respectable_life: known: Recover the compass discreetly without exposing Inês or his own past.; confidence unrecorded; alternatives: (none recorded) → known: Establish a testable account that protects Inês and prevents an unsafe restart, rather than accept paid silence.; confidence unrecorded; alternatives: (none recorded)
