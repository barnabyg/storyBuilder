# The Names in the Wall

Plan brief-11; schema 1; tier M

Character mina: Mina Okafor

Character ruth: Ruth Bell

Character daniel: Daniel Shah

Character leah: Leah Chen

## s1: The Inventory

On closing morning, Mina discovers that the century-old bathhouse's donor mural is listed for removal.

Present: mina, daniel

Beat s1-b1: Mina folds towels as she has since her husband's death, then finds an auction label on the tiled donor names.

Beat s1-b2: Board chair Daniel refuses her correction and warns that abandoning her closing duties could jeopardize her severance.

Fact fact-auction: The posted auction inventory treats the donor mural as removable property.; initial holders: daniel

Fact fact-ruth-housing: Ruth's daughter needs the nonprofit's promised housing.; initial holders: ruth

Reveal reveal-inventory: fact fact-auction at s1; holders: mina (acquired at scene start)

## s2: What People Need

Mina asks former patrons for help and discovers that saving the bathhouse is not their shared demand.

Present: mina, ruth

Beat s2-b1: Mina calls regulars from the desk despite Daniel's warning and asks Ruth to bring photographs of the mural.

Beat s2-b2: Ruth brings a donor photograph but refuses a reopening petition because her daughter needs the nonprofit's promised housing.

Causal cause-needs-compromise: earlier cause s2 → effect s3

Reveal reveal-ruth-housing: fact fact-ruth-housing at s2; holders: mina (acquired at scene start)

## s3: A Route Through

Mina helps the housing nonprofit's architect find a way to retain the mural without retaining the baths.

Present: mina, ruth, leah

Beat s3-b1: Mina shows Leah the donor names crossing the mural's border into adjoining tiles, exposing what auction removal would destroy.

Beat s3-b2: Leah marks a public passageway around the retained wall on her plan while Ruth gathers patrons' support for preservation rather than reopening.

Causal cause-needs-compromise: earlier cause s2 → effect s3

Causal cause-plan-condition: earlier cause s3 → effect s4

Setup setup-passage-s3 at s3: Leah's passageway plan offers a concrete preservation proposal, not yet a binding commitment.

## s4: The Condition

At the afternoon board meeting, Mina risks her standing to argue for a limited, enforceable compromise.

Present: mina, ruth, daniel, leah

Beat s4-b1: Mina submits the patrons' signed request and accepts responsibility for organizing during work hours when Daniel challenges her credibility.

Beat s4-b2: After Leah identifies a contingency allowance for the passageway, Mina requests a binding preservation condition and explicitly accepts the bathhouse's closure.

Causal cause-plan-condition: earlier cause s3 → effect s4

## s5: The Final Round

The board secures the mural's public future, and Mina closes the bathhouse without mistaking preservation for reprieve.

Present: mina, daniel, leah

Beat s5-b1: Daniel signs the nonprofit's revised agreement preserving the complete mural in the new public passageway and strikes it from the auction inventory.

Beat s5-b2: With the bathhouse permanently closed, Mina makes her final round of its empty rooms and leaves her husband's spare towel unfolded.

Payoff payoff-passage-s5: setup setup-passage-s3 → payoff at s5

State mina-goal-s1 [s1] mina goal closing-day-purpose: known: Complete the closing duties with her customary precision.; confidence unrecorded; alternatives: (none recorded) → known: Stop the mural's removal despite Daniel's refusal to correct the inventory.; confidence unrecorded; alternatives: (none recorded)

State mina-belief-s2 [s2] mina belief patrons-shared-needs: known: Former patrons will equate protecting their memories with reopening the baths.; confidence unrecorded; alternatives: (none recorded) → known: Loyalty to the baths can coexist with needing the housing that replaces them.; confidence unrecorded; alternatives: (none recorded)

State mina-goal-s3 [s3] mina goal closing-day-purpose: known: Stop the mural's removal despite Daniel's refusal to correct the inventory.; confidence unrecorded; alternatives: (none recorded) → known: Win support for retaining the complete wall in a public passageway without blocking housing.; confidence unrecorded; alternatives: (none recorded)

State mina-goal-s4 [s4] mina goal closing-day-purpose: known: Win support for retaining the complete wall in a public passageway without blocking housing.; confidence unrecorded; alternatives: (none recorded) → known: Secure a binding preservation condition, accepting closure and responsibility for organizing despite the severance risk.; confidence unrecorded; alternatives: (none recorded)

State mina-goal-s5 [s5] mina goal closing-day-purpose: known: Secure a binding preservation condition, accepting closure and responsibility for organizing despite the severance risk.; confidence unrecorded; alternatives: (none recorded) → known: Finish her final round and leave, without treating the saved mural as a reprieve for the baths.; confidence unrecorded; alternatives: (none recorded)
