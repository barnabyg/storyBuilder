Beyond the closed doors, somebody was testing a microphone by apologising into it.

“Eight minutes,” Marta said.

Nuno started the security footage six seconds before the museum’s theft clip began.

The ship juddered on its cradle. Beside its polished hull, the tiny brass compass crept across the tilted platform. Inês appeared at the edge of the crowd, watching not the visitors but the gap beneath the ship.

“There,” Nuno said.

The compass slid. Her hand darted out and caught it immediately above the drive slot.

He stopped the picture.

“In the version you showed me, that begins with her hand closing.”

“It was prepared quickly,” Marta said.

“So was the display.”

Inês set a wooden disc beside the exposed mechanism. It matched the compass in diameter and thickness; Nuno had watched her measure both. The real compass remained in its labelled conservation tray.

With the motor isolated, she turned the hand crank. The platform tilted. Nuno released the disc where the footage showed the compass starting its slide.

It slipped into the slot.

The crank stopped.

“Now the motor would keep pulling,” Inês said.

She applied gentle pressure. With the drive jammed, its linkage pushed against the cradle instead. One support rose clear of its stop; the great ship leaned towards them. Nuno’s stomach tightened before the padded restraint caught it.

Inês let go.

For a moment, the only sound was the microphone.

“Welcome. Welcome. Sorry.”

Nuno laid Marta’s signed instruction beside the conservation log.

“‘Run for gala regardless of outstanding adjustments,’” he read. “And here: ‘Loose objects must be secured before operation.’ Inês logged the compass eleven minutes after she caught it.”

Marta looked from her signature to the ship, suspended at an angle no maritime museum should encourage.

“You could have brought it directly to me.”

“You told me to stop holding up the opening,” Inês said.

Marta smoothed the paper. Then she fetched the electrician from the doorway and watched him disconnect the motor’s supply.

“The compass was recovered by our conservator during an unsafe movement of the exhibit,” she said. “She prevented serious damage. That goes in the report.”

“And the reward?” Nuno asked.

Marta’s eyes narrowed.

“For the conservation department,” he suggested.

When the doors opened, the ship stood level, silent and magnificently stationary. Inês was beside it, accepting Marta’s introduction without offering to demonstrate anything.

Nuno gathered the first donors around him.

“This vessel,” he announced, “has survived a remarkable number of dangers without leaving Lisbon.”

Behind him, Marta took a glass of water.

Tonight, he decided, the truth would hold their attention perfectly well.