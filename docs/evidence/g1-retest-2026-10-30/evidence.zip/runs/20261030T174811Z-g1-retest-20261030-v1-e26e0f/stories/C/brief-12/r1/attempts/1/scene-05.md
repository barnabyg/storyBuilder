Ruth knocked back, twice.

When the firefighters reached the landing, she took them down herself. “Beside the electrical room. The door looks like part of the wall.”

One firefighter caught her arm before she could touch it. Heat came through the painted plywood. She stepped aside and showed him where the old frame began.

The first blow shook dust from the stair treads. At the second, someone inside cried out.

“Low on the left,” Ruth said. “She’s right behind it.”

They worked more carefully after that. Ruth stood where Elena could hear her and kept saying her name.

They brought her out on a carry sheet, one bare foot showing beneath a gray blanket. Her eyes were open. In the crowded courtyard, tenants made a narrow passage between folding chairs and shopping carts. Ruth followed until a paramedic knelt beside Elena and fitted a mask over her mouth.

Then every window above them went dark. The exhaust fan over the basement steps wound down, and the building became strangely quiet.

Elena caught Ruth’s wrist. Her grip was weak but deliberate.

“Bird?”

“Out,” Ruth said. “He’s out.”

Voss arrived through the side gate with his phone pressed to his ear. He stopped when he saw the camera pointed toward him.

“It was an accidental sealing,” he told the fire captain. “Contractors. A misunderstanding about which rooms were occupied.”

Ruth felt Elena’s fingers tighten.

Voss turned to her. “Your staff keys. Now.”

For years, that voice had sent her to leaking ceilings with a bucket before anyone called an inspector. It had kept her son’s bed in the small apartment behind the laundry room.

She took out her phone instead.

The messages were still there: Leave that door closed. Elena can discuss arrears with me. Then, after Ruth’s first question that afternoon: Don’t involve anyone else.

Below them were her own replies about patched wiring, a bypassed breaker, repairs she had never reported because Voss had promised proper work next month.

The captain gave her an address to send them to.

“All of it?” she asked.

“Send what you have.”

She selected the whole conversation.

Voss held out his hand for the keys. Ruth placed them in his palm after the file had gone.

Across the courtyard, her son stood beside a neighbor, holding their parrot in a borrowed cage. He looked toward the dark laundry-room windows.

“Can we go home?”

Ruth’s phone showed Delivered. It did not tell her what would happen next.