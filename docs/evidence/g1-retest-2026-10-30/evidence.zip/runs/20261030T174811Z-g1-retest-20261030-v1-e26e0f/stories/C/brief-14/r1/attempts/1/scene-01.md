“This,” said Nuno Vale, as the model carrack shuddered on its motorized cradle, “recreates the Portuguese experience of rounding the Cape. Courage, uncertainty, and a worrying noise from underneath.”

His tourists laughed. Nuno liked a laugh: it moved people along without making them feel moved.

The ship was the museum’s new flagship attraction, a gilded vessel large enough to accommodate several admirals and their grievances. Its deck tilted above painted waves. Underneath, through a gap in the unfinished casing, a metal drive slot snapped back and forth.

NO LOOSE OBJECTS NEAR DRIVE SLOT, warned a yellow label.

“Phones safely away, please,” Nuno said. “The Atlantic has swallowed enough expensive things.”

He steered a child’s dangling souvenir medal away from the machinery with two fingers. Once, those fingers had removed watches without troubling their owners. Now he used them to point out azulejos. Reinvention was largely a matter of finding a different use for your hands.

Director Marta intercepted him beside the navigation cases.

“Your group can look at the maps.”

“They’ve paid for stories.”

“Tell them the maps are disputed.”

Nuno dispatched twelve people toward a coastline on which nobody agreed, then followed her behind a pillar.

“The brass compass is missing,” she said.

He glanced at the empty velvet hollow in the case beside the ship. The compass had been scarcely bigger than a biscuit.

“Perhaps it’s gone exploring.”

“The donor gala begins at seven.”

“Then it should dress quickly.”

“Nuno.”

That disposed of the jokes. Marta held her phone flat between them.

“There is a thousand-euro reward for its return. Before the guests arrive. No publicity.”

On the screen, visitors crowded around the tilting carrack. A woman in a green scarf leaned across the navigation display. Her hand closed; she turned; something small and yellow vanished toward her coat pocket.

Inês.

Nuno kept his face pleasantly vacant. He had practised that expression before magistrates.

She was greyer now, but she still slipped sideways through a crowd, leaving everyone else to make room. They had once worked the number twenty-eight tram together. He had not seen her since becoming, on paper and increasingly in fact, respectable.

“Do you recognize her?” Marta asked.

Nuno watched the movement again in his mind: the reach, the closed hand, the turn.

“I might be able to find her.”

“Good. I need the compass back and a straightforward explanation.”

From behind the pillar came a metallic clack, followed by an admiring tourist’s gasp.

Nuno handed back the phone.

“Let me try talking to her first.”