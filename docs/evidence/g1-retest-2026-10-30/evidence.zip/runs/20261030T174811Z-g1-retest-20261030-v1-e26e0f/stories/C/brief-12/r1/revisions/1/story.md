The breaker snapped back before Ruth could take her thumb away.

"Again?" someone said behind her.

"Give me a minute."

She kept her voice level. Eleven years as superintendent had taught her that people could wait longer if they didn't hear you worrying.

The stairwell smelled of hot rubber and the onions someone on the third floor was frying despite the heat. Tenants sat on the steps because their apartments were worse. Mrs. Ortiz held a bag of frozen peas against her neck. Above her, two children lay with their cheeks on the cool edges of the treads.

"Who's plugged an air conditioner into the landing outlet?" Ruth asked.

Nobody answered.

Then a green bird struck the wall beside her head.

It caught itself on the open panel door, claws scraping metal. Its beak hung open.

"Elena's bird," Mrs. Ortiz said.

Ruth borrowed the dish towel from her shoulder and offered it beneath the parrot's feet.

"Come on, Captain."

He stepped onto the towel and bit her knuckle through it.

"Lovely to see you too."

A man on the second floor got up without meeting her eyes. A moment later Ruth heard an air conditioner stop. She reset the breaker. This time it held.

Her phone buzzed.

Mateo: Can I open our door? It's cooler outside.

Stay inside till I come, she typed.

He was ten, old enough to stay alone while she worked in the building, young enough to ask whether there would still be school if the streets melted.

Against her wrist, Captain said, "Open the basement door."

Mrs. Ortiz laughed. "He's got a complaint."

"Open the basement door," he said again, in a woman's strained voice.

Ruth stopped folding the towel around him.

The basement door often stuck in humid weather. Elena had been complaining about it since June. Ruth had planed the bottom twice and told Voss the frame needed replacing.

"I'll take him down," she said.

At the bottom of the stairs, three new boards crossed the door.

Ruth stood looking at them. Yesterday she had gone through that door for a box of tap washers. Beyond it were the old storage rooms and, at the far end, the room Voss called Elena's workroom.

Sawdust lay on the lowest step.

Captain leaned toward the door.

"Open the basement door."

Ruth touched a bright screw head.

"What are you doing?"

Voss stood above her with his car keys in his hand. His pale shirt was damp beneath the arms.

"Elena's bird got out."

"So give it back."

"Is she down there?"

"No."

"Where is she?"

"How would I know?"

He came down two steps. Ruth could smell his aftershave beneath the stairwell heat.

"Why's it boarded?"

"Unauthorized access. I've been telling you about people sleeping down there."

Ruth looked at him.

He had taken Elena's rent himself until February, when he began leaving the envelopes for Ruth to enter in the ledger. Cash, six hundred and fifty dollars, marked STORAGE. Elena cleaned offices at night. Sometimes Ruth saw her leaving at five in the morning with a toothbrush case sticking out of her bag.

Ruth had never asked where she slept.

"I should check," she said.

"The basement is empty."

From the electrical cupboard opposite came a low buzzing. The light overhead faded, then brightened.

"I need to check that too."

"Then check that. It's not behind the door."

She found the screwdriver in her hand without remembering taking it from her belt.

Voss looked at it.

"Touch those boards and I call the police."

"For opening a door?"

"For damaging property after being expressly told not to."

Above them, someone called Ruth's name. Water was dripping through a kitchen ceiling. Usually she would already be climbing, asking whether it was clean water, telling someone to put a pot underneath.

Voss lowered his voice.

"Your apartment comes with the job. I shouldn't have to remind you."

Their apartment was two rooms behind the laundry, with a bedroom barely wide enough for Mateo's bed. Its separate lease existed only in Ruth's unanswered requests for one.

She put away the screwdriver.

"I'll get the bird a drink."

"Good," Voss said. "Look after your boy."

Mrs. Ortiz found an old travel cage. Ruth put Captain inside with a saucer of water, then climbed to her apartment.

Mateo was doing a puzzle at the kitchen table in his underwear. He had sorted all the blue pieces into a cereal bowl.

"Did you fix the lights?"

"For now."

"Can we go to the pool?"

It had closed at noon because there weren't enough lifeguards. She had not told him yet.

"Maybe we can go to Mrs. Chen's. Her fan's better."

He looked at the cage. "Are we keeping him?"

"No."

Ruth stood him at the sink to wash his hands, although they were clean. She needed him occupied while she searched her phone.

Three weeks earlier, Voss had sent: Elena's door needs exterior hasp. Tenants getting into storage. Install before Friday.

Ruth had installed it. Elena had been at work. When Ruth asked who would have the key, Voss said he would handle it.

Below the message was her own reply: Done.

She remembered the room's flowered curtain, visible through the half-open inner door. A pair of slippers beneath a chair. She had looked at the hasp instead.

"Come on," she told Mateo.

Mrs. Chen took him without asking why. Ruth said she would be back soon, then went downstairs.

Beside the basement entrance, a ventilation grille sat low in the wall. Its bottom screw had stripped years ago. Ruth had meant to replace it and instead kept bending the corner back whenever someone caught a shopping bag on it.

She knelt and removed the other screw.

Heat breathed into her face.

"Elena?"

Nothing.

She put her mouth nearer the opening.

"It's Ruth."

A scrape came from inside.

"Is he there?"

Ruth lowered herself onto one elbow. The short duct opened into the storage corridor, but she could see only a strip of concrete.

"Voss? No."

"Don't tell him."

"Are you hurt?"

"I'm dizzy."

"Can you come closer?"

"I'm here."

The voice was so near that Ruth reached into the opening before realizing there was another grille at the far end.

"Did he lock you in?"

"He said he wanted to talk about the increase. I told him I'd already called the city. Then he went out. I heard the drill."

"When?"

"This morning."

Ruth looked at her watch. Nearly five.

"I thought he was frightening me. Then I thought you'd come for something."

The buzzing across the landing grew louder and stopped. In the silence Ruth heard Elena breathing.

"The fan's off again," Elena said. "There's no air."

Captain had probably slipped past Voss that morning. Elena had spent the day calling into a door while the bird repeated her from somewhere on the stairs.

"I've found him," Ruth said. "Captain. He's all right."

"Please open it."

"I will."

Ruth tried the nearest board with both hands. It did not move. She could remove the screws, but the outside hasp would still be locked beneath them.

She called emergency services.

"A woman's trapped in our basement. The exit's screwed shut. She's been there since this morning, and she's dizzy. We're losing power."

As she gave the address, the stairwell light went amber.

The dispatcher told her to stay out of the basement and keep the exit clear.

"The owner put the boards up," Ruth said.

There was a brief pause, then another question. Ruth answered it.

"Yes. He knew she was there."

She could not know what Voss had seen before he shut the door. But he had refused to let her look. She gave the dispatcher his name.

When she stood, he was at the top of the basement steps.

"Who was that?"

"The fire department."

He stared at her, then glanced toward the entrance as if calculating how long he had.

"You should have called me."

"You were here."

"I would have opened it."

"Then open it now."

For a moment neither moved.

Voss took out his phone.

"She's not a tenant," he said. "You know that. She's been using storage without permission."

"I entered her rent."

"You entered what I gave you."

Upstairs, a door opened. Mrs. Ortiz leaned over the railing.

"Everything all right?"

Ruth almost said yes. The word came readily; she had used it during leaks, arguments, the winter the boiler failed. It meant she was handling things. It meant there was no need to call anyone else.

"Elena's locked in the basement," she said instead. "Please keep Mateo with Mrs. Chen. The fire department's coming."

Voss took a step toward her.

"Be careful what you say."

Mrs. Ortiz did not move.

"I heard her," Ruth said, louder now. "Come down and listen."

Another door opened.

Voss's face changed as Mr. Ahmed appeared with his phone in his hand.

"This is a maintenance issue," Voss told him. "Give us room."

"Give her the key," Ruth said.

Voss looked from one phone to the other. Then he reached into his pocket and tossed Ruth a ring.

The keys landed on the step between them.

She picked them up.

"Which one?"

"The small brass."

Behind the boards, Elena knocked.

Ruth crouched. Her driver bit into the first screw, slipped, caught again. Sweat ran into her eyes. She had bought the cheap screws in a hurry that morning six months ago when a cupboard hinge broke; now she hated their soft heads, the way the cross rounded under pressure.

"You're damaging the frame," Voss said.

Mrs. Ortiz came down beside him.

"Stand back," she told him.

Ruth removed two boards. The third had been driven through the door itself. Before she could loosen it, the driver stalled in her hand.

Not the tool. The building.

The stairwell lights went out. Upstairs, someone cried out, followed by the abrupt silence of every fan.

In the dark, Ruth heard Elena say her name.

"I'm here."

Mr. Ahmed switched on his phone's light. Ruth fitted the bit again.

The last board fell against her shin.

She unlocked the hasp she had installed and pulled.

The swollen door held.

Ruth braced a foot against the frame. It opened an inch, releasing air that smelled of damp bedding and overheated wire.

A firefighter's voice called from above.

"Down here," Mrs. Ortiz shouted.

They moved Ruth aside. She showed them the narrow gap, told them where Elena was. One firefighter leaned into the door with a tool while another called through it.

Ruth stood pressed against the wall. Her hands had begun to shake now that nobody needed them.

They brought Elena out seated between two firefighters, her arms over their shoulders. She wore a blue nightdress and one plastic sandal. Ruth had seen that nightdress hanging behind the flowered curtain.

In the courtyard, neighbors moved their chairs to make room for the stretcher. Someone brought water and was told to wait. Mateo stood beside Mrs. Chen, holding Captain's cage with both hands.

Elena lifted her head at the bird's whistle.

"He's here," Ruth said.

Elena reached toward the cage, then let her hand fall. A paramedic put an oxygen mask over her face.

Voss came through the side gate speaking into his phone.

"An occupied storage space," he was saying. "Apparently my superintendent wasn't aware she needed access."

Ruth opened the message thread.

There were the orders for the hasp. Complaints she had forwarded about heat and blocked drains. Voss's answers: Handle quietly. Don't put that in the group. Inspector doesn't need to come for a loose wire.

And her own assurances beneath them.

She selected the conversation and sent it to Mrs. Ortiz and Mr. Ahmed. Then she sent the rent ledger photograph she kept for balancing the cash.

Voss lowered his phone.

"You need to think about what you're doing."

"I am."

A fire lieutenant asked who had keys to the basement. Ruth held up the ring.

"And you're the superintendent?"

"Yes."

"I'll need your name."

She gave it. When he asked about the sealed door, she told him about the hasp, the boards, the voice through the vent. She did not leave out what she had installed.

Voss waited until the lieutenant turned away.

"Staff keys," he said, holding out his hand. "We'll discuss your employment tomorrow."

Mateo had come closer. He looked at Voss's hand, then at Ruth.

She separated her apartment key from the ring. Voss watched her do it but said nothing.

"Can we go home?" Mateo asked.

Ruth looked at the dark windows above the laundry. Their towels were still hanging there. Inside, the puzzle covered the kitchen table.

"In a little while."

Her phone vibrated. Mrs. Ortiz had replied to the messages.

I have them.

Across the courtyard, Voss was making another call. Ruth put the apartment key deep in her pocket and stayed beside her son while the paramedics wheeled Elena through the gate.
