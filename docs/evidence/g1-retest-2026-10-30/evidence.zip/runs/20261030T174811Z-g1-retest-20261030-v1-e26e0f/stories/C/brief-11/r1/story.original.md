Mina folded the towels in thirds, then in half, keeping the worn borders inside. Since her husband's death she had come in forty minutes early to do this. At home there were too few things to put in order; here, even on the last morning, a trolley waited.

She made twelve stacks of eight. Mr. Bell would want two towels, though he always returned one dry. The sisters who came on Fridays would search the piles for the oldest, softest ones. Mina had left those on top before remembering that neither sister had visited since the closing notice.

She wheeled the trolley into the entrance hall.

A yellow auction label covered the first three letters of ADEYEMI.

Mina stopped. The label had been stuck directly to the blue glaze, beneath the tiled date, 1926. She lifted one corner with her thumbnail. A small gummy thread stretched between paper and wall.

On the inventory pinned beside reception she found it halfway down the second page: LOT 47. DECORATIVE CERAMIC PANEL. BUYER TO ARRANGE REMOVAL.

The names ran through the branches of a tile-painted tree: shopkeepers, a church sewing circle, three men identified only as "dock labourers." Some had paid for individual baths; others had contributed pennies toward the building. Mina knew where the cracked tiles were, where a repair had given one woman a differently coloured surname.

Daniel arrived carrying coffee and a folder.

"This needs correcting," she said, pointing.

He set the coffee on the reception counter, on top of her list of locker keys.

"The auction company assessed it."

"It isn't a panel. It's the wall."

"They have specialists."

"The names go round the corner."

Daniel looked round the corner, as though she might have been mistaken.

"I can't reopen the inventory this morning, Mina."

She took a pen from her pocket. "Then strike it out and initial it."

"No."

For a moment she heard only the pipes knocking behind reception.

"The housing trust needs the building cleared," he said. "They've already waited. We have obligations."

"I've worked here twenty-seven years."

"I know. And your severance reflects that." He lowered his voice. "It also depends on completing the handover. Please don't abandon your closing duties over this."

Her pen had left a dot beside lot 47. She capped it carefully.

After Daniel went upstairs, Mina moved his coffee off the key list. Then she opened the reception drawer and took out the old telephone book in which she kept the regulars' numbers.

The numbers had outlasted several of the people beside them. Mina turned past her own small crosses in the margins and dialed Ruth.

Daniel had warned her not to use the desk telephone to organize opposition. Until she signed the closing documents, she was still an employee; her severance depended on completing her duties. She kept the receiver low, though there was nobody in reception to overhear.

"They've put the mural on the auction list," she said.

"The whole wall?"

"It says removable. Have you still got your photographs?"

"I've got the one of my father."

"Bring it, please. Anything showing the names."

She called six more numbers. One had been disconnected. Mr. Bell wanted to know whether he could collect the sandals he had left in locker nineteen. A woman Mina remembered by her habit of folding her towel lengthwise said she would come if someone could bring her back before her carer arrived.

Before Ruth arrived, Mina ruled a sheet of paper with a pencil and wrote across the top: We request that the closure be suspended and the baths reopened. Beneath it she left space for names.

Ruth came carrying a photograph between two pieces of cereal-box cardboard. She wore her good raincoat, the one she used to hang inside out so the lining could dry while she bathed.

In the picture, a younger man stood beside the mural with his palm resting under a blue tile. JOSEPH MENSAH, it read. His trouser cuffs were wide; he looked faintly embarrassed by the attention.

"He gave two weeks' wages," Ruth said. "My mother mentioned it whenever we needed shoes."

Mina placed the petition beside the photograph and offered her pen.

Ruth read the heading twice.

"No," she said.

"We need names before the meeting."

"Not under that."

Mina kept the pen extended for another moment, then laid it down.

"My daughter's applied for one of those flats," Ruth said. "She and the boys are in her sister's front room. Every morning they put the mattresses away before anyone can have breakfast."

"You never said."

"You always had my towel ready."

From upstairs came the scrape of furniture being moved. Mina looked at the photograph again. She had known Ruth's preferred hook, the temperature she complained about, which knee made the steps difficult.

"I want his name kept," Ruth said. "I don't want them selling it to somebody for a kitchen. But I won't sign away her chance."

Mina drew the petition back. On a clean sheet she wrote Ruth's name, then stopped.

"What would you be willing to ask for?" she said.

Ruth looked past her, towards the entrance. "Ask Leah what can stay without costing anyone a flat."

The architect had been waiting beside the towel counter with a roll of drawings under her arm. Mina had left her there while she finished the telephone calls. Now she lifted the counter flap.

"Come and see what they've put in the sale."

At the mural, Leah read the auction label, then stepped back to take in the blue trees, the yellow sun above the painted pool.

"Not just that," Mina said.

She put one finger beside the narrow green border. The name ADELAIDE PRICE began inside it and ended three tiles beyond, on what looked from a distance like ordinary cream wall. Below it, the smaller letters of AND HER SISTERS crossed a repaired seam.

"They paid by the letter, some of them. The man doing it ran out of room."

Leah bent to look. Mina showed her another name turning the corner, its final letters tucked beneath the window ledge.

"The photograph in the catalogue stops here." Mina traced the border without touching it. "If they cut out the picture, they cut through the names."

Leah set down her drawings.

"I hadn't seen these."

Mina nearly said that no one had asked her. Instead she fetched the folding table from the laundry and wiped it before Leah spread out the plan.

The new building lay over the old one in thin grey lines. Where Mina expected the warm room, there were bicycle stores.

"This wall isn't carrying the roof," Leah said. "We'd still need an engineer to check how it could be supported during demolition."

Mina pointed to the strip beside it. "That was the delivery entrance. Straight through to Bell Lane."

Leah followed it on the drawing. She measured, rubbed something out, then drew two parallel lines around the retained wall.

"A public passage, possibly. Keep the whole return here. Move the cycle-store door." She paused. "I can't promise this today."

Behind them Ruth was calling people back.

"No, not a petition to reopen. The wall, all the names. Somewhere anyone can walk in and see them."

Mina heard her ask permission to write down each name. She had not thought to do that herself.

"Public," Mina said. "Not somewhere you need a resident's key."

Leah wrote the word beside the new lines.

"Opening hours, maintenance, access—that would all need agreeing."

At the edge of the table, Mina smoothed a curl in the paper. Her wedding ring tapped the proposed passageway.

"Put those on the drawing too," she said.

At three, Mina laid the signed request before the board secretary. The sheets had curled in the damp office; she had flattened them beneath the first-aid box. Now one corner lifted again.

"Twenty-three signatures," she said. "For keeping the whole wall where it stands, with public access through the new building."

Daniel turned the first page without reading it.

"You approached these people as an employee?"

"I've known some of them thirty years."

"That isn't what I asked."

Behind her, Ruth shifted a chair. Mina kept her hands on the table, where everyone could see them.

"Yes."

"During your working hours?"

"Yes. I telephoned them from the office. I asked Ruth to bring the sheets round."

"The board relied on you to manage an orderly closure. Your severance agreement includes cooperation with that process."

She had read the agreement at her kitchen table, leaving the other place clear although there was no longer anyone to sit there. She knew the sum to the penny.

"I understand," she said. "Ruth didn't organize it. I did."

Daniel pushed the papers toward the secretary. "Then we should be careful about presenting this as an independent expression of public opinion."

"They signed what's written there," Mina said. "They didn't sign away their opinions because I asked them."

Leah unrolled the drawing before Daniel could answer. She weighted one end with her phone.

"The passage follows the existing entrance bay. We can retain the wall and brace it during demolition without retaining the wet rooms." She indicated a narrow band beside the proposed courtyard. "There's an allowance for unforeseen entrance and access works. We can use part of that contingency for the passageway. It will reduce what's available elsewhere, but it doesn't remove any homes."

"How firm is that estimate?" a board member asked.

"Preliminary. The structural survey is still required."

Mina looked at the drawn doorway. Leah had added opening hours beside it, and a note requiring the names to remain visible.

"I'm not asking you to approve a drawing and hope," Mina said. "Please make it a condition of the transfer. The complete mural stays in place. The passage is public, without a purchase or an appointment. Someone has to be responsible for maintaining it."

"And the baths?" Daniel asked.

"The baths close tonight."

Saying it before them was different from knowing it alone.

"I'll finish the closure," she said. "This request doesn't ask you to keep them open."

The chair drew the papers closer and asked the secretary to bring up the draft transfer terms.

The secretary read the added paragraph aloud. The complete mural, including its border and every donor's name, would remain in place within the new passageway. Access from the street would be free, with daily opening hours fixed in the agreement. The preservation condition would bind any future owner.

"Not just the centre panel," Mina said.

"The complete mural," the secretary repeated, and turned the screen so she could see.

Leah laid her drawing beside the agreement. On the plan, the passage ran where people had once queued for towels. Beyond it were the stairs to the flats.

Daniel read both pages before signing. Then he took the auction inventory and drew a line through the mural's entry, initialling the margin. He passed it to the secretary to replace the posted copy.

Mina watched the ink dry. She had expected to feel something larger.

"You'll have copies," the secretary told her.

"Yes. Thank you."

The chair moved to the next item. There were costs still to approve, a survey to commission. Mina gathered her bag without interrupting.

By the time she returned, the bathhouse had been closed for forty minutes. The notice on the outer door gave no date for reopening. Inside, the afternoon light reached across the entrance floor, showing the places her mop had missed along the skirting.

She began at the changing rooms.

Every locker stood open. She checked them anyway, passing her hand along the upper shelves where spectacles and wedding rings had sometimes been left. In the smallest cubicle she found a hairpin. She put it in the lost-property tin, then stood holding the lid. At last she closed it.

The pools were drained. Without water, the deep end seemed less deep, its sloping floor exposed beneath the lights. She checked the taps, the windows, the service-room latch. There was no reason to hurry and no reason to take longer.

In the linen cupboard lay her husband's spare towel, kept behind the clean stack through the months of his illness and the months after. He had disliked the bathhouse towels, their stiff narrow hems.

She took it out. One corner had folded under itself. Her hands began the familiar work of bringing the edges together, then stopped.

She left it unfolded on the changing-room bench.

At the mural she paused long enough to read three names she knew and one she did not. Soon people would pass here carrying shopping, pushing prams, looking for an address. They would not need her to hand them anything.

Mina switched off the entrance lights and went outside to lock the door.
