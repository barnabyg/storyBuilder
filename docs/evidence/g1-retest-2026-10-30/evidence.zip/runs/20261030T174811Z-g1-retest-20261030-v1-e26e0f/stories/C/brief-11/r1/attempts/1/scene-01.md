Mina folded the towels in thirds, then in half, keeping the worn borders inside. Since her husband’s death she had come in forty minutes early to do this. At home there were too few things to put in order; here, even on the last morning, a trolley waited.

She made twelve stacks of eight. Mr. Bell would want two towels, though he always returned one dry. The sisters who came on Fridays would search the piles for the oldest, softest ones. Mina had left those on top before remembering that neither sister had visited since the closing notice.

She wheeled the trolley into the entrance hall.

A yellow auction label covered the first three letters of ADEYEMI.

Mina stopped. The label had been stuck directly to the blue glaze, beneath the tiled date, 1926. She lifted one corner with her thumbnail. A small gummy thread stretched between paper and wall.

On the inventory pinned beside reception she found it halfway down the second page: LOT 47. DECORATIVE CERAMIC PANEL. BUYER TO ARRANGE REMOVAL.

The names ran through the branches of a tile-painted tree: shopkeepers, a church sewing circle, three men identified only as “dock labourers.” Some had paid for individual baths; others had contributed pennies toward the building. Mina knew where the cracked tiles were, where a repair had given one woman a differently coloured surname.

Daniel arrived carrying coffee and a folder.

“This needs correcting,” she said, pointing.

He set the coffee on the reception counter, on top of her list of locker keys.

“The auction company assessed it.”

“It isn’t a panel. It’s the wall.”

“They have specialists.”

“The names go round the corner.”

Daniel looked round the corner, as though she might have been mistaken.

“I can’t reopen the inventory this morning, Mina.”

She took a pen from her pocket. “Then strike it out and initial it.”

“No.”

For a moment she heard only the pipes knocking behind reception.

“The housing trust needs the building cleared,” he said. “They’ve already waited. We have obligations.”

“I’ve worked here twenty-seven years.”

“I know. And your severance reflects that.” He lowered his voice. “It also depends on completing the handover. Please don’t abandon your closing duties over this.”

Her pen had left a dot beside lot 47. She capped it carefully.

After Daniel went upstairs, Mina moved his coffee off the key list. Then she opened the reception drawer and took out the old telephone book in which she kept the regulars’ numbers.