On the way to the conservation workshop, Nuno discovered that anxiety had done nothing good for his retirement.

“Yours, I believe,” he told a German visitor, returning a wallet he had mistaken for his own.

At the next doorway, he returned another.

The third belonged to a woman from his tour, who looked at him sharply.

“You dropped it,” he said.

“No, I didn’t.”

“Then we’ve caught it exceptionally early.”

He put both hands in his jacket pockets and kept them there until he reached the workshop.

Inês stood at a workbench beneath a white inspection lamp, wearing safety glasses and tightening a bracket in a vice. Her museum badge read DISPLAY INSTALLER. Beside it hung a pencil on string.

“You’ve gone respectable,” Nuno said.

“So have you. Apparently they pay you to talk now.”

“An oversight I’m trying not to draw attention to.”

She finished tightening the bracket before looking at him. He remembered that economy of movement. Once, it had made her formidable on the number twenty-eight tram. Here it seemed chiefly to annoy a stubborn screw.

“You could have told me you worked here.”

“You could have visited without a theft.”

“I’m broadening my range.”

She set down her screwdriver.

“The compass,” he said. “I’ve seen the video.”

“Which version?”

He took his hands out of his pockets.

Inês led him to a shallow conservation tray. The tiny brass compass lay on acid-free tissue beside a numbered label. She turned the register towards him.

“Time received. Condition. Location. My signature. Conservation assistant’s countersignature.”

Nuno read it twice. “That is an unusually thorough way to steal something.”

“It’s an entirely ordinary way to do my job.”

He glanced towards the door. “Let me take it back. Quietly. Marta gets her happy ending.”

“Marta gets a reason to restart the platform.”

A telephone rang on the bench. Inês pressed the speaker button with the end of her pencil.

“Is Vale there?” Marta asked. “Security said he was heading down.”

“He’s here.”

“Good. Bring up the compass. The gala rehearsal starts in twenty minutes. I want the ship turning.”

“The platform isn’t safe,” Inês said.

“We have already discussed this.”

“You’ve spoken. That’s different.”

Nuno looked at the bracket in the vice, then at the compass.

“I saw your signed instruction, Marta.”

“Then you know what’s required.”

The line clicked dead.

Inês closed the tray’s transparent cover.

“You may tell her exactly where it is,” she said. “But it stays logged here until that platform is safe.”

For once, Nuno could think of nothing reassuring to say.