Leena found the first flower while clearing a blocked dripper. It hung beneath a leaf, white and small enough to mistake for a scrap of root sleeve.

She set down the probe.

The beans were nineteen days old. They should have been making leaves for another three weeks.

She photographed the blossom beside a ruler, then widened the frame to include the tray number. Six more flowers showed along the rack. One had opened against a warm pipe, creasing its petals.

Outside the greenhouse window lay a wheel track, a cable, and gray ground that had never supported anything. Inside, nutrient solution clicked through the valve she had repaired.

Leena checked the sowing record, then the light schedule. Both were correct.

Six days earlier, a minor radiation storm had sent the three of them into the shelter for lunch. Pavel had complained about eating beside the toilet. The greenhouse dosimeters had stayed below the intervention threshold, although the rack nearest the outer wall had received almost twice the dose measured farther in.

Most of the flowers were near that wall.

Most, not all.

Commander Imani appeared in the hatch while Leena was marking their positions.

“What’s wrong?”

“Early flowering. Twenty-three days early.”

Imani looked along the rack, then toward the insulated seed cabinet beyond the inner hatch.

“A radiation response?”

“Possibly.”

“Can it spread?”

“A flowering response isn’t contagious.”

“Unless that isn’t what we’re looking at.”

Leena took her hand off the screen.

The cabinet held their reserve seed in sealed packets. Nothing was about to leap through its seals. But seeds had to come out eventually, into this room, through these hands and tools. A root-borne infection could persist in the water system. A mistaken harvest could enter the seed inventory.

“I don’t know the cause yet,” she said.

Imani checked the shift clock. “Isolate those trays. At shift change, the affected crop goes through the sterilizer unless you can give me a containment plan.”

“That’s forty-eight plants.”

“I can count them.”

“The lander isn’t due for forty-one days.”

“I can count those too.”

Leena looked back at the flowers. On Earth, a department head had once introduced her as the scientist who could always find a reason not to proceed. Here, with a genuine anomaly in front of her, caution meant destroying it before she understood it.

“Give me time to establish whether they’re dangerous.”

“You have five hours. Not to establish that they’re safe. To show me how we can afford not knowing.”

After Imani left, Leena fitted a fine pollination bag over each flower. Beans mostly fertilized themselves, but mostly was not a containment standard.

Then she called Pavel.

He arrived carrying a valve kit and half a piece of toast.

“All four trays?” he asked.

“They share a return.”

“The portable reservoir takes eleven liters out of reserve.”

“We can recover it after treatment.”

He tucked the toast into his chest pocket and knelt. “Hold this.”

She held a capped hose while he disconnected the return. A bead of nutrient solution swelled at the coupling; he caught it with a cloth and sealed the cloth in a waste bag.

When the independent pump started, the leaves shivered.

Pavel opened the maintenance log. “Cause?”

“Undetermined.”

He entered it without asking her to make the answer better.

Leena sampled flowering plants and apparently normal neighbors. The roots were pale, without lesions. Nutrient concentrations were ordinary. No heat excursion showed in the logs; the light timer had not reset during the storm.

Her first rapid assay showed strong activity in a flowering regulator and an elevated stress marker.

She laid the result beside the dose map.

Injury could make a plant reproduce early. That might save a generation. It might also produce three empty pods on a plant expected to feed them for weeks. The assay did not distinguish a useful response from a last effort.

Still, she looked longest at the strong signal.

Imani requested an update.

Leena wrote: Affected trays isolated. Distribution and initial assay consistent with radiation-induced reproductive acceleration.

She read it twice. Consistent with was accurate.

She sent the message without the raw files. The repeat would take thirty minutes. She wanted to resolve any differences before inviting discussion.

On Earth, she had delayed a field release because the controls were behaving strangely. A colleague had put her caveats on a slide. Leena would like another season, he had said, and the room had laughed. Later, the controls had proved her right, but by then she had learned to arrive with results nobody could pull apart.

The repeat did not support the first.

The flowering signal was weak. The stress marker was near baseline.

She checked the extraction control, sample labels, reagent lot. All passed.

Different leaves could give different results. A transient response could already be fading. None of that made the first interpretation stronger.

She was reopening her message when Pavel returned.

“I need your worst-case yield.”

“Zero.”

He set his tablet beside the samples. He had removed the entire rack from the food plan. Eleven days before the lander arrived, their stores fell below the reserve floor.

“If we cut portions tonight, we stay above it,” he said.

“Replanting won’t close the gap.”

“I know.”

“They may still set pods.”

“Can I budget for them?”

“No.”

He changed a figure. The daily ration shrank.

Leena watched him save it. “You could wait until we know more.”

“Then we’d have to cut more later.”

Imani entered with six sealed sampling tubes.

“That leaves two for a water-quality incident,” she said, putting them down. Her eyes moved to the assay display. “Is that the result you reported?”

“The repeat.”

“Why is it different?”

“I don’t know yet.”

Imani read the message on her wrist screen.

“The first result was consistent with—”

“I read what you wrote.”

Leena stopped.

Pavel’s food plan remained open between them. Imani had spent part of their margin collecting supplies for a test Leena had made sound more conclusive than it was.

“I wanted to resolve the discrepancy first,” she said.

“And while you did that?”

Leena looked at the two assay curves.

“I should have sent both.”

“Yes.”

The portable pump hummed behind them.

Leena opened the crew channel. She uploaded both results, the calibration files, the dose map, and the observations that did not fit it. Then she added: My earlier interpretation was premature. Cause, yield, and heritability remain unknown.

She nearly followed it with an explanation. Instead, she sent it.

Imani checked the upload.

“What can we decide before shift change?” she asked.

Leena took a clean sheet from under the sampling tubes.

“Whether we can keep four plants without making the rest of the greenhouse part of the experiment.”

They met in the galley, where Pavel could spread out the station drawings.

There were ninety minutes left.

Leena proposed two flowering plants and two matched controls from the inner rack. Separate vessels, identical conditions. No beans eaten. No seeds returned to storage. The rest of the affected crop would be sterilized.

“The spare root-study chamber,” she said.

Pavel tapped its drain on the drawing. “That valve seeps.”

“Can you replace it?”

“Not today.”

She began to explain that the leak rate was very low. Pavel waited.

“What would make it independent?” she asked instead.

“Cap the drain. Individual waste bottles. Put each vessel in a secondary tray.”

“And the air?”

“Filtered exhaust to the utility treatment line. Nothing back into the greenhouse.”

Imani leaned over the drawing. “Sampling?”

“Under the transfer hood. Two people present.”

“That hood is beside the seed cabinet.”

Leena stared at the neat rectangle she had drawn around the chamber. She had accounted for the plants at rest and forgotten every time a person would have to touch them.

Pavel pulled up the utility alcove.

“We can move the hood here.”

“That’s your repair bench,” Leena said.

“Yes.”

He began listing what would have to come off it.

They worked through power, temperature, waste capacity, and the steps for a spill. Leena entered measurements for flower number, leaf damage, pod set, seed development. The first assays would be repeated with matched leaf ages; they would check the shared nutrient water for signs of infection, while acknowledging that a negative screen could not exclude every cause.

“And if they look healthy?” Imani asked.

“No release. Growing offspring requires another decision.”

“Whose?”

“All three of us.”

Imani made her put that in writing.

A failed seal or loss of filtration would stop the test. Contamination outside a vessel would trigger destruction of the retained plants and treatment of the alcove. Any crew member could call the stop. Opening a vessel required two people and a logged reason.

Pavel studied the work list.

“This takes the rest of my maintenance block. The exercise bike stays broken.”

Leena glanced at the ration figures pinned in the corner of his screen.

“I’m sorry.”

“You can help me move the bench.”

Imani signed the plan. “Post the reduced portions now. These plants don’t go back into the food budget.”

They had fifty-two minutes.

Pavel wheeled the hood into the alcove while Imani emptied the repair bench. Leena cleaned vessels and laid out labels. They spoke almost entirely in numbers: filter ratings, bottle capacities, temperature limits, minutes remaining.

At the rack, Leena reached toward the largest flowering plant. It had thick leaves and three blooms.

She stopped, checked the selection method they had written, and took the plants from the two predetermined positions instead. One had a single flower. The other had two.

Their wet root sleeves resisted the trays. She eased them free without trimming, then transferred them under the hood. Pavel read each label aloud; Imani checked it against the map.

Before the final transfer, the pressure test on one empty vessel failed.

Leena looked at the clock.

“We could—”

Pavel was already loosening the lid.

She closed her mouth and held the vessel while he changed the gasket.

The second test held. They transferred the last control, sealed the hood, checked the waste bottles, and stood together while Pavel verified the exhaust flow.

Four minutes remained.

Imani signed the containment record. Then she authorized sterilization of the remaining crop.

Leena loaded the plants herself.

There were buds beneath leaves she had not examined, small pale knots at the joints. She could no longer tell whether she was seeing more because there were more, or because she knew to look. She recorded their presence before putting each tray into the sterilizer.

A flower caught on her glove and came free.

For a moment she held it. Then she placed it with the rest.

The lid locked.

Forty-six affected plants destroyed. Two retained. Two controls removed from the inner rack. Forty-eight empty positions to clean and sow again, and two more farther in.

Pavel had already brought out the replacement seed, still sealed. Imani checked the packet numbers against the inventory before he set them on the clean side of the bench.

Leena watched that small, ordinary precaution with new attention.

Later, in the galley, Pavel was rewriting the meal portions in larger figures so no one would read the old amounts beneath them.

“Will the beans help?” he asked.

“Not this food schedule.”

“I meant eventually.”

She considered the two flowering plants in their separate vessels. Earlier reproduction might mean less water, shorter lighting cycles, another harvest between supply flights. It might mean weak seed and poor yields. The storm might have had nothing to do with it.

“I don’t know.”

He handed her the marker.

“Check my arithmetic.”

Before sleep shift, all three inspected the alcove. Imani checked the seals against the signed diagram. Pavel measured the waste levels. Leena entered the first observations in the shared log.

The single flower had partly closed after transfer. Handling stress was one explanation. She entered the observation and left the cause blank.

They scheduled measurements for days three, seven, fourteen, and twenty-one. A second decision would be needed before any seed could germinate. Pavel added a reminder to inspect the temporary exhaust connection every shift.

Inside the vessel, the plant stood under its lamp, roots suspended in clear nutrient solution. There was room above it for pods, if it made them.

Leena saved the schedule. Imani confirmed the first watch. Then they turned down the alcove lights and left the four vessels running behind the closed door.