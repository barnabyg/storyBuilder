"This," said Nuno Vale, as the model carrack shuddered on its motorized cradle, "recreates the Portuguese experience of rounding the Cape. Courage, uncertainty, and a worrying noise from underneath."

His tourists laughed. Nuno liked a laugh: it moved people along without making them feel moved.

The ship was the museum's new flagship attraction, a gilded vessel large enough to accommodate several admirals and their grievances. Its deck tilted above painted waves. Underneath, through a gap in the unfinished casing, a metal drive slot snapped back and forth.

NO LOOSE OBJECTS NEAR DRIVE SLOT, warned a yellow label.

"Phones safely away, please," Nuno said. "The Atlantic has swallowed enough expensive things."

He steered a child's dangling souvenir medal away from the machinery with two fingers. Once, those fingers had removed watches without troubling their owners. Now he used them to point out azulejos. Reinvention was largely a matter of finding a different use for your hands.

Director Marta intercepted him beside the navigation cases.

"Your group can look at the maps."

"They've paid for stories."

"Tell them the maps are disputed."

Nuno dispatched twelve people toward a coastline on which nobody agreed, then followed her behind a pillar.

"The brass compass is missing," she said.

He glanced at the empty velvet hollow in the case beside the ship. The compass had been scarcely bigger than a biscuit.

"Perhaps it's gone exploring."

"The donor gala begins at seven."

"Then it should dress quickly."

"Nuno."

That disposed of the jokes. Marta held her phone flat between them.

"There is a thousand-euro reward for its return. Before the guests arrive. No publicity."

On the screen, visitors crowded around the tilting carrack. A woman in a green scarf leaned across the navigation display. Her hand closed; she turned; something small and yellow vanished toward her coat pocket.

Inês.

Nuno kept his face pleasantly vacant. He had practised that expression before magistrates.

She was greyer now, but she still slipped sideways through a crowd, leaving everyone else to make room. They had once worked the number twenty-eight tram together. He had not seen her since becoming, on paper and increasingly in fact, respectable.

"Do you recognize her?" Marta asked.

Nuno watched the movement again in his mind: the reach, the closed hand, the turn.

"I might be able to find her."

"Good. I need the compass back and a straightforward explanation."

From behind the pillar came a metallic clack, followed by an admiring tourist's gasp.

Nuno handed back the phone.

"Let me try talking to her first."

Marta did not agree. She arranged the papers on her desk into a rectangle, which Nuno recognised as the administrative equivalent of folding one's arms.

He bent over the gala brochure instead.

In its photograph, the museum's great model ship sailed above a delighted school party. Beneath the hull, the machinery had been cropped out, leaving the vessel apparently sustained by Portuguese achievement. At the edge of the picture, something small and golden caught the light.

"May I?"

He picked up the magnifier beside Marta's letter opener.

"Our visitors generally admire the ship," she said.

"I've always supported the smaller attractions."

The compass lay on the narrow ledge beside the drive slot. Not in its little velvet hollow, not behind glass: beside the opening through which the display's mechanism travelled. The warning Nuno had made a joke about on his tour—KEEP LOOSE OBJECTS CLEAR—was visible just below it.

"When was this taken?"

"This morning. Before we opened."

"An excellent likeness of a loose object."

Marta reached for the brochure. A sheet came with it, caught beneath the glossy cover, and slid across the desk.

Nuno steadied it with two fingers. Once, those fingers had extracted wallets on moving trams. Now they prevented office accidents. Reinvention deserved more applause.

The sheet was a workshop checklist. Several boxes remained empty. One line read: Drive-slot guard awaiting fitting. Below it, in blue ink: Run display for press and gala preparation. Guard to follow.

Marta's signature occupied more space than the instruction.

"The contractors are behind," she said, taking the sheet. "We cannot postpone the entire museum whenever someone lacks a screw."

"Certainly not. Lisbon would close."

She put the checklist in a drawer.

Nuno glanced back at the security monitor. Inês leaned into frame, her hand descending; then the clip stopped with her face turned towards the camera.

"Could I see the full recording? A minute before this. A minute after."

"You've seen her take it."

"I've seen her hand move. Hands have a surprisingly broad repertoire."

"I need a culprit, Senhor Vale, not a seminar."

Outside, someone tested a microphone. A tremendous, apologetic cough filled the corridor.

"The donors arrive at seven," Marta continued. "Bring me the compass before then, and the reward is yours. Otherwise I circulate that image to every newspaper and police contact I have."

Nuno set down the magnifier.

"A face is difficult to uncirculate."

"Then you'd better speak to her quickly."

He smiled his professional smile: warm, reassuring, and giving absolutely nothing away.

"Now that," he said, "is something I can do."

On the way to the conservation workshop, Nuno discovered that anxiety had done nothing good for his retirement.

"Yours, I believe," he told a German visitor, returning a wallet he had mistaken for his own.

At the next doorway, he returned another.

The third belonged to a woman from his tour, who looked at him sharply.

"You dropped it," he said.

"No, I didn't."

"Then we've caught it exceptionally early."

He put both hands in his jacket pockets and kept them there until he reached the workshop.

Inês stood at a workbench beneath a white inspection lamp, wearing safety glasses and tightening a bracket in a vice. Her museum badge read DISPLAY INSTALLER. Beside it hung a pencil on string.

"You've gone respectable," Nuno said.

"So have you. Apparently they pay you to talk now."

"An oversight I'm trying not to draw attention to."

She finished tightening the bracket before looking at him. He remembered that economy of movement. Once, it had made her formidable on the number twenty-eight tram. Here it seemed chiefly to annoy a stubborn screw.

"You could have told me you worked here."

"You could have visited without a theft."

"I'm broadening my range."

She set down her screwdriver.

"The compass," he said. "I've seen the video."

"Which version?"

He took his hands out of his pockets.

Inês led him to a shallow conservation tray. The tiny brass compass lay on acid-free tissue beside a numbered label. She turned the register towards him.

"Time received. Condition. Location. My signature. Conservation assistant's countersignature."

Nuno read it twice. "That is an unusually thorough way to steal something."

"It's an entirely ordinary way to do my job."

He glanced towards the door. "Let me take it back. Quietly. Marta gets her happy ending."

"Marta gets a reason to restart the platform."

A telephone rang on the bench. Inês pressed the speaker button with the end of her pencil.

"Is Vale there?" Marta asked. "Security said he was heading down."

"He's here."

"Good. Bring up the compass. The gala rehearsal starts in twenty minutes. I want the ship turning."

"The platform isn't safe," Inês said.

"We have already discussed this."

"You've spoken. That's different."

Nuno looked at the bracket in the vice, then at the compass.

"I saw your signed instruction, Marta."

"Then you know what's required."

The line clicked dead.

Inês closed the tray's transparent cover.

"You may tell her exactly where it is," she said. "But it stays logged here until that platform is safe."

For once, Nuno could think of nothing reassuring to say.

Then he noticed the grease.

It lay in a black crescent along the compass's rim, quite unlike the pale wax on the conservation bench.

"May I?"

Inês turned the custody tray towards him without letting go.

"Looking," she said. "Not borrowing. You always confused those."

Ten minutes later, kneeling beside the ship display's open service hatch, Nuno found the same black grease along the mouth of the drive slot. Above it, the warning about loose objects had been partly covered by a label thanking the principal donor.

He held the tray near the opening. The crescent on the brass matched the greasy lip.

"Something's been getting acquainted," he said.

Inês closed the hatch.

"That is why it stays in custody."

"I'm not asking you to put it back. I'm asking you to help me show what happens."

"With that ship on top? No."

"Without it."

She studied him.

It was an uncomfortable novelty, being assessed for caution.

"We lift the ship onto its conservation cradle," he said. "You supervise. Power isolated until you say otherwise. Then we test the drive with something expendable."

"You?"

"I was hoping for a washer."

At last she fetched the padded trolley.

They had settled the ship safely into its cradle when Marta appeared. Her gaze went from the empty plinth to the compass tray.

"Excellent. You've recovered it."

"We've moved it six metres," said Inês. "There's a log."

Marta drew Nuno aside.

"The reward is still available. I can describe it as a consultancy payment. The compass was misplaced during maintenance, you found it, and we needn't trouble anyone with the details."

"Including the instruction you signed to run the unfinished display?"

Her smile held, though apparently at considerable expense.

"The gala opens in forty minutes."

Nuno looked at the waiting cradle. He could take the money, return to his tour and spend the evening pointing out other people's historical errors.

"No consultancy," he said. "And no convenient thief."

Marta's eyes flicked towards Inês.

"Especially not her."

Back in the workshop, Inês opened the security terminal.

"My installer account still has export access," she said. "They remembered to remove my name from the exhibition panel, but not that."

At Nuno's request, she selected the full camera recording, including the minutes before and after the excerpt he had been shown.

The download bar advanced with institutional reluctance.

Nuno waited until two complete copies had saved.

Then he picked up the tray.

"Now," he said, "let's give the mechanism a chance to tell its own story."

Beyond the closed doors, somebody was testing a microphone by apologising into it.

"Eight minutes," Marta said.

Nuno started the security footage six seconds before the museum's theft clip began.

The ship juddered on its cradle. Beside its polished hull, the tiny brass compass crept across the tilted platform. Inês appeared at the edge of the crowd, watching not the visitors but the gap beneath the ship.

"There," Nuno said.

The compass slid. Her hand darted out and caught it immediately above the drive slot.

He stopped the picture.

"In the version you showed me, that begins with her hand closing."

"It was prepared quickly," Marta said.

"So was the display."

Inês set a wooden disc beside the exposed mechanism. It matched the compass in diameter and thickness; Nuno had watched her measure both. The real compass remained in its labelled conservation tray.

With the motor isolated, she turned the hand crank. The platform tilted. Nuno released the disc where the footage showed the compass starting its slide.

It slipped into the slot.

The crank stopped.

"Now the motor would keep pulling," Inês said.

She applied gentle pressure. With the drive jammed, its linkage pushed against the cradle instead. One support rose clear of its stop; the great ship leaned towards them. Nuno's stomach tightened before the padded restraint caught it.

Inês let go.

For a moment, the only sound was the microphone.

"Welcome. Welcome. Sorry."

Nuno laid Marta's signed instruction beside the conservation log.

"'Run for gala regardless of outstanding adjustments,'" he read. "And here: 'Loose objects must be secured before operation.' Inês logged the compass eleven minutes after she caught it."

Marta looked from her signature to the ship, suspended at an angle no maritime museum should encourage.

"You could have brought it directly to me."

"You told me to stop holding up the opening," Inês said.

Marta smoothed the paper. Then she fetched the electrician from the doorway and watched him disconnect the motor's supply.

"The compass was recovered by our conservator during an unsafe movement of the exhibit," she said. "She prevented serious damage. That goes in the report."

"And the reward?" Nuno asked.

Marta's eyes narrowed.

"For the conservation department," he suggested.

When the doors opened, the ship stood level, silent and magnificently stationary. Inês was beside it, accepting Marta's introduction without offering to demonstrate anything.

Nuno gathered the first donors around him.

"This vessel," he announced, "has survived a remarkable number of dangers without leaving Lisbon."

Behind him, Marta took a glass of water.

Tonight, he decided, the truth would hold their attention perfectly well.