# Behind the Sealed Door

Plan brief-12; schema 1; tier M

Character ruth: Ruth Delgado

Character landlord: Martin Voss

Character tenant: Elena Cruz

## s1: The Loose Bird

A parrot interrupts Ruth's quiet management of a sweltering apartment block.

Present: ruth

Beat s1b1: While resetting an overloaded hallway circuit, Ruth catches a tenant's parrot in the crowded stairwell.

Beat s1b2: The bird repeats, "Open the basement door," and Ruth finds fresh boards across the basement entrance.

Fact fact-elena-sealed: Voss sealed Elena, the parrot's owner, inside her basement room after a rent dispute.; initial holders: tenant, landlord

Setup setup-power at s1: The overloaded hallway circuit establishes that the heat-strained power supply may fail.

## s2: An Empty Basement

The landlord makes Ruth's investigation a threat to her family's home.

Present: ruth, landlord

Beat s2b1: Voss insists the basement is empty and threatens to call police if Ruth touches the boards.

Beat s2b2: After he reminds her that her apartment comes with her job, Ruth pockets her tools and returns upstairs to her child.

## s3: Through the Vent

Ruth confirms that a tenant is trapped beside the overheating electrical room.

Present: ruth, tenant

Beat s3b1: Ruth removes a stairwell vent grille and hears Elena identify herself as the parrot's owner.

Beat s3b2: Elena says Voss sealed her inside her basement room after a rent dispute, while a nearby extractor fan repeatedly stalls.

Causal s3-s4-rescue-call: earlier cause s3 → effect s4

Reveal s3-reveal-elena: fact fact-elena-sealed at s3; holders: ruth (acquired at scene start)

## s4: No Quiet Fix

Ruth seeks public help instead of protecting the landlord again.

Present: ruth, landlord

Beat s4b1: Ruth leaves her child with a neighbor and calls firefighters about the trapped tenant and impending electrical failure.

Beat s4b2: When Voss blocks the stairs, Ruth summons neighbors to witness the door and sends them maintenance messages documenting his basement alterations.

Causal s3-s4-rescue-call: earlier cause s3 → effect s4

Knowledge use s4-use-elena-sealed: ruth uses fact fact-elena-sealed at s4

## s5: Out in the Open

Elena reaches safety, but Ruth cannot secure her own family's future.

Present: ruth, landlord, tenant

Beat s5b1: Ruth guides firefighters to the sealed room, and they carry Elena into the crowded courtyard before the building loses power.

Beat s5b2: As Voss calls the sealing accidental and demands Ruth's staff keys, she submits messages that also expose her own unreported repairs.

Payoff s5-payoff-power: setup setup-power → payoff at s5

State s1-ruth-goal [s1] ruth goal response-to-building-trouble: known: Keep the building running through quiet repairs.; confidence unrecorded; alternatives: (none recorded) → known: Check whether the bird's plea and fresh boards signal someone needing help.; confidence unrecorded; alternatives: (none recorded)

State s2-ruth-goal [s2] ruth goal response-to-building-trouble: known: Check whether the bird's plea and fresh boards signal someone needing help.; confidence unrecorded; alternatives: (none recorded) → known: Suspend the investigation to protect her child's home.; confidence unrecorded; alternatives: (none recorded)

State s3-ruth-goal [s3] ruth goal response-to-building-trouble: known: Suspend the investigation to protect her child's home.; confidence unrecorded; alternatives: (none recorded) → known: Get Elena out before the failing ventilation and power make rescue impossible.; confidence unrecorded; alternatives: (none recorded)

State s4-ruth-goal [s4] ruth goal response-to-building-trouble: known: Get Elena out before the failing ventilation and power make rescue impossible.; confidence unrecorded; alternatives: (none recorded) → known: Secure public rescue and witnesses so Voss cannot quietly obstruct help.; confidence unrecorded; alternatives: (none recorded)

State s5-ruth-goal [s5] ruth goal response-to-building-trouble: known: Secure public rescue and witnesses so Voss cannot quietly obstruct help.; confidence unrecorded; alternatives: (none recorded) → known: Submit the full record against Voss's denial, even where it implicates her.; confidence unrecorded; alternatives: (none recorded)
