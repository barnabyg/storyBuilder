Leena found the first flower while clearing a blocked dripper. It hung beneath a leaf, white and small enough to mistake for a torn piece of root sleeve.

She put down the probe.

The beans were nineteen days old. They should have been making leaves for another three weeks.

She photographed the blossom with a ruler beside it, then widened the frame to include the tray number. There were six more flowers on the rack. One had opened against the underside of a pipe, its petals creased by the warm metal.

Beyond the greenhouse window, sunlight lay on gray ground that had never supported anything. Inside, the fans whispered through leaves. Nutrient solution clicked through the valve she had just repaired.

Leena checked the sowing record, then the light schedule. Both were correct.

The radiation storm had passed six days earlier. A minor event: the crew had eaten lunch in the shelter, then returned to work. The greenhouse dosimeter had stayed below the intervention threshold. Nevertheless, the rack nearest the outer wall had received almost twice the dose measured at the inner rack.

Most of the flowers were near that wall.

Most, not all.

She was enlarging the tray map when Commander Imani appeared in the hatch.

“Problem?”

“Early flowering.”

“How early?”

“Twenty-three days.”

Imani took a moment to absorb that. Leena appreciated the moment; then she saw the commander glance toward the insulated cabinet beyond the inner hatch.

“Could it reach the seed stock?”

“A flowering response isn’t contagious.”

“Is that what this is?”

Leena looked back at the map. “I don’t know yet.”

They had one greenhouse, one reserve of viable seed, and a supply lander due in forty-one days. The beans filled a carefully measured gap between the current stores and the next harvest. There were no spare beds.

“Bag the flowers,” Imani said. “Stop circulation from those trays. At shift change, the affected crop goes through the sterilizer.”

“That’s forty-eight plants.”

“It’s fewer than everything.”

“Give me time to test them.”

“You have five hours. Show me a containment plan I can trust. Don’t spend them trying to prove there’s no risk.”

Leena had come to the Moon partly because, during her last year on Earth, a department head had introduced her as the scientist who could find a reason not to proceed. Now she was being ordered to destroy plants before she could establish why they had changed.

She heard herself say, “You asked me to keep this greenhouse productive.”

“I’m asking you to keep it productive next year, too.”

After Imani left, Leena counted the flowers again.

She fitted each with a fine pollination bag, supporting the stems with a gloved finger. Beans mostly pollinated themselves, but mostly was not a containment standard. Then she called Pavel.

He arrived carrying a valve kit and the piece of toast he had forgotten at breakfast.

“All four trays?” he asked.

“They share a return.”

“The portable reservoir will take water out of reserve.”

“Eleven liters. We can recover it after treatment.”

He knelt beside the rack. “You’ve already calculated that?”

“Yes.”

“Good. Hold this.”

She held a capped hose while he disconnected the return line. A bead of nutrient solution trembled at the coupling before he caught it with a cloth.

When the separate pump started, the leaves shivered.

Pavel checked the seals, then opened the maintenance log for her signature. “What do I put under cause?”

“Undetermined.”

He entered it without comment.

Leena sampled the flowering plants and six neighbors. She checked root color, substrate conductivity, temperature logs. The roots were pale; the nutrient concentrations were ordinary. The light timer had not reset during the storm.

Her first rapid assay showed increased activity in a flowering regulator and a strong stress response. That was compatible with radiation exposure. It was also compatible with several other injuries, including heat and root damage.

She laid the result beside the dose map.

A plant could respond to injury by reproducing sooner. That might save a generation. It might also produce three empty pods on a plant that should have fed them for weeks.

She knew all that. Still, she found herself looking longest at the strong signal.

Imani requested an update.

Leena wrote: Affected trays isolated. No similar flowering observed elsewhere. Initial assay consistent with stress-induced reproductive acceleration.

She paused before the last sentence, then left it.

She did not attach the files. She wanted the repeat first.

On Earth, she had once asked to delay a field release because the controls were behaving strangely. A colleague had put her caveats on a slide. Leena would like another season, he had said, and the room had laughed. Afterward she had learned to arrive with conclusions people could not easily pull apart.

The repeat assay did not support the first.

Leena checked the extraction control. It passed. She checked the reagent lot, the sample identification, her own calculations. The flowering signal was weak. The stress marker was near baseline.

She sat without moving until the screen dimmed.

There were innocent explanations. Different leaves, different developmental stages, a response already fading. But none made the two results agree.

She reopened her message to Imani.

Pavel came in before she changed it.

“I need the worst-case yield.”

“Zero.”

He looked at her.

“That’s the worst case,” she said.

He set his tablet beside her samples. He had taken the entire crop out of the food plan. Eleven days before the lander arrived, their stores fell below the reserve floor.

“We can reduce portions now,” he said. “Or reduce them more later.”

“Replanting won’t close the gap.”

“I know. I’m not asking whether you should have grown faster beans.”

She almost smiled. Then she saw that he wasn’t smiling.

“I asked you yesterday if the crop was on schedule.”

“It was.”

“Did you look?”

She thought of the flower pressed beneath the pipe. It had not opened that morning.

“I checked growth totals. Not every plant.”

“All right,” Pavel said. “Then I need the range, not the number you hope for.”

Imani entered with a tray of sealed sampling tubes. Leena had requested them before the repeat finished.

“Stores had six,” she said. “That leaves two for a water-quality incident.”

Her eyes went to the assay display.

“Is that the result you reported?”

“The repeat.”

“Why is it different?”

“I don’t know.”

Imani read the message on her wrist screen, then looked back at Leena. “You made this sound more settled than it is.”

“The first result was consistent with—”

“I read that part.”

Leena put down the sampling tube she was holding.

“I wanted to resolve it before I sent both.”

Pavel’s food budget remained open between them.

She had imagined uncertainty staying on her bench until she could make it useful. Meanwhile, Imani had been deciding what could be risked, and Pavel had been counting meals.

“I should have sent them,” she said.

“Yes,” Imani said.

For a few seconds, only the portable pump spoke.

Then Leena opened the crew channel and uploaded both assay files, the calibration records, the dose map, and her original message.

She added: This interpretation was premature.

Imani watched her send it.

“Uploading isn’t a containment plan.”

“No,” Leena said. “I need to work on that with you.”

They met in the galley because the greenhouse terminal could not display Pavel’s engineering drawings beside the crop records.

There were ninety minutes until shift change.

Leena began with what she could defend. The plants were flowering early. The cause was unknown. The storm was a candidate, not a finding. Nothing yet established useful adaptation, disease, or heritability.

“We can’t settle yield in ninety minutes,” she said. “We can decide whether there’s a safe way to find out.”

She proposed retaining two flowering plants in the spare root-study chamber, with two matched controls from the inner rack. Everything else in the affected trays would be destroyed.

Pavel enlarged the chamber drawing.

“The drain valve seeps.”

“Can we replace it?”

“Not before shift change.”

Leena felt the familiar urge to explain why seepage was unlikely to matter. She stopped.

“What would make it independent?”

“Cap the drain. Separate waste bottles. Individual vessels inside the chamber.”

“And the air?”

“Filtered exhaust to the utility treatment line. No return to the greenhouse.”

Imani folded her arms. “How do you inspect the plants?”

“Through the vessels. Sampling only under the transfer hood, with two people present.”

“That hood is beside the seed cabinet.”

Leena stared at the plan. She knew every centimeter of the greenhouse and had somehow left the cabinet out of her proposal.

Pavel pulled the drawing toward him. “We can move the hood into the utility alcove. Disconnect the chamber heater circuit and use its power feed.”

“The plants need heat,” Imani said.

“The alcove stays warm from the water processor. We’ll log temperature separately.”

Leena began entering requirements. Leak tests before transfer. Dedicated tools. Sealed waste. No harvested beans for food. No seeds entering storage.

“Endpoints?” Imani asked.

“Flower counts, leaf damage, pod set, seed development. Compare them with the controls.”

“And if they look healthy?”

“That isn’t permission to release them. We’d need another decision before growing any offspring.”

Imani pointed to the shared screen. “Put that in.”

Leena did.

They set stop conditions: a failed seal, loss of filtration, contamination outside a vessel. Any crew member could suspend the test. Opening a vessel required two signatures.

Pavel studied the work list. “This takes my maintenance block. The exercise bike stays broken.”

Imani looked at the food budget still pinned in the corner of the screen.

“Post the reduced portions tonight,” she said. “Don’t budget for these plants.”

Then she signed.

They finished with nine minutes left.

Pavel moved the hood on a wheeled tool stand while Imani cleared the alcove and sealed its ventilation grille. Leena chose two flowering plants from different trays. She wanted the largest one, with three blooms and thick leaves, but selected by the numbered positions they had agreed upon.

One had a single flower. The other had two.

Their root sleeves slid reluctantly from the tray, trailing wet threads. She transferred each into a clean vessel without trimming the roots. Pavel read the labels aloud; Imani checked them against the map.

The controls came next. All four vessels received identical light and nutrient settings. They waited for the pressure tests together.

One seal failed.

Leena felt her mouth open.

Pavel was already reaching for the replacement gasket. “We haven’t transferred that plant yet.”

She shut her mouth and helped him change it.

The second test held.

At shift change, Imani authorized sterilization of the remaining crop. Leena loaded the plants herself. There were buds hidden beneath leaves she had not examined, and one small flower came free against her glove.

She placed it in the vessel with the rest.

When the lid locked, she checked the inventory: forty-six affected plants destroyed, two retained. Two controls transferred. Forty-eight empty planting positions to clean and sow again.

Later, she found Pavel in the galley, rewriting the meal portions in larger figures so nobody would mistake the old amounts for the new.

“Will the beans help?” he asked.

“Not this food schedule.”

“I meant eventually.”

“I don’t know.”

He nodded and gave her the marker to check his arithmetic.

Before sleep shift, the three of them inspected the alcove. Imani verified the seals. Pavel checked waste levels. Leena entered the first observations in a log all of them could edit.

The single flower had closed slightly after transfer. That might mean nothing more than handling stress. She recorded it without interpretation.

On the shared calendar, she entered the next inspection, then the measurements for days three, seven, fourteen, and twenty-one. Yield remained blank. Inheritance remained blank.

Inside its vessel, the little plant stood under the lamp with its roots in clear solution. There was room above it for pods, if it made them.

Leena saved the schedule, and Imani confirmed the first watch.