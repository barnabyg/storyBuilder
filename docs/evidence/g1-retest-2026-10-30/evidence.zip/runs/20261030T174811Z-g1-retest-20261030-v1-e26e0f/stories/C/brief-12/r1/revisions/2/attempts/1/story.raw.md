The breaker kicked back with a sound Ruth felt in her teeth.

“Again?” someone said.

“Give me a minute.”

People could wait longer if they didn’t hear you worrying. In eleven years as superintendent, Ruth Delgado had learned that before she learned anything about wiring.

Tenants sat along the stairs because their apartments were hotter. Mrs. Ortiz held a bag of frozen peas against her neck. On the landing above, two children lay with their cheeks against the terrazzo.

“Who’s running an air conditioner off the hall outlet?”

Nobody answered.

A green bird flew past Ruth’s ear and struck the wall. It caught itself on the open electrical-panel door, claws ticking against metal.

“Elena’s,” Mrs. Ortiz said.

Ruth offered her shoulder towel beneath its feet.

“Come on, Captain.”

He climbed aboard and bit her through the cotton.

“Good to see you too.”

Upstairs, an apartment door shut. An air conditioner stopped. Ruth reset the breaker and this time it held, though the cables entering the panel still smelled hot.

Her phone buzzed.

Mateo: Can I open our door?

Stay inside till I come.

He was ten. Their apartment was behind the laundry, and when the dryers ran, his bedroom wall warmed like a skillet. She had switched them off at noon, leaving notes on the machines. Someone had peeled one off.

Against her wrist, Captain said, “Ruth. Open the door.”

Mrs. Ortiz laughed. “Even the bird knows who to ask.”

“Open the basement door.”

Not Elena’s usual bright voice, the one Captain used to ask for coffee. This was thin and breathless.

Ruth stopped adjusting the towel.

“Have you seen Elena today?”

“Her shift changed, I think.”

Elena cleaned offices at night. She kept her bird in a basement room Voss called storage, although storage did not need slippers beneath a bed. Ruth had carried a space heater down there in January and told Elena not to run it with the kettle.

She had not asked why a woman paying six hundred and fifty dollars a month had to choose.

“I’ll take him down.”

At the bottom of the stairs, three fresh boards crossed the basement door. Sawdust lay in the corners of the steps. Beneath the boards was the hasp Ruth had installed three weeks earlier, on Voss’s instructions.

She touched a bright screw head.

“What are you doing?”

Voss stood above her, car keys in his hand.

“Elena’s bird got out. Is she down there?”

“No.”

“Where is she?”

“How would I know?”

Captain leaned toward the door.

“Open the basement door.”

Voss looked at the bird, then at Ruth.

“Why the boards?” she asked.

“People have been getting into storage. I told you.”

“You told me to put a hasp on.”

“And apparently that wasn’t enough.”

Across the landing, the electrical cupboard buzzed. The light faded and recovered.

“I need to get in,” Ruth said. “Check nobody’s there.”

“The basement is empty.”

She took the screwdriver from her belt.

“Touch that door and I’ll call the police.”

“For doing my job?”

“For damaging property after a direct instruction not to.”

Someone called Ruth from the second floor. A kitchen ceiling was dripping. Ordinarily she would already have been climbing, asking whether the water was clean.

Voss came down one step.

“Your apartment comes with the job. Don’t make this into something.”

For eleven years she had asked for a separate lease. Voss always said his lawyer was drawing one up. Mateo had grown from a baby sleeping in a drawer beside her bed to a boy who could touch both bedroom walls with his arms spread.

Ruth put the screwdriver away.

“I’ll get the bird some water.”

“Good. Look after your boy.”

Mrs. Ortiz lent her an old travel cage. Upstairs, Mateo was sorting puzzle pieces into cereal bowls. Sweat had flattened his hair.

“Did you fix it?”

“For now.”

“Are we keeping him?”

Captain hung sideways from the cage bars.

“No. He belongs to Elena.”

“The lady downstairs?”

Ruth looked at her son.

“She let me hold him when you fixed her sink.”

Of course he knew. He went with her on Saturday repairs. Only the adults pretended the room was something else.

She stood him at the sink with the bird’s water dish and opened her messages.

Elena’s door needs exterior hasp. Tenants getting into storage. Before Friday.

Ruth had asked: Who gets keys?

I’ll handle it.

Below that was her own reply.

Done.

She remembered Elena’s flowered curtain, the pillow folded beneath it. She had fitted the hasp carefully so the screws would bite into sound wood.

“Put your shorts on,” she told Mateo.

“Are we going to the pool?”

“Mrs. Chen’s.”

He looked at her face and stopped asking.

Mrs. Chen opened her door with a damp towel around her shoulders.

“Can he stay a while?”

“How long?”

“I don’t know.”

Mrs. Chen took the cage as well as the boy.

“Have you eaten?” she asked him, and Ruth was grateful enough to find it difficult to speak.

Downstairs, the light was dimmer. Ruth crouched beside a low ventilation grille opposite the basement door. One corner had been bent for years; she had kept meaning to replace it. She removed the remaining screw and lifted it away.

Heat breathed against her face.

“Elena?”

Nothing.

“It’s Ruth.”

A scrape came from the other end.

“Is he gone?”

Ruth lowered herself onto one elbow. The duct crossed beneath the landing and opened into the basement corridor.

“Voss? Yes.”

“Don’t tell him.”

“Are you hurt?”

“I keep getting dizzy.”

“Can you get to the stairs?”

“I’m at the door.”

Ruth looked at the boards.

“What happened?”

“He came about the increase. I said no. I said I called the city.”

“When was this?”

“This morning. He went out and locked it. Then the drill started.”

“What time?”

“After nine. Captain got past him. I thought you’d bring him back.”

It was five seventeen.

Ruth pressed her forehead against the wall. She had spent the morning unclogging a bath, carrying Mrs. Ortiz’s groceries, finding a package left in the wrong hall.

“Did he answer when you called?”

“He said I could stay there until I learned to answer my phone.”

Ruth felt suddenly cold along her arms.

“The fan stopped,” Elena said. “It came back before. It hasn’t this time.”

“Listen to me. Captain’s upstairs. He’s got water. I’m getting you out.”

She called emergency services.

“A woman’s locked in our basement. The door’s boarded shut. She’s been there all day in the heat, and she’s dizzy.”

The dispatcher asked for the address, then whether Elena was breathing normally.

Ruth bent to the vent again.

“Elena? Talk to me.”

“Please don’t leave.”

“I’m right here.”

She put the phone on speaker. When the dispatcher asked who had locked the door, Ruth gave Voss’s name and repeated what Elena had told her.

She did not say maintenance problem. She did not say misunderstanding.

“Who are you calling?”

Voss stood at the top of the steps.

“The fire department. Get the key.”

He stared at her phone.

“You should have called me.”

“You were here.”

“I told you the basement was empty.”

“She’s at the door.”

For several seconds he said nothing. The dispatcher asked Ruth whether she was safe.

Voss heard.

“Perfectly safe,” he said. “I’m the owner. We have an unauthorized occupant refusing—”

“Get the key,” Ruth said.

A door opened above them. Mrs. Ortiz leaned over the railing.

“Ruth?”

Ruth nearly said, Everything’s fine.

The answer was ready before she had thought. She had used it during leaks and shouting matches, when the boiler quit, when an inspector asked whether the tenants had complaints. It meant she was handling things. It meant nobody needed to come.

“Elena’s locked in the basement,” she said. “The fire department’s coming. Will you keep people off these stairs?”

Mrs. Ortiz looked at Voss.

“Be careful,” he told Ruth.

“Come and listen,” Ruth said.

Mr. Ahmed appeared behind Mrs. Ortiz with his phone. Then the second-floor tenant who had unplugged his air conditioner.

“This isn’t a show,” Voss said.

“Then open it,” Mrs. Ortiz told him.

Voss dug in his pocket and threw a small key onto the step.

Ruth picked it up.

“The boards too,” she said.

“That door’s your responsibility.”

He moved aside, looking up at the phones.

Ruth took out her screwdriver.

The first screw came loose easily. The second had been driven crooked, and she had to lean her whole weight into it. Sweat dripped from her chin.

Behind the door, Elena said, “Ruth?”

“First board’s coming off.”

She said it loudly enough for Elena to hear and for Voss not to be able to deny it later.

Mr. Ahmed came down and held the board while she backed out the last screw. His phone lay on the step, recording their shoes.

“You can stop filming,” Voss said.

Mr. Ahmed did not answer.

The board came free. Ruth handed it up. At the second, her screwdriver slipped and cut the heel of her hand.

“Here.” Mrs. Ortiz offered the towel she had been wearing around her neck.

Ruth wrapped it around the handle for a better grip.

Above them, the light turned orange.

A refrigerator motor labored behind an apartment door. The electrical cupboard gave a sharp crack, and everything stopped.

No fans. No televisions. No dryer somebody had restarted.

In the dark, a child began to cry.

Mr. Ahmed switched on his phone’s light.

“Don’t touch the panel,” Ruth said. “Nobody resets anything.”

“Leave the door,” the dispatcher told her. “The crew’s approaching.”

“One more board.”

“Ma’am—”

“Elena?”

No answer.

Ruth put her mouth near the gap beneath the door.

“Elena, knock if you can hear.”

Two soft taps.

She turned the screwdriver. Each rotation seemed impossibly small. The screw came out warm.

The final board dropped against her ankle. She fitted the key into the padlock, opened the hasp, and pulled.

The door moved half an inch.

She pulled harder. The swollen bottom dragged against the floor, and through the gap came the smell of damp bedding and something electrical burned hot.

Boots sounded above.

“Everybody back.”

Ruth kept hold of the knob until a firefighter touched her shoulder.

“Where is she?”

“Right behind it. It opens in.”

He knelt and called through the gap. Another firefighter guided Ruth up two steps, then set a tool against the frame.

She wanted to explain the door, how long it had been sticking, how she had asked Voss to replace it. Instead she pointed out the electrical cupboard and told him it had arced.

The frame split. The door opened with a long scrape.

Elena was on the floor, one bare foot braced against the bottom panel as though she had been trying to help.

They brought her out between two firefighters. She wore a blue nightdress and one plastic sandal. Her other hand was clenched around something white.

On the landing it fell open: a folded rent receipt, damp enough to tear.

In the courtyard, neighbors moved their chairs for the stretcher. Someone carried down a jug of water. Mrs. Chen arrived with Mateo and the cage.

Captain whistled.

Elena turned her head.

“He’s here,” Ruth said.

Elena reached toward the cage. A paramedic took her wrist gently and fitted an oxygen mask over her face.

Ruth stood beside her until Elena caught two of her fingers.

“I called you,” Elena whispered.

“I know.”

“Not today. Last week. About the lock.”

Ruth remembered the message now. Can you come when he isn’t here?

She had replied, Busy today. Tomorrow?

Tomorrow had become a flooded sink and a delivery of furnace filters.

“I should have come,” she said.

Elena’s grip loosened. The paramedic asked Ruth to step back.

Voss came through the gate talking into his phone.

“An occupied storage room,” he said. “Apparently she’d been letting someone live there.”

Ruth opened her messages before she could decide to wait until things settled.

She sent Mrs. Ortiz and Mr. Ahmed the exchange about the hasp, then the rent-ledger photographs. STORAGE, month after month, beside Elena’s name. She included her own replies. Done. Collected. I’ll take care of it.

Mr. Ahmed’s phone chimed in his hand.

“Keep those,” she said.

Voss lowered his phone.

“You need to think about what you’re doing.”

A fire lieutenant approached with a notebook.

“Who’s responsible for the basement?”

Voss began speaking, but Ruth gave her name. She described the boards, the voice through the vent, Voss’s refusal to open the door. Then she told him who had installed the hasp.

The lieutenant wrote it down.

When he moved away, Voss held out his hand.

“Staff keys. We’ll discuss your employment tomorrow.”

Mateo came close enough that his shoulder touched her arm.

Ruth separated their apartment key from the ring. It caught at the split, and she had to use a fingernail to work it free. Voss watched without helping.

“Can we go home?” Mateo asked.

Above the laundry, their windows were dark. His puzzle covered the kitchen table. There was milk in the refrigerator and twenty-eight dollars in the tin behind it.

“In a little while.”

She handed Voss the other keys.

Her phone vibrated.

Mrs. Ortiz: I have them.

Ruth looked across the courtyard. Mr. Ahmed was showing something on his screen to the lieutenant. Voss had already turned away to make another call.

Mateo reached for her injured hand. She gave him the other one and stayed beside the stretcher until Elena was wheeled through the gate.