# Before the Harvest

Plan brief-13; schema 1; tier M

Character leena: Leena Sato

Character commander: Commander Imani

Character engineer: Pavel Chen

## s1: Flowers Out of Season

Leena discovers premature flowers in the lunar greenhouse after a minor radiation storm.

Present: leena, commander

Beat s1-b1: Leena photographs dwarf-bean flowers weeks ahead of schedule and checks their trays against the storm dosimeter.

Beat s1-b2: Imani orders the crop destroyed at shift change unless Leena demonstrates a safe alternative that protects the seed bank.

Fact fact-early-flowers: The dwarf beans are flowering weeks ahead of schedule after the storm; the cause is unestablished.; initial holders: (none)

Fact fact-omitted-results: Leena's progress report omitted conflicting assay results.; initial holders: leena

Reveal reveal-early-flowers: fact fact-early-flowers at s1; holders: leena, commander (acquired at scene start)

## s2: A Private Investigation

Leena isolates the crop but keeps her inconclusive findings to herself.

Present: leena, engineer

Beat s2-b1: Leena bags the flowers and asks Pavel to disconnect the affected trays from shared nutrient circulation.

Beat s2-b2: Remembering colleagues who dismissed her caution on Earth, she withholds ambiguous assay results and requests more time.

Causal cause-withholding-discovery: earlier cause s2 → effect s3

Knowledge use use-isolate-anomaly: leena uses fact fact-early-flowers at s2

## s3: The Missing Margin

A failed replication forces Leena to confront the cost of withholding uncertainty.

Present: leena, commander, engineer

Beat s3-b1: Leena's repeat assay fails to reproduce a promising stress-response signal, leaving adaptation and damage unresolved.

Beat s3-b2: Pavel's food-budget calculation exposes a harvest shortfall, and Imani discovers that Leena's progress report omitted the conflicting results.

Causal cause-withholding-discovery: earlier cause s2 → effect s3

Reveal reveal-omitted-results: fact fact-omitted-results at s3; holders: commander (acquired at scene start)

## s4: An Auditable Risk

Leena shares her incomplete evidence and proposes a bounded experiment.

Present: leena, commander, engineer

Beat s4-b1: Before the deadline, Leena gives the crew her raw results and admits that early flowering proves neither safety nor useful adaptation.

Beat s4-b2: She proposes retaining two plants in an independent chamber with matched controls, fixed sampling dates, and written destruction thresholds.

## s5: The First Entry

The crew preserves an isolated sample and begins a test with no promised outcome.

Present: leena, commander, engineer

Beat s5-b1: Imani authorizes the protocol, and the crew seals two plants in separate containment before sterilizing the remaining anomalous crop.

Beat s5-b2: With ration adjustments posted and control plants installed, Leena opens the shared test log without predicting future yield or inheritance.

State leena-goal-s1 [s1] leena goal crop-preservation: known: Bring the scheduled bean crop to harvest.; confidence unrecorded; alternatives: (none recorded) → known: Find evidence for a safe alternative to destruction before shift change.; confidence unrecorded; alternatives: (none recorded)

State commander-belief-s1 [s1] commander belief acceptable-crop-risk: known: Routine greenhouse safeguards are sufficient for the scheduled crop.; confidence unrecorded; alternatives: (none recorded) → known: Keeping the anomalous crop requires demonstrated protection of the seed bank.; confidence unrecorded; alternatives: (none recorded)

State leena-belief-s2 [s2] leena belief sharing-uncertainty: known: Careful evidence could earn the crop a reprieve.; confidence unrecorded; alternatives: (none recorded) → known: Sharing inconclusive results invites dismissal; stronger evidence must come first.; confidence unrecorded; alternatives: (none recorded)

State leena-belief-s3 [s3] leena belief sharing-uncertainty: known: Sharing inconclusive results invites dismissal; stronger evidence must come first.; confidence unrecorded; alternatives: (none recorded) → known: Withholding uncertainty has compromised the crew's decisions and her credibility.; confidence unrecorded; alternatives: (none recorded)

State leena-belief-s4 [s4] leena belief sharing-uncertainty: known: Withholding uncertainty has compromised the crew's decisions and her credibility.; confidence unrecorded; alternatives: (none recorded) → known: Shared uncertainty and enforceable limits make a responsible test possible without proving the crop safe.; confidence unrecorded; alternatives: (none recorded)
