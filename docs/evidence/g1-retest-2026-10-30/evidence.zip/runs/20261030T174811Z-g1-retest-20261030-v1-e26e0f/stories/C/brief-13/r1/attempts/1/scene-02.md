She took seven pollination bags from the sterile drawer. Each was fine enough to admit light and air, with a drawstring that closed around the flower stem. She worked slowly, supporting each blossom with a gloved finger so its weight would not bend the stalk.

Then she called Pavel.

“I need trays twelve through fifteen off the shared nutrient loop.”

“All four?”

“They share a return line.”

He crouched beside the rack, hooking one boot under a floor rail. “Flowers don’t travel through plumbing.”

“No. But until I know what changed, I don’t want their drainage going anywhere else.”

Pavel looked at the small white bags. “Separate reservoir means another pump. And hand sampling.”

“I’ll do the sampling.”

He fetched two capped hoses and a portable tank. Leena held the return line while he closed the valves. A little nutrient solution gathered at the coupling, trembling in a clear globe before Pavel caught it with an absorbent cloth.

“Imani still wants these cleared by shift change?”

“Yes.”

“That gives you five hours.”

“I know.”

Once the pump was running, he checked the seals and left her the maintenance tablet to sign.

Leena sampled leaf tissue from the flowering plants and from the adjacent rack. The rapid assays consumed forty minutes and three cartridges they could not replace until the next supply landing.

The first showed elevated expression of a flowering regulator. The second did not. A stress marker was high in both the affected plants and the controls. None of it distinguished storm damage from an ordinary response to something she had missed: temperature, nutrient balance, a faulty light timer.

She laid the results side by side.

On Earth, a colleague had once projected her caveats onto a meeting-room wall. “Leena would like another season,” he had said, and people had laughed before she could explain what the controls had shown. Later, when a trial failed, nobody remembered the laughter. They remembered that she had delayed it.

She opened the report to Imani.

Isolation complete. No evidence yet of spread beyond affected trays.

Below that she began, Assays show—

She stopped. Imani would ask whether the results established safety. They did not. On a station counting meals against harvest dates, ambiguity would make destruction easier to authorize.

Leena deleted the unfinished line.

Request two additional hours before disposal to complete comparison testing.

She attached the isolation log, but not the assay files. Those she saved in her working folder, carefully labeled, as though careful labels made them less withheld.

Then she selected another leaf for sampling.