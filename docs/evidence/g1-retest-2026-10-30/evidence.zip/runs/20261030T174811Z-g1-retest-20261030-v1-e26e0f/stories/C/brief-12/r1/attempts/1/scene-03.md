Ruth stayed by the door until her child’s footsteps retreated down the hall. Then she took the stubby screwdriver from her pocket.

She would only check the vent. That was not the same as opening the basement. It was the sort of distinction she had made for Voss for years.

On the half-landing, she knelt beside the grille. Heat breathed through its slots, carrying a smell of hot dust. She loosened the screws into her cupped palm and lifted the grille away.

“Hello?”

A scrape came from below, then a woman’s voice.

“Is he still there?”

“Who?”

“Voss.”

Ruth lowered herself onto one elbow. The duct turned beyond her reach.

“He’s gone. This is Ruth. The superintendent.”

“My bird,” the woman said. “Did you find him? Green, with a yellow head?”

“Yes.”

“I’m Elena. He’s mine.”

Ruth knew the name. Cash in an envelope, slid under the office door. No apartment number, just BASEMENT written in Voss’s square handwriting on the rent sheet. Ruth had entered the payments without asking which room.

“Are you hurt?”

“I can’t get the door open.”

Somewhere behind the wall, a motor started. Its blades scraped, gathered speed, then stopped with a dull click.

“Tell me what happened.”

“I said I wouldn’t pay the increase. There’s no window. The sink backs up. I told him I’d call the city.” Elena paused to breathe. “He came down to talk. Then he went outside and shut me in. I heard the drill. He put something across the door.”

Ruth looked toward the basement entrance. The fresh strip of plywood Voss had called a repair ran from the door onto its frame.

“When?”

“This morning. I thought he’d come back.”

The motor tried again. Ruth recognized it now: the extractor beside the electrical room, the one she had asked Voss to replace in June. He had told her to oil it.

“Is that fan near you?”

“Through the wall. It keeps stopping. The wall’s too hot to lean against.”

Ruth pressed her hand against the duct. Warm metal. Above her, the landing light dimmed, recovered, dimmed again.

She pictured her child upstairs, the refrigerator holding one carton of milk and tomorrow’s lunch. Voss had made clear how quickly those rooms could stop belonging to them.

“Ruth?”

“I’m here.”

“Please don’t go away.”

Ruth set the grille flat on the landing so it could not fall back across the opening.

“I have to get help,” she said. “I’m not leaving you down there.”