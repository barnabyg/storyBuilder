Leena photographed the first flower with a scale beside it, then took a second image wide enough to include the tray number. The blossom was white, folded like a scrap of clean laundry between two leaves. There were six more on the neighboring plants.

She checked the sowing date.

Twenty-three days early.

Behind her, the greenhouse fans drew moisture from the air with their usual soft whistle. Nothing smelled scorched or sick. Roots hung pale in their channels; nutrient solution ticked through a valve. Beyond the small inspection window lay gray ground that had never supported anything.

Leena moved down the rack, photographing each flowering plant before touching a leaf.

The radiation storm had passed during sleep shift. A minor event, according to the station bulletin. She pulled the dosimeter record onto her tablet and matched its timestamps to the greenhouse tray map. The rack nearest the outer shielding had registered the highest dose, still below their intervention threshold. Most of the flowers were there.

Most, not all.

She enlarged the map. Two flowering plants stood farther inside, beside plants with no visible buds. It was the kind of pattern that invited an explanation before it deserved one.

"Leena?"

Commander Imani stood in the hatch, one hand hooked through the restraint beside it. She looked from the tablet to the flowers.

"They're early," Leena said. "By three weeks."

"From the storm?"

"After the storm. I don't know about from."

Imani came closer. "What does it do to harvest?"

"If the pods set normally, we might get beans early. We might get fewer. Flowering doesn't tell us that yet."

The next protein shipment was forty-one days out. Leena knew because she had built the planting schedule around it.

"Could this reach the seed bank?" Imani asked.

"A flowering change isn't an infection."

"That wasn't my question."

"No." Leena lowered the tablet. "We don't know what caused it. I can't rule out a disease or a handling problem."

Imani glanced toward the inner hatch, beyond which their replacement seed lay in cold storage. "Then the crop goes into the sterilizer at shift change."

Leena's fingers tightened around the tablet. She had come farther than anyone in her old department to work without hearing that caution was just indecision.

"That leaves us short," she said.

"Losing the bank leaves us short for years. Show me a safe alternative before shift change. One that protects the seed stock, not just these plants."

"How long?"

"Five hours."

After Imani left, Leena looked again at the photographs. Seven flowers, sharp and white. She opened a new record and entered the time.

She took seven pollination bags from the sterile drawer. Each was fine enough to admit light and air, with a drawstring that closed around the flower stem. She worked slowly, supporting each blossom with a gloved finger so its weight would not bend the stalk.

Then she called Pavel.

"I need trays twelve through fifteen off the shared nutrient loop."

"All four?"

"They share a return line."

He crouched beside the rack, hooking one boot under a floor rail. "Flowers don't travel through plumbing."

"No. But until I know what changed, I don't want their drainage going anywhere else."

Pavel looked at the small white bags. "Separate reservoir means another pump. And hand sampling."

"I'll do the sampling."

He fetched two capped hoses and a portable tank. Leena held the return line while he closed the valves. A little nutrient solution gathered at the coupling, trembling in a clear globe before Pavel caught it with an absorbent cloth.

"Imani still wants these cleared by shift change?"

"Yes."

"That gives you five hours."

"I know."

Once the pump was running, he checked the seals and left her the maintenance tablet to sign.

Leena sampled leaf tissue from the flowering plants and from the adjacent rack. The rapid assays consumed forty minutes and three cartridges they could not replace until the next supply landing.

The first showed elevated expression of a flowering regulator. The second did not. A stress marker was high in both the affected plants and the controls. None of it distinguished storm damage from an ordinary response to something she had missed: temperature, nutrient balance, a faulty light timer.

She laid the results side by side.

On Earth, a colleague had once projected her caveats onto a meeting-room wall. "Leena would like another season," he had said, and people had laughed before she could explain what the controls had shown. Later, when a trial failed, nobody remembered the laughter. They remembered that she had delayed it.

She opened the report to Imani.

Isolation complete. No evidence yet of spread beyond affected trays.

Below that she began, Assays show—

She stopped. Imani would ask whether the results established safety. They did not. On a station counting meals against harvest dates, ambiguity would make destruction easier to authorize.

Leena deleted the unfinished line.

Request two additional hours before disposal to complete comparison testing.

She attached the isolation log, but not the assay files. Those she saved in her working folder, carefully labeled, as though careful labels made them less withheld.

Then she selected another leaf for sampling.

The second leaf gave her nothing.

Leena checked the extraction controls, then the reagent lot. Both passed. On the screen, the stress-response marker sat close to baseline, nowhere near the sharp rise in the first sample. She ran the calculation again without changing any inputs.

The same flat result appeared.

She had wanted the first signal to mean that the beans were managing the storm's damage: slowing repair elsewhere, advancing reproduction, making a workable adjustment to a hostile place. But injured plants could flower early too. A last expenditure, not an improvement.

One leaf supported her hope. Another did not. Neither told her what would fill a pod.

She was still looking at the traces when Pavel came through the greenhouse door carrying a tablet against his chest.

"I need a yield estimate."

"You have the schedule."

"I have a schedule that assumes those trays produce beans in five weeks." He nodded toward the sealed growing enclosure. White flowers stood above the dwarf plants. "If they set now, can we hold the harvest?"

"I don't know if they'll set."

Pavel put the tablet beside her screen. He had removed the anomalous crop from the food budget entirely. A red column ran down the right side.

"We can cover most of it with stores. Not all. We fall below the reserve minimum eleven days before the next delivery."

Leena scrolled through his figures. No arithmetic mistake offered itself.

"Replacing them today wouldn't close that gap," she said.

"No. Replacing them yesterday wouldn't either. But I could have started adjusting portions yesterday."

Commander Imani entered while he was speaking. She stopped beside the bench, read the budget, then looked at Leena's assay display.

"Which result is this?"

"The repeat."

Imani opened Leena's progress report on her wrist screen. "You wrote that the initial screening suggested a coordinated stress response."

"It did."

"And these?"

Leena could have explained tissue variation, sampling noise, the weakness of any conclusion drawn from so few plants. Each explanation was true. None answered the question.

"They conflict."

"They aren't in the report."

"I wanted to settle it before—"

"Before I saw it?"

The ventilation hummed through the pause. Leena remembered committee rooms on Earth, how quickly a qualification became a reason to stop listening. She had learned to arrive with every loose end tied down.

Here, Pavel had been counting meals from what she chose to tell them.

"I thought another assay would clarify it," she said.

Imani glanced at the clock above the enclosure. "Shift change is still the deadline."

Leena lowered her eyes to the two traces. She had kept the uncertainty at her bench. It had reached everyone anyway.

There were twenty-three minutes left before shift change.

Leena sent the assay files to the crew channel without removing the failed run. She included the calibration logs, the greenhouse dosimeter readings, and the progress report she had sent that morning. Beside its claim of consistent results, she marked the two traces that contradicted it.

The commander watched the files open on the galley screen. The engineer stood by the water dispenser, holding an empty cup.

"I should have given you these when I got them," Leena said. "I thought I could resolve the disagreement before anyone needed to act on it."

"We were already acting on it," the commander said.

"Yes."

She kept her hands away from the screen. She wanted to point out the stronger trace, explain why she had trusted it. Instead she waited while they read.

"The flowers are early," she said at last. "That's the observation. It doesn't establish that the storm caused the change. It doesn't prove the plants are safe, and it doesn't prove they've adapted usefully. Early flowering could leave us with fewer beans, or none."

"So your recommendation is destruction?"

"My recommendation is to retain two plants for a test. Not to return the crop to production."

She opened a blank work order.

"The spare root-study chamber has its own air loop and waste reservoir. No connection to greenhouse drainage. Two flowering plants, each in a sealed growth vessel. Two matched controls from the unaffected batch—same cultivar, sowing date, substrate, and light cycle."

"The chamber's return valve leaks," the engineer said.

Leena stopped typing.

"Then independence is a requirement, not an assumption. If you can't certify the loop before transfer, this proposal fails."

The engineer set down the cup and leaned toward the screen.

Leena entered sampling dates: baseline at transfer, then days three, seven, fourteen, and twenty-one. Flower counts, pollen viability, leaf damage, pod set. Genetic assays with the failed replication attached, not replaced.

"Destruction thresholds go in writing before anything moves," she said. "A failed containment check. Any pollen detected outside a growth vessel. A positive result in the chamber's waste trap. No discretionary extension from me."

"And if the results disagree again?" the commander asked.

"They stay in the record. No release to production or the seed bank. We review them together."

The commander looked at the remaining time, then back at her.

"Put down who can stop the test."

Leena added a line beneath the thresholds.

"Any of us," she said, and turned the screen so they could amend it.

Imani added a second authorization field beneath Leena's name.

"Two signatures to open either enclosure," she said. "Mine or the engineer's, as well as yours. A failed seal ends that sample."

Leena read the amended lines. Once, she would have heard only the restriction.

"Agreed."

Imani signed. "Proceed."

They worked through the last hour of the shift. The engineer brought two transparent culture chambers from stores and fitted each with its own filtered air line and sealed drainage reservoir. Neither would return water to the greenhouse loop. Leena selected two plants from opposite ends of the affected tray, recording their positions before she touched them.

One had three white flowers. The other had a single bloom tucked beneath a leaf.

She lifted each root plug into a separate chamber. Imani checked the labels against the tray map; the engineer tested the seals. They waited together while the pressure readings settled.

Only after both chambers passed did Imani release the sterilization cycle for the remaining crop.

Leena helped load the plants into the treatment vessel. Their stems bent against her gloves. There were unopened buds she had not counted, and she felt the old impulse to ask for another hour.

Instead she checked the vessel inventory against the number destroyed.

The lid locked. On its small display, the temperature began to rise.

By the time they finished cleaning the empty bed, revised ration allowances were posted beside the galley hatch. The missing beans had become smaller portions and another week of stored protein. Someone had penciled the new meal quantities underneath, then checked the arithmetic twice.

In the observation rack, the engineer installed ordinary dwarf beans from an unaffected tray. Their chambers matched the other two: light, temperature, water, handling. Leena checked the settings while he read them aloud.

"Anything else?" he asked.

She looked at the four chambers. "Not that I know of."

At the terminal, she opened a log with crew-wide access. She attached the original assay files, including the conflicting results, then entered the failed replication. Under observations, she recorded flower counts and leaf condition. Under unknowns, she wrote that the cause of early flowering remained undetermined.

She left yield and inheritance unestimated.

Imani stood beside her as she entered the next inspection time.

"If nothing changes?" the commander asked.

"We record that too."

Leena saved the entry. Behind them, a fan started inside one of the sealed chambers. The single flower trembled in the airflow, and then held still.
