The breaker kicked back before Ruth could take her thumb away.

“Don’t,” she told Mr. Ahmed, who had leaned over her shoulder. “It’s hot.”

“So is my apartment.”

On the stairs behind him, Mrs. Ortiz held a packet of frozen peas against her neck. Two boys sat with their feet in a roasting pan of water. For three days the building had kept the heat of the day before, and everyone had begun bringing things into the stairwell: chairs, chargers, grievances.

“Who’s using the landing outlet?” Ruth asked.

No one answered. Then an air conditioner stopped somewhere above them.

She reset the breaker. This time it held, though the panel kept humming.

A green bird dropped onto its open door.

Mrs. Ortiz cried out. The bird spread its wings, panting, and Ruth caught it in the towel she carried for hot pipes.

“Elena’s,” Mrs. Ortiz said. “I heard him earlier. Thought she had him upstairs.”

Captain bit Ruth through the towel.

“Glad somebody’s comfortable.”

Her phone vibrated.

Mateo: Can I leave our door open?

Stay inside. Coming soon.

He was ten. She had left him with a puzzle, two bottles of water, and instructions not to use the stove. Their apartment was behind the laundry, where the dryers made the bedroom wall hot even after they stopped.

Captain twisted toward the basement steps.

“Ruth,” he said.

She looked down at him.

“Ruth. Open the door.”

Not Elena’s bright greeting voice. Something thinner.

“When did you last see her?” Ruth asked Mrs. Ortiz.

“Yesterday, I think.”

At the foot of the stairs, three fresh boards crossed the basement door. Sawdust dusted the sill.

Yesterday there had been only the padlocked hasp.

Ruth touched a screw head. Captain stretched toward the door.

“Open the door.”

“What are you doing?”

Voss stood on the landing above, his car keys hooked over one finger.

“Looking for Elena.”

“She’s not here.”

“Her bird is.”

“Then put it somewhere.”

“Why’s this boarded?”

“People have been getting into storage.”

He came down two steps. His shirt was damp under the arms, but he smelled of the cold interior of his car, leather and aftershave.

Ruth had collected Elena’s envelope on Monday: six hundred and fifty dollars, cash. Voss required her to enter it as storage rental. Elena cleaned offices overnight. Her room at the back of the basement had a flowered curtain and a hotplate Ruth had once repaired.

“She pays you,” Ruth said.

“For storage.”

“Where is she?”

“Am I supposed to keep track of everyone?”

Across the landing, the electrical cupboard buzzed more loudly. Ruth glanced at it.

“I need an electrician. I sent you the pictures.”

“And I said tomorrow.”

“The main connection’s getting hot.”

“Then tell people to turn things off.”

She shifted Captain against her hip and took her screwdriver from her belt.

Voss’s expression changed.

“Touch those boards and I’m calling the police.”

“I work here.”

“At my discretion.”

From upstairs came a shout about a leaking kitchen ceiling. Usually Ruth would already have been climbing, asking whether the water was clean.

Voss lowered his voice.

“Your apartment comes with the job. Think before you make a situation.”

She put the screwdriver away.

“Good,” he said. “Go see to your boy.”

In their kitchen, Mateo was sorting blue puzzle pieces into a cereal bowl. He looked at the towel.

“Is that a bird?”

“Temporarily.”

Mrs. Ortiz had lent her an old travel cage. Ruth settled Captain inside with water in a jar lid, then searched her messages.

Three weeks earlier: Put exterior hasp on rear basement room. Occupant leaving door unsecured. I’ll handle key.

Her reply: Done.

She remembered fitting the metal plate while Elena slept somewhere else after her shift. A pair of slippers stood beneath the chair inside. Ruth had measured twice so the screws would go in straight.

“Are we keeping him?” Mateo asked.

“No.”

“Why are you mad?”

“I’m thinking.”

He pushed a blue piece into a gap. It did not fit, but he pressed harder.

“Don’t force it,” Ruth said, too sharply.

She took her hand off the phone.

“Get your sandals. We’re going to Mrs. Chen’s.”

Mrs. Chen had a battery fan and a couch with a sheet over it. Ruth asked her to keep Mateo and the bird.

“How long?”

“I don’t know.”

Mrs. Chen looked at her, then opened the door wider.

Back downstairs, Ruth knelt beside the ventilation grille near the basement entrance. One corner was already loose; she had bent it back for years instead of replacing the stripped screw. She removed the other screw and pulled.

Hot air touched her face. The short duct opened into the basement corridor.

“Elena?”

Nothing.

“It’s Ruth.”

A scrape, then a voice close enough to make Ruth reach into the duct.

“Is he gone?”

“Yes.”

“Don’t tell him I called you.”

“Are you hurt?”

“I keep getting sick.”

“Can you get to the door?”

“I’m here.”

Ruth lay on her side. Through the inner grille she could see concrete and the edge of a bare foot.

“What happened?”

“He came about the increase. I told him I’d spoken to housing. He said if it was storage, I should stop living in it.”

“When?”

“This morning. Before nine.”

It was nearly five.

“He shut it. Then I heard the drill. I thought he’d come back.”

Ruth gripped the grille.

“Why didn’t you call?”

“My phone’s in the room. That door shut behind me. The latch—”

The latch Ruth had promised to fix. It caught unless you lifted the handle.

“I heard people,” Elena said. “I kept calling. Captain was out here with me. He went up the stairs.”

Ruth thought of the air conditioners, televisions, everyone calling her name.

“I have him. He’s safe.”

“The fan stopped. Can you open it?”

“Yes.”

Ruth called emergency services from the bottom step.

“A woman’s locked in a basement. The owner boarded the exit. She’s been in there since this morning. She’s dizzy, and we may lose power.”

The dispatcher asked the address, whether Elena was conscious, whether there was smoke.

“No smoke. An electrical panel’s overheating.”

“Don’t enter the basement.”

“I won’t.”

“Who sealed the door?”

“The landlord. That’s what she says. He’s here, and he won’t let me open it.”

She gave Voss’s name. Saying it to someone who was writing it down felt different from saying it in the building.

When Ruth stood, he was above her.

“Who did you call?”

“Fire department.”

“You should have called me.”

“You were here.”

“I told you it was empty.”

“She’s at the door.”

He glanced toward the street entrance.

“Then she went in after the contractor finished.”

“The boards are outside.”

“You don’t understand what you’re getting involved in.”

Ruth started up the steps toward him.

“Give me the key.”

He did not move.

Above them, Mrs. Ortiz opened her door.

“Ruth? Is the water supposed to be off?”

“Please come down.”

“What’s wrong?”

“Elena’s locked in the basement. I need someone else to hear her.”

Voss turned.

“This is a maintenance matter.”

Mrs. Ortiz came down in her slippers. At the next landing, Mr. Ahmed appeared with his phone.

“Don’t film me,” Voss said.

“Give me the key,” Ruth repeated.

He looked at the phone. Then he took a ring from his pocket and held it out, not quite within reach.

“You’re responsible for anything damaged.”

She took it.

“The brass one?”

He nodded.

Ruth fitted the screwdriver into the first screw. She had a drill upstairs, but going to get it meant leaving Elena and leaving Voss.

“Mr. Ahmed, can you get my tool bag from Mrs. Chen? Outside her door.”

He hesitated.

“Keep your phone here,” she said.

He set it on the stair rail, camera facing them.

Mrs. Ortiz crouched beside the vent.

“Elena? It’s me.”

A faint answer.

“I’m staying right here,” Mrs. Ortiz said.

The first screw came out. The second fought her. Ruth pressed the heel of her hand against the driver until the slot caught.

“You could have waited,” Voss said.

Ruth kept turning.

“Eleven years,” he said. “Have I ever put you out?”

The board dropped. She started the next one.

She thought of the ledger upstairs, the envelopes, the inspection notices he asked her to leave in his office. Once she had moved Elena’s hotplate into a tool cabinet before an insurance visit. Elena had thanked her afterward.

The landing light dimmed.

“Everyone unplug your air conditioners!” Ruth shouted.

A door slammed upstairs. Somewhere a child began to cry.

The light went out.

So did the humming panel. In the sudden quiet, Ruth heard Elena dragging a breath.

“I’m here,” Ruth said.

Mrs. Ortiz switched on her phone’s light and held it over Ruth’s hands.

Mr. Ahmed returned with the bag. Ruth found the drill by touch, set it low, and backed out the remaining screws. The last board struck her shin.

She unlocked the hasp she had installed.

The door opened half an inch and stuck.

“Move away from it, Elena.”

“I can’t stand.”

“Just move your feet. As far as you can.”

Ruth pulled until the handle cut into her palm. The frame had swollen tight around the door.

Boots sounded in the stairwell.

“Here,” Mr. Ahmed called. “Down here.”

A firefighter moved Ruth aside. She showed him the gap, told him where Elena was, then pressed herself against the opposite wall while another firefighter spoke through the opening.

Voss began explaining about unauthorized occupancy.

“Outside, sir,” the firefighter said.

The door gave with a wooden crack.

They brought Elena out between them, her feet dragging. She wore a blue nightdress and one plastic sandal. Ruth had seen that nightdress drying behind the flowered curtain.

Elena’s hand caught Ruth’s shirt.

“I called you.”

“I know.”

“All day.”

“I know,” Ruth said again, though she had not known, and had been close enough to hear.

In the courtyard, neighbors moved their chairs for the stretcher. Mrs. Chen stood near the gate with Mateo and Captain’s cage. The bird whistled, and Elena lifted her head.

“He’s here,” Ruth told her.

A paramedic fitted an oxygen mask over Elena’s face. Her hand rose toward the cage, then settled against the sheet.

Voss came through the side entrance talking into his phone.

“Apparently the superintendent permitted someone to occupy storage.”

Ruth opened their message thread.

Orders for the hasp. Elena’s payments. The complaint about the latch. Her photographs of the scorched electrical connection, followed by Voss’s reply: Don’t bring the city into every little thing.

And her own: I’ll handle it.

She sent the thread to Mrs. Ortiz and Mr. Ahmed, then the photographs of the rent ledger.

Mr. Ahmed looked at his screen.

“You want me to cut the video? The part where he—”

“Keep all of it.”

A fire lieutenant asked Ruth who had keys. She held up the ring. He asked about the boards, then the padlock.

“I fitted the hasp,” she said. “Three weeks ago.”

“On an occupied room?”

“Yes.”

Behind him, Voss stopped talking.

Ruth gave the lieutenant her full name and showed him the messages. He photographed the screen, but said someone else would need to take her statement.

When he moved away, Voss held out his hand.

“Staff keys.”

Mateo stood close enough that Ruth could feel the cage brushing her leg.

She separated her apartment key from the ring. There was no lease in her name, only eleven years of wages with the room deducted.

“We’ll discuss that tomorrow,” Voss said.

She put the remaining keys in his hand.

“Can we go home?” Mateo asked.

Above the laundry, their windows were dark. The towels she had hung that morning still covered the bars.

“In a little while.”

Her phone vibrated.

Mrs. Ortiz: I have them.

At the gate, the paramedics lifted Elena into the ambulance. Ruth raised her hand so Elena could see where Captain was, though she could not tell whether Elena saw her.

Voss was making another call.

Ruth put the apartment key deep in her pocket and stayed beside her son.