Nuno began with the cloakroom, where information was exchanged more freely than umbrellas.

“The woman from catering?” said the attendant. “Asked for the cannon technician three times. Very persistent. Then out through the service entrance, carrying her jacket.”

“Perhaps she dislikes artillery.”

“Perhaps she dislikes being told to ask someone else.”

Nuno contributed a scandal concerning a tourist’s allegedly therapeutic ferret, then went looking for the technician.

He found him kneeling beside a speaker, holding a screwdriver with the exhausted tenderness of a man considering another profession.

“Seabra wanted the microphone fixed,” the man said. “Urgently. Apparently donors cannot give unless they hear themselves thanked.”

“And the cannon?”

“Only I load it. Only I approve it. That was the arrangement.”

“Was?”

The technician glanced towards the gallery. “I haven’t approved anything.”

Beside the cannon, a floral arrangement had acquired the proportions of an admiral’s funeral. Under its lowest fern lay the red warning tag Nuno remembered. He lifted it by its string.

Beneath the printed warning, someone had written: CHECK BARREL.

“Temporary staff,” Seabra said behind him, “sometimes become dramatic when corrected.”

Nuno turned. “An inexpensive precaution.”

“The cannon is to be polished and ready. Not dismantled.” Seabra extended his hand for the tag.

Nuno surrendered it. He had already read it twice.

At the catering desk, he explained that a tourist had lost something and that the woman who had left earlier might have picked it up. A supervisor supplied Bia’s company number.

Outside, beneath a stone navigator pointing confidently away from the trouble, Nuno typed an old phrase:

Coffee, no saucer.

Once, it had meant he wanted a conversation, not a share.

He added his name. Respectability had made him cautious; it had not made him memorable to everyone.