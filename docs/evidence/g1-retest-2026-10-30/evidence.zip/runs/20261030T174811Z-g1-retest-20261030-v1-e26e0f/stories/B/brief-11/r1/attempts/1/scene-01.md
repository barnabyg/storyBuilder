Mina set the towels in stacks of twelve, folded edges toward the aisle. She pressed her palm on each stack, correcting a lean only she would have noticed. In the staff kitchen she filled the kettle and put out two mugs, the white one and the brown one with a chip beneath its handle. Then she returned the brown one to the cupboard. There was no reason to wash it again.

The bathhouse had opened in 1924. On its last morning, the pipes knocked behind the kitchen wall as they always did.

Beside the closure notice, someone had pinned six pages of auction inventory. Mina read past benches, lockers, brass coat hooks. Halfway down the second page was “decorative tile panel, removable.”

She took her glasses off, wiped them on her tunic, and read it again.

Lot 63. In the entrance hall, a yellow sticker bearing that number had been stuck above the old drinking fountain. The fountain had been dry for eleven years, but the tiled tree around it still spread green branches over the basin and onto the adjoining wall.

Mina followed a branch with one finger. The donor names were worked into the leaves and trunk: E. Baines, the Iqbal family, St. Agnes Laundry Workers. Some names occupied a single tile; others crossed the joins. She traced Okonkwo around the corner, where the tree widened beyond the fountain’s alcove.

A surveyor’s chalk line ran straight down through Feldman, Pereira and Bell. She photographed it, then stepped back and photographed the whole wall.

The site manager came in carrying a carton of key tags.

“Withdrawals need board approval,” he said when she showed him the inventory. “Four o’clock meeting. I can send them a query.”

“It isn’t a panel.”

He looked from her phone to the wall.

“Put that in writing, Mina. I can’t change the lots myself.” He shifted the carton. “And leave the handover sheet on my desk. Payroll’s waiting for my confirmation before they release your severance.”

She lowered the phone. The kettle clicked off in the kitchen.