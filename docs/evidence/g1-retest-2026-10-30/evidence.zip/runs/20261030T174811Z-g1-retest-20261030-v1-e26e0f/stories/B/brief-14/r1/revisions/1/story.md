"Observe the figurehead," Nuno Vale told his tourists.

Twelve faces tilted towards the gilded woman above the gallery door. Nuno transferred the museum leaflet from his left hand to his right.

"And that is how sailors lost their wages ashore. Everybody watches the pointing hand."

A German gentleman checked his wallet.

"Pure theatre," Nuno assured him.

This was true now. He paid taxes, wore comfortable shoes and had acquired a reputation for getting school parties through maritime history without casualties. His former profession survived chiefly as an understanding of where people weren't looking.

Director Seabra approached between the model frigates.

"Stay a moment, Vale. We're rehearsing tonight's finale."

A replica cannon faced the rows of chairs laid out for the donor gala. Beside it, a technician held a brass cap.

"Compressed air," he explained. "Paper ships only. Nothing solid in the barrel."

"Discovery raining upon generosity," said Seabra.

"Does generosity know?" Nuno asked.

The technician unscrewed the cannon's loading hatch. On the worktable stood a tray of folded paper ships and an open display case containing a tiny brass compass. Its velvet-lined lid had been propped upright.

"Our star object," Seabra said. "The case lock is being repaired. Naturally it will be secured before the guests arrive."

The technician set the cap beside it.

"Those could be brothers," Nuno said.

"Except one has threads," said the technician. "And neither goes inside."

A microphone shrieked at the far end of the gallery.

Seabra winced. "Please fix that. I'll arrange the ships."

"Don't load anything. I haven't checked the—"

But the director was already straightening the paper boats, turning their prows towards the photographer. Nuno saw him move the brass cap into the velvet recess to clear a space.

A catering worker near the door lifted one hand towards Seabra. With the other, she straightened her cuff.

Nuno knew that small adjustment. Bia used to make it before entering a crowd.

He turned back to his tourists.

"Now," he said brightly, "the Portuguese discovery of the world. Which came as a considerable surprise to the people already living in it."

His smile lasted until Seabra found him at the ticket desk.

"A private word."

"My group is waiting."

"They can look at the rope."

"They've paid for maritime history."

"It's historic rope."

In his office, Seabra opened a security clip on his laptop.

The frame showed a crowded corner of the navigation gallery. Bia reached behind the display's raised lid, brought out a small brass object and tucked it into her apron.

Nuno recognized the movement before the face: elbow close, wrist relaxed. Shelter the object, never clutch it.

"The compass," Seabra said. "Five hundred euros for its recovery. You know everyone around here."

"Not everyone. Lisbon keeps producing people."

"Then exercise your celebrated eye."

Nuno leaned closer. The picture was cropped tightly. A sleeve appeared at its left edge; Bia's raised palm was directed towards whoever wore it.

"Could I see the minute before this?"

"This is the relevant part."

As Bia stepped away, something circular gleamed in the compass's velvet recess.

The loading cap.

"Has anyone checked the cannon?"

Seabra closed the laptop halfway.

"I'm asking about a theft."

"And I'm asking about a cannon. Maritime history has room for both."

"The technician is dealing with it."

"May I speak to the woman?"

"If you can find her. She's left."

"Has she?"

Seabra regarded him. "I need a simple explanation before the donors arrive, Vale. Not one of your entertaining digressions."

Outside, Nuno told his tourists that the final ten minutes of their tour were being refunded.

The German gentleman looked disappointed.

"Will we miss a story?"

"I'm afraid," Nuno said, "I haven't got the ending yet."

The cloakroom attendant had seen Bia leave.

"She asked for the cannon man three times. Then the director told her agency there'd been a theft."

"Before or after she left?"

"Before. She heard him. Went white."

Nuno found the technician under a speaker, his screwdriver clenched between his teeth.

"Have you checked the cannon?"

"No. Now the lectern's buzzing."

"The director says you're dealing with it."

The technician removed the screwdriver. "The director has a generous understanding of my whereabouts."

In the gallery, the cannon's hatch was shut. A red warning tag lay beneath a fern in the enormous floral arrangement beside it.

DO NOT FIRE.

Below, in ballpoint: CHECK BARREL.

Nuno lifted it by the string.

"Catering staff are not qualified to interfere with equipment," Seabra said behind him.

"Yet qualified to identify it."

"She was told to leave it alone."

"And did you check?"

"The cannon will be checked."

Nuno looked at the empty chairs. Little gilt cards reserved the front row for the museum's principal benefactors.

He put the tag over the firing lever.

Seabra waited until Nuno turned away before removing it.

Getting Bia's number from the catering supervisor required a story about a lost bracelet and considerable sympathy concerning unreliable casual staff. Nuno disliked the story but told it well.

Outside, beneath a stone navigator pointing confidently across the street, he sent a message.

Coffee, no saucer. Nuno.

It had once meant he wanted a conversation, not a share.

Her reply came quickly.

Opposite. And don't bring anyone.

Bia sat at the café window in black catering clothes and shoes chosen for standing, not escape.

"You look prosperous," she said.

"These are washable trousers."

"That's how it starts."

He sat.

"Do you have the compass?"

"Yes."

"Were you planning to mention that to someone?"

"I tried. Apparently I was hired to put olives on things."

Nuno glanced towards the museum.

Bia stopped stirring her coffee.

"I saw him put something in the cannon that wasn't paper. I went over. He told me not to fuss in front of visitors. So when he turned away, I took it out."

"The compass."

"I put on the warning tag and went to find the technician. By the time I came back, Seabra was on the phone telling my agency to send somebody trustworthy."

"Why leave?"

"Because he asked whether they'd checked my record."

Neither spoke for a moment.

Nuno could hear cups being stacked behind the counter.

"I was going to ring the agency from here," she said. "Explain before they stopped answering. Then I thought about how it sounded. I took a valuable museum object home for safety."

"You haven't gone home."

"No. Apparently I'm waiting for a better sentence."

"Give it to me. I'll return it."

"And what does he call me afterwards?"

"I won't give him your name."

"He already has my name. I want him to stop calling me a thief."

That landed more cleanly than she could have intended.

Nuno had spent years making his old skills sound like amusing research. He knew how swiftly an institution could turn a history into a verdict.

"Come back in half an hour," he said. "Bring the compass."

"Why?"

"Because I'm going to make him watch the part before the theft."

Seabra was arranging champagne glasses when Nuno returned.

"I can recover it," Nuno said.

"Excellent. Who has it?"

"First, preserve the complete security recording."

"The relevant extract is preserved."

"Then preserving the rest should be easy."

Seabra put down a glass.

"I recommended you to this museum, Vale. Your references were unusually brief."

"They concerned my work."

"I'd hate to discover an omission."

For a moment Nuno saw everything Seabra could touch: his regular tours, his arrangement with the hotels, the small flat whose rent had become comfortably predictable.

Beyond the director, the gala coordinator was advancing with a clipboard.

Nuno raised his voice.

"Before the guests enter, has the cannon been certified safe?"

The coordinator stopped.

"It will be," Seabra said.

"The warning tag has been removed twice."

"By whom?" she asked.

Nuno looked at Seabra. He offered him no distraction.

The coordinator called the technician over.

"Disconnect it," she said.

"We're already behind schedule," Seabra protested.

"Then we're fortunate to have found something we're not doing."

The technician shut the air valve and uncoupled the hose. Only then did Nuno notice how tightly he had been holding his hands.

"And the full security recording," he said. "Please."

The coordinator looked from him to Seabra.

"The insurer will want it," she said.

That, apparently, was an argument with professional qualifications.

They watched the recording in the security room.

The full view included the cannon, the display and Seabra standing between them.

He moved the loading cap into the compass's velvet recess. Then, gathering the paper ships into the tray, he swept up the little brass compass with them.

On the screen, Nuno's tour group passed in front of the camera.

When they cleared it, Seabra tipped the tray through the open loading hatch.

Bia approached. Her hand rose.

Seabra waved her away without looking up from his telephone.

She waited until he left, reached through the hatch and drew out the compass. The display lid concealed the opening from the camera.

From the cropped camera, Nuno corrected himself.

Bia attached the warning tag. She spoke to a passing attendant, then hurried away.

The technician leaned towards the monitor.

"Stop it there."

The image froze on the open hatch.

"That's where the load goes," he said.

Seabra inspected his cuffs.

"The paper would have cushioned it."

"No," said the technician.

"It's very small."

"So is a bullet."

In the silence that followed, somebody knocked.

Bia stood in the doorway with a supermarket bag. She removed a parcel wrapped in a catering napkin and set it on the desk.

Nobody reached for it.

"You took an irreplaceable object out of the museum," Seabra said at last.

"You were going to fire it at the people paying for the roof," Bia said.

The coordinator sat down.

Nuno almost did too. Instead, he watched the director look towards the monitor, where his own hand remained poised above the loading hatch.

"You recognized the cap in the case," Seabra said.

"Eventually," Nuno replied. "You?"

Seabra said nothing.

"You could have stopped the preparations."

"There would have been questions."

"There still are."

The coordinator took a pen from her clipboard.

"We'll start with the agency," she said. "You're withdrawing the allegation in writing."

"And paying the shift," Nuno said.

Bia looked at him.

"The whole shift," he added.

Seabra's mouth tightened. "The reward was offered for recovery."

"Which has occurred," said the coordinator.

Nuno had never liked her more.

By six, the cannon was locked in a storeroom. Volunteers handed paper ships to the arriving guests. Several donors seemed relieved not to be required to enjoy an explosion.

At the lectern, Seabra gripped his prepared speech.

"A member of our event staff prevented an unsafe loading error this afternoon," he said. "The responsibility was mine. Our compass has been safely returned."

He paused, perhaps hoping for applause.

Nuno stepped forward.

"We had intended to finish with a cannon," he told the guests. "Instead, you'll have a story. Quieter, though not necessarily shorter."

A woman in the front row laughed.

He told them about navigation: about pilots who distrusted a confident bearing, and lookouts whose chief qualification was being somewhere the captain wasn't.

At the back, Bia accepted a paper ship from the coordinator.

Afterwards, Nuno divided the reward beneath the cloakroom lamp.

"You could have kept it," Bia said.

"The money?"

"The compass."

She smiled. He slid half the notes towards her.

On his next tour, the repaired case contained both the compass and a small new label describing how an event worker had prevented a dangerous accident.

The German gentleman had returned with his wife.

"So," he said, reading it, "you found the ending."

Nuno glanced at the label. The director had wanted "procedural irregularity." The coordinator had insisted on "loading error." Bia had asked only that they spell her name correctly.

"Yes," Nuno said. "Though several people tried to help me lose it."
