Seabra was supervising the alignment of champagne glasses when Nuno returned.

“I can recover the compass,” Nuno said. “But I won’t identify anyone until the complete recording is preserved.”

“The relevant extract is preserved.”

“Then the irrelevant parts should be easy.”

Seabra lowered his voice. “I could tell the police how unusually knowledgeable my guide appears to be.”

Nuno felt his respectable life contract to the width of a handcuff. Behind Seabra, the gala coordinator arrived carrying a clipboard and three expressions of distress.

He let her come within earshot.

“Has the cannon received its required safety check?” he asked the technician.

The technician stopped coiling a cable.

“What safety check?” said the coordinator.

“The compressed-air display,” Nuno said. “Before we fire paper ships over our principal benefactors.”

“It isn’t a weapon,” Seabra said.

“Excellent. Let’s establish that while nobody is standing in front of it.”

The coordinator put down her clipboard.

Seabra looked at her, then at the technician. “Isolate the air supply. Briefly.”

“And I’ll fetch the complete recording,” she said.

The technician shut the valve and disconnected the hose. Preparations stopped around him, reluctantly, like traffic encountering a fallen wardrobe.

At the monitor, the full recording began several minutes before the familiar clip.

Seabra appeared beside the cannon. He removed its loading cap and set it in the velvet recess. Turning back, he picked up the similarly sized brass compass instead. He dropped it through the loading hatch, then poured in the paper ships.

Nobody spoke.

Bia entered the frame. She raised a hand. Seabra waved her away without turning.

She waited until he moved, reached through the still-open hatch, extracted the compass and attached the warning tag.

The coordinator checked the cropped clip’s boundaries.

Both Seabra’s mistake and Bia’s warning fell outside them.