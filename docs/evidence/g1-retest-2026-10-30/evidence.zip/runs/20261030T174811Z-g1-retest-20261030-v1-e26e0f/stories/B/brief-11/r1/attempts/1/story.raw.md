Mina set the towels in stacks of twelve, folded edges toward the aisle. She pressed her palm on each stack, correcting a lean only she would have noticed. In the staff kitchen she filled the kettle and put out two mugs, the white one and the brown one with a chip beneath its handle. Then she returned the brown one to the cupboard. There was no reason to wash it again.

The bathhouse had opened in 1924. On its last morning, the pipes knocked behind the kitchen wall as they always did.

Beside the closure notice, someone had pinned six pages of auction inventory. Mina read past benches, lockers, brass coat hooks. Halfway down the second page was "decorative tile panel, removable."

She took her glasses off, wiped them on her tunic, and read it again.

Lot 63. In the entrance hall, a yellow sticker bearing that number had been stuck above the old drinking fountain. The fountain had been dry for eleven years, but the tiled tree around it still spread green branches over the basin and onto the adjoining wall.

Mina followed a branch with one finger. The donor names were worked into the leaves and trunk: E. Baines, the Iqbal family, St. Agnes Laundry Workers. Some names occupied a single tile; others crossed the joins. She traced Okonkwo around the corner, where the tree widened beyond the fountain's alcove.

A surveyor's chalk line ran straight down through Feldman, Pereira and Bell. She photographed it, then stepped back and photographed the whole wall.

The site manager came in carrying a carton of key tags.

"Withdrawals need board approval," he said when she showed him the inventory. "Four o'clock meeting. I can send them a query."

"It isn't a panel."

He looked from her phone to the wall.

"Put that in writing, Mina. I can't change the lots myself." He shifted the carton. "And leave the handover sheet on my desk. Payroll's waiting for my confirmation before they release your severance."

She lowered the phone. The kettle clicked off in the kitchen.

Mina poured the kettle into the teapot and left it standing. On a sheet from the incident book she wrote: We, the undersigned, demand that nothing in the bathhouse be disturbed pending consultation with its users.

By nine, steam had softened the windows. She carried the sheet on her clipboard to the bench beneath the broken clock, where Mr. Bell was folding his trousers along the creases. Thirty-eight years on the buses, and he still arrived at seven minutes past.

"About the closure," she said.

"Disgrace," he said, and signed before she could steady the board.

She took his quickness as encouragement. At the hooks beside the women's entrance, Leila was hanging her coat inside out, keeping the lining clear of the wet wall. Mina had already put the rubber mat in the corner shower for her.

"We're asking them to leave things alone."

Leila read the sheet. "I can't sign this."

"It's the last morning. They could at least—"

"I'm on their waiting list, Mina. The housing people. Have been since February."

From the showers came the knock of a dropped soap dish. Mina glanced toward it, grateful for something she knew how to attend to.

"I only mean the mural."

Leila held the clipboard between them and put a finger under nothing.

"Does this mean the boilers? The roof? Would keeping your wall hold up the flats?"

Mina had written the demand at the same desk where she recorded deliveries, with the same confidence that a clear entry prevented mistakes. Now she saw how much she had left unclear.

She unclipped the paper and tore away the blank space below Mr. Bell's signature. On that piece she wrote, slowly: Preserve the donor mural in the redevelopment. This request does not seek to reopen the bathhouse.

She did not offer it for signing.

"If it stayed," she asked Leila, "what would being able to see it actually require?"

Leila kept hold of her towel.

"Who would have the key?" she asked.

No one answered. Mina folded the petition beneath the counter and went to change the laundry.

Between loads she opened the lost-property contact book. Some entries had ticks beside them: spectacles collected, scarf posted, owner deceased. Her husband's handwriting appeared on a loose slip he had brought her lunch on. She turned it face down.

"This is Mina Okafor, from the baths," she said when the first person answered. "I'm calling about the tiled mural. Would you be willing to talk about it? You needn't sign anything."

Two people declined. One asked whether his swimming trunks were still there.

Mrs. Bennett sent a photograph. Her mother stood beside the newly completed tiles, holding a handbag against her stomach. The names were sharp behind her; at the bottom of the photograph, someone's thumb obscured a corner.

"She cleaned houses to give that money," Mrs. Bennett said. "Please keep the photograph safe."

Mr. D'Souza remembered the collection differently.

"It was for a boiler. We were tired of cold water."

"Your father's name is on the wall."

"Yes. He enjoyed that. I didn't like names being put up. People who couldn't pay used the baths too."

Mina stopped writing, then put down his last sentence.

Leila returned while the sheets were spinning. She held out her phone, displaying a photograph of the housing proposal pinned inside the library.

"Look. That's the street."

A narrow passage ran through to a courtyard. Beside it was the thick line of the mural's existing wall.

Mina enlarged the image. "Does that mean it stays?"

"It means they've drawn a passage there."

Mina fetched the tape measure. She measured width and height twice, then photographed the masonry at each edge, including the places where tile disappeared beneath later plaster.

On the office computer she made two folders: WALL—MEASUREMENTS AND PHOTOGRAPHS; PATRONS—ACCOUNTS AND IMAGES. Mrs. Bennett's photograph went into the second.

She checked the labels. Then she returned to Mr. D'Souza's sentence and left it exactly as he had said it.

The site manager found her copying the inventory beside the towel ledger.

"Is this for a protest?"

"It's a record of what's being sold."

He looked at the telephone, then at the names on her pad. "Work time, Mina. Patron records. If there's a complaint, I can't sign off a clean handover." He lowered his voice. "Your final payment depends on that paperwork."

She put the receiver back in its cradle. The last number remained undialled.

Before the remaining bathers left, she asked each contributor separately: could she give their words, photographs and names to the board? Mrs. Bell agreed to the photograph but not her address. Mr. D'Souza wanted his whole sentence included. Two people declined. Mina crossed them off without asking why. Those already gone she messaged from her own phone, using only numbers they had given her that morning.

At three she clocked out. She left the towel count unfinished, with a note explaining where she had stopped.

The copy shop smelled of hot paper. She paid from the envelope marked NOVEMBER, counting out enough for twelve sets and a large print of Leila's plan. The money had been intended for groceries during her first month without wages. She asked for a receipt.

The retired bus driver arrived as she was sorting the pages. Under his arm was a placard: SAVE OUR BATHS.

"I won't take that into the meeting," Mina said.

"You're settling before they've even said no."

"They've said the baths are closing."

"So you do their work for them?"

She squared the copies against the counter. "I'm asking for something they can still do."

Leila spread the plan between the stapler and the till. Together they found the proposed public passageway. Mina held the paper while Leila traced the existing mural wall.

In the margin Mina wrote one request: withdraw mural from auction; retain wall in public passageway; no reduction in housing capacity.

"Not the whole room?" Leila asked.

Mina looked at the line they had drawn.

"The wall."

"We will not discuss reopening," the chair said. "That decision is final."

"The bathhouse will close today," Mina said. She had rehearsed it without today, but the word came. "This petition doesn't ask you to change that."

She passed the corrected sheets around, followed by measurements, photographs, and a plan showing the proposed passageway. Her hand paused over each stack until someone took it.

The nonprofit's project manager turned the plan toward himself. "That passage was intended to be gated. Residents need secure access."

Leila leaned forward. "I'm on your waiting list. I want a flat there." She looked at the photograph beneath his wrist. "But I don't want our names turned into an amenity behind a lock."

"The names of donors," the chair said.

"Some of their children still live here."

A board member asked whether the tiles could simply be lifted and stored until there was somewhere suitable.

Mina found the close-up. Blue letters crossed a masonry joint; the final stroke of one name occupied two tiles.

"They aren't panels," she said. "The names run across the joints. I've kept that wall clean for thirty-one years, but I can't guarantee what taking it apart would do."

The project architect drew the plan closer. With her pencil she moved the passage entrance.

"Subject to a survey, retaining it appears feasible. We wouldn't lose any homes." She tapped the elevation. "The decorative cladding allowance could go toward protection and conservation instead. We'd need to cost that properly."

Mina folded her hands.

The chair dictated the amended resolution: withdraw the mural lot from auction; make retention in a publicly accessible passageway a condition of the site agreement; install an immediate protective enclosure; commission a conservation survey before demolition.

The vote carried, with one abstention.

People began gathering their papers. Mina stayed seated while the clerk typed. When the chair asked if she needed anything else, she pointed to the screen.

"I'd like to wait until it's entered."

The clerk read it back. Mina listened to every word.

When Mina returned, the site manager was waiting at the counter with the auction inventory. He ruled a line through the mural's entry, initialled it, and handed her the signed handover form.

"The demolition crew will need your photographs," he said. "To locate the tiled edges. They can't tell from the drawings where it stops."

"I numbered them."

"Send the whole set."

She folded the form along its existing crease.

Leila helped carry the remaining towels to the collection cage by the service door. Without them, the shelves showed pale rectangles in the paint. One towel caught on a wire; Mina freed it rather than pull.

"I hope I can bring my daughter through the passage one day," Leila said. "Show her her grandfather's name."

Mina reached for the petition copies beneath the counter, then stopped.

"Would you like these?"

Leila considered the thick bundle. "Just the page he signed. If that's all right."

Mina found it and gave it to her.

After Leila left, Mina walked through the changing rooms. She checked beneath every bench, lowering herself carefully, one hand against the wood. There was a hairpin, a damp receipt, nothing anyone would come back for. In the showers she turned each tap firmly shut. The pipes knocked behind the tiles. Usually someone answered the noise with a complaint or a joke; tonight she could hear it travel.

At the mural, a strip of petition tape still clung below the lowest names. She worked it loose with her thumbnail and rolled the sticky length into a small grey bead. The conservator's survey marks remained: short blue strokes on the plaster beyond the tiled edges. She left them untouched and switched off the lights.

In the staff room, her husband's mug stood beside the kettle. She wrapped it in a clean cloth and packed it beside her own. There was room for both.

Outside, she locked the bathhouse and tested the handle once. Then she pushed the keys through the agreed letter slot and heard them land inside.