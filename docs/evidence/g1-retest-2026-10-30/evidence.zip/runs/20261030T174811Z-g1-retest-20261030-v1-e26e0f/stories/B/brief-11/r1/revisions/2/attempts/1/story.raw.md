Mina set the towels in stacks of twelve, folded edges toward the aisle. In the staff kitchen she filled two mugs before noticing what she had done. She emptied the brown one, dried it and returned it to the cupboard.

Her husband had been dead eight months. After retiring he had brought her lunch on Thursdays and stayed until she finished, drinking tea while she balanced the till. It was Friday.

Behind the kitchen wall, the pipes knocked. On the last morning of its hundred-and-second year, the bathhouse sounded ready for another hundred.

Beside the closure notice hung six pages of auction inventory. Mina read them while the kettle boiled: benches, lockers, brass hooks. Halfway down the second page she found “decorative tile panel, removable.”

A yellow sticker numbered 63 had been fixed above the entrance-hall fountain.

The tiled tree grew around its basin and onto the adjoining wall. Names occupied the leaves and branches: E. Baines, the Iqbal family, St. Agnes Laundry Workers. The collection had paid for replacement boilers in 1978. In the opening photograph, women stood in their coats holding cups while a councillor pretended to turn a valve.

Mina followed Pereira around the corner. A chalk line ran through the last three letters.

When the site manager arrived, she brought him to the fountain.

“It isn’t a panel.”

Harris checked his list. “The auctioneer assessed it.”

“Did he look round the corner?”

“He’ll have had a reason.”

She showed him the name crossing the angle of the walls. He rubbed at the chalk with his thumb.

“Send photographs. The transfer board meets at four.”

“Today?”

“Last approval before the nonprofit takes possession.”

Forty-six homes. The notice promised a lift, bicycle storage and a courtyard where the boiler house stood. Mina had pinned it straight herself.

“Can they take it out of the auction?”

“You can ask.” He handed her the handover folder. “But I need this completed tonight. Payroll needs my signature for the additional payment.”

She knew the amount to the penny. Without it, she would have to move before spring.

In the office she took a sheet from the incident book and wrote: We, the undersigned, demand that nothing in the bathhouse be disturbed pending consultation with its users.

Mr Bell signed without his glasses.

“About time.”

He was folding his trousers beneath the broken clock. For twenty-three years he had used the end locker, where he could reach the hooks without bending. Mina had never asked where he would wash next week.

Leila read the sheet beside the women’s entrance. Mina had already laid a rubber mat in the corner shower for her ankle.

“I’m on their waiting list,” Leila said.

“I mean the tiles.”

“That isn’t what you’ve written.”

A soap dish clattered in the showers. Mina turned towards it.

“Mina. My daughter sleeps beside our cooker. I won’t sign anything that holds up those flats.”

Mina looked down at her neat, unquestionable handwriting.

She crossed out the sentence. Beneath it she wrote: Preserve the donor mural in the redevelopment. This request does not seek to reopen the bathhouse.

“Where would it go?” Leila asked.

“The entrance, perhaps.”

“To the flats? Who would have the key?”

Mina lowered the clipboard.

By eleven, six people had asked about the soap, three about locker deposits, and one had cried because he had expected to come on Monday. Mina gave him a closure leaflet, then took it back.

“Would you like me to call someone?”

He shook his head. She sat beside him while he put on his shoes.

Between laundry loads she began asking about the wall. Mrs Bennett remembered her mother cleaning an extra house each week for the boiler fund. She offered to telephone former patrons.

“Tell them it’s the mural,” Mina said. “Not a campaign to keep us open.”

“That won’t please everyone.”

“No.”

Mrs Bennett sent a photograph of her mother beside the newly finished tree, handbag pressed against her stomach.

Mr D’Souza said, “We were tired of freezing. That’s why we gave.”

“Your father’s name is there.”

“He liked that part.” He considered. “People who couldn’t give belonged here too.”

Mina wrote down both sentences.

At noon Leila returned with a photograph of the development plan displayed in the library.

“There’s a passage from the street to the courtyard.”

They enlarged it on the office screen. A thick black line ran beside the proposed passage, approximately where the mural stood.

“It might be a new wall,” Mina said.

“Ask.”

Mina fetched her tape measure.

For thirty-one years she had cleaned the tree with a soft brush, keeping her fingers clear of the crazed glaze near the basin. Now she measured both walls and photographed the cracks. Behind a loose noticeboard she found a blue leaf she had not seen since the smoking ban.

Harris caught her kneeling there.

“I’ve had a call about a petition to stop demolition.”

“The first sheet was wrong. I’ve corrected it.”

“Has everyone who signed seen the correction?”

She thought of Mr Bell, still soaking his feet.

“I’ll make sure.”

Harris looked into the office. Photographs covered the towel ledger.

“The collection lorry comes at three. I can’t sign off linen I haven’t checked.”

“I’ll have it ready.”

“And if you’re going to the meeting, clock out.”

When he had gone, she sat on her hands until they stopped shaking. She could still put the photographs away. There were deposits to reconcile, thirty-one years of instructions for boilers that would never be fired again. No one had employed her to save a wall.

Then the telephone rang. A former patron wanted to know whether St. Agnes Laundry Workers was still legible.

Mina said it was.

At three she counted the last towels into the cage and showed Harris the reconciled ledger. He ticked the boxes. The keys and meter readings could wait until her return.

At the copy shop she paid for six sets of photographs and measurements from the envelope marked NOVEMBER. Leila held the plan flat while Mina wrote beside the passage: Can this remain public?

Mr Bell appeared carrying a placard.

SAVE OUR BATHS.

“Mrs Bennett said you were going to fight them.”

“For the mural. I’m sorry. I should have found you before you left.”

“You got my signature.”

“On something I shouldn’t have written.”

He stared at the copied photographs.

“So we ask for a bit of wall.”

“Yes.”

“I don’t need a wall, Mina.”

She almost promised to find him somewhere else. The nearest public showers involved two buses and stairs.

“I know it isn’t what you need.”

He turned the placard against his leg. For a moment she thought he might tear it.

She held out the revised request. “Will you read this before you decide?”

He took it but stayed outside when they entered the library.

The board met upstairs. Through the window Mina could see the bathhouse roof, patched lead flashing bright in the late sun.

The chair allowed her to distribute the papers.

“We cannot revisit the closure.”

“The baths will close tonight.”

Saying it felt like agreeing to something she had hoped might happen without her.

“But the auction describes this as a removable panel. It’s built into two walls. I’m asking you to withdraw it from sale and keep it where it is.”

The nonprofit’s project manager examined her measurements.

“We can’t accept an unlimited conservation liability.”

“We can’t lose homes,” the chair said.

Leila leaned forward. “I’m waiting for one. I want them built.”

She put her photograph of the library plan on the table.

“Could people come through here and see it?”

“That’s residents’ access. We intended gates.”

The architect, attending by video, asked for the drawing to be held closer to the camera. For several minutes the discussion went on without Mina: fire separation, drainage, the fountain projecting into the route. The passage could widen into the old reception area without altering the flats. The inner gate would have to move.

“That uses the entrance-screen allowance,” the project manager said.

“We’d retain the existing masonry,” the architect replied. “There may be a demolition saving. I’d need an engineer’s inspection.”

A board member suggested lifting the tiles and storing them until funds could be raised.

Mina put a close-up before him.

“That crack goes through three letters. I don’t know what would survive.”

“Would a photographic record be acceptable?”

She looked at Mrs Bennett’s mother, standing beside the tree in her good coat.

“As a record. Not instead.”

The chair took off her glasses.

“Public access means lighting, insurance, cleaning.”

Mina nearly said she would clean it. She could see herself arriving with the bucket and brush, grateful for a reason to be there. But she might become ill. She might leave.

Leila said, “It could close at dusk.”

The project manager made figures on a pad. At the door, Mr Bell came in carrying his placard face inward. He sat at the back. Mina made room on the table for the photograph he had brought: himself much younger, beside a woman in a bathing cap, both laughing at something outside the frame.

“My wife,” he said when the chair looked at him. “Not about the tiles. I just thought you should see.”

The chair let the photograph remain.

The revised proposal withdrew the mural from auction and required its retention on the existing walls within a public passageway, open during stated daytime hours. The nonprofit would maintain it. Surveys had to precede demolition nearby; any necessary alteration to those conditions would return to the board.

“There’s a cost,” the project manager said. “We can absorb it within the revised entrance budget. Provided you’re not asking us to retain the fountain plumbing.”

“The basin’s part of the tree,” Mina said. “The water needn’t run.”

The architect nodded.

The vote carried with one abstention.

Mina asked the clerk to read the conditions back. She listened for the words public and existing walls. Then she gathered her papers, leaving Mr Bell’s photograph until he came forward to collect it.

At the library stairs he said, “I still think they should keep the baths.”

“I know.”

“Tuesday mornings’ll be long.”

She had nothing useful to offer him. This time she did not reach for a leaflet.

When she returned, Harris was checking the meters. He gave her the clipboard. She entered the figures, checked the windows and signed the final handover page.

He signed beneath her.

“Email me the edge photographs,” he said. “Before you lose access to that account.”

She watched him tear off her copy of the form.

Leila helped clear the office. Without the towels, pale rectangles showed on the shelves.

“My father’s there,” she said. “S. Rahman. The alterations shop.”

“I know the name.”

“He hated his first name. Said nobody here pronounced it properly.”

Mina had cleaned those words for decades.

“How did he say it?”

Leila told her, then said it again more slowly.

At the door she chose a photograph to keep. Mina waited until she had crossed the street before beginning her final round.

Under the changing-room benches lay a hairpin and a bus ticket softened by water. In the corner shower she lifted Leila’s rubber mat and hung it over the rail. Then she took it down and put it with the things for disposal.

She checked every tap. The pipes knocked once, and she waited for the sound to travel through the empty rooms.

At the mural she softened the auction sticker with warm water and eased it off with her thumbnail. A clean square remained above the fountain. She left the chalk for the surveyors.

In the kitchen she wrapped her white mug and her husband’s brown one separately in a tea towel. Both fitted in her bag if she laid the folder flat beneath them. She emptied the kettle and unplugged it.

Outside, she locked the bathhouse and tested the handle once. She pushed the keys through the agreed letter slot and heard them land inside.