Leena Sato found the first flower while looking for mites. It hung beneath a bean leaf, white and small enough to mistake for a scrap of filter cloth.

She hooked one foot beneath the rack rail and raised the stem. Two more flowers faced the nutrient pipes. Above them, unopened buds crowded the growing tip.

For a moment she checked the tray label instead of the plant.

The beans had three weeks of leaf and root growth left on the schedule. Their harvest occupied a narrow strip in the food ledger, between the last peas and the next potatoes. Leena had chosen this cultivar partly because it was predictable.

Eleven of the thirty-six plants were flowering.

Over the rack, a yellow tag marked the shielding panel that had failed to seat during the radiation storm six days earlier. The failure had lasted nineteen minutes. The storm was classified as minor, but that described the danger to people behind the shelter wall.

Leena photographed the flowers and called Commander Vale.

Vale came carrying an unopened breakfast pouch. She examined the plants, then the seed cabinet bolted across the aisle.

"Isolate the rack. Nothing goes into planting stock."

"I've suspended its harvest designation."

"Sterilize it with tonight's waste."

Leena looked at the cycle clock. Twelve hours. The station ran its high-temperature sterilizer when the other heavy loads were off; missing that window meant keeping suspect material for another day.

"Flowering isn't a diagnosis."

"No. Can you rule out disease?"

"Not yet."

"Then I can replace thirty-six plants from seed. I can't replace a season's planting stock if we carry something into it."

"The bank is sealed."

"Until you open it for tomorrow's sowing."

Leena rested her hand on the rack rail. "Give me until the cycle. I can determine whether there's a defensible reason to keep a small sample."

"You cannot establish safety in twelve hours."

"No."

Vale waited.

"I can propose a contained test," Leena said.

"Then propose that. Don't bring me a reason to save the crop because you grew it."

After Vale left, Leena closed the clear rack enclosure, isolated the nutrient return, and diverted the drain into a waste bladder. She entered the quarantine code. Tomorrow's seed allotment would now have to be opened at the clean bench in the galley.

In her private notes, she typed: Likely transient stress response.

She deleted "likely."

On Earth, she had spent fourteen years asking for another growing cycle, another control, another season of field data. At her last institute, a director had returned her trial proposal with a single sentence: Your caution has become an obstacle to delivery.

She had come to the Moon because here caution was supposed to be useful.

Now she wanted these flowers to be useful too. She recognized the wish before she could disguise it as a hypothesis.

She fetched the pollination sleeves.

By the end of the first hour, every flower was enclosed and every plant numbered. Beans generally pollinated themselves. Generally was not a containment measure.

She compared the affected rack with the adjacent planting: same seed lot, same sowing shift, same feed mixture. Root temperatures were normal. Neither lamp controller had drifted. Both racks had received a nutrient pulse forty seconds late.

The image archive showed visible buds three days after the storm. It established sequence, not cause. Two dosimeters had recorded the shielding failure, neither at the height of the growing tips.

The pathogen screen found nothing on its limited panel.

Under the microscope, some pollen accepted the viability stain. Two unopened buds had twisted anthers; another had petals fused along one edge.

Leena saved those images in a separate folder and opened the next sample.

Arun arrived four hours after Vale's visit, carrying disposal sleeves and seal tape. He managed the food ledger, the seed inventory, and whatever else no one had remembered to assign.

"You reserved the assay cabinet."

"Provisionally."

"For four days."

"One day won't tell us much."

"I need it for the replacement seed checks."

"There's room for three small plants."

"And a drain into greenhouse recovery."

"I was going to cap it."

"With what?"

She had not yet worked that out.

Arun set the sleeves down. On his tablet, he removed the bean harvest from the food ledger. A green band vanished. Fresh-food portions shrank across six names.

"Calories are covered," he said. "But cargo is already eleven days late. Vale's stretched the reserve margin once. If the replacement sowing slips, we lose the next harvest too."

"I haven't delayed it."

"You've reserved the equipment."

She looked back at the microscope.

"Are they dangerous?" he asked.

"Early flowering doesn't necessarily—"

"Leena. I have to decide where to open tomorrow's seed packets."

She turned off the microscope light.

"I don't know."

"All right. Show me."

She brought up the malformed buds, then the screen results.

"This doesn't rule out an organism we don't test for. Some pollen may be viable. The plants may be damaged, or they may have accelerated flowering under stress. That doesn't mean their offspring would do it."

"Does Vale have these?"

"Not yet."

"Why not?"

She could have said she was still assembling the evidence. She had said that often enough on Earth, keeping a question private until she could present it with its answer. Here, while she assembled, other people were making decisions around the gap.

"I wanted something conclusive."

Arun glanced at the folder of images.

"Send what you have."

They met in the galley because it was the only place all six could sit. A loose piece of lettuce trembled against the intake grille. Each time it lifted, the fan clicked.

Leena put the damaged flowers on the wall screen first.

"We don't know whether the storm caused this," she said. "We don't know whether it's inherited. Early flowering might mean a shorter crop cycle. It might mean the plants are dying sooner."

Vale folded her hands around her breakfast pouch, still unopened.

"And contamination?" asked Imani, the station mechanic.

"A mutation doesn't jump from one plant to another. Pollen could cross into the next planting. Disease could travel through the return line or on tools. Seeds could be mislabeled. We can control those routes, but not by being careful in some general way."

"So we destroy the rack," Vale said.

"Yes."

Leena had not expected the word to cost her so much.

"I'm requesting two plants in the assay cabinet. One apparently healthy, one impaired. An unaffected control in a separate root module. No shared nutrient solution. No food use. No seed use."

Imani enlarged the cabinet diagram.

"This drain cap you've drawn. What is it?"

"Something I need your help designing."

"And you've put the control downstream of the other two."

Leena leaned forward. Imani was right.

For half an hour they traced routes through the cabinet: liquid, exhaust, sampling port, gloves, tools, waste. Arun added the cabinet's power draw and the time needed to move the seed checks. Vale asked who would inspect the seals.

"Someone other than me," Leena said.

"Who can terminate the test?"

"You can."

"On what grounds?"

"Loss of containment. A positive pathogen indication. An unexplained pressure drop. Power beyond the agreed limit."

"And if the plants simply look worse?"

Leena considered it.

"We document it. If they die, we sterilize them. Poor growth is one of the results we're testing for."

Vale nodded toward the screen. "Put all of that in writing. Including what this will cost."

Back in the greenhouse, Leena and Arun watched the archive in time lapse. Leaves rose toward the lamps and settled at night. In the center of the affected rack, stems stopped lengthening before flowers opened above undersized leaves. Near the shielding bracket, three plants continued to grow.

"There," Arun said.

She felt the attraction immediately: severe exposure in the center, useful adaptation at the edge. A clean pattern. A reason to save them.

She opened the measurements.

One edge plant had expanding leaves but depressed photosynthetic efficiency. One central plant had slowed before its first visible bud. The estimated doses were too uncertain to divide the rack into meaningful groups.

"Maybe," she said. "But not from this."

Arun watched the graphs replace one another.

"What would establish it?"

"More plants. Known doses. Replication."

"Which we can't do."

"Not now."

She uploaded the contradictory plots to the shared log.

Arun handed her a pouch of lentil paste. Her fingers shook as she fitted the nozzle.

"Have you eaten?"

"I meant to."

"It's cold."

She ate while they calibrated the leaf sensor against the unaffected rack.

Two hours before the deadline, Imani brought a removable drain closure and a rigid secondary tray. She had made the closure from a spare sampling-port fitting; it could be pressure-tested without opening the cabinet.

"The seal held through three tests," she said. "I want another after installation."

Arun had found a way to conduct the seed checks in a sealed germination box. Inspection would be awkward, but sowing could proceed on time.

"The cabinet light comes out of the supplemental greens allocation," he said. "Two fresh portions a week until the next harvest."

"I can give up mine."

"No."

Leena looked at him.

"It isn't your electricity. Or your cabinet. I've divided it across the roster."

She looked down at the six names. Offering her own portions had seemed fair. It would also have made the experiment feel like hers again.

"Put it in the request," she said.

When Vale returned, the sterilizer had begun its warm-up. Leena could feel its vibration through the rail beneath her foot.

"Why these two?" Vale asked.

"One is still growing reasonably well. One has clear impairment. They give us something to compare, though they're not replicates."

"So what can two plants tell us?"

"Whether either can finish developing pods under containment. How its condition changes. Whether there's a question worth spending more resources on."

"Not whether we have a new cultivar."

"No."

"And the seed?"

"If any forms, it stays sleeved, counted, and sealed inside the cabinet. Germination requires a separate proposal."

Vale read the protocol while Imani finished the installed pressure test.

Beyond the commander's shoulder, white flowers crowded the rack. Leena could still ask for four plants. The cabinet would hold them if they removed the control, or crowded the modules, or accepted a little less access around the seals.

She looked at the empty space drawn between the trays on Imani's diagram.

Vale signed.

"Forty-eight-hour review. Arun verifies the daily records. Imani owns the containment checks. If either says stop, we stop while we investigate."

Leena countersigned.

The first selected plant had wound a tendril around its support. She eased it loose while Arun held the transfer sleeve. It took longer than cutting it would have. She checked the flower bags, lowered the root module into its tray, and read the number aloud.

Arun repeated it before sealing the sleeve to the cabinet port.

The impaired plant came away easily. Its roots made a sparse cream fringe against the module mesh. The control was dark-leaved, compact, without a bud.

They closed the cabinet and tested it again.

Then Arun held open the first disposal sleeve.

Leena took the shears.

For weeks, she had trained these stems into their supports. Now she cut each one below the lowest leaf, keeping it inside the rack enclosure until Arun had the sleeve around it. Twice they stopped to reconcile a number with the disposal record. A loose flower slipped from a fold of fabric; Arun caught it against the sleeve wall before it could reach the floor.

They checked the empty sockets for fallen seed, though no pods had formed. They sealed the roots, tools, and nutrient waste for sterilization.

When the last sleeve entered the chamber, rack four was bare.

Leena watched Arun confirm the cycle temperature. There would be no recovering anything once it reached its hold time. She stayed until the display showed that it had.

At the cabinet, they exchanged places for the checks. Arun read the values while she entered them; then she read them back while he verified. Imani inspected the drain closure. Vale posted the revised food schedule beside the hatch, with the experiment's power allocation on its own line.

Leena uploaded her original notes as well as the corrected ones. Beside "transient stress response," she added the alternatives she had not wanted to write that morning. She attached the limits of the pathogen screen and sent the review invitation to all six.

Inside the cabinet, a flower was wilting within its sleeve. Its petals had begun folding around the place where a pod might grow. The leaves above it remained green.

Arun paused at the hatch.

"Coming?"

She entered the plant number, the time, and the flower's condition. Then she set tomorrow's observation interval and left the log open on the shared screen.

Behind her, the cabinet light stayed on as she went with him to supper.
