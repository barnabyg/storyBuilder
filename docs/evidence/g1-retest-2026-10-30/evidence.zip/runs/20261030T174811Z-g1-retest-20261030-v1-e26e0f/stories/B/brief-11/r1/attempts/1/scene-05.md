“We will not discuss reopening,” the chair said. “That decision is final.”

“The bathhouse will close today,” Mina said. She had rehearsed it without today, but the word came. “This petition doesn’t ask you to change that.”

She passed the corrected sheets around, followed by measurements, photographs, and a plan showing the proposed passageway. Her hand paused over each stack until someone took it.

The nonprofit’s project manager turned the plan toward himself. “That passage was intended to be gated. Residents need secure access.”

Leila leaned forward. “I’m on your waiting list. I want a flat there.” She looked at the photograph beneath his wrist. “But I don’t want our names turned into an amenity behind a lock.”

“The names of donors,” the chair said.

“Some of their children still live here.”

A board member asked whether the tiles could simply be lifted and stored until there was somewhere suitable.

Mina found the close-up. Blue letters crossed a masonry joint; the final stroke of one name occupied two tiles.

“They aren’t panels,” she said. “The names run across the joints. I’ve kept that wall clean for thirty-one years, but I can’t guarantee what taking it apart would do.”

The project architect drew the plan closer. With her pencil she moved the passage entrance.

“Subject to a survey, retaining it appears feasible. We wouldn’t lose any homes.” She tapped the elevation. “The decorative cladding allowance could go toward protection and conservation instead. We’d need to cost that properly.”

Mina folded her hands.

The chair dictated the amended resolution: withdraw the mural lot from auction; make retention in a publicly accessible passageway a condition of the site agreement; install an immediate protective enclosure; commission a conservation survey before demolition.

The vote carried, with one abstention.

People began gathering their papers. Mina stayed seated while the clerk typed. When the chair asked if she needed anything else, she pointed to the screen.

“I’d like to wait until it’s entered.”

The clerk read it back. Mina listened to every word.