The site manager found her copying the inventory beside the towel ledger.

“Is this for a protest?”

“It’s a record of what’s being sold.”

He looked at the telephone, then at the names on her pad. “Work time, Mina. Patron records. If there’s a complaint, I can’t sign off a clean handover.” He lowered his voice. “Your final payment depends on that paperwork.”

She put the receiver back in its cradle. The last number remained undialled.

Before the remaining bathers left, she asked each contributor separately: could she give their words, photographs and names to the board? Mrs. Bell agreed to the photograph but not her address. Mr. D’Souza wanted his whole sentence included. Two people declined. Mina crossed them off without asking why. Those already gone she messaged from her own phone, using only numbers they had given her that morning.

At three she clocked out. She left the towel count unfinished, with a note explaining where she had stopped.

The copy shop smelled of hot paper. She paid from the envelope marked NOVEMBER, counting out enough for twelve sets and a large print of Leila’s plan. The money had been intended for groceries during her first month without wages. She asked for a receipt.

The retired bus driver arrived as she was sorting the pages. Under his arm was a placard: SAVE OUR BATHS.

“I won’t take that into the meeting,” Mina said.

“You’re settling before they’ve even said no.”

“They’ve said the baths are closing.”

“So you do their work for them?”

She squared the copies against the counter. “I’m asking for something they can still do.”

Leila spread the plan between the stapler and the till. Together they found the proposed public passageway. Mina held the paper while Leila traced the existing mural wall.

In the margin Mina wrote one request: withdraw mural from auction; retain wall in public passageway; no reduction in housing capacity.

“Not the whole room?” Leila asked.

Mina looked at the line they had drawn.

“The wall.”