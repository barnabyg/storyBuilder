By the time the disposal bin was sealed, Leena’s gloves smelled of crushed leaves.

Arun waited beside the isolation cabinet. Together they checked the door gasket, the filtered exhaust, and the seals around the sampling ports. He read each pressure value aloud; she entered it, then they exchanged places and repeated the check.

They logged temperature, humidity, radiation dose, and reservoir chemistry. Leena placed the unaffected control beside the two anomalous plants, each in its own tray. Arun adjusted the lamps until the meters agreed. The nutrient solutions came from the same batch.

“Baseline saved,” he said.

Vale posted the revised schedule on the greenhouse door and the mess display. Replacement sowing would begin tomorrow. Bean portions would be reduced for nineteen days; stored lentils would cover part of the gap. The cabinet’s power allocation appeared on a separate line.

Leena looked at that line longer than the others. Nobody had hidden it under maintenance.

At the terminal, she uploaded the images, instrument files, and handwritten observations she had transcribed during the night. Beneath them she listed what they did not know: whether the storm had caused the change, whether it was heritable, whether early flowering would reduce yield, whether any resulting seed would germinate.

She scheduled a review for forty-eight hours later, with three possible decisions: continue, modify, terminate.

Arun accepted the invitation. Vale’s acknowledgment followed.

Before leaving, Leena checked the plants once more. Inside a pollination bag, one white flower had begun to wilt. Its folded petals obscured the ovary. She could not tell whether it would set a pod, much less a viable one.

She entered the time, the plant number, and what she could see. Then she closed the log.