The street door banged upstairs. Ruth slid her phone into her shirt pocket, microphone exposed.

Manny came down with his keys in his fist. He stopped two steps above her, his face wet with sweat.

“Move away from there.”

“Elena’s inside.”

“Elena gets confused.”

“Then open it.”

He glanced at the basement door but made no move toward it. “You’ve turned a maintenance dispute into an emergency. What did you tell them when you called?”

Ruth pressed her pocket once, checking that the phone hadn’t tipped forward. “Give me the padlock key.”

“That lock belongs to the contractor.”

“You own the building.”

“I don’t carry everybody’s keys.”

The keys clicked as he closed his hand.

From behind the door came a small scraping sound. Manny talked over it.

“You need to think about what happens next.”

He took out his phone and held up a photograph of a work sheet. Ruth recognized the boxes before she saw her signature: emergency lighting, basement ventilation, corridor wiring. He swiped to another.

“You signed these.”

“You said the electrician was coming.”

“But you signed that the work was completed.” His voice softened. “Someone investigates, they’ll ask you. Not just me. You’ve got your apartment here. Your daughter.”

She had signed so the inspection would pass, so the fines wouldn’t become another rent increase. That was what she had told herself.

She stepped past him toward the stairs.

“Where are you going?”

“To meet the responders.”

His hand closed around her wrist. For a moment she stood still, obeying the old instinct to keep a hallway argument from becoming everyone’s business.

Then she twisted free.

“Mrs. Shah!” she shouted up the stairwell. “Mrs. Shah, I need you to hear this!”