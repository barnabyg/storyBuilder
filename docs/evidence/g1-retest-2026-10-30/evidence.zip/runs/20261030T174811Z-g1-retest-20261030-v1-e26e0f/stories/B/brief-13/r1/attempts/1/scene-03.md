Arun came through the greenhouse hatch carrying disposal sleeves and a spool of seal tape.

“Vale wants the rack ready.” He set the sleeves beside the sink, then checked his tablet. “You’ve booked the assay cabinet through tomorrow.”

“I need it for the samples.”

“What samples? I was counting on it for the replacement seed checks.”

Leena adjusted the microscope’s focus, though the cells were already sharp. “The reservation is provisional.”

“So is this.”

He laid the tablet beside her eyepiece. The food ledger showed the bean harvest as a green bar between two planting cycles. Arun tapped it, and the bar disappeared. Fresh-food portions dropped across the crew roster.

“We can cover calories from stores,” he said. “But if these yield badly, we’re on reduced fresh portions until the next planting comes in. And if I can’t clear that seed, the next planting slips.”

She had counted the hours the cabinet would give her. She had not counted what those hours belonged to.

“Are the beans dangerous?” he asked.

“The flowering response doesn’t necessarily imply an unstable genome. A stress-mediated change in expression could—”

“Leena. Are they dangerous?”

“There are several kinds of risk.”

He picked up the seal tape. “Then tell me which ones I’m containing. I won’t improvise a barrier around an experiment you haven’t disclosed.”

“On Earth, committees spent years telling me I was too cautious. Every time I asked for another control, they—”

She stopped. Arun waited.

She knew what dismissal felt like. She had used that memory to excuse keeping the decision out of anyone else’s hands.

“I don’t know,” she said. “And I kept that to myself because I wanted time before anyone could judge what I was trying to save.”