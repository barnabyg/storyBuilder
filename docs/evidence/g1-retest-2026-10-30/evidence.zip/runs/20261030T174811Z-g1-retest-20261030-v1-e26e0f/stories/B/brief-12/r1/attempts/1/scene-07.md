In the ambulance, a paramedic laid cold packs beneath Elena’s arms. Ruth waited until Elena looked at her.

“Your phone. Can I get it?”

“Behind the flour tin,” Elena whispered. “Kitchen shelf. You can show them.”

Mrs. Shah went upstairs with Ruth and watched her retrieve it. The photographs showed bare copper at a junction box, a scorched breaker, ventilation grilles packed with insulation. Elena had photographed dates and labels. But there was no picture of Manny at the door, no hand turning a key.

Ruth sent copies to the investigator whose card was damp in her pocket, then to Mrs. Shah. She added her recordings and photographs of the maintenance sheets.

Under them she typed: I signed the inspection entries marked R.D. I did not inspect the work. Manny told me it had been completed. I signed anyway.

She read it once before pressing send.

Outside, Manny stood beside the investigator.

“She had the keys,” he said. “Basement access was her responsibility. So was reporting electrical faults. Ask her how long she let things go.”

Ruth stopped within hearing. Manny glanced at her and continued speaking.

Ten minutes later, her phone lit up.

Employment terminated effective immediately. Return all building keys tonight.

At dusk, Ruth sat with Isabel in the hall outside their dark apartment. Mrs. Shah brought water. Someone from the fourth floor brought chargers and a battery pack; someone else offered a spare room without looking directly at Ruth.

Isabel leaned against her, holding the warm bottle between her knees.

From Elena’s covered cage beside them, the parrot said, “I can’t breathe.”

Ruth’s screen showed the investigator’s unanswered request to call back. She left it visible beside Manny’s message, the keys still heavy in her pocket.