Bia arrived carrying the compass in a paper bag.

Seabra reached for it. She put it on the technician’s table instead.

“All this,” the director said, “for something that would only have made a little noise. Removing it was unnecessary.”

The technician held up the disconnected air hose, then selected a wooden disk the same diameter as the compass.

“Without pressure,” he said.

He slid the disk into the barrel and lowered a measuring rod through the loading slot. Its tip indicated the line of fire: straight across the room, ending at the donors’ front row.

“The disk is harmless like this. Brass, with the air connected, would not be.” He tapped the safety sheet already clipped to the cannon’s stand. “No solid loads. It’s explicit.”

Seabra inspected his cuffs.

Nuno waited until he stopped.

“You mixed up the compass and the demonstration piece. Bia removed what you’d made into a projectile. Then your theft story concealed the mistake and let you carry on preparing the same unsafe finale.”

“I can pay the reward,” Seabra said. “If we agree this was a misunderstanding.”

“No reward. A signed withdrawal of the theft allegation. Payment for Bia’s interrupted shift. And a public safety correction that names no temporary worker.”

“That sounds unnecessarily formal.”

“So did the allegation.”

The gala coordinator stood beside the closed entrance, holding her guest list.

“I’m not admitting anyone until this is settled.”

On the security monitor, the preserved footage waited at the moment before the camera’s convenient version began.

Seabra looked from it to the coordinator.

“Bring me something to sign.”

By six, the cannon was behind a locked door. In its place, volunteers folded paper ships for distribution by hand.