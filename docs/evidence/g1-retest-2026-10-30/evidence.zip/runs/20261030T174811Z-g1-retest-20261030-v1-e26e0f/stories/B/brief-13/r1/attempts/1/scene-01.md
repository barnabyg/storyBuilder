Leena Sato found the first white flower while checking the dwarf beans for mites. It hung beneath a leaf, small enough to mistake for a scrap of filter cloth.

She lifted the next stem. Two more flowers.

The plants should have had another three weeks of leaves and roots before flowering. She checked the planting log, then checked it again against the tags clipped to the trays. Same batch. Same sowing date.

Only then did she call Vale.

While she waited, she opened the environmental record. Six days earlier, during the minor radiation storm, the shielding panel above rack four had failed to seat. Maintenance had corrected it in nineteen minutes. The dose registered beneath it was elevated, though the summary classified the incident as minor.

Commander Vale arrived with his breakfast pouch still folded in one hand.

“How many?”

“Eleven flowering. I haven’t examined all the plants.”

He studied the blossoms without touching them. “Quarantine the rack. Next waste cycle, we destroy it.”

“That’s tonight.”

“Early flowers can mean small plants and poor yields. We’ve budgeted food around this harvest.” He glanced toward the seed-storage cabinet. “Nothing from that rack enters planting stock.”

Leena kept her hands still. On Earth, she had learned how quickly caution could become someone else’s reason to stop listening.

“Give me twelve hours for an assessment. It’s probably harmless—a stress response. I can establish whether there’s cause to preserve a sample.”

Vale looked at her. “Twelve hours. Isolated from now on. No extensions.”

After he left, she closed the rack’s clear enclosure and entered the quarantine code. Then she opened her inspection notes.

Probably harmless.

She watched the cursor blink after the words. She had no result that belonged beside them.

She deleted the phrase.