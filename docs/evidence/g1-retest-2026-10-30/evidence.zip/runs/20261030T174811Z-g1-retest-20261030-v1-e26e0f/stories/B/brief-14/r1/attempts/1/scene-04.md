Bia was at the café opposite the museum, stirring an espresso that had surrendered some time ago.

“Senhora,” Nuno said, “you resemble an old acquaintance.”

“How unfortunate for her. You resemble a man who once stole a policeman’s watch while asking the time.”

“A common face. May I sit?”

“If you’re selling a walking tour, I live here.”

He sat. She wore black catering trousers and shoes with sensible soles. He remembered shoes chosen chiefly for speed.

“I do events now,” she said. “Legitimate shifts. Bad pay, declared income. Sometimes both.”

“And today?”

“I saw a dangerous mistake. I tried to tell Seabra. He told me the gala was under control.”

“So you took the compass.”

“Yes. I went back to explain, but he was announcing a theft. Then everyone had to remain available for questioning. Available, apparently, means frightened and unpaid.”

She slid her phone across the table. In the photograph, the tiny brass compass lay wrapped in a catering napkin beside the red warning tag.

“Taken before he announced anything,” she said. “Check the time.”

Nuno enlarged the image, then checked the timestamp. He had hoped for an explanation he could carry back in one pocket. This needed both hands.

“Trust me with it.”

Bia reclaimed her phone.

“Your new life looks comfortable. Does it depend on pretending people like me never existed?”

“Bia—”

“You tell tourists stories. Is that where we went? Edited out between the earthquake and lunch?”

Outside, a guide raised a yellow umbrella. Nuno watched strangers gather beneath it.

“I won’t purchase my own innocence with your name,” he said.

She studied him.

“Get the complete security recording. Not Seabra’s little performance.”

“And then?”

“I’ll come back with the compass.”