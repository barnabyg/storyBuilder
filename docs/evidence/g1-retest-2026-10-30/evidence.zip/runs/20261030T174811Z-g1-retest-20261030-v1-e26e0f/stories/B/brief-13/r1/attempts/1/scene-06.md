At the deadline, Vale stood beside the display long enough for its light to dim.

“You haven’t justified keeping the rack.”

“No,” Leena said.

She felt the old argument gathering: the value of more specimens, the information they would lose. She let it pass and handed him the protocol she had written beneath the figures.

“Three plants. The strongest of the early bloomers, the stunted one from the end tray, and an unaffected control.”

Vale scrolled without answering.

The cabinet would have sealed nutrient containment and filtered exhaust. Every flower would be bagged before transfer. Tools would remain inside, dedicated to those three plants. Nothing—not a leaf clipping, not a drop of nutrient solution—would return to the greenhouse. All waste would be sterilized.

“You’ve assigned disposal to yourself,” he said.

“Yes.”

“And if the cabinet loses containment?”

“You end the test. You don’t need my agreement.” She kept her hands still. “We record growth, pod set, and seed viability. That’s the limit of this approval. Any trial involving offspring comes back to you separately.”

Vale looked through the cabinet’s inspection window.

“Three plants,” he said. “Under this protocol.”

He signed, and Leena countersigned before she could mistake permission for vindication.

She bagged the flowers herself. The vigorous plant caught briefly against its support; she freed it without breaking the stem. The stunted plant lifted easily. Last came the control, green and unremarkable. She secured each root module inside the cabinet, checked the seals, and recorded the time.

Arun waited beside the sterilizer with an empty disposal sleeve.

Leena took the shears from him. Across the rack, pale flowers trembled in the ventilation.

“Start at this end?” he asked.

“Yes,” she said, and held the first stem steady.