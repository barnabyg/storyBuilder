Leena folded the tablet against her chest and stood between the racks until her breathing slowed. Then she fetched the pollination sleeves.

She bagged each open flower, cinching the translucent fabric below the calyx. At the service panel she closed the rack’s return valve and diverted its nutrient flow into a waste bladder. Nothing from these roots would reach another tray.

She inventoried all thirty-six plants: height, leaf count, flowers, unopened buds. Only when every stem had a numbered collar did she sterilize her scissors and take tissue samples.

The unaffected rack across the aisle was the same cultivar, planted on the same shift. She laid its records beside the flowering rack’s: root-zone temperatures, lamp spectra, illumination periods, pump cycles, conductivity. One delivery pulse had arrived forty seconds late. Both racks had received it.

Archived images showed ordinary leaves until the storm. Afterward, the affected plants had continued growing without visible injury. She enlarged the frames, looking for something embarrassingly simple—a lamp left on, a sensor reading the wrong tray. Nothing explained the flowers.

The rapid screen returned negative results for every pathogen on its limited panel. Leena saved the report without forwarding it. Under the microscope, several pollen grains took up the viability stain; beside them, dissected buds showed twisted anthers and petals fused along one edge.

She examined another bud before recording that.

In the request window she typed: Authorization to transfer two plants to sealed assay cabinet.

The cabinet offered filtered air, independent lighting, independent cooling. It also drew from the power allocation reserved for replacement seedlings.

She opened the load estimate. Two plants would mean dimmer lamps over the next sowing, or a postponed sowing altogether.

Her thumb hovered over Send. She saved the request as a draft and returned to the microscope.