“Before we begin,” Seabra told the donors, gripping the lectern, “a member of our event staff prevented an unsafe loading error during preparations. Responsibility for that error is mine.”

He paused. Nobody supplied the applause he appeared to have budgeted for.

“Our compass has also been recovered.”

He removed its cloth with the enthusiasm of a waiter revealing a disputed bill.

Nuno stepped forward before the silence became a permanent exhibit.

“We had intended to finish with a cannon,” he said. “Instead, you will have a story. It is quieter, though I cannot promise shorter.”

A donor laughed cautiously.

Nuno told them about navigation: how a captain could possess excellent charts, polished boots and the absolute confidence of everyone aboard, and still be steering towards a rock.

“Respectable institutions are rather like ships,” he said. “Occasionally they need someone to tell them they are pointing the wrong way. Preferably before the champagne.”

This time the laughter came freely. Near the doors, Bia handed a paper ship to a woman wearing enough pearls to ballast it.

“You’ve become alarmingly honest,” she told him afterwards.

“I still made a director surrender money without touching his pockets.”

The museum paid the promised recovery reward before the caterers finished clearing. Nuno counted the notes beneath the cloakroom lamp and passed half to Bia.

“Compensation,” he said, “for an evening spent preventing a theft that never happened.”

She counted her share again. He found this reassuring.

On his next tour, Nuno stopped beside the compass.

“This instrument once saved a roomful of important people without moving its needle.”

A tourist bent towards the official label.

“Was that really what happened?”

“For once,” Nuno said, “you needn’t take only my word for it.”