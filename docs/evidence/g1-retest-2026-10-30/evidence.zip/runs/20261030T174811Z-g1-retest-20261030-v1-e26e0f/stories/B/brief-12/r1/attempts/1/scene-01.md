Ruth held the breaker off for ten seconds, then pushed it back. The hallway lights came on above the tenants crowded along the stairs, where an open roof door offered the promise of air.

“Unplug something,” she told them. “Anything you can spare.”

Nobody moved. Upstairs, a baby cried.

The panel smelled of hot pennies. A brown scorch spread above the breaker for the second-floor hall, darker than yesterday. Ruth kept her fingers away from it. With every window unit working against the hundred-degree heat, she doubted the building would make it through another afternoon.

“Mom.”

Isabel stood below her with a green parrot gripping her forearm. Her daughter was twelve and trying not to look frightened by its hooked beak.

“Found him on the basement landing.”

“Don’t hold him against your face.” Ruth offered the bird her screwdriver handle. It stepped onto the rubber grip, revealing the yellow patch at its neck. “That’s Elena’s. From 3B.”

The parrot cocked its head.

“Manny, open the basement. I can’t breathe.”

Ruth looked at Isabel.

It was Elena’s voice, almost: the same low pitch, the little catch before breathe. Elena who brought Ruth coffee when the laundry drains backed up, who always apologized before asking for anything.

“Did he say that downstairs?”

Isabel nodded.

At 3B, Ruth knocked twice. The door shifted under her knuckles.

“Elena?”

Inside, the curtains were drawn against the sun. Elena’s phone lay charging beside a half-filled water glass. Ruth called her name again, then backed into the hall.

“Go to Mrs. Shah’s. Stay there until I come.”

“What about you?”

“Give her the bird.”

Ruth watched Isabel enter Mrs. Shah’s apartment before she turned toward the basement stairs.