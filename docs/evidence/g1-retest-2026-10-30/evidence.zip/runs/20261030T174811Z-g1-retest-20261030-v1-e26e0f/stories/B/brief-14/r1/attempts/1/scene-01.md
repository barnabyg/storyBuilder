“Observe the ship’s figurehead,” Nuno Vale told his tourists, pointing upward. Twelve faces tilted obediently. With his other hand he drew a museum leaflet from his jacket pocket.

“And that is why sailors lost their wages ashore. Everyone watches the pointing hand, nobody the pocket beneath it.”

The German gentleman laughed and checked his wallet.

“Pure theatre,” Nuno assured him. Respectability required these little disclaimers.

Director Seabra interrupted beside the model frigates, clapping twice for attention he evidently considered transferable.

“The finale, please. Imagine the donors here.”

A technician stood behind a replica cannon aimed across the gallery. He explained that compressed air would send a cloud of paper ships fluttering over the guests.

“Discovery raining upon generosity,” Seabra said.

“Provided generosity wears safety glasses,” Nuno murmured.

Beside the cannon stood an open display case containing a tiny brass compass. On the loading table lay a round brass cap scarcely larger.

“Twins,” Nuno said, indicating both. “One finds India; the other keeps the wind in.”

The technician did not smile. “Paper only inside the barrel. Anything solid becomes a projectile.”

He held up the cap, showing its threaded rim, then screwed it onto the rear fitting.

“Let me finish the display,” Seabra said, moving between them. “And I’ll load the ships. The folds must face the audience.”

He shifted the open case closer to the cannon, collected a tray of paper boats, and pulled a red DO NOT FIRE tag from the firing lever.

“It spoils the photographs.”

Nuno opened his mouth, but Seabra was already summoning the photographer.

“Onward,” Nuno told his tourists. “Portugal awaits.”

An event worker caught his eye beyond them. She straightened one cuff while checking every exit.

Bia.

Nuno’s respectable smile stayed precisely where it was.