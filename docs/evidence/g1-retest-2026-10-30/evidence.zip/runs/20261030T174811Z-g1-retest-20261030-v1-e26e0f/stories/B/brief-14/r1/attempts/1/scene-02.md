It survived until Seabra appeared beside the ticket desk and said, “A private word. Your group can admire the rope.”

“They’ve paid for maritime history.”

“It’s historic rope.”

In the director’s office, Seabra turned a laptop towards him. The security clip showed shoulders crowding the navigation exhibit. Between them, an event worker reached into the display area, withdrew a small brass object and slipped it into her apron.

Nuno knew the wrist before he knew the face.

Bia. Older, naturally; everyone had been inconsiderate enough to get older. But she still tucked her elbow close after a lift, as though sheltering a candle.

“The compass,” Seabra said. “Well?”

“The camera angle makes the action difficult to interpret.”

“She puts it in her pocket.”

“Apron. Angles are particularly unkind to aprons.”

Seabra paused the clip. “There will be a reward for its recovery. Five hundred euros. Your tours teach you to read people, I’m told.”

“My tours teach people that Henry the Navigator suffered from a misleading job title.”

“Then navigate this. I need a name before the donors arrive.”

Nuno leaned closer. The image was cropped tightly around the exhibit, cutting off whoever stood to the worker’s left. Seabra dragged the playback marker to the beginning. Bia’s open palm was already raised towards that missing person.

“Play it again.”

As the crowd shifted, the velvet recess became visible. Something round lay where the compass belonged: the cannon’s loading cap.

Nuno kept his hands loosely folded.

“Could I see the preceding minute?”

“There is no time for a documentary.”

“It might clarify—”

“Bring me a simple culprit, Vale, and I can promise discretion.”

Nuno looked at Bia’s arrested hand.

“How fortunate,” he said, “that simplicity is so inexpensive.”