The breaker held on Ruth's second try. Above her, the stairwell bulbs brightened, and six window units started at once with a sound like trucks pulling away.

"Unplug what you can," she told the tenants on the stairs. "Not just switch it off. Pull the plug."

"The fridge too?" Mr. Vega asked.

"Leave the fridge."

It was the fourth day above a hundred degrees. People had propped their apartment doors open, sacrificing privacy for air that wasn't moving anyway. A child slept on a towel on the second-floor landing. Someone had carried a kitchen chair halfway to the roof and abandoned it.

The electrical panel smelled like pennies held too long in a fist. Ruth closed its cover.

"Mom."

Isabel stood at the bottom of the stairs with a green parrot on her forearm. Ruth's daughter was twelve; she had lately begun saying Mom in a patient, warning tone, as though Ruth were the one who needed watching.

"Don't let him near your eyes."

"He was on the basement railing. He climbed onto me."

The bird had a yellow patch at its neck. Elena's bird, from 3B. Elena carried him to the laundry room on her shoulder and argued with him about whether he was getting enough attention.

Ruth offered him the rubber handle of her screwdriver. He stepped across.

"Manny," he said. "Open the door."

Isabel looked at Ruth.

The bird shifted his feet.

"Open the door. I can't breathe."

Ruth knew the borrowed voice. It had Elena's slight pause between can't and breathe.

"When did he start saying that?"

"Downstairs. Before I picked him up."

At 3B, Ruth knocked. The door stood open an inch, held by a folded grocery circular. Inside, a phone was charging on the kitchen counter. A little desk fan moved warm air over an empty chair. The birdcage door hung open.

"Elena?"

No answer.

Ruth put the parrot inside and latched the cage. She called Elena's phone. It vibrated against the counter.

"Go to Mrs. Shah," she told Isabel. "Stay there."

"What did the bird mean?"

"I'm going to find out."

The basement door had a new hasp, its bright screws driven through flaking brown paint. A heavy padlock hung from it. Ruth's master key wouldn't enter.

She pressed the bell beside the frame, an old courtesy for anyone doing laundry below. Nothing rang. Manny had disconnected the laundry machines in April, saying they cost more to repair than they earned.

"Elena?"

From behind the door came a faint dragging noise.

Ruth called Manny.

"Why is the basement padlocked?"

"Sewage backup. Contractor's coming."

"You didn't tell me."

"I'm telling you now."

She bent close to the gap beneath the door. A red plastic strip protruded, printed with half a white flower. Elena's shopping bag.

"Is Elena down there?"

"She went to her sister's."

"Her phone's upstairs."

"Then she forgot it."

Ruth kept her voice low. There were open doors above her, people listening without wanting to be involved.

"Her bird was loose on the basement stairs."

"Ruth. Leave the lock alone."

She straightened.

"Is she inside?"

"Do you want me calling the police about those electrical repairs? You're not licensed. Your name's on the inspection sheets."

"You said the electrician had—"

"And the apartment comes with the job. You understand that?"

He hung up.

Ruth stood with the phone against her ear. She had lived in the superintendent's apartment for seven years. Isabel's height marks were penciled on the kitchen jamb. The last apartment Ruth had priced would have taken nearly all her wages before groceries.

She climbed two steps, thinking she could call Elena's sister. Find a number. Establish something before making trouble.

Then the dragging sound came again.

Ruth went down and switched off the stairwell fan. In the sudden quiet she knocked three times with her wrench.

Two knocks answered. A pause. One more.

She called emergency services.

While the dispatcher took the address, Ruth crouched at the door.

"Elena. It's Ruth."

"Please."

"They're sending help."

The dispatcher asked whether Elena was conscious and breathing. Ruth answered, gave her own number, described the overloaded panel. Heat emergencies were delaying crews. She was told not to force her way into an unsafe space.

When she could end the call, she started a video, holding the new lock in frame.

"Elena, how did you get down there?"

"Manny said come see. Said he fixed it."

"Fixed what?"

"The rooms. The air."

Ruth's knees hurt against the concrete.

There had been beds down there in winter. Manny had called them temporary accommodation for the renovation crew. Ruth had left notices about keeping the stairwell clear, then stopped leaving notices when he told her they weren't tenants and weren't her concern.

"I took pictures yesterday," Elena said. "He wanted them off my phone."

"Your phone's upstairs. I saw it."

"I told him." A breath scraped through the gap. "He said I could wait."

Ruth checked that the video had saved.

For years she had taken complaints by phone because Manny said written complaints made insurance trouble. She had learned to call a leaking ceiling a stain until she knew which answer he wanted. Once, after he refused to pay for an electrician, she had signed the box he marked with a yellow tab. After that he sent the forms already tabbed.

She texted Mrs. Shah: Keep Isabel with you. Don't let Manny take her anywhere.

Then she sent the video.

The street door slammed above her.

Manny came down carrying keys. His polo shirt was dark under the arms. He stopped when he saw Ruth's phone.

"Who have you called?"

"The fire department. Open the door."

"There's a contractor's lock."

"Then call him."

"Don't give me orders in my building."

Behind the door, Elena coughed. Manny looked toward it, then back at Ruth.

"She's been going places she has no business going."

"Open it and tell the firefighters that."

He lowered his voice.

"You think they'll just ask about me? I've got seven years of records with your signature. Emergency lights. Ventilation. Wiring."

Ruth slid her phone into her shirt pocket, camera facing out. She could not tell whether it was still recording.

"You told me the work was done."

"You certified it."

There it was, plainly said, and her first thought was still to keep him from saying it where the neighbors could hear.

She stepped toward the stairs.

He caught her wrist.

For a second she stayed still. She had quieted so many arguments here: rent, noise, a bicycle chained to the wrong railing. Keep your voice down. Let's not do this in front of everyone.

Then she pulled back hard.

"Mrs. Shah!"

Her shout went all the way up.

Manny released her. Mrs. Shah appeared above them, followed by Mr. Vega and a woman holding a phone.

"Isabel's with my husband," Mrs. Shah said.

"Get everyone away from the panel," Ruth told her. "And someone wait outside for the fire crew."

"What's happening?" Mr. Vega asked.

"Elena's locked in the basement."

Manny spread his hands. "Nobody knows that."

They all heard her then: "Ruth."

Mrs. Shah came down two steps.

"Open the door, Mr. Cole."

He looked from her to the woman filming.

"I'm getting the contractor."

He went upstairs, already speaking into his phone.

Ruth fetched her hacksaw from the cupboard beside the panel. The shackle was thick, but two screws in the hasp had missed the frame and bitten only into trim. She tested the metal with her pry bar.

"Film this," she told the woman. "Before I damage it."

"My name's Naila," the woman said.

Ruth knew she should have known that. She had fixed Naila's kitchen tap twice.

"I signed reports for repairs he didn't do," Ruth said.

Nobody answered.

"I'll have to tell them that."

"Yes," Mrs. Shah said.

The word steadied her more than reassurance would have.

Mr. Vega held the pry bar while Ruth worked a screwdriver beneath the hasp. One screw lifted. The trim split, but the inner screws held.

"Elena, move away from the door."

"I'm sitting."

"Can you move back?"

A small sound. No answer.

Ruth lay on her side and shone her phone through the gap. She could see a shoe, the corner of the red bag, nothing more.

Mrs. Shah brought water. Ruth squeezed the bottle and pushed its flattened middle beneath the door.

"It's by your feet. Can you reach it?"

Something brushed the plastic.

The lights dimmed.

From the panel came a dry, uneven crackle.

Ruth scrambled up. A trace of gray slipped from the top of the cover.

"Upstairs. Everyone."

Mr. Vega still held the pry bar.

"Now."

She called the dispatcher again, saying smoke, saying Elena was no longer answering. Then she opened the panel's outer cover, keeping clear of the scorched branch breakers, and pulled the main disconnect.

Everything stopped: fans, compressors, the rattle of somebody's television upstairs.

In the silence, a baby began crying.

Ruth turned on her phone light. Naila stood three steps above, still filming.

"Go up," Ruth said.

"The crew needs to see."

"They'll see. Please."

Naila retreated, keeping the beam pointed down until Ruth reached the landing.

Ruth stood where she could see the basement door. She had shut off the last fan Elena might have had. She knew she had needed to do it. She kept looking at the narrow dark gap anyway.

Boots struck the lobby floor.

Mrs. Shah's voice came first. "Here. Down here."

The firefighters moved Ruth aside. One asked about the smoke; she pointed out the disconnect. Another knelt at the lock. Their cutter snapped the shackle, but the door stuck against something inside.

"Person immediately behind it," Ruth said.

They opened it slowly, a few inches at a time, until a firefighter could squeeze through.

Their lights found plywood partitions reaching almost to the overhead pipes. Numbered doors. An extension cord fastened along a beam with bent nails. Through one open doorway Ruth saw a mattress, a rice cooker, work boots set neatly on newspaper.

Then they were bringing Elena out.

Her blouse was soaked. The red shopping bag lay across her stomach, one handle broken. Ruth recognized the little flowered blouse she wore to collect her pension.

"Is anyone else down there?" a firefighter asked.

"Working," Elena whispered. "They go early."

"How many?"

Elena shut her eyes.

Ruth moved back as they carried her upstairs, and the tenants moved back in turn, making a passage through the dark.

Outside, the heat felt almost cool.

A paramedic put cold packs against Elena's neck. When Ruth came near, Elena caught her fingers.

"Tito?"

"Upstairs. In his cage."

"The pictures."

"Your phone?"

Elena nodded. "You can show."

Manny stood near the entrance talking to a police officer. He was no longer sweating heavily. Someone had brought him a bottle of water.

Ruth gave her name to the officer.

"The door was padlocked from outside. I found her. I have a recording."

Manny turned.

"She's responsible for basement access," he said. "Ask her about the electrical reports."

"I signed them," Ruth said.

The officer looked up from his notebook.

"Not here," he said. "One at a time."

With Mrs. Shah beside her, Ruth went to 3B. Elena had once given her the phone code so she could order a replacement stove knob. Ruth tried it. The screen opened.

The photographs were dated the previous afternoon. Mattresses. A covered ventilation grille. Water staining around a cable box. One image showed a scorched outlet beside a kettle.

They showed what Elena had seen. They did not show who had installed it, or who had turned a key.

Ruth sent copies to the fire investigator, then to Mrs. Shah. She sent her video too. Manny's voice had recorded badly from her pocket: keys, cloth rubbing, a few clear words. Your signature. Your apartment.

She wrote down the rest while she could still remember it, including what she herself had signed. Then she sent that.

By dusk, tenants were sitting along the pavement with bags of thawing food. Two basement residents had returned from work and were speaking to the firefighters. Nobody knew when the electricity could be restored.

Ruth's phone lit up.

Employment terminated effective immediately. Return all keys. We will discuss possession of the apartment tomorrow.

She read it twice.

Isabel sat beside her on the front step, Elena's covered birdcage between her shoes. Mrs. Shah had offered them her sofa. Mr. Vega had said he knew someone who might need a superintendent, though he hadn't said where.

"Are we moving?" Isabel asked.

"I don't know yet."

From under the cover, Tito made the squeak of Elena's kitchen cupboard.

Ruth's phone rang. The investigator's number.

Across the pavement, Manny watched her with his own phone in his hand.

Ruth answered, keeping the building keys in her other fist.
