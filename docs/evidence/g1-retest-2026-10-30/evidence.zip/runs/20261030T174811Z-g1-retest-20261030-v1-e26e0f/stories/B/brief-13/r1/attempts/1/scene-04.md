Twenty minutes later, Leena stood beside the galley screen while the others crowded around the table. She had divided the display into three columns.

“Known: flowering began weeks ahead of schedule. The affected trays occupied the same rack during the radiation storm. We haven’t established that the storm caused it.”

She moved her finger across.

“Unknown: whether they’ll set viable seed, what yield they’ll give, whether their offspring would flower early. Suspected: radiation damage, or a stress response. Plants sometimes flower because conditions are bad, not because they’ve acquired a useful adaptation.”

Vale folded her arms. “And the danger to the other crops?”

“An altered bean isn’t automatically contagious. A genetic change doesn’t jump between trays. But we haven’t ruled out disease. Seeds can get mixed during handling. And calling a cabinet ‘isolation’ doesn’t make it adequate.”

She stopped there, resisting the urge to add that she had always been careful.

Vale looked toward the greenhouse hatch.

“The seed bank is our only reliable reserve until the next supply landing. If we lose a harvest, we can ration. If we compromise those seeds, rationing won’t fix it.” She turned back to Leena. “I can’t approve an uncontrolled rescue because these plants might be useful.”

“No,” Leena said. “You shouldn’t.”

For a moment, only the galley fan spoke.

“Then what are we deciding?” someone asked.

Leena erased the question she had put beneath the columns: Can the crop be saved?

In its place she typed: Can we safely contain a tiny sample long enough to test it?

“Not our next harvest,” she said. “A test with disposal rules.”

Vale pulled a chair closer to the screen.

“Start with every way material could leave the enclosure.”