By the time they had traced the drains, filters, gloves, and waste bags, the next image sequence was ready.

Leena watched it beside Arun. Under the time-lapse clock, leaves lifted and settled as the lamps cycled. Along the rack’s central strip, where the dosimeters recorded the highest exposure, stems barely lengthened. Flowers opened above undersized leaves.

“There,” Arun said, pointing toward the edge.

Three plants near the shielding bracket had flowered too, but their leaves continued expanding. Leena ran the sequence backward, then forward. For a moment she wanted to call those three the answer.

Instead, she opened the measurements.

Leaf area, stem extension, fluorescence: the numbers refused a clean division. One edge plant had normal growth but depressed photosynthetic efficiency. A central plant had lost growth before producing its first bud. Flowering time overlapped across both groups.

“We can’t use the flowers as a verdict,” she said. “Not damage. Not adaptation.”

Arun pulled his chair closer to the table. Together they checked the calibration against the unaffected rack.

With one hour forty-three minutes remaining, Leena sent Vale the results without removing the contradictory measurements. On the shared channel, she said, “Some exposed plants are clearly impaired. Several others aren’t visibly impaired yet. Early flowering doesn’t distinguish them. We cannot establish eventual edible yield before your deadline, and inheritance would require another generation.”

Arun brought up the assay cabinet’s load sheet.

“Two small plants,” he said, shifting outlines inside its usable volume, “and one unaffected control. Separate trays. Closed drainage.”

“What does it cost?” Leena asked.

He checked again.

“A modest diversion from the supplemental lamps. But we’d have to lower the next greens harvest estimate and move two fresh-food portions into the reserve-food schedule.”

Leena left those figures visible beside her results.