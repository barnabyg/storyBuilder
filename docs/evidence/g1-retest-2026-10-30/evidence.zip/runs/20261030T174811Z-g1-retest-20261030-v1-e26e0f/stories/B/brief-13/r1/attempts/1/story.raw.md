Leena Sato found the first white flower while checking the dwarf beans for mites. It hung beneath a leaf, small enough to mistake for a scrap of filter cloth.

She lifted the next stem. Two more flowers.

The plants should have had another three weeks of leaves and roots before flowering. She checked the planting log, then checked it again against the tags clipped to the trays. Same batch. Same sowing date.

Only then did she call Vale.

While she waited, she opened the environmental record. Six days earlier, during the minor radiation storm, the shielding panel above rack four had failed to seat. Maintenance had corrected it in nineteen minutes. The dose registered beneath it was elevated, though the summary classified the incident as minor.

Commander Vale arrived with his breakfast pouch still folded in one hand.

"How many?"

"Eleven flowering. I haven't examined all the plants."

He studied the blossoms without touching them. "Quarantine the rack. Next waste cycle, we destroy it."

"That's tonight."

"Early flowers can mean small plants and poor yields. We've budgeted food around this harvest." He glanced toward the seed-storage cabinet. "Nothing from that rack enters planting stock."

Leena kept her hands still. On Earth, she had learned how quickly caution could become someone else's reason to stop listening.

"Give me twelve hours for an assessment. It's probably harmless—a stress response. I can establish whether there's cause to preserve a sample."

Vale looked at her. "Twelve hours. Isolated from now on. No extensions."

After he left, she closed the rack's clear enclosure and entered the quarantine code. Then she opened her inspection notes.

Probably harmless.

She watched the cursor blink after the words. She had no result that belonged beside them.

She deleted the phrase.

Leena folded the tablet against her chest and stood between the racks until her breathing slowed. Then she fetched the pollination sleeves.

She bagged each open flower, cinching the translucent fabric below the calyx. At the service panel she closed the rack's return valve and diverted its nutrient flow into a waste bladder. Nothing from these roots would reach another tray.

She inventoried all thirty-six plants: height, leaf count, flowers, unopened buds. Only when every stem had a numbered collar did she sterilize her scissors and take tissue samples.

The unaffected rack across the aisle was the same cultivar, planted on the same shift. She laid its records beside the flowering rack's: root-zone temperatures, lamp spectra, illumination periods, pump cycles, conductivity. One delivery pulse had arrived forty seconds late. Both racks had received it.

Archived images showed ordinary leaves until the storm. Afterward, the affected plants had continued growing without visible injury. She enlarged the frames, looking for something embarrassingly simple—a lamp left on, a sensor reading the wrong tray. Nothing explained the flowers.

The rapid screen returned negative results for every pathogen on its limited panel. Leena saved the report without forwarding it. Under the microscope, several pollen grains took up the viability stain; beside them, dissected buds showed twisted anthers and petals fused along one edge.

She examined another bud before recording that.

In the request window she typed: Authorization to transfer two plants to sealed assay cabinet.

The cabinet offered filtered air, independent lighting, independent cooling. It also drew from the power allocation reserved for replacement seedlings.

She opened the load estimate. Two plants would mean dimmer lamps over the next sowing, or a postponed sowing altogether.

Her thumb hovered over Send. She saved the request as a draft and returned to the microscope.

Arun came through the greenhouse hatch carrying disposal sleeves and a spool of seal tape.

"Vale wants the rack ready." He set the sleeves beside the sink, then checked his tablet. "You've booked the assay cabinet through tomorrow."

"I need it for the samples."

"What samples? I was counting on it for the replacement seed checks."

Leena adjusted the microscope's focus, though the cells were already sharp. "The reservation is provisional."

"So is this."

He laid the tablet beside her eyepiece. The food ledger showed the bean harvest as a green bar between two planting cycles. Arun tapped it, and the bar disappeared. Fresh-food portions dropped across the crew roster.

"We can cover calories from stores," he said. "But if these yield badly, we're on reduced fresh portions until the next planting comes in. And if I can't clear that seed, the next planting slips."

She had counted the hours the cabinet would give her. She had not counted what those hours belonged to.

"Are the beans dangerous?" he asked.

"The flowering response doesn't necessarily imply an unstable genome. A stress-mediated change in expression could—"

"Leena. Are they dangerous?"

"There are several kinds of risk."

He picked up the seal tape. "Then tell me which ones I'm containing. I won't improvise a barrier around an experiment you haven't disclosed."

"On Earth, committees spent years telling me I was too cautious. Every time I asked for another control, they—"

She stopped. Arun waited.

She knew what dismissal felt like. She had used that memory to excuse keeping the decision out of anyone else's hands.

"I don't know," she said. "And I kept that to myself because I wanted time before anyone could judge what I was trying to save."

Twenty minutes later, Leena stood beside the galley screen while the others crowded around the table. She had divided the display into three columns.

"Known: flowering began weeks ahead of schedule. The affected trays occupied the same rack during the radiation storm. We haven't established that the storm caused it."

She moved her finger across.

"Unknown: whether they'll set viable seed, what yield they'll give, whether their offspring would flower early. Suspected: radiation damage, or a stress response. Plants sometimes flower because conditions are bad, not because they've acquired a useful adaptation."

Vale folded her arms. "And the danger to the other crops?"

"An altered bean isn't automatically contagious. A genetic change doesn't jump between trays. But we haven't ruled out disease. Seeds can get mixed during handling. And calling a cabinet 'isolation' doesn't make it adequate."

She stopped there, resisting the urge to add that she had always been careful.

Vale looked toward the greenhouse hatch.

"The seed bank is our only reliable reserve until the next supply landing. If we lose a harvest, we can ration. If we compromise those seeds, rationing won't fix it." She turned back to Leena. "I can't approve an uncontrolled rescue because these plants might be useful."

"No," Leena said. "You shouldn't."

For a moment, only the galley fan spoke.

"Then what are we deciding?" someone asked.

Leena erased the question she had put beneath the columns: Can the crop be saved?

In its place she typed: Can we safely contain a tiny sample long enough to test it?

"Not our next harvest," she said. "A test with disposal rules."

Vale pulled a chair closer to the screen.

"Start with every way material could leave the enclosure."

By the time they had traced the drains, filters, gloves, and waste bags, the next image sequence was ready.

Leena watched it beside Arun. Under the time-lapse clock, leaves lifted and settled as the lamps cycled. Along the rack's central strip, where the dosimeters recorded the highest exposure, stems barely lengthened. Flowers opened above undersized leaves.

"There," Arun said, pointing toward the edge.

Three plants near the shielding bracket had flowered too, but their leaves continued expanding. Leena ran the sequence backward, then forward. For a moment she wanted to call those three the answer.

Instead, she opened the measurements.

Leaf area, stem extension, fluorescence: the numbers refused a clean division. One edge plant had normal growth but depressed photosynthetic efficiency. A central plant had lost growth before producing its first bud. Flowering time overlapped across both groups.

"We can't use the flowers as a verdict," she said. "Not damage. Not adaptation."

Arun pulled his chair closer to the table. Together they checked the calibration against the unaffected rack.

With one hour forty-three minutes remaining, Leena sent Vale the results without removing the contradictory measurements. On the shared channel, she said, "Some exposed plants are clearly impaired. Several others aren't visibly impaired yet. Early flowering doesn't distinguish them. We cannot establish eventual edible yield before your deadline, and inheritance would require another generation."

Arun brought up the assay cabinet's load sheet.

"Two small plants," he said, shifting outlines inside its usable volume, "and one unaffected control. Separate trays. Closed drainage."

"What does it cost?" Leena asked.

He checked again.

"A modest diversion from the supplemental lamps. But we'd have to lower the next greens harvest estimate and move two fresh-food portions into the reserve-food schedule."

Leena left those figures visible beside her results.

At the deadline, Vale stood beside the display long enough for its light to dim.

"You haven't justified keeping the rack."

"No," Leena said.

She felt the old argument gathering: the value of more specimens, the information they would lose. She let it pass and handed him the protocol she had written beneath the figures.

"Three plants. The strongest of the early bloomers, the stunted one from the end tray, and an unaffected control."

Vale scrolled without answering.

The cabinet would have sealed nutrient containment and filtered exhaust. Every flower would be bagged before transfer. Tools would remain inside, dedicated to those three plants. Nothing—not a leaf clipping, not a drop of nutrient solution—would return to the greenhouse. All waste would be sterilized.

"You've assigned disposal to yourself," he said.

"Yes."

"And if the cabinet loses containment?"

"You end the test. You don't need my agreement." She kept her hands still. "We record growth, pod set, and seed viability. That's the limit of this approval. Any trial involving offspring comes back to you separately."

Vale looked through the cabinet's inspection window.

"Three plants," he said. "Under this protocol."

He signed, and Leena countersigned before she could mistake permission for vindication.

She bagged the flowers herself. The vigorous plant caught briefly against its support; she freed it without breaking the stem. The stunted plant lifted easily. Last came the control, green and unremarkable. She secured each root module inside the cabinet, checked the seals, and recorded the time.

Arun waited beside the sterilizer with an empty disposal sleeve.

Leena took the shears from him. Across the rack, pale flowers trembled in the ventilation.

"Start at this end?" he asked.

"Yes," she said, and held the first stem steady.

By the time the disposal bin was sealed, Leena's gloves smelled of crushed leaves.

Arun waited beside the isolation cabinet. Together they checked the door gasket, the filtered exhaust, and the seals around the sampling ports. He read each pressure value aloud; she entered it, then they exchanged places and repeated the check.

They logged temperature, humidity, radiation dose, and reservoir chemistry. Leena placed the unaffected control beside the two anomalous plants, each in its own tray. Arun adjusted the lamps until the meters agreed. The nutrient solutions came from the same batch.

"Baseline saved," he said.

Vale posted the revised schedule on the greenhouse door and the mess display. Replacement sowing would begin tomorrow. Bean portions would be reduced for nineteen days; stored lentils would cover part of the gap. The cabinet's power allocation appeared on a separate line.

Leena looked at that line longer than the others. Nobody had hidden it under maintenance.

At the terminal, she uploaded the images, instrument files, and handwritten observations she had transcribed during the night. Beneath them she listed what they did not know: whether the storm had caused the change, whether it was heritable, whether early flowering would reduce yield, whether any resulting seed would germinate.

She scheduled a review for forty-eight hours later, with three possible decisions: continue, modify, terminate.

Arun accepted the invitation. Vale's acknowledgment followed.

Before leaving, Leena checked the plants once more. Inside a pollination bag, one white flower had begun to wilt. Its folded petals obscured the ovary. She could not tell whether it would set a pod, much less a viable one.

She entered the time, the plant number, and what she could see. Then she closed the log.