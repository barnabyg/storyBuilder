When Mina returned, the site manager was waiting at the counter with the auction inventory. He ruled a line through the mural’s entry, initialled it, and handed her the signed handover form.

“The demolition crew will need your photographs,” he said. “To locate the tiled edges. They can’t tell from the drawings where it stops.”

“I numbered them.”

“Send the whole set.”

She folded the form along its existing crease.

Leila helped carry the remaining towels to the collection cage by the service door. Without them, the shelves showed pale rectangles in the paint. One towel caught on a wire; Mina freed it rather than pull.

“I hope I can bring my daughter through the passage one day,” Leila said. “Show her her grandfather’s name.”

Mina reached for the petition copies beneath the counter, then stopped.

“Would you like these?”

Leila considered the thick bundle. “Just the page he signed. If that’s all right.”

Mina found it and gave it to her.

After Leila left, Mina walked through the changing rooms. She checked beneath every bench, lowering herself carefully, one hand against the wood. There was a hairpin, a damp receipt, nothing anyone would come back for. In the showers she turned each tap firmly shut. The pipes knocked behind the tiles. Usually someone answered the noise with a complaint or a joke; tonight she could hear it travel.

At the mural, a strip of petition tape still clung below the lowest names. She worked it loose with her thumbnail and rolled the sticky length into a small grey bead. The conservator’s survey marks remained: short blue strokes on the plaster beyond the tiled edges. She left them untouched and switched off the lights.

In the staff room, her husband’s mug stood beside the kettle. She wrapped it in a clean cloth and packed it beside her own. There was room for both.

Outside, she locked the bathhouse and tested the handle once. Then she pushed the keys through the agreed letter slot and heard them land inside.