Leena Sato found the first flower while checking the dwarf beans for mites. It hung beneath a leaf, white and small enough to mistake for a scrap of filter cloth.

She steadied herself against the rack and lifted the next stem. Two more flowers. In the Moon’s gravity, the branches offered so little resistance that she still sometimes mistook a healthy plant for a brittle one.

The beans should have had three more weeks to build leaves and roots. She checked the sowing log against the tray tags, then examined the buds farther up the stems.

Eleven plants were flowering. More would open soon.

Above rack four, a yellow maintenance label marked the shielding panel that had failed to seat during the radiation storm six days earlier. Nineteen minutes, according to the repair record. The storm was classified as minor. That classification described the danger to the crew, not to a bean’s growing tip.

She called Commander Vale.

Vale arrived with a breakfast pouch tucked into her belt. She looked first at the flowers, then at the seed cabinet across the aisle.

“Close the rack. Nothing goes into planting stock.”

“I’ve already suspended the harvest designation.”

“And the rack goes through sterilization tonight.”

Leena glanced at the waste-cycle clock. Twelve hours.

“We don’t know what’s happened.”

“I know we can replace these plants from seed. I don’t know whether we can replace the seed bank if we mishandle this.”

“The flowers aren’t a diagnosis.”

“No. They’re a reason to stop treating this as food.”

That was fair, and harder to answer than panic would have been.

“Give me until the waste cycle,” Leena said. “I can assess whether a small sample is worth keeping.”

Vale studied her. “You cannot establish safety in twelve hours.”

“No. But I can establish whether we have a defensible test.”

“Then that’s what I want. Not a reason to keep the beans because they’re yours.”

After Vale left, Leena closed the rack’s clear enclosure. She isolated its nutrient return and diverted the drain into a waste bladder, then entered the quarantine code.

In her notes she had typed: Likely transient stress response.

She read it twice and removed “likely.”

On Earth, she had spent fourteen years asking people to wait: another growing cycle before release, another control before a trial. At her last institute, a director had called her impeccable judgment “an obstacle to delivery.” She had come to the Moon because caution here was supposed to count as competence.

Now there were flowers where she had promised beans, and she wanted, with an urgency that embarrassed her, to prove they were not a failure.

She fetched the pollination sleeves.

By the time the first hour had passed, every open flower was enclosed in fine fabric. Beans usually pollinated themselves, but usually was not a containment method. She numbered all thirty-six plants, photographed their growing tips, and took tissue with sterilized scissors.

The adjacent rack held the same cultivar, sown on the same shift. She compared lamp schedules, root temperatures, nutrient chemistry, pump cycles. Both racks had received one feed pulse forty seconds late. Neither had overheated.

Archived images showed the first visible buds three days after the storm. That established a sequence, not a cause. The instruments measured radiation at two points beneath the panel; the plants between them had received doses she could only estimate.

The pathogen screen found nothing on its limited panel.

Under the microscope, some pollen took up the viability stain. Two unopened buds had twisted anthers. Another had petals fused along one edge.

Leena set those images aside and opened the next sample.

When Arun came through the hatch, she had not left the bench for four hours.

He carried disposal sleeves under one arm and a coil of seal tape under the other. A strip of green thread clung to his cuff from the galley’s repair kit.

“You reserved the assay cabinet,” he said.

“Provisionally.”

“I need it for germination checks.”

“Only for a day.”

He put the sleeves down. “Your reservation says four.”

She had entered four days because one day would tell her almost nothing. She had not sent the accompanying request because she wanted results to put beside it.

“I was going to discuss it.”

“When?”

Leena turned the microscope light off.

Arun brought up the food ledger. The scheduled bean harvest made a narrow green bridge between two plantings. He removed it. Fresh-food portions shrank across six names.

“Calories are covered,” he said. “Nobody starves. But Vale’s already using the reserve margin to stretch us to the delayed cargo landing. If replacement sowing slips too, we lose the next bridge.”

“The cabinet has space for three small plants.”

“And a drain that empties into the greenhouse recovery line.”

She knew that. She had planned to cap it.

He waited, letting her hear how thin that answer would sound.

“Are they dangerous?” he asked.

“Early flowering doesn’t necessarily imply—”

“Leena.”

She looked at the dark eyepieces.

“I don’t know.”

“All right. What don’t you know?”

She almost said she needed time. Instead she showed him the malformed buds, then the negative screen.

“This doesn’t rule out an organism we don’t test for. The pollen may be viable. The plants could make poor seed, or perfectly ordinary seed. Some may be damaged. Some might be responding to stress without permanent genetic change.”

“Vale’s seen this?”

“Not yet.”

Arun picked up the tape but did not leave.

She had wanted to protect the work until she understood it. In practice, she had made everyone else work with less information than she had.

“Give me ten minutes,” she said. “Then help me explain it.”

They met in the galley because there was nowhere else all six could sit. A lettuce leaf, escaped from somebody’s lunch, clung to the intake grille. The ventilation clicked each time it caught an edge.

Leena put the images on the wall screen, including the damaged buds.

“I asked for time as if time alone would settle this,” she said. “It won’t. Not before tonight.”

Vale leaned back without speaking.

“We have an association with the shielding failure. We don’t have proof of cause. We have early flowering, but that can happen when a plant is under stress. It isn’t evidence that we’ve acquired a faster crop.”

“And contamination?” asked Imani, the station mechanic.

“An altered bean genome doesn’t spread through the air. Disease could. Pollen and seeds could be moved by us. The most immediate risk may be a handling mistake.”

“So we sterilize them,” Vale said.

“The rack, yes.”

Saying it hurt more than Leena expected.

She changed the display to a diagram of the assay cabinet.

“I’m asking whether we can safely retain two plants, with an unaffected control. Not for food. Not for breeding. A contained observation.”

Imani pointed to the drain.

“Capped, with an internal reservoir,” Leena said.

“Capped how?”

Leena stopped. “I need you to tell me.”

Imani pulled the diagram toward her.

For the next half hour, they traced every route out of the cabinet: drain, exhaust, sampling port, gloves, tools, waste. Arun added the cost of the electricity. Vale asked who would inspect the seals and who could terminate the test.

“Anyone responsible for station safety,” Leena said. “Including you, without my consent.”

“And what would make you terminate it?”

“Loss of containment. A pathogen indication. A power demand above the agreed limit.”

“Write those down.”

When they returned to the greenhouse, Arun stayed.

Together they watched the image archive in time lapse. Leaves lifted toward the lamps and settled into darkness. In the central trays, stems scarcely lengthened before flowers opened above undersized leaves. Near the shielding bracket, three plants flowered while continuing to grow.

“There,” Arun said.

Leena felt the sudden temptation of a simple explanation: high exposure damaged the center; lower exposure had produced something useful along the edge.

She opened the measurements before she could say it.

One edge plant had expanding leaves but depressed photosynthetic efficiency. One central plant had slowed before its first visible bud. Estimated radiation dose, flowering time, and growth did not separate into tidy groups.

Arun watched her compare the graphs.

“Not there?” he asked.

“Maybe. But not because we can draw a line through three plants.”

He nodded and fetched the calibration reference.

They checked the instruments against the unaffected rack. Then Leena uploaded the contradictory plots to the shared station log.

Her hands were shaking slightly from hunger. Arun pushed a pouch of lentil paste across the bench without looking up from the load sheet.

“Cold,” he warned.

She ate it anyway.

Two hours remained when Imani finished testing a removable drain closure and a rigid secondary tray. The cabinet could hold three separate root modules without connecting their nutrient solutions. Its exhaust filter passed the integrity check.

“Keeping the cabinet lit means less supplemental light over the greens,” Arun said. “I can move the seed checks to a sealed germination box. It’s slower to inspect, but we won’t delay sowing.”

“What do we lose?”

“Two fresh portions a week until the next greens harvest. Shared across the roster.”

Leena looked at her own name among the six. It would have been easier to offer up her portions, make the experiment a private sacrifice. But she could not pay privately for shared power, shared space, or someone else’s time.

“Put that in the request,” she said.

At the waste-cycle deadline, Vale came to the greenhouse carrying Leena’s protocol on a tablet.

“Why these two?” she asked.

“One growing reasonably well despite flowering early. One visibly impaired. The control lets us check whether the cabinet itself is causing poor growth.”

“One of each proves very little.”

“Yes. This is an observation trial. It may tell us which question is worth a larger experiment. It won’t establish inheritance.”

“And any seeds?”

“Remain sealed. Counted, photographed, stored in the cabinet. No germination without separate approval.”

Vale read the termination rules again.

Beyond her shoulder, white flowers crowded the quarantined rack. In a month, some might have become pods. Leena had selected every seed, adjusted every feed cycle. She could still ask for six plants instead of two. More replicates, better evidence.

She kept silent. The cabinet was only so large. The next planting needed its power.

Vale signed.

“Forty-eight-hour review. If the seals or the load estimates are wrong, we stop.”

Leena countersigned, then called Arun over to witness the transfers.

The vigorous plant caught on its support. She freed one tendril slowly, unwilling to tear it simply because the clock was running. The impaired plant came away easily, its roots a sparse cream fringe inside the module. Last came the control, dark-leaved and without a bud.

They secured all three in separate trays, checked the flower sleeves, and closed the cabinet.

Then Arun held open the first disposal sleeve.

Leena took the shears.

She had expected herself to hesitate. Instead she worked methodically, holding each stem steady while Arun received the cut material. Twice she stopped to verify a plant number against the disposal record. Once he caught a loose flower before it reached the floor.

When the final sleeve entered the sterilizer, rack four was a grid of empty sockets.

They exchanged places for the cabinet checks. Arun read the pressure values aloud while Leena entered them; then she read while he verified. Imani inspected the drain closure again. Vale posted the revised food schedule beside the greenhouse hatch.

The experiment’s power allocation occupied its own line.

Leena uploaded her microscope images, the radiation estimates, and the notes she had made before she understood how little she knew. She included the limited pathogen screen and marked its limitations. The review invitation went to all six crew members.

Inside the cabinet, a flower had begun to wilt within its sleeve. The petals were folding over the place where a pod might form. There was no way yet to tell whether the plant had hurried toward a successful harvest or spent its remaining strength on a seed that would never grow.

Arun paused at the hatch. “Anything else?”

“Not tonight.”

She entered the plant number, the time, and what she could see. Then she left the log open on the shared screen and went with him to supper.