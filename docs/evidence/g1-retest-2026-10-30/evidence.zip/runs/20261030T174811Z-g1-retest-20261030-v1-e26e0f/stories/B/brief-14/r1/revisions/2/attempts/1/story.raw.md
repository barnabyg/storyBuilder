“Observe the figurehead,” Nuno Vale told his tourists.

Twelve faces tilted towards the gilded woman above the gallery door. Nuno passed the museum leaflet behind his back.

“And that is how sailors lost their wages ashore. Everybody watches the pointing hand.”

A German gentleman checked his wallet.

“Pure theatre,” Nuno assured him.

It was theatre now. He paid taxes, wore shoes recommended by a pharmacist and had become the guide hotels requested for difficult families. His former profession survived chiefly as an understanding of where people weren’t looking.

Behind the group, Director Seabra was arranging paper ships beside a replica cannon.

“For tonight’s donor gala,” he explained. “A finale.”

The cannon faced three rows of gilt chairs. Above them, a banner announced FIVE CENTURIES OF PORTUGUESE INGENUITY.

“Compressed air,” said the technician kneeling beside it. “Confetti and these little boats.”

“Discovery raining upon generosity,” Seabra said.

The technician opened a hatch on top of the barrel and unscrewed a brass loading cap.

“Paper only. Anything solid becomes a projectile.”

“Even generosity?” Nuno asked.

The technician smiled. Seabra didn’t.

On the adjoining table stood an open display case containing the museum’s smallest treasure: a brass compass scarcely wider than a biscuit. Its upright lid carried a photograph of the sixteenth-century pilot said to have owned it.

“The lock’s being repaired,” Seabra said, noticing Nuno’s glance. “It will be secured before the guests arrive.”

The technician put the loading cap beside the compass.

“Twins,” Nuno said.

“Only one has threads.” The technician tapped the cap. “Neither belongs down the barrel.”

A microphone shrieked.

Seabra pointed towards the lectern. “Could you deal with that?”

“Don’t load anything until I’ve checked—”

“Yes, yes. I can manage paper.”

The technician went. Seabra moved the brass cap into the velvet recess to make room for his tray of boats.

A catering worker at the doorway straightened her cuff.

Nuno knew that gesture. Bia used to make it before entering a crowd.

Her hair was shorter and going grey at the temples. Her expression, on seeing him, remained professionally blank.

Nuno turned back to his tourists.

“And now, Portuguese navigation: the art of reaching somewhere entirely unexpected and naming it after someone who stayed at home.”

He had nearly delivered them to the gift shop when Seabra intercepted him.

“A private word.”

“My group is waiting.”

“They can examine the rope.”

“They’ve paid for maritime history.”

“It’s historic rope.”

In his office, Seabra opened a security clip on his laptop.

It showed the navigation gallery crowded with visitors. Behind the raised display lid, Bia’s arm moved. A small brass object appeared in her fingers and disappeared into her apron.

Nuno recognized the movement before the face: elbow close, wrist easy. Shelter the object; never clutch it.

“The compass,” Seabra said. “Five hundred euros for its recovery. Discreetly.”

“Have you called the police?”

“Not yet. There’s no need to alarm the trustees before we know the facts.”

“An excellent time to discover them.”

“The caterer says you know the woman.”

Nuno kept his eyes on the screen.

“We’ve met.”

“Then perhaps you can persuade her not to ruin her life over something she can’t sell.”

In the velvet recess, something round gleamed.

“The cap,” Nuno said.

“What?”

“Could I see the minute before this?”

“This is the relevant portion.”

At the left edge of the picture, Bia raised her free hand towards a sleeve. Someone she was trying to stop.

“Who selected it?”

“I did. Security gave me access. I thought that would save time.”

“And the cannon?”

“The technician is dealing with the cannon. I’m asking you to deal with the theft.”

The word sat comfortably in Seabra’s mouth. Nuno disliked how comfortably it sat in his own mind.

Outside, he told his tourists that the last ten minutes of their tour were being refunded.

The German gentleman looked disappointed.

“Will we miss a story?”

“I’m afraid I haven’t got the ending.”

The cloakroom attendant had seen Bia leave.

“She asked for the technician three times. Then the director rang her agency.”

“What did he say?”

“That they should send somebody without complications.”

“Did she hear?”

“Everybody heard.”

Nuno found the technician beneath the lectern.

“Has the cannon been checked?”

“No. Now the microphone only works if I hold this cable.”

“Then let it enjoy a rest.”

They went together. The cannon’s hatch was shut. Under a fern in the huge floral arrangement beside it lay a red tag.

DO NOT FIRE.

Below that, in ballpoint: CHECK BARREL.

The technician picked it up.

“That’s mine. From the tool bag.”

“Not your writing?”

“No.”

Nuno read the firm, square capitals. Bia had once addressed false-bottomed suitcases with the same conscientious hand.

“Disconnect it,” he said.

Seabra arrived as the technician shut the air valve.

“What are you doing?”

“Checking the barrel,” said the technician.

“We have a rehearsal in fifteen minutes.”

“Then we’ll rehearse something else.”

“Surely we needn’t dismantle the entire—”

The technician uncoupled the hose. It hissed, and Nuno felt his shoulders loosen.

The loading hatch came open. Inside were paper ships. Nothing else.

“See?” Seabra said.

The technician looked at the tag, then at him.

“Who found this?”

“I did,” Seabra said. “It was spoiling the flowers.”

Nuno took out his telephone.

Getting Bia’s number from the catering supervisor required a story about a lost bracelet. It was a good story, with a worried widow and a clasp that caught on aprons. He disliked himself for using it.

He sent: Coffee, no saucer. Nuno.

It had once meant a conversation, not a share.

Her answer arrived almost immediately.

Across the road. They won’t let me back in.

Then: Don’t let him fire the cannon.

Nuno looked through the window. Beneath the statue of a navigator pointing confidently towards a pharmacy, Bia sat outside a café.

He crossed.

“You look prosperous,” she said.

“These trousers are washable.”

“That’s how it starts.”

On the table stood an untouched coffee and a supermarket bag.

“Do you have it?” he asked.

“Yes.”

“Thank God.”

“Interesting choice. You haven’t asked why.”

Nuno sat down.

“He showed me a film.”

“Did he show you himself?”

“No.”

“There’s your answer.”

She pushed her coffee away.

“I tried to find the man with the tools. Then Seabra was telling my agency to check my record. In front of the waiters.”

“Why didn’t you leave it with someone?”

“Who? Him?”

She nodded towards the museum.

“I knew what the picture would look like. I thought I’d explain once someone was willing to listen. Then I got outside and realized I was a woman with a record carrying a museum exhibit in a shopping bag.”

Nuno glanced at the bag.

“I can take it back. No names.”

“He already has my name.”

“I mean—”

“I know what you mean. You’ll say you found it somewhere. He’ll say he recovered stolen property. I lose my shifts, and you stay charming.”

That landed cleanly.

He had spent twelve years turning his practiced eye into respectable entertainment. His references concerned punctuality, languages and the successful management of schoolchildren. None covered the years when he and Bia had worked the tram queues.

“He’s offering five hundred euros,” Nuno said.

“For a culprit or a compass?”

Nuno stood.

“Stay here.”

“Are you coming back?”

“Yes.”

She studied him, then pulled her coffee towards her.

“You used to say that very well.”

Seabra was supervising champagne glasses when Nuno returned.

“I can recover it.”

“Excellent. Where is she?”

“First we watch the complete recording.”

“We’ve watched the relevant part.”

“Then you won’t mind showing me the rest.”

Seabra set down a glass.

“I recommended you to the hotels, Vale. Your references were unusually brief.”

For a moment Nuno saw everything the director could touch: regular bookings, the small flat, the pleasure of answering questions about his work without preparing a lie.

“You asked whether I knew her,” he said. “I did. Years ago.”

“In what capacity?”

Nuno let the question wait between them.

Then he said, “She put a warning on your cannon. You removed it.”

“She was interfering with equipment.”

“And your film starts after that?”

The gala coordinator approached with a seating plan.

“Is there a problem?”

“No,” Seabra said.

“Yes,” Nuno said.

She stopped.

Nuno pointed towards the cannon.

“The technician found an unauthorized load and a warning tag that had been hidden.”

“Paper,” Seabra said. “He found paper.”

“Then the full recording will reassure everyone.”

The coordinator looked at Seabra.

“The insurer will want it preserved.”

This, apparently, was a request with professional qualifications.

They watched in the security room: Nuno, Seabra, the coordinator and the technician, still holding his screwdriver.

In the full picture, the display case and the cannon stood side by side. The raised lid concealed the loading hatch from the narrower view Seabra had chosen.

Seabra appeared on screen. He placed the loading cap in the compass’s velvet recess.

Then he gathered the paper boats into the tray.

Among their white prows lay a little brass circle.

“There,” Nuno said.

They watched Seabra tip the tray into the cannon.

Bia crossed the gallery, one hand raised. Seabra waved her away while answering his telephone. She pointed at the hatch. He turned his back.

The director in the security room moved his lips, but said nothing.

On screen, Bia waited until he walked away. Then she reached behind the display lid, opened the hatch and brought out the compass.

She looked towards Seabra, now beyond the camera’s edge. She looked at the compass, the open case, the brass cap occupying its recess.

Then she pocketed it, fetched the warning tag from the tool bag and tied it across the firing lever.

The technician leaned forward.

“That would have gone straight into the front row.”

“The paper might have—” Seabra began.

“No.”

“It’s a very small object.”

“So is a tooth. You wouldn’t want one fired at you.”

Nuno watched the rest. Bia stopped an attendant, pointed towards the cannon and hurried after the technician.

No flourish. No accomplice waiting by a door. Just a woman trying to get somebody to listen.

“When did you recognize the cap in the case?” Nuno asked.

Seabra stared at the frozen picture.

“You knew there’d been a mistake,” Nuno said. “You could have stopped everything.”

“There would have been questions.”

The coordinator opened her notebook.

“There are.”

Nuno called Bia.

She arrived carrying the supermarket bag. From it she took a parcel wrapped in a catering napkin and laid it on the desk.

Seabra reached towards it.

Bia kept her palm on the napkin.

“My agency,” she said.

The coordinator turned to Seabra.

“First.”

He wrote the email while they watched. At Bia’s request, he changed “misunderstanding” to “unfounded allegation.” At the coordinator’s, he added that the museum would pay her full shift.

“And the reward?” Nuno asked.

Seabra looked up.

“It was offered for recovery.”

“Here it is.”

Bia lifted her hand.

By six, the cannon was locked in a storeroom. Volunteers handed paper ships to arriving donors. Several looked relieved not to be required to enjoy an explosion.

At the lectern, Seabra abandoned the first page of his speech.

“A member of our event staff prevented a dangerous loading error this afternoon,” he said. “The responsibility was mine. The compass has been safely returned.”

Bia stood at the back, no apron now, holding a glass of champagne.

Nuno caught her eye before stepping forward.

“We had intended to finish with a cannon,” he told the guests. “Instead, you’ll have a story. Quieter, though not necessarily shorter.”

Afterwards, beneath the cloakroom lamp, he divided the reward.

“You could have kept it,” Bia said.

“The money?”

“The compass.”

“It wouldn’t have suited my flat.”

“Too much brass?”

“Insufficient security.”

She laughed and took her half.

On his next tour, the repaired case contained the compass and a new label. It described how Beatriz Costa, a member of the event staff, had prevented the accidental firing of the object during gala preparations.

The German gentleman had returned with his wife.

“So,” he said, reading it, “you found the ending.”

Nuno glanced at the label. Seabra had requested “procedural irregularity.” The coordinator had insisted on “loading error.” Bia had wanted her name spelled correctly.

“Yes,” Nuno said. “Though several people tried to help me lose it.”