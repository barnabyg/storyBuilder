Mrs. Shah appeared on the landing with Mr. Vega and the woman from 3B, whose name Ruth had never learned.

“Isabel’s in my apartment,” Mrs. Shah said. “Door locked.”

Manny’s fingers loosened on Ruth’s arm. He looked at the three faces above him, then released her.

“You’re making this something it isn’t.” He backed toward the lobby, pulling out his phone. “All of you.”

Ruth waited until he was beyond the stairwell door.

“I signed maintenance records for work he never did,” she said. “Inspections, repairs. I signed them.”

Mr. Vega looked at her.

“I’ll answer for that. Right now there’s a woman behind this door. Elena.” She pointed to the woman from 3B. “Please film. The lock, the hinges, everything.” Then to Mrs. Shah: “Wait outside for the fire crew. Bring them straight here.”

From her tool cupboard Ruth fetched the hacksaw. She braced the blade against the exposed curve of the padlock shackle. Each stroke scraped through the stairwell. Sweat ran into her eyes.

Mr. Vega took over when her hand cramped.

The woman filming offered her water bottle. Ruth drank a mouthful, squeezed the bottle nearly flat, and pushed it through the gap beneath the door.

“Elena. Water. Just by your hand.”

Something dragged across the floor inside, then stopped.

“I can’t,” Elena whispered.

The stairwell lights dimmed. A sharp, burning smell rose from the electrical panel beside the tool cupboard.

“Elena?”

No answer.

Ruth pulled Mr. Vega back by his shirt.

“Upstairs. Away from that cupboard. Both of you.”

She lifted her phone.

“The lights are dimming,” she told the dispatcher. “There’s a burning smell at the panel. The woman inside isn’t answering now. Please tell the crew.”