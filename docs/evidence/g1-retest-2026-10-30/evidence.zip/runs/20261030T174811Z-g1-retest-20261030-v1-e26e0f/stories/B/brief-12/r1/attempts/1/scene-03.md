She struck the door three times with her wrench, spacing the blows so they could not be mistaken for work.

For a moment there was only the hum of the stairwell light.

Then two blows came back. The second barely reached her.

Ruth pulled out her phone and called emergency services before she could make herself listen again.

“Someone’s locked in our basement,” she said, giving the address. “It’s dangerously hot down here. The electricity keeps dipping, and we’ve got wiring that can’t carry the load.”

The dispatcher asked whether the person was conscious.

“They answered me. Please send the fire department.”

“Units are responding to multiple heat-related emergencies. There may be a delay. Do not enter an unsafe space yourself. Stay where you can direct responders.”

Ruth looked at the new padlock. “I’m outside the door.”

She ended the call only when instructed, then crouched near the gap above the threshold.

“Help is coming. Who’s there?”

“Elena.”

Ruth knew the voice from the third floor, though now it sounded scraped thin.

“Manny locked it,” Elena said. “I took pictures. The wires down here. He wanted my phone.”

“How long have you been inside?”

“I don’t know. The little fan stopped.”

Ruth held her hand against the gap. Nothing moved against her fingers.

“I’m going to record you,” she said. “Tell me again.”

She started a video, keeping the new lock in frame while Elena repeated herself. For years Ruth had kept complaints out of writing, calling Manny instead, giving him time to put things right. Now she checked that the recording had saved.

Then she texted Mrs. Shah: Keep Isabel upstairs with you. Lock the apartment door. Don’t open it for Manny, whatever he says.