Mina poured the kettle into the teapot and left it standing. On a sheet from the incident book she wrote: We, the undersigned, demand that nothing in the bathhouse be disturbed pending consultation with its users.

By nine, steam had softened the windows. She carried the sheet on her clipboard to the bench beneath the broken clock, where Mr. Bell was folding his trousers along the creases. Thirty-eight years on the buses, and he still arrived at seven minutes past.

“About the closure,” she said.

“Disgrace,” he said, and signed before she could steady the board.

She took his quickness as encouragement. At the hooks beside the women’s entrance, Leila was hanging her coat inside out, keeping the lining clear of the wet wall. Mina had already put the rubber mat in the corner shower for her.

“We’re asking them to leave things alone.”

Leila read the sheet. “I can’t sign this.”

“It’s the last morning. They could at least—”

“I’m on their waiting list, Mina. The housing people. Have been since February.”

From the showers came the knock of a dropped soap dish. Mina glanced toward it, grateful for something she knew how to attend to.

“I only mean the mural.”

Leila held the clipboard between them and put a finger under nothing.

“Does this mean the boilers? The roof? Would keeping your wall hold up the flats?”

Mina had written the demand at the same desk where she recorded deliveries, with the same confidence that a clear entry prevented mistakes. Now she saw how much she had left unclear.

She unclipped the paper and tore away the blank space below Mr. Bell’s signature. On that piece she wrote, slowly: Preserve the donor mural in the redevelopment. This request does not seek to reopen the bathhouse.

She did not offer it for signing.

“If it stayed,” she asked Leila, “what would being able to see it actually require?”

Leila kept hold of her towel.

“Who would have the key?” she asked.