Mina set the towels in stacks of twelve, folded edges toward the aisle. In the staff kitchen she filled the kettle and took down two mugs. She had put water into both before she noticed. She emptied the brown one, dried it, and returned it to the cupboard.

Her husband had been dead eight months. He had never worked at the baths, but after retiring he had brought her lunch on Thursdays. It was Friday.

The pipes knocked behind the kitchen wall. On the last morning of its hundred-and-second year, the bathhouse sounded as though it expected another hundred.

Beside the closure notice hung six pages of auction inventory. Mina read them while the kettle boiled: benches, lockers, brass hooks. Halfway down the second page was "decorative tile panel, removable."

In the entrance hall, a yellow sticker numbered 63 had been fixed above the dry drinking fountain.

The tiled tree grew around the fountain and continued onto the adjoining wall. Names occupied its leaves and branches: E. Baines, the Iqbal family, St. Agnes Laundry Workers. They commemorated the collection that had replaced the boilers in 1978. Mina remembered the opening ceremony from a photograph: women in coats holding cups, a councillor pretending to turn a valve.

She followed Pereira around the corner. A chalk line ran through the last three letters.

The site manager arrived carrying a carton of key tags.

"It isn't removable," she told him.

"Anything can be removed."

"Not necessarily whole."

He looked at the wall. "Send me something. The disposal board meets at four."

"Today?"

"They have to approve the final transfer."

To the housing nonprofit. Forty-six homes, according to the notice. A lift, bicycle storage, a courtyard where the boiler house stood.

Mina showed him where a name crossed two tiles.

"I can forward a query," he said. "I can't withdraw a lot."

He shifted the carton against his hip.

"And I need your handover completed tonight. The additional severance payment depends on it. You signed the schedule."

She had. She knew the amount to the penny, and how many months it would last.

In the office she took a sheet from the incident book and wrote: We, the undersigned, demand that nothing in the bathhouse be disturbed pending consultation with its users.

Mr. Bell signed without putting on his glasses.

"About time," he said.

He was folding his trousers beneath the broken clock, as he had done every Tuesday and Friday for twenty-three years. Mina knew he needed the end locker because he could no longer bend to reach the lower hooks. She had never asked where he would wash next week.

Leila was hanging her coat inside out beside the women's entrance. Mina had already put a rubber mat in the corner shower for her ankle.

"We're asking them to leave things alone," Mina said.

Leila read the sheet.

"I'm on their waiting list."

"I mean the tiles."

"That isn't what you've written."

From the showers came the clatter of a dropped soap dish. Mina turned toward it, relieved by a problem with an established remedy.

"Mina."

She turned back.

"My daughter sleeps beside our cooker. I won't sign anything that holds up those flats."

Mina looked down at the words she had written in her neat, unquestionable hand.

She tore off the unused lower half of the page.

On it she wrote: Preserve the donor mural in the redevelopment. This request does not seek to reopen the bathhouse.

Leila read that too.

"Where would it go?"

"Perhaps they could put it in the entrance."

"To the flats?"

"Yes."

"Then who would have the key?"

Mina lowered the clipboard.

By eleven, six people had asked her what would happen to the soap, three had asked about their locker deposits, and one had cried because he had expected to come on Monday. Mina gave him the closure leaflet, then took it back.

"Is there someone you'd like me to call?"

He shook his head. She sat beside him until he could put on his shoes.

Between laundry loads she began collecting accounts of the wall. Not signatures this time. She asked people what they remembered, and whether she could share it at the meeting.

Mrs. Bennett sent a photograph of her mother standing beside the newly finished tree, handbag pressed against her stomach.

"She cleaned houses to give that money."

Mr. D'Souza said, "It was a boiler fund. We were tired of freezing."

"Your father's name is there."

"He liked that part." He considered. "Plenty of people couldn't give anything. They belonged here too."

Mina wrote down both sentences.

She called two former patrons from the lost-property book before stopping with her finger beside a third number. The book had been entrusted to her for returning things. She closed it. Mrs. Bennett offered to contact people she knew; Mina asked her to give them Mina's own number.

At noon Leila returned with a photograph of the development plan displayed in the library.

"There's meant to be a passage from the street to the courtyard."

On the office screen they enlarged it until the lettering blurred. The proposed passage ran beside a thick black line, exactly where the mural stood.

"It might only mean they haven't drawn the demolition properly," Mina said.

"Ask."

Mina fetched her tape measure.

For thirty-one years she had cleaned the tree with a soft brush, working grime from the grout, avoiding the crazed glaze near the basin. Now she measured it twice and photographed the places where its branches disappeared beneath later plaster. She found tiles behind a loose noticeboard that she had not seen since the smoking ban.

The site manager caught her kneeling there.

"I've had a call about a campaign."

"A request."

"Someone's saying you're stopping the sale."

"Who?"

"That isn't the point."

She stood, using the fountain for support.

He glanced into the office, where the towel ledger lay open beneath photographs.

"You're still on duty. If I have to report an incomplete handover, payroll will hold the completion payment while it's reviewed."

For a moment she wanted to offer him the camera, the papers, the whole morning. She could go back to counting linen. The baths would close and she would have enough money to remain in her flat until spring.

Instead she said, "The laundry's ready for collection. There are eighteen towels still out. I'll finish the count when they come back."

"And the meeting?"

"I'll clock out."

She had not raised her voice. Afterwards her hands shook so badly she had to sit on them before answering the telephone.

At three, with the last bathers gone, she counted the towels and completed the deposit ledger. She left the keys and meter readings for her return.

At the copy shop she paid for eight sets of photographs, statements and measurements from the envelope marked NOVEMBER. Leila held the large plan flat while Mina wrote beside the passage: Could this remain public?

Mr. Bell arrived with a cardboard placard.

SAVE OUR BATHS.

"I can't take that in," Mina said.

"You got my signature."

"On something I shouldn't have written."

"So now we ask for a bit of wall?"

"Yes."

His lower lip tightened. Without his dentures, which he removed to bathe, he sometimes looked startled by his own anger.

"I don't need a wall, Mina."

"I know."

She almost said she would find him another place, but she knew the nearest public showers involved two buses and a flight of stairs.

"No," she said. "I don't know what you'll do."

He put the placard beneath his arm.

She left a copy of the new request on the counter for him. When she and Leila reached the street, he was still inside.

The board met upstairs in the library. Through the window Mina could see the bathhouse roof, its patched lead flashing bright in the late sun.

The chair let her distribute the papers, then said, "We cannot reconsider the closure."

"The baths will close today."

Saying it before strangers felt disloyal. She continued.

"The auction describes the mural as a removable panel. It's built into two walls. Before you sell it, I'd like you to look at what you'd be selling."

The nonprofit's project manager studied her photographs.

"We can't accept an uncapped conservation liability."

"And we can't lose homes," said the chair.

Leila leaned forward. "I'm waiting for one of those homes."

She gave her application number. Mina watched the project manager write it down, then stop himself and turn the paper over.

"I want the flats built," Leila said. "But if that's a passage beside the wall, could people still come through and see it?"

"It's residents' access," he said. "We intended gates."

The architect, attending by video, asked someone to hold the plan closer to the camera.

For several minutes the discussion went on without Mina. Fire separation, drainage, maintenance. The fountain projected too far. The passage could be widened into the old reception area without changing the flats, but the decorative screen budget would have to go.

"That screen conceals the bins," the project manager said.

"Then we'll need cheaper bin storage," the architect said. "Retaining the masonry may actually save some demolition work. I need an engineer to inspect it."

A board member suggested lifting the tiles and storing them.

Mina laid a close-up in front of him.

"The last stroke of that name is on the next tile. There are cracks you can't see in the big photograph. I don't know what would survive."

"Would you accept a photographic record?"

She looked at Mrs. Bennett's mother, small and upright beside the leaves.

"No."

It was the first answer she had given without qualification.

The chair took off her glasses.

"Public access creates an ongoing cost. Lighting. Insurance. Cleaning."

"Daytime access," Leila said. "It needn't be open all night."

Mina had wanted to promise that she would clean it. The offer was ready, a familiar way to make herself useful. She kept quiet. Someone would have to be paid after her.

The architect proposed a separately gated residential entrance beyond the passage. The project manager calculated on a pad. Outside, a bus pulled away from the stop; Mina followed it with her eyes until he spoke.

"If the capital cost stays within the revised allowance, we can take on maintenance."

"Not just until the next design change," Mina said.

The chair looked at her, then asked the clerk to amend the transfer conditions.

The mural would be withdrawn from auction and retained on its existing wall within a public passageway. Access would be guaranteed during stated daytime hours. A structural and conservation survey would precede work; any necessary changes would return to the board, not be delegated to the demolition contractor.

The vote carried with one abstention.

Mina remained seated while the clerk entered the resolution. She asked her to read it back.

When she returned, the site manager was checking the service meters. He gave her the clipboard without speaking. She entered the figures, checked the windows and signed the final page.

He signed beneath her.

"Send the photographs," he said. "Especially the edges."

She folded her copy of the handover form and put it in her bag.

Leila helped move the last towels into the collection cage. Without them, pale rectangles showed on the shelves.

"My father's on that wall," she said. "S. Rahman. He ran the alterations shop."

"I know the name."

"He hated his first name. Said nobody here pronounced it properly."

Mina smiled. She had polished those two words for decades and never known that.

At the door Leila asked if she could keep one of the photographs. Mina let her choose.

Then she made her final round.

Under the changing-room benches she found a hairpin and a bus ticket softened by water. In the corner shower she lifted Leila's rubber mat and hung it over the rail to dry, then remembered there was no reason to leave it ready.

She turned each tap shut. The pipes knocked once, and she waited until the sound had travelled through the empty rooms.

At the mural she removed the auction sticker with warm water and her thumbnail. A clean yellow square remained above the fountain. She left the chalk line for the surveyors.

In the kitchen she packed her white mug and her husband's brown one, wrapping them separately in a clean tea towel. Then she emptied the kettle.

Outside, she locked the bathhouse and tested the handle once. She pushed the keys through the agreed letter slot and heard them land inside.
