The basement door had a new hasp screwed into its frame, bright metal against the blistered paint. Ruth tried her master key in the padlock anyway. It would not enter.

Beneath the door, a strip of red fabric lay across the threshold. She crouched and touched it. Woven plastic, with one white flower: Elena’s shopping bag. Ruth had carried it upstairs for her when the elevator stopped last month.

She called Manny Cole.

“Why is there a padlock on the basement?”

“Because we had sewage down there.”

“You didn’t tell me.”

“I’m telling you now. Nobody goes in until it’s cleaned.”

“Elena’s bag is caught under the door.”

“Elena went to her sister’s.” His answer came quickly. “She probably left some junk.”

Sweat ran down Ruth’s back. Behind her, the stairwell fan rattled on its stand, pushing hot air against her calves.

“Her parrot’s loose. It keeps saying something about you. About opening—”

“Listen carefully, Ruth. Those electrical repairs you’ve been doing? No permit, no license. I can report that to the police.”

“You told me to get the lights working.”

“And you decided how. You want people asking questions, that’s your choice.” He paused. “But the apartment comes with the job. Think about Isabel.”

The call ended.

Ruth stood. She climbed two steps, already arranging his explanation into something she could repeat. Sewage. A visit to a sister. Nothing she needed to fix.

How many maintenance sheets had she signed because Manny would not release money for the next repair until the last one was marked complete? Enough to know where her signature would be.

She went back down and switched off the fan. Its blades slowed, then stopped.

Ruth bent toward the door and listened.