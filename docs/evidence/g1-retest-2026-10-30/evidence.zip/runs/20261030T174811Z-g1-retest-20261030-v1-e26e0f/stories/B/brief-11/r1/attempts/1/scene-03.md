No one answered. Mina folded the petition beneath the counter and went to change the laundry.

Between loads she opened the lost-property contact book. Some entries had ticks beside them: spectacles collected, scarf posted, owner deceased. Her husband’s handwriting appeared on a loose slip he had brought her lunch on. She turned it face down.

“This is Mina Okafor, from the baths,” she said when the first person answered. “I’m calling about the tiled mural. Would you be willing to talk about it? You needn’t sign anything.”

Two people declined. One asked whether his swimming trunks were still there.

Mrs. Bennett sent a photograph. Her mother stood beside the newly completed tiles, holding a handbag against her stomach. The names were sharp behind her; at the bottom of the photograph, someone’s thumb obscured a corner.

“She cleaned houses to give that money,” Mrs. Bennett said. “Please keep the photograph safe.”

Mr. D’Souza remembered the collection differently.

“It was for a boiler. We were tired of cold water.”

“Your father’s name is on the wall.”

“Yes. He enjoyed that. I didn’t like names being put up. People who couldn’t pay used the baths too.”

Mina stopped writing, then put down his last sentence.

Leila returned while the sheets were spinning. She held out her phone, displaying a photograph of the housing proposal pinned inside the library.

“Look. That’s the street.”

A narrow passage ran through to a courtyard. Beside it was the thick line of the mural’s existing wall.

Mina enlarged the image. “Does that mean it stays?”

“It means they’ve drawn a passage there.”

Mina fetched the tape measure. She measured width and height twice, then photographed the masonry at each edge, including the places where tile disappeared beneath later plaster.

On the office computer she made two folders: WALL—MEASUREMENTS AND PHOTOGRAPHS; PATRONS—ACCOUNTS AND IMAGES. Mrs. Bennett’s photograph went into the second.

She checked the labels. Then she returned to Mr. D’Souza’s sentence and left it exactly as he had said it.