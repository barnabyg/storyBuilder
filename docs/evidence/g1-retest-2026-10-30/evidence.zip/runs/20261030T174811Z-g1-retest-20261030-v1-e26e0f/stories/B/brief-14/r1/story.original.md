"Observe the ship's figurehead," Nuno Vale told his tourists, pointing upward. Twelve faces tilted obediently. With his other hand he drew a museum leaflet from his jacket pocket.

"And that is why sailors lost their wages ashore. Everyone watches the pointing hand, nobody the pocket beneath it."

The German gentleman laughed and checked his wallet.

"Pure theatre," Nuno assured him. Respectability required these little disclaimers.

Director Seabra interrupted beside the model frigates, clapping twice for attention he evidently considered transferable.

"The finale, please. Imagine the donors here."

A technician stood behind a replica cannon aimed across the gallery. He explained that compressed air would send a cloud of paper ships fluttering over the guests.

"Discovery raining upon generosity," Seabra said.

"Provided generosity wears safety glasses," Nuno murmured.

Beside the cannon stood an open display case containing a tiny brass compass. On the loading table lay a round brass cap scarcely larger.

"Twins," Nuno said, indicating both. "One finds India; the other keeps the wind in."

The technician did not smile. "Paper only inside the barrel. Anything solid becomes a projectile."

He held up the cap, showing its threaded rim, then screwed it onto the rear fitting.

"Let me finish the display," Seabra said, moving between them. "And I'll load the ships. The folds must face the audience."

He shifted the open case closer to the cannon, collected a tray of paper boats, and pulled a red DO NOT FIRE tag from the firing lever.

"It spoils the photographs."

Nuno opened his mouth, but Seabra was already summoning the photographer.

"Onward," Nuno told his tourists. "Portugal awaits."

An event worker caught his eye beyond them. She straightened one cuff while checking every exit.

Bia.

Nuno's respectable smile stayed precisely where it was.

It survived until Seabra appeared beside the ticket desk and said, "A private word. Your group can admire the rope."

"They've paid for maritime history."

"It's historic rope."

In the director's office, Seabra turned a laptop towards him. The security clip showed shoulders crowding the navigation exhibit. Between them, an event worker reached into the display area, withdrew a small brass object and slipped it into her apron.

Nuno knew the wrist before he knew the face.

Bia. Older, naturally; everyone had been inconsiderate enough to get older. But she still tucked her elbow close after a lift, as though sheltering a candle.

"The compass," Seabra said. "Well?"

"The camera angle makes the action difficult to interpret."

"She puts it in her pocket."

"Apron. Angles are particularly unkind to aprons."

Seabra paused the clip. "There will be a reward for its recovery. Five hundred euros. Your tours teach you to read people, I'm told."

"My tours teach people that Henry the Navigator suffered from a misleading job title."

"Then navigate this. I need a name before the donors arrive."

Nuno leaned closer. The image was cropped tightly around the exhibit, cutting off whoever stood to the worker's left. Seabra dragged the playback marker to the beginning. Bia's open palm was already raised towards that missing person.

"Play it again."

As the crowd shifted, the velvet recess became visible. Something round lay where the compass belonged: the cannon's loading cap.

Nuno kept his hands loosely folded.

"Could I see the preceding minute?"

"There is no time for a documentary."

"It might clarify—"

"Bring me a simple culprit, Vale, and I can promise discretion."

Nuno looked at Bia's arrested hand.

"How fortunate," he said, "that simplicity is so inexpensive."

Nuno began with the cloakroom, where information was exchanged more freely than umbrellas.

"The woman from catering?" said the attendant. "Asked for the cannon technician three times. Very persistent. Then out through the service entrance, carrying her jacket."

"Perhaps she dislikes artillery."

"Perhaps she dislikes being told to ask someone else."

Nuno contributed a scandal concerning a tourist's allegedly therapeutic ferret, then went looking for the technician.

He found him kneeling beside a speaker, holding a screwdriver with the exhausted tenderness of a man considering another profession.

"Seabra wanted the microphone fixed," the man said. "Urgently. Apparently donors cannot give unless they hear themselves thanked."

"And the cannon?"

"Only I load it. Only I approve it. That was the arrangement."

"Was?"

The technician glanced towards the gallery. "I haven't approved anything."

Beside the cannon, a floral arrangement had acquired the proportions of an admiral's funeral. Under its lowest fern lay the red warning tag Nuno remembered. He lifted it by its string.

Beneath the printed warning, someone had written: CHECK BARREL.

"Temporary staff," Seabra said behind him, "sometimes become dramatic when corrected."

Nuno turned. "An inexpensive precaution."

"The cannon is to be polished and ready. Not dismantled." Seabra extended his hand for the tag.

Nuno surrendered it. He had already read it twice.

At the catering desk, he explained that a tourist had lost something and that the woman who had left earlier might have picked it up. A supervisor supplied Bia's company number.

Outside, beneath a stone navigator pointing confidently away from the trouble, Nuno typed an old phrase:

Coffee, no saucer.

Once, it had meant he wanted a conversation, not a share.

He added his name. Respectability had made him cautious; it had not made him memorable to everyone.

Bia was at the café opposite the museum, stirring an espresso that had surrendered some time ago.

"Senhora," Nuno said, "you resemble an old acquaintance."

"How unfortunate for her. You resemble a man who once stole a policeman's watch while asking the time."

"A common face. May I sit?"

"If you're selling a walking tour, I live here."

He sat. She wore black catering trousers and shoes with sensible soles. He remembered shoes chosen chiefly for speed.

"I do events now," she said. "Legitimate shifts. Bad pay, declared income. Sometimes both."

"And today?"

"I saw a dangerous mistake. I tried to tell Seabra. He told me the gala was under control."

"So you took the compass."

"Yes. I went back to explain, but he was announcing a theft. Then everyone had to remain available for questioning. Available, apparently, means frightened and unpaid."

She slid her phone across the table. In the photograph, the tiny brass compass lay wrapped in a catering napkin beside the red warning tag.

"Taken before he announced anything," she said. "Check the time."

Nuno enlarged the image, then checked the timestamp. He had hoped for an explanation he could carry back in one pocket. This needed both hands.

"Trust me with it."

Bia reclaimed her phone.

"Your new life looks comfortable. Does it depend on pretending people like me never existed?"

"Bia—"

"You tell tourists stories. Is that where we went? Edited out between the earthquake and lunch?"

Outside, a guide raised a yellow umbrella. Nuno watched strangers gather beneath it.

"I won't purchase my own innocence with your name," he said.

She studied him.

"Get the complete security recording. Not Seabra's little performance."

"And then?"

"I'll come back with the compass."

Seabra was supervising the alignment of champagne glasses when Nuno returned.

"I can recover the compass," Nuno said. "But I won't identify anyone until the complete recording is preserved."

"The relevant extract is preserved."

"Then the irrelevant parts should be easy."

Seabra lowered his voice. "I could tell the police how unusually knowledgeable my guide appears to be."

Nuno felt his respectable life contract to the width of a handcuff. Behind Seabra, the gala coordinator arrived carrying a clipboard and three expressions of distress.

He let her come within earshot.

"Has the cannon received its required safety check?" he asked the technician.

The technician stopped coiling a cable.

"What safety check?" said the coordinator.

"The compressed-air display," Nuno said. "Before we fire paper ships over our principal benefactors."

"It isn't a weapon," Seabra said.

"Excellent. Let's establish that while nobody is standing in front of it."

The coordinator put down her clipboard.

Seabra looked at her, then at the technician. "Isolate the air supply. Briefly."

"And I'll fetch the complete recording," she said.

The technician shut the valve and disconnected the hose. Preparations stopped around him, reluctantly, like traffic encountering a fallen wardrobe.

At the monitor, the full recording began several minutes before the familiar clip.

Seabra appeared beside the cannon. He removed its loading cap and set it in the velvet recess. Turning back, he picked up the similarly sized brass compass instead. He dropped it through the loading hatch, then poured in the paper ships.

Nobody spoke.

Bia entered the frame. She raised a hand. Seabra waved her away without turning.

She waited until he moved, reached through the still-open hatch, extracted the compass and attached the warning tag.

The coordinator checked the cropped clip's boundaries.

Both Seabra's mistake and Bia's warning fell outside them.

Bia arrived carrying the compass in a paper bag.

Seabra reached for it. She put it on the technician's table instead.

"All this," the director said, "for something that would only have made a little noise. Removing it was unnecessary."

The technician held up the disconnected air hose, then selected a wooden disk the same diameter as the compass.

"Without pressure," he said.

He slid the disk into the barrel and lowered a measuring rod through the loading slot. Its tip indicated the line of fire: straight across the room, ending at the donors' front row.

"The disk is harmless like this. Brass, with the air connected, would not be." He tapped the safety sheet already clipped to the cannon's stand. "No solid loads. It's explicit."

Seabra inspected his cuffs.

Nuno waited until he stopped.

"You mixed up the compass and the demonstration piece. Bia removed what you'd made into a projectile. Then your theft story concealed the mistake and let you carry on preparing the same unsafe finale."

"I can pay the reward," Seabra said. "If we agree this was a misunderstanding."

"No reward. A signed withdrawal of the theft allegation. Payment for Bia's interrupted shift. And a public safety correction that names no temporary worker."

"That sounds unnecessarily formal."

"So did the allegation."

The gala coordinator stood beside the closed entrance, holding her guest list.

"I'm not admitting anyone until this is settled."

On the security monitor, the preserved footage waited at the moment before the camera's convenient version began.

Seabra looked from it to the coordinator.

"Bring me something to sign."

By six, the cannon was behind a locked door. In its place, volunteers folded paper ships for distribution by hand.

"Before we begin," Seabra told the donors, gripping the lectern, "a member of our event staff prevented an unsafe loading error during preparations. Responsibility for that error is mine."

He paused. Nobody supplied the applause he appeared to have budgeted for.

"Our compass has also been recovered."

He removed its cloth with the enthusiasm of a waiter revealing a disputed bill.

Nuno stepped forward before the silence became a permanent exhibit.

"We had intended to finish with a cannon," he said. "Instead, you will have a story. It is quieter, though I cannot promise shorter."

A donor laughed cautiously.

Nuno told them about navigation: how a captain could possess excellent charts, polished boots and the absolute confidence of everyone aboard, and still be steering towards a rock.

"Respectable institutions are rather like ships," he said. "Occasionally they need someone to tell them they are pointing the wrong way. Preferably before the champagne."

This time the laughter came freely. Near the doors, Bia handed a paper ship to a woman wearing enough pearls to ballast it.

"You've become alarmingly honest," she told him afterwards.

"I still made a director surrender money without touching his pockets."

The museum paid the promised recovery reward before the caterers finished clearing. Nuno counted the notes beneath the cloakroom lamp and passed half to Bia.

"Compensation," he said, "for an evening spent preventing a theft that never happened."

She counted her share again. He found this reassuring.

On his next tour, Nuno stopped beside the compass.

"This instrument once saved a roomful of important people without moving its needle."

A tourist bent towards the official label.

"Was that really what happened?"

"For once," Nuno said, "you needn't take only my word for it."
