The breaker held on Ruth's second try. Above her, the stairwell bulbs brightened, and a chorus of window units started with a sound like trucks pulling away.

"Unplug what you can," she told the tenants on the stairs. "Not just switch it off."

"The fridge?" Mr. Vega asked.

"Leave the fridge."

It was the fourth day above a hundred degrees. Apartment doors stood open, offering views people usually kept to themselves: a man sleeping in his underwear, dishes stacked in a bathtub, a kitchen table pushed aside to make room for another bed.

The electrical panel smelled like hot pennies. Ruth closed its cover without touching the blister in the paint.

"Mom."

Isabel stood on the bottom step with a green parrot gripping her forearm.

"Don't put him near your face."

"He climbed on me. He was on the basement railing."

The bird belonged to Elena in 3B. Usually he rode her shoulder to the laundry room, where she still went to exchange paperbacks although Manny had disconnected the machines in April.

Ruth offered him the rubber handle of her screwdriver. He stepped across.

"Manny," he said. "Open the door."

Isabel smiled. Then the bird said, in a thinner voice, "Please. I can't breathe."

Ruth stopped holding out her other hand.

The bird bent and scraped his beak along the screwdriver.

"Where's Elena?" Isabel asked.

Ruth looked down the basement steps.

"Let's take him home."

At 3B, a grocery circular held the door open an inch. Elena's phone lay charging beside a bowl of cut peaches. The cage stood open.

Ruth called her name, checked the bathroom, then shut the bird into his cage.

"Go to Mrs. Shah," she told Isabel.

"Is she downstairs?"

"I'm going to check."

"Take your phone."

Ruth had left it charging in their apartment. Isabel went to fetch it before Ruth could answer.

The basement door had a new hasp. Bright screws bit into the old brown frame, and a padlock hung where Ruth's master key used to turn.

She knocked.

"Elena?"

Something scraped inside.

Ruth called Manny.

"Why's there a padlock on the basement?"

"Sewage. I've got somebody coming."

"Is Elena down there?"

"She went out."

"Her bird was loose. Her phone's upstairs."

"Then she forgot them."

Ruth crouched. A strip of red plastic protruded beneath the door, printed with half a white flower. Elena brought that shopping bag to the food pantry every Thursday.

"There's something caught under the door."

"Leave it alone."

"Come open it."

A pause. She could hear his car indicator.

"You want the city looking at your electrical work, Ruth? Your name's on those inspection sheets."

"You told me the electrician had finished."

"And you signed. Remember that before you start calling people."

He hung up.

Isabel was behind her, holding out the phone charger as well as the phone.

"Mrs. Shah's making room in her freezer for our chicken."

"Go back to her."

"Mom."

"Please."

After Isabel left, Ruth climbed two steps. She could call Elena's sister. Someone would have her number. There might be an explanation that didn't cost Ruth her job.

Their apartment came with the job. Isabel's height was penciled on its kitchen jamb, seven marks above a chipped tile Ruth had never replaced. The last apartment Ruth had priced would have taken almost all her pay.

Behind her came the scrape again.

She switched off the stairwell fan and struck the door three times with her wrench.

Two knocks answered.

"Elena?"

"Ruth."

She called emergency services.

The dispatcher took the address and asked whether Elena was breathing.

"Yes. But it's hot down there. There aren't any windows."

Crews were responding to heat emergencies across the district. Help was coming. Ruth was told not to enter an unsafe space.

She put the phone on speaker and knelt.

"How long have you been inside?"

"Since before lunch."

It was almost four.

"Are you hurt?"

"Dizzy."

"Stay low."

"I am low."

Ruth closed her eyes for a moment.

When the call ended, she started a video, showing the lock and the strip of bag.

"Elena, what happened?"

"Manny said come see. He'd fixed the air."

"For the rooms?"

"Yes."

Ruth kept the camera steady.

There had been beds below since winter. Temporary accommodation for the renovation crew, Manny had said. She had posted notices about blocked access to the drain, then stopped when he told her the men weren't tenants and weren't her concern.

"I brought Tito," Elena said. "He flew when Manny shouted. I thought he went upstairs."

"What was Manny shouting about?"

"My pictures. He wanted my phone."

"It's in your kitchen."

"I told him. He said I could stay till I remembered where I put it."

Ruth heard herself breathe on the recording.

"Did he know you were still down there?"

"I was holding the bag in the door."

Ruth looked at the red strip.

From above came a child complaining that the lift wouldn't work. They hadn't had a working lift for three years.

"I've called the fire department," Ruth said.

"Manny said you wouldn't."

Ruth stopped the recording and sent it to Mrs. Shah. Then she wrote: Keep Isabel with you. Don't let Manny take her anywhere.

She fetched a pry bar and her drill from the cupboard beside the panel.

The screw heads in the hasp were already burred. Whoever fitted it had used the wrong bit. Ruth tried the least damaged one, bearing her weight against the drill. It turned half a revolution and jammed.

"Elena, move away from the door."

"I can't get up."

"Slide backward. Just a little."

A soft dragging, then a cough.

The street door slammed.

Manny came down with a ring of keys. His shirt was dark beneath the arms.

"Put that away."

"Open it."

"You called the fire department?"

"Open the door."

He looked at her phone propped against the opposite wall.

"She's been interfering with work. Going through people's things."

"Tell them when they get here."

"You think they'll only ask me questions?"

He moved closer. Ruth could smell the mint he chewed to cover cigarettes.

"Emergency lights. Ventilation. Wiring. Seven years of your signatures."

She had learned to call a leak a stain until she knew which answer he wanted. After the first form she signed, he sent the others with yellow tabs showing her where.

"I'll tell them," she said.

His expression changed, but only slightly.

"Give me the drill."

He caught her wrist when she reached for it.

For a second she stayed still. She had settled hundreds of arguments in this stairwell. Keep your voice down. Let's not do this in front of everybody.

"Mrs. Shah!" she shouted.

Manny let go.

Mrs. Shah appeared on the landing with Mr. Vega behind her. A woman from the fourth floor held up a phone.

"What's happening?" Mr. Vega asked.

"Elena's locked downstairs," Ruth said. "He won't open it."

"I don't have that key," Manny said.

"Then why did you come?" Mrs. Shah asked.

From behind the door came a faint, unmistakable "Please."

Manny looked up at the phones.

"I'm getting the contractor."

He went upstairs. Ruth listened until the street door shut.

"Isabel?"

"With my husband," Mrs. Shah said.

Ruth picked up the drill.

"Film the lock before we break anything," she told the woman.

"Naila," the woman said. "My name's Naila."

Ruth had fixed her kitchen tap twice.

"Naila. Thank you."

One screw came out. The next spun uselessly in rotten wood. Ruth pushed the pry bar beneath the plate.

"I signed reports saying things were repaired," she said. "Some of them weren't."

Mr. Vega took the bar to give her room to work.

"You can tell that to the fire people," he said.

"They may shut the whole building."

He looked toward the basement door.

"Give me the hammer."

They lifted one edge of the hasp. Fresh wood split around an inner screw.

"Elena?"

No answer.

Ruth lay on her side and shone her phone beneath the door. A shoe. Red plastic. Beyond that, darkness.

Mrs. Shah brought water. Ruth crushed the middle of the bottle and forced it into the gap, but the neck wouldn't pass.

The lights dimmed.

From the panel came a dry crackle.

"Everybody upstairs."

Mr. Vega kept hold of the bar.

"Ruth, we nearly—"

"Get them outside. Use the front stairs. Don't touch the lift gate."

A thread of gray rose from the panel cover.

She called the dispatcher again, saying smoke, saying the woman wasn't answering. Then she opened the outer cover and pulled the main disconnect, keeping clear of the branch breakers.

The building stopped around her.

In the silence a baby began to cry.

"Go," she told Naila.

Naila backed upward, filming until the darkness swallowed her.

Ruth's phone light lay across the broken trim. She had turned off the last fan Elena might have had. She knew why she had done it, but she couldn't leave her sitting behind that door.

She put the pry bar back into the gap.

"Elena. I'm still here."

Her palms slipped. She wiped them on her trousers, set one foot against the frame and pulled.

The wood cracked sharply. The hasp came away on a splintered tongue of trim.

The door opened two inches and struck something soft.

Ruth stopped.

"Elena, can you move your foot?"

Nothing.

Boots sounded in the lobby. Ruth shouted before anyone called her name.

A firefighter came down carrying a light. She showed him where the door caught.

"Person directly behind it. I've switched off the main."

He took her place. Another firefighter led her up three steps while his partner eased through the opening.

Their lights found plywood partitions beneath the pipes. Numbered doors. An extension cord fixed along a beam with bent nails. Through one doorway Ruth saw a mattress and work boots standing neatly on newspaper.

Then Elena was coming out.

Her head rested against a firefighter's shoulder. The broken shopping bag trailed from one wrist.

"Anyone else inside?" he asked her.

"Working," she whispered. "They go early."

Outside, the heat felt almost cool.

A paramedic laid cold packs against Elena's neck. Ruth stood where Elena could see her.

"Tito?"

"In his cage."

"The pictures. Show them."

"I will."

Elena caught her hand with surprising strength.

"I wasn't stealing."

"I know."

Manny stood beside the entrance talking to a police officer. Someone had given him bottled water.

Ruth approached with her phone.

"I found her. The door was padlocked outside."

Manny turned.

"She manages basement access. Ask about the inspections."

"I signed them," Ruth said.

The officer looked from one to the other.

"One at a time."

With Mrs. Shah beside her, Ruth went to 3B. She took Elena's charging phone downstairs for the investigator rather than trying to unlock it. Then she sent him her video and Naila's number.

Her own recording had caught Elena's account clearly. Manny's voice from later, after Ruth had put the phone in her pocket, came through in scraps: signatures, give me, cloth rubbing against the microphone.

She wrote down the rest, including the yellow tabs. Before she could soften anything, she sent it.

By dusk, people sat along the pavement with shopping bags of thawing food. Two men who slept in the basement had returned from work. One kept asking a firefighter whether he could retrieve his passport.

Ruth's phone lit up.

Employment terminated effective immediately. Return all building keys. We will address your occupancy tomorrow.

She read it twice, then forwarded it to the investigator. A small check mark appeared beside the message. Nothing followed.

Isabel sat beside her on the front step, Tito's covered cage between her shoes. Mrs. Shah had offered them her sofa. Ruth had thanked her without saying yes.

"Are we moving?" Isabel asked.

"I don't know yet."

Across the pavement, Manny put his phone away and watched them.

From beneath the cover, Tito made the squeak of Elena's kitchen cupboard. Isabel slipped one finger between the bars.

Ruth's phone rang. The investigator.

She answered, keeping the building keys in her other fist.
