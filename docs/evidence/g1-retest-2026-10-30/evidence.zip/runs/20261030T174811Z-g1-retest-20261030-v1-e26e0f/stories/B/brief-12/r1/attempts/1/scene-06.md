The lights went out while Ruth was pulling against the cutter handles. The shackle held. Somewhere above her, a child began to cry.

“Keep the light here.”

Mrs. Ahmed’s phone beam shook across Ruth’s wrists, then steadied on the bite she had made in the metal. Ruth reset the jaws. Sweat ran into her eyes. Without the fans and window units, she could hear people breathing on the stairs.

From the entrance came the tenant’s shout: “Down here! She’s down here!”

Boots struck the steps. Ruth let herself be moved aside, though her hands kept the shape of the handles. A firefighter asked everyone to back up. Another knelt at the damaged lock. Metal snapped; the door still resisted. They drove a tool between the frame and the wood, and the frame split with a noise that made Ruth flinch.

Their lights swept narrow plywood corridors. Padlocked doors had been fitted into partitions that reached almost to the pipes overhead. Each compartment held mattresses, cartons, furniture: rooms Manny had called storage, built without permits, without any way out except this door.

Elena lay just inside, one arm around a shopping bag.

The firefighters called to her and knelt. Ruth backed against the wall as more equipment passed her.

On the stairs, Elena’s fingers caught hers over the edge of the carry sheet.

“My photographs,” she whispered. “Phone charging. Three B.”

Then her grip loosened, and Ruth had to let go.

She followed them into the street. The tenants stood along the pavement, watching Elena come out into the ambulance lights.

Ruth turned to the firefighter beside her.

“That basement door was locked from outside,” she said. “My name is Ruth Delgado. I saw it.”