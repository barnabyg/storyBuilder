Ruth held the breaker off for ten seconds, then pushed it back. The hallway lights came on above the tenants crowded along the stairs, where an open roof door offered the promise of air.

"Unplug something," she told them. "Anything you can spare."

Nobody moved. Upstairs, a baby cried.

The panel smelled of hot pennies. A brown scorch spread above the breaker for the second-floor hall, darker than yesterday. Ruth kept her fingers away from it. With every window unit working against the hundred-degree heat, she doubted the building would make it through another afternoon.

"Mom."

Isabel stood below her with a green parrot gripping her forearm. Her daughter was twelve and trying not to look frightened by its hooked beak.

"Found him on the basement landing."

"Don't hold him against your face." Ruth offered the bird her screwdriver handle. It stepped onto the rubber grip, revealing the yellow patch at its neck. "That's Elena's. From 3B."

The parrot cocked its head.

"Manny, open the basement. I can't breathe."

Ruth looked at Isabel.

It was Elena's voice, almost: the same low pitch, the little catch before breathe. Elena who brought Ruth coffee when the laundry drains backed up, who always apologized before asking for anything.

"Did he say that downstairs?"

Isabel nodded.

At 3B, Ruth knocked twice. The door shifted under her knuckles.

"Elena?"

Inside, the curtains were drawn against the sun. Elena's phone lay charging beside a half-filled water glass. Ruth called her name again, then backed into the hall.

"Go to Mrs. Shah's. Stay there until I come."

"What about you?"

"Give her the bird."

Ruth watched Isabel enter Mrs. Shah's apartment before she turned toward the basement stairs.

The basement door had a new hasp screwed into its frame, bright metal against the blistered paint. Ruth tried her master key in the padlock anyway. It would not enter.

Beneath the door, a strip of red fabric lay across the threshold. She crouched and touched it. Woven plastic, with one white flower: Elena's shopping bag. Ruth had carried it upstairs for her when the elevator stopped last month.

She called Manny Cole.

"Why is there a padlock on the basement?"

"Because we had sewage down there."

"You didn't tell me."

"I'm telling you now. Nobody goes in until it's cleaned."

"Elena's bag is caught under the door."

"Elena went to her sister's." His answer came quickly. "She probably left some junk."

Sweat ran down Ruth's back. Behind her, the stairwell fan rattled on its stand, pushing hot air against her calves.

"Her parrot's loose. It keeps saying something about you. About opening—"

"Listen carefully, Ruth. Those electrical repairs you've been doing? No permit, no license. I can report that to the police."

"You told me to get the lights working."

"And you decided how. You want people asking questions, that's your choice." He paused. "But the apartment comes with the job. Think about Isabel."

The call ended.

Ruth stood. She climbed two steps, already arranging his explanation into something she could repeat. Sewage. A visit to a sister. Nothing she needed to fix.

How many maintenance sheets had she signed because Manny would not release money for the next repair until the last one was marked complete? Enough to know where her signature would be.

She went back down and switched off the fan. Its blades slowed, then stopped.

Ruth bent toward the door and listened.

She struck the door three times with her wrench, spacing the blows so they could not be mistaken for work.

For a moment there was only the hum of the stairwell light.

Then two blows came back. The second barely reached her.

Ruth pulled out her phone and called emergency services before she could make herself listen again.

"Someone's locked in our basement," she said, giving the address. "It's dangerously hot down here. The electricity keeps dipping, and we've got wiring that can't carry the load."

The dispatcher asked whether the person was conscious.

"They answered me. Please send the fire department."

"Units are responding to multiple heat-related emergencies. There may be a delay. Do not enter an unsafe space yourself. Stay where you can direct responders."

Ruth looked at the new padlock. "I'm outside the door."

She ended the call only when instructed, then crouched near the gap above the threshold.

"Help is coming. Who's there?"

"Elena."

Ruth knew the voice from the third floor, though now it sounded scraped thin.

"Manny locked it," Elena said. "I took pictures. The wires down here. He wanted my phone."

"How long have you been inside?"

"I don't know. The little fan stopped."

Ruth held her hand against the gap. Nothing moved against her fingers.

"I'm going to record you," she said. "Tell me again."

She started a video, keeping the new lock in frame while Elena repeated herself. For years Ruth had kept complaints out of writing, calling Manny instead, giving him time to put things right. Now she checked that the recording had saved.

Then she texted Mrs. Shah: Keep Isabel upstairs with you. Lock the apartment door. Don't open it for Manny, whatever he says.

The street door banged upstairs. Ruth slid her phone into her shirt pocket, microphone exposed.

Manny came down with his keys in his fist. He stopped two steps above her, his face wet with sweat.

"Move away from there."

"Elena's inside."

"Elena gets confused."

"Then open it."

He glanced at the basement door but made no move toward it. "You've turned a maintenance dispute into an emergency. What did you tell them when you called?"

Ruth pressed her pocket once, checking that the phone hadn't tipped forward. "Give me the padlock key."

"That lock belongs to the contractor."

"You own the building."

"I don't carry everybody's keys."

The keys clicked as he closed his hand.

From behind the door came a small scraping sound. Manny talked over it.

"You need to think about what happens next."

He took out his phone and held up a photograph of a work sheet. Ruth recognized the boxes before she saw her signature: emergency lighting, basement ventilation, corridor wiring. He swiped to another.

"You signed these."

"You said the electrician was coming."

"But you signed that the work was completed." His voice softened. "Someone investigates, they'll ask you. Not just me. You've got your apartment here. Your daughter."

She had signed so the inspection would pass, so the fines wouldn't become another rent increase. That was what she had told herself.

She stepped past him toward the stairs.

"Where are you going?"

"To meet the responders."

His hand closed around her wrist. For a moment she stood still, obeying the old instinct to keep a hallway argument from becoming everyone's business.

Then she twisted free.

"Mrs. Shah!" she shouted up the stairwell. "Mrs. Shah, I need you to hear this!"

Mrs. Shah appeared on the landing with Mr. Vega and the woman from 3B, whose name Ruth had never learned.

"Isabel's in my apartment," Mrs. Shah said. "Door locked."

Manny's fingers loosened on Ruth's arm. He looked at the three faces above him, then released her.

"You're making this something it isn't." He backed toward the lobby, pulling out his phone. "All of you."

Ruth waited until he was beyond the stairwell door.

"I signed maintenance records for work he never did," she said. "Inspections, repairs. I signed them."

Mr. Vega looked at her.

"I'll answer for that. Right now there's a woman behind this door. Elena." She pointed to the woman from 3B. "Please film. The lock, the hinges, everything." Then to Mrs. Shah: "Wait outside for the fire crew. Bring them straight here."

From her tool cupboard Ruth fetched the hacksaw. She braced the blade against the exposed curve of the padlock shackle. Each stroke scraped through the stairwell. Sweat ran into her eyes.

Mr. Vega took over when her hand cramped.

The woman filming offered her water bottle. Ruth drank a mouthful, squeezed the bottle nearly flat, and pushed it through the gap beneath the door.

"Elena. Water. Just by your hand."

Something dragged across the floor inside, then stopped.

"I can't," Elena whispered.

The stairwell lights dimmed. A sharp, burning smell rose from the electrical panel beside the tool cupboard.

"Elena?"

No answer.

Ruth pulled Mr. Vega back by his shirt.

"Upstairs. Away from that cupboard. Both of you."

She lifted her phone.

"The lights are dimming," she told the dispatcher. "There's a burning smell at the panel. The woman inside isn't answering now. Please tell the crew."

The lights went out while Ruth was pulling against the cutter handles. The shackle held. Somewhere above her, a child began to cry.

"Keep the light here."

Mrs. Ahmed's phone beam shook across Ruth's wrists, then steadied on the bite she had made in the metal. Ruth reset the jaws. Sweat ran into her eyes. Without the fans and window units, she could hear people breathing on the stairs.

From the entrance came the tenant's shout: "Down here! She's down here!"

Boots struck the steps. Ruth let herself be moved aside, though her hands kept the shape of the handles. A firefighter asked everyone to back up. Another knelt at the damaged lock. Metal snapped; the door still resisted. They drove a tool between the frame and the wood, and the frame split with a noise that made Ruth flinch.

Their lights swept narrow plywood corridors. Padlocked doors had been fitted into partitions that reached almost to the pipes overhead. Each compartment held mattresses, cartons, furniture: rooms Manny had called storage, built without permits, without any way out except this door.

Elena lay just inside, one arm around a shopping bag.

The firefighters called to her and knelt. Ruth backed against the wall as more equipment passed her.

On the stairs, Elena's fingers caught hers over the edge of the carry sheet.

"My photographs," she whispered. "Phone charging. Three B."

Then her grip loosened, and Ruth had to let go.

She followed them into the street. The tenants stood along the pavement, watching Elena come out into the ambulance lights.

Ruth turned to the firefighter beside her.

"That basement door was locked from outside," she said. "My name is Ruth Delgado. I saw it."

In the ambulance, a paramedic laid cold packs beneath Elena's arms. Ruth waited until Elena looked at her.

"Your phone. Can I get it?"

"Behind the flour tin," Elena whispered. "Kitchen shelf. You can show them."

Mrs. Shah went upstairs with Ruth and watched her retrieve it. The photographs showed bare copper at a junction box, a scorched breaker, ventilation grilles packed with insulation. Elena had photographed dates and labels. But there was no picture of Manny at the door, no hand turning a key.

Ruth sent copies to the investigator whose card was damp in her pocket, then to Mrs. Shah. She added her recordings and photographs of the maintenance sheets.

Under them she typed: I signed the inspection entries marked R.D. I did not inspect the work. Manny told me it had been completed. I signed anyway.

She read it once before pressing send.

Outside, Manny stood beside the investigator.

"She had the keys," he said. "Basement access was her responsibility. So was reporting electrical faults. Ask her how long she let things go."

Ruth stopped within hearing. Manny glanced at her and continued speaking.

Ten minutes later, her phone lit up.

Employment terminated effective immediately. Return all building keys tonight.

At dusk, Ruth sat with Isabel in the hall outside their dark apartment. Mrs. Shah brought water. Someone from the fourth floor brought chargers and a battery pack; someone else offered a spare room without looking directly at Ruth.

Isabel leaned against her, holding the warm bottle between her knees.

From Elena's covered cage beside them, the parrot said, "I can't breathe."

Ruth's screen showed the investigator's unanswered request to call back. She left it visible beside Manny's message, the keys still heavy in her pocket.
